/**
 * Il Widget Allerta della Protezione Civile FVG blocca l'accesso
 * automatico (robots.txt), quindi non va scrapato: va richiesto/
 * generato manualmente su protezionecivile.fvg.it e incollato qui
 * come da istruzioni ufficiali (di solito un <iframe> o uno snippet
 * <script>). Vedi README, sezione Fase 1.
 *
 * Finché non è stato ottenuto, mostriamo un placeholder invece di
 * un iframe rotto.
 */
export function AllertaWidgetSlot() {
  const CODICE_WIDGET_INSERITO = false; // metti true dopo aver incollato lo snippet sotto

  if (!CODICE_WIDGET_INSERITO) {
    return (
      <div className="border border-line rounded p-3 text-xs font-mono text-ink-faint">
        Widget ufficiale Protezione Civile FVG non ancora collegato — vedi README, sezione
        Fase 1, per richiederlo e incollarlo qui.
      </div>
    );
  }

  return (
    <div>
      {/* Incolla qui lo snippet ufficiale ricevuto da protezionecivile.fvg.it,
          es.:
          <iframe src="..." width="100%" height="..." frameBorder="0" />
      */}
    </div>
  );
}
