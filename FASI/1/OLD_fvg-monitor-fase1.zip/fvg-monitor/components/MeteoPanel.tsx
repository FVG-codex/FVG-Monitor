"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { ZoneChip } from "@/components/ZoneChip";

type CittaKey = "trieste" | "udine" | "gorizia" | "pordenone";

const ZONA_PER_CITTA: Record<CittaKey, "A" | "B" | "C" | "D"> = {
  // mappatura provvisoria sulle 4 zone di allerta ufficiali — da
  // verificare/correggere quando integreremo i dati reali della
  // Protezione Civile in Fase 2 (per ora Trieste=zona costiera C
  // è l'unica confermata dal mockup, le altre sono indicative)
  trieste: "C",
  gorizia: "C",
  udine: "B",
  pordenone: "A",
};

const NOMI_CITTA: Record<CittaKey, string> = {
  trieste: "Trieste",
  udine: "Udine",
  gorizia: "Gorizia",
  pordenone: "Pordenone",
};

type Scadenza = {
  giorno: string;
  data_validita: string;
  regione_testo: string | null;
  per_citta: Record<CittaKey, { cielo: string | null; pioggia: string | null; temporale: string | null; tmin: string | null; tmax: string | null }>;
};

type MeteoData = {
  bollettino_emesso: string;
  situazione_generale: string;
  tendenza: string;
  scadenze: Scadenza[];
  osservazioni_data: string | null;
  ieri: Record<string, { tmin: string | null; tmax: string | null }>;
};

export function MeteoPanel({ cittaSelezionata }: { cittaSelezionata: CittaKey | "regione" }) {
  const [dati, setDati] = useState<MeteoData | null>(null);
  const [stato, setStato] = useState<"loading" | "ready" | "error">("loading");

  useEffect(() => {
    let attivo = true;
    async function carica() {
      const { data, error } = await supabase
        .from("snapshots")
        .select("data, updated_at")
        .eq("id", "meteo:previsioni")
        .single();
      if (!attivo) return;
      if (error || !data) {
        setStato("error");
        return;
      }
      setDati(data.data as MeteoData);
      setStato("ready");
    }
    carica();
    // ricontrolla ogni 5 minuti mentre la pagina resta aperta
    const id = setInterval(carica, 5 * 60 * 1000);
    return () => {
      attivo = false;
      clearInterval(id);
    };
  }, []);

  if (stato === "loading") {
    return <p className="text-ink-faint text-sm font-mono">Caricamento previsioni…</p>;
  }
  if (stato === "error" || !dati) {
    return (
      <p className="text-ink-faint text-sm font-mono">
        Previsioni non disponibili al momento — il bollettino OSMER viene aggiornato circa una
        volta al giorno, riprova più tardi.
      </p>
    );
  }

  const domani = dati.scadenze.find((s) => s.giorno === "DOMANI");
  const cittaKeys = Object.keys(NOMI_CITTA) as CittaKey[];
  const daMostrare = cittaSelezionata === "regione" ? cittaKeys : [cittaSelezionata];

  return (
    <div>
      {/* Nessuna temperatura "adesso": i dati OSMER real-time non sono
          ripubblicabili prima di 24h. Il widget ufficiale ARPA (via
          widget.meteo.fvg.it) andrà qui una volta ottenuto il codice
          via email — vedi README, sezione Fase 1. */}
      <div className="border border-line rounded p-3 mb-4 text-xs font-mono text-ink-faint">
        Condizioni in tempo reale: in attesa del widget ufficiale ARPA FVG (richiesta manuale
        via widget.meteo.fvg.it — vedi README)
      </div>

      <p className="font-serif italic text-ink-dim text-sm mb-4">{dati.situazione_generale}</p>

      {domani && (
        <div className="space-y-3 mb-4">
          <div className="font-cond font-semibold text-xs uppercase tracking-wide text-ink-faint">
            Domani ({domani.data_validita})
          </div>
          {daMostrare.map((citta) => {
            const c = domani.per_citta[citta];
            if (!c) return null;
            return (
              <div key={citta} className="flex items-center gap-3 text-sm border-t border-line pt-2">
                <span className="font-cond font-semibold min-w-[90px] flex items-center gap-1.5">
                  {NOMI_CITTA[citta]} <ZoneChip zone={ZONA_PER_CITTA[citta]} />
                </span>
                <span className="text-ink-dim flex-1">
                  {c.cielo}
                  {c.temporale && `, ${c.temporale}`}
                  {c.tmin && c.tmax && (
                    <span className="font-mono text-ink-faint ml-2">
                      {c.tmin}–{c.tmax}°C
                    </span>
                  )}
                </span>
              </div>
            );
          })}
        </div>
      )}

      <p className="text-ink-faint text-xs font-mono border-t border-line pt-3">
        Bollettino emesso il {dati.bollettino_emesso} — fonte:{" "}
        <a href="https://www.meteo.fvg.it" className="text-cool">
          OSMER ARPA FVG
        </a>
      </p>
    </div>
  );
}
