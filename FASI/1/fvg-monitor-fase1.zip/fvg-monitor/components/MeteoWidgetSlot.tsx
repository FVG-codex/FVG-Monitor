import { HtmlEmbed } from "@/components/HtmlEmbed";
import type { ProvinciaSlug } from "@/lib/province";

/**
 * Widget ufficiale ARPA FVG (condizioni meteo in tempo reale), uno per
 * provincia. Vanno richiesti singolarmente su widget.meteo.fvg.it
 * indicando la località (Trieste / Udine / Gorizia / Pordenone) — vedi
 * README, sezione Fase 1.
 *
 * Incolla ogni snippet ricevuto via email nella entry corrispondente
 * qui sotto (sostituendo `null`). Le città non ancora configurate
 * mostrano automaticamente un placeholder, senza toccare le altre.
 */
const SNIPPET_PER_CITTA: Record<ProvinciaSlug, string | null> = {
  trieste: null,
  udine: null,
  gorizia: null,
  pordenone: null,
};

export function MeteoWidgetSlot({ slug, cittaNome }: { slug: ProvinciaSlug; cittaNome: string }) {
  const snippet = SNIPPET_PER_CITTA[slug];

  if (!snippet) {
    return (
      <div className="border border-line rounded p-3 text-xs font-mono text-ink-faint">
        Widget ufficiale ARPA FVG per {cittaNome} non ancora collegato — richiedilo su
        widget.meteo.fvg.it indicando questa località, poi incolla lo snippet ricevuto in
        components/MeteoWidgetSlot.tsx.
      </div>
    );
  }

  return <HtmlEmbed html={snippet} />;
}
