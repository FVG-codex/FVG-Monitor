// Job di ingestione "leggera" (Fase 1): fonti API/RSS dirette, nessun
// browser headless necessario. Gira su GitHub Actions ogni 15 minuti
// (vedi .github/workflows/ingest-light.yml).
//
// Richiede due variabili d'ambiente (impostate come GitHub Secrets):
//   SUPABASE_URL
//   SUPABASE_SERVICE_ROLE_KEY   ← NON la chiave anon: questa bypassa RLS
//                                  ed è l'unica autorizzata a scrivere.
//
// Facoltativa (solo per il modulo "Colonnine elettriche", 03/10/2026):
//   OPENCHARGEMAP_API_KEY   ← chiave personale gratuita registrata
//                              dall'utente su openchargemap.org. Se manca,
//                              quel solo modulo si salta con un avviso —
//                              non fa fallire l'intera esecuzione.

import { createClient } from "@supabase/supabase-js";
import { XMLParser } from "fast-xml-parser";
import * as cheerio from "cheerio";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  console.error("Mancano SUPABASE_URL o SUPABASE_SERVICE_ROLE_KEY nell'ambiente.");
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

// Le fonti esterne a volte hanno timeout transitori (visto con
// dati.friuliveneziagiulia.it: ETIMEDOUT). Un solo tentativo fallito
// non deve far cadere l'intero job — 2 retry con una breve pausa,
// usato per tutte le chiamate di rete dello script.
//
// TIMEOUT_MS_DEFAULT (aggiunto il 26/08/2026): senza un timeout
// esplicito, il fetch nativo di Node aspetta diversi minuti prima di
// arrendersi da solo su un server che accetta la connessione ma non
// risponde mai — con ~40 chiamate sequenziali nello script (una fonte
// lenta/bloccata basta) un'esecuzione può superare l'intervallo del
// cron (15 minuti) e restare "in progress" molto più a lungo del
// normale, causando accumulo di esecuzioni in coda su GitHub Actions
// (vedi anche concurrency/timeout-minutes in
// .github/workflows/ingest-light.yml). 20 secondi per tentativo è
// abbondante per API/HTML di poche decine di KB come quelle usate qui.
const TIMEOUT_MS_DEFAULT = 20_000;

async function fetchConRetry(url, options = {}, tentativi = 3) {
  let ultimoErrore;
  for (let i = 0; i < tentativi; i++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), TIMEOUT_MS_DEFAULT);
    try {
      return await fetch(url, { ...options, signal: controller.signal });
    } catch (err) {
      ultimoErrore = err;
      if (i < tentativi - 1) await new Promise((r) => setTimeout(r, 1000 * (i + 1)));
    } finally {
      clearTimeout(timer);
    }
  }
  throw ultimoErrore;
}
const xml = new XMLParser({ ignoreAttributes: false, attributeNamePrefix: "@_" });

// Il testo del bollettino contiene entità HTML (es. "igrave;" per "ì")
// che fast-xml-parser non decodifica automaticamente, non essendo
// entità XML standard — solo &amp; &lt; &gt; &quot; &apos; lo sono.
const ENTITA_HTML = {
  agrave: "à", egrave: "è", igrave: "ì", ograve: "ò", ugrave: "ù",
  Agrave: "À", Egrave: "È", Igrave: "Ì", Ograve: "Ò", Ugrave: "Ù",
  aacute: "á", eacute: "é", iacute: "í", oacute: "ó", uacute: "ú",
  ecirc: "ê", ocirc: "ô", nbsp: " ", ndash: "–", mdash: "—",
  laquo: "«", raquo: "»", deg: "°", agrave1: "à",
};

function decodeEntitaHtml(str) {
  return str
    // Entità numeriche decimali (es. "&#8216;"/"&#8217;" per le virgolette
    // tipografiche “ ’ usate da WordPress — bug reale segnalato dall'utente
    // il 05/09/2026, visibile nei titoli di Trieste All News mostrati
    // lettera per lettera invece che come apostrofo/virgolette) — non
    // gestite dal solo elenco ENTITA_HTML sotto, che copre solo le entità
    // HTML *nominate* più comuni per l'italiano.
    .replace(/&#(\d+);/g, (_match, codice) => String.fromCodePoint(Number(codice)))
    // Entità numeriche esadecimali (es. "&#x2019;"), stesso principio.
    .replace(/&#x([0-9a-fA-F]+);/g, (_match, hex) => String.fromCodePoint(parseInt(hex, 16)))
    .replace(/&([a-zA-Z]+);/g, (match, nome) => ENTITA_HTML[nome] ?? match);
}

// Quando un tag XML ha sia un attributo che del testo (es.
// <TMIN um="°C">21</TMIN>), fast-xml-parser restituisce un oggetto
// { "@_um": "°C", "#text": "21" } invece di una stringa semplice.
// Questo helper normalizza entrambi i casi, per evitare di scrivere
// oggetti dove il frontend si aspetta testo (causa un crash React),
// e decodifica le entità HTML residue.
function testo(v) {
  if (v === null || v === undefined) return null;
  const s = typeof v === "object" ? (v["#text"] !== undefined ? String(v["#text"]) : null) : String(v);
  return s === null ? null : decodeEntitaHtml(s);
}

// Scrittura in `history` sospesa dal 06/09/2026: il database Supabase ha
// superato 1.5GB dopo sole due settimane di esecuzioni ogni 15 minuti, e la
// causa era quasi interamente questa tabella. `history` era pensata fin
// dallo schema iniziale "per fasi successive, grafici/andamenti", ma
// nessuna pagina del sito la legge ancora (verificato con una ricerca nel
// codice) — nel frattempo upsertSnapshot() ci scriveva incondizionatamente
// il payload INTERO ad ogni esecuzione, da ~35 punti di chiamata diversi
// (alcuni dentro cicli per provincia/competizione, es. calcio su 9
// competizioni × 2 stagioni), senza alcuna deduplicazione né scadenza —
// anche per dati che cambiano raramente (farmacie, piste ciclabili,
// classifiche calcio fuori giornata, viabilità). L'unica eccezione già
// esistente era `sci:risultati` (vedi ingestRisultatiSci), che scrive in
// history solo se qualcosa è davvero cambiato.
//
// Riattivare (mettendo STORICO_ATTIVO a true) solo quando esisterà
// davvero una funzionalità che legge questa tabella (andamenti/grafici
// storici). A quel punto vale la pena generalizzare subito il controllo
// "scrivi solo se cambiato" a tutti i moduli e/o aggiungere una pulizia
// automatica delle righe più vecchie di N giorni, per non ripetere lo
// stesso problema da capo.
const STORICO_ATTIVO = false;

// Bug reale trovato il 05/10/2026 (log di ingestion fornito dall'utente):
// "meteo-pazzi-telegram" e "meteo-pazzi-previsioni" sono falliti con
// "TypeError: fetch failed" dentro upsertSnapshot, non nel recupero della
// fonte esterna (quello era andato a buon fine, come per gli altri ~45
// moduli nella stessa esecuzione). Il commento sopra (riga ~34) dice che
// il retry di rete è "usato per tutte le chiamate di rete dello script" —
// ma non era vero: fetchConRetry copre solo le fetch verso le fonti
// esterne, mentre la scrittura su Supabase (questa funzione, usata da
// OGNI modulo) chiamava il client una sola volta e si arrendeva al primo
// errore di rete transitorio. Corretto applicando lo stesso schema di
// retry già usato sopra, invece di lasciare questo l'unico punto di rete
// del progetto senza tolleranza ai guasti. L'upsert è idempotente (stessa
// `id`), quindi ripetere la stessa scrittura in caso di errore è sempre
// sicuro.
async function upsertConRetry(tabella, payload, tentativi = 3) {
  let ultimoErrore;
  for (let i = 0; i < tentativi; i++) {
    const { error } = await supabase.from(tabella).upsert(payload);
    if (!error) return;
    ultimoErrore = error;
    if (i < tentativi - 1) await new Promise((r) => setTimeout(r, 1000 * (i + 1)));
  }
  throw ultimoErrore;
}

async function upsertSnapshot(id, module, zone, data) {
  try {
    await upsertConRetry("snapshots", { id, module, zone, data, updated_at: new Date().toISOString() });
  } catch (error) {
    throw new Error(`Upsert fallito per ${id}: ${error.message}`);
  }

  if (!STORICO_ATTIVO) return;

  // storico: una riga in più ad ogni esecuzione, utile in fasi successive
  const { error: histError } = await supabase
    .from("history")
    .insert({ module, zone, data });
  if (histError) console.warn(`Storico non salvato per ${module}: ${histError.message}`);
}

// Legge uno snapshot già salvato (se esiste) — usato dai moduli che
// mantengono una cache lato dati (es. risultati gare sci, vedi sotto)
// per non ripetere richieste HTTP già soddisfatte in un'esecuzione
// precedente. Mai fatale: se manca o la lettura fallisce si riparte da
// zero, il chiamante deve gestire `null` come "nessuna cache".
async function leggiSnapshotEsistente(id) {
  const { data, error } = await supabase.from("snapshots").select("data").eq("id", id).maybeSingle();
  if (error || !data) return null;
  return data.data ?? null;
}

// ---------------------------------------------------------------------
// METEO — bollettino previsioni OSMER ARPA FVG
// Fonte pubblica per sviluppatori (dev.meteo.fvg.it), non soggetta al
// vincolo delle 24h che riguarda invece i dati REAL-TIME delle stazioni.
// Le uniche osservazioni di stazione che ingeriamo qui sono quelle del
// giorno precedente (già oltre le 24h), etichettate esplicitamente
// "ieri" nel frontend — MAI la temperatura "adesso".
// ---------------------------------------------------------------------

function pad2(n) {
  return String(n).padStart(2, "0");
}

// OGGI — aggiornamento infragiornaliero (09/09/2026): l'utente ha segnalato
// che meteo.fvg.it mostra, sulla scheda "oggi dalle 08", un testo con
// prefisso "AGGIORNAMENTO: ..." quando il bollettino della mattina viene
// rivisto nel corso della giornata — e che il sito non lo intercettava.
// Verificato riga per riga il bollettino XML che ingeriamo sopra
// (dev.meteo.fvg.it/xml/previsioni/PW*.xml): contiene SOLO le scadenze
// "DOMANI"/"DOPODOMANI" più un testo di sintesi generale e una tendenza —
// MAI un campo "OGGI" né alcun testo "AGGIORNAMENTO". Non è quindi un
// problema di frequenza di ingestione: quella fonte non porta proprio
// questo dato, va preso altrove.
//
// La sezione "oggi" del sito pubblico https://www.meteo.fvg.it/home.php
// è renderizzata direttamente nell'HTML della pagina (non caricata via
// JavaScript/API — confermato sia con WebFetch sia, soprattutto, con
// l'outerHTML reale fornito dall'utente il 09/09/2026), quindi
// raggiungibile con un fetch+cheerio normale come le altre fonti HTML del
// progetto. Markup verificato su quell'outerHTML: un carosello con 4
// `.item` (oggi/domani/dopodomani/tendenza); quello di "oggi" viene
// individuato tramite `img[alt="oggi"]` (non per posizione nel DOM, che
// in teoria potrebbe cambiare) risalendo al contenitore `.item` più
// vicino. Al suo interno: uno `<strong>` col giorno in italiano, un
// `.small` con "emissione: ...", un `.text-justify.sipadd` col testo
// libero (con o senza prefisso "AGGIORNAMENTO:"), e una tabella con righe
// "pianura"/"costa" (colonne tmin/tmax/tmed) — stessa granularità delle
// fasce F3 (Bassa Pianura)/F4 (Costa) già usate sopra per domani/
// dopodomani, non un dato per singola città.
//
// Se questo blocco fallisce (rete, markup cambiato) si perde solo la
// sezione "oggi": il resto del bollettino (domani/dopodomani, già
// funzionante) non viene toccato — stesso principio di tolleranza ai
// guasti già usato per ogni altra fonte del progetto.
const FASCIA_HTML_PER_CITTA = { trieste: "costa", udine: "pianura", gorizia: "pianura", pordenone: "pianura" };

async function fetchMeteoOggi() {
  try {
    const res = await fetchConRetry("https://www.meteo.fvg.it/home.php", {
      headers: { "User-Agent": "Mozilla/5.0 (compatible; FVGMonitorBot/1.0)" },
    });
    if (!res.ok) {
      console.warn(`Pagina meteo.fvg.it non disponibile per "oggi" (HTTP ${res.status})`);
      return null;
    }
    const $ = cheerio.load(await res.text());
    const $item = $('img[alt="oggi"]').first().closest(".item");
    if ($item.length === 0) {
      console.warn('Blocco "oggi" non trovato in meteo.fvg.it/home.php (markup cambiato?)');
      return null;
    }

    // Scope alla colonna testuale (".selectable"), non all'intero ".item":
    // la colonna con l'immagine/tabella evoluzione ha anch'essa una classe
    // "small" (su ".table-responsive.small", la tabella oraria 4/12/20) che
    // altrimenti vincerebbe su ".find(...).first()" essendo prima nel DOM.
    const $col = $item.find(".selectable").first();
    const giorno = $col.find("strong").first().text().trim() || null;
    const emissione = $col.find(".small").first().text().replace(/^emissione:\s*/i, "").trim() || null;
    const testoLibero = $col.find(".text-justify.sipadd").first().text().trim();
    if (!testoLibero) return null;

    const perFascia = {};
    $col.find("table tbody tr").each((_, tr) => {
      const $tr = $(tr);
      const fascia = $tr.find("td").first().text().trim().toLowerCase();
      if (fascia !== "pianura" && fascia !== "costa") return;
      perFascia[fascia] = {
        tmin: $tr.find("td.tmin").text().trim() || null,
        tmax: $tr.find("td.tmax").text().trim() || null,
      };
    });

    return { giorno, emissione, testo: testoLibero, perFascia };
  } catch (err) {
    console.warn(`Errore nel recupero del blocco "oggi" da meteo.fvg.it: ${err.message}`);
    return null;
  }
}

async function ingestMeteo() {
  const now = new Date();
  const oggi = `${now.getUTCFullYear()}${pad2(now.getUTCMonth() + 1)}${pad2(now.getUTCDate())}`;
  const ieriDate = new Date(now);
  ieriDate.setUTCDate(ieriDate.getUTCDate() - 1);
  const dataIeriStr = `${ieriDate.getUTCFullYear()}${pad2(ieriDate.getUTCMonth() + 1)}${pad2(ieriDate.getUTCDate())}`;

  // Il bollettino di oggi viene pubblicato di solito verso mezzogiorno
  // UTC — nelle ore prima non esiste ancora (404). In quel caso usiamo
  // quello di ieri, così il dato viene comunque rielaborato con il
  // codice più recente invece di lasciare ferma una riga vecchia su
  // Supabase fino alla pubblicazione.
  let res = await fetchConRetry(`https://dev.meteo.fvg.it/xml/previsioni/PW${oggi}.xml`);
  if (!res.ok) {
    console.warn(`Bollettino di oggi (${oggi}) non disponibile, provo con quello di ieri (${dataIeriStr})`);
    res = await fetchConRetry(`https://dev.meteo.fvg.it/xml/previsioni/PW${dataIeriStr}.xml`);
  }
  if (!res.ok) {
    console.warn(`Nessun bollettino disponibile (né oggi né ieri, HTTP ${res.status})`);
    return;
  }

  const parsed = xml.parse(await res.text());
  const root = parsed.data;
  const previsioni = root.previsioni;
  const scadenzeRaw = Array.isArray(previsioni.scadenze.scadenza)
    ? previsioni.scadenze.scadenza
    : [previsioni.scadenze.scadenza];

  // Mappa zone qualitative (cielo/pioggia/temporale) per provincia,
  // più le fasce F3 (Bassa Pianura → entroterra) e F4 (Costa → Trieste)
  // per le temperature min/max: il bollettino OSMER non dà una
  // temperatura puntuale per città, solo un intervallo per fascia
  // altimetrica — è un'approssimazione dichiarata, non un dato esatto.
  const ZONA_PER_CITTA = { trieste: "A9", udine: "A6", gorizia: "A7", pordenone: "A5" };
  const FASCIA_TEMP_PER_CITTA = { trieste: "F4", udine: "F3", gorizia: "F3", pordenone: "F3" };

  const scadenze = scadenzeRaw.map((s) => {
    const zoneList = Array.isArray(s.zone.zona) ? s.zone.zona : [s.zone.zona];
    const zoneByNome = Object.fromEntries(zoneList.map((z) => [z["@_nome"], z]));

    const perCitta = {};
    for (const [citta, codiceZona] of Object.entries(ZONA_PER_CITTA)) {
      const z = zoneByNome[codiceZona];
      const fascia = zoneByNome[FASCIA_TEMP_PER_CITTA[citta]];
      perCitta[citta] = {
        cielo: testo(z?.CIELO_DESCRIZIONE),
        pioggia: testo(z?.PIOGGIA_DESCRIZIONE),
        temporale: testo(z?.TEMPORALE_DESCRIZIONE),
        tmin: testo(fascia?.TMIN),
        tmax: testo(fascia?.TMAX),
      };
    }

    return {
      giorno: testo(s["@_giorno"]), // "DOMANI" | "DOPODOMANI"
      data_validita: testo(s["@_data_validita"]),
      regione_testo: testo(zoneByNome.REGIONE?.TESTO),
      per_citta: perCitta,
    };
  });

  // "Oggi" (incluso l'eventuale "AGGIORNAMENTO:" infragiornaliero) non è
  // nell'XML sopra — va preso dall'HTML pubblico, vedi fetchMeteoOggi().
  // Inserito come prima scadenza (giorno: "OGGI") così il frontend può
  // trattarlo come le altre senza una struttura dati a parte.
  const oggiHtml = await fetchMeteoOggi();
  if (oggiHtml) {
    const perCittaOggi = {};
    for (const citta of Object.keys(ZONA_PER_CITTA)) {
      const f = oggiHtml.perFascia[FASCIA_HTML_PER_CITTA[citta]];
      perCittaOggi[citta] = {
        cielo: null,
        pioggia: null,
        temporale: null,
        tmin: f?.tmin ?? null,
        tmax: f?.tmax ?? null,
      };
    }
    scadenze.unshift({
      giorno: "OGGI",
      data_validita: oggiHtml.giorno,
      regione_testo: oggiHtml.testo,
      aggiornamento: /^aggiornamento\s*:/i.test(oggiHtml.testo),
      per_citta: perCittaOggi,
    });
  }

  // Osservazioni del giorno precedente (già >24h, pubblicabili)
  const osservazioniData = testo(root.osservazioni?.["@_data"]);
  const stazioniRaw = root.osservazioni?.stazioni?.stazione;
  const stazioniList = stazioniRaw ? (Array.isArray(stazioniRaw) ? stazioniRaw : [stazioniRaw]) : [];
  const ieri = Object.fromEntries(
    stazioniList
      .filter((s) => s["@_nome"])
      .map((s) => {
        const tmin = testo(s.TMIN);
        const tmax = testo(s.TMAX);
        return [
          testo(s["@_nome"]),
          { tmin: tmin === "n.d." ? null : tmin, tmax: tmax === "n.d." ? null : tmax },
        ];
      })
  );

  const payload = {
    bollettino_emesso: testo(previsioni.emissione),
    situazione_generale: testo(previsioni.SITUAZIONEGENERALE_TESTO),
    tendenza: testo(previsioni.TENDENZA_TESTO),
    scadenze,
    osservazioni_data: osservazioniData,
    ieri,
  };

  await upsertSnapshot("meteo:previsioni", "meteo", null, payload);
  console.log(
    "Meteo aggiornato:",
    testo(previsioni.emissione),
    oggiHtml ? `(oggi: ok${oggiHtml && /^aggiornamento\s*:/i.test(oggiHtml.testo) ? ", AGGIORNAMENTO" : ""})` : "(oggi: non disponibile)"
  );
}

// ---------------------------------------------------------------------
// "PAZZI PER IL METEO GORIZIANO" (09/09/2026) — due riquadri aggiuntivi
// nella pagina Meteo, richiesti dall'utente, sotto i pannelli Meteo/Radar
// esistenti: (1) gli ultimi aggiornamenti dal canale Telegram pubblico
// del meteorologo amatoriale Lorenzo Ghiraldelli, (2) le sue previsioni
// temporalesche pubblicate sul suo sito WordPress. Due fonti indipendenti
// dello stesso autore, non collegate all'XML OSMER usato sopra.
//
// Verificato prima di scrivere codice (via WebFetch, entrambe le fonti):
// - Canale Telegram (`t.me/pazziperilmeteo`): l'anteprima web pubblica
//   `t.me/s/<canale>` esiste per qualunque canale Telegram pubblico,
//   nessun login necessario — mostra gli ultimi ~12-20 messaggi in HTML
//   statico (non serve JS), ciascuno con un permalink `t.me/<canale>/<id>`.
//   Selettori (`div.tgme_widget_message[data-post]`,
//   `.tgme_widget_message_text`, `time[datetime]` dentro
//   `a.tgme_widget_message_date`) scritti inizialmente sulla struttura
//   nota/stabile del widget pubblico Telegram (senza outerHTML reale,
//   perché WebFetch converte in markdown e non permette di leggere le
//   classi CSS esatte), **poi confermati corretti il 09/09/2026 contro
//   l'outerHTML reale della pagina fornito dall'utente** — inclusi i casi
//   limite osservati nel markup reale: messaggi solo-foto senza
//   `.tgme_widget_message_text` (scartati correttamente, nessun testo da
//   mostrare), messaggi con foto+testo insieme, e l'ultimo messaggio della
//   pagina privo dell'attributo `data-view` (ininfluente, non usato).
// - Sito previsioni (`pazziperilmeteo.fvg.it`): WordPress standard, feed
//   RSS di categoria verificato su `/category/previsioni-temporalesche/feed/`
//   (senza l'anno nel percorso — stesso contenuto della versione con
//   "/2026/" ma senza bisogno di aggiornarla ogni anno, stessa lezione
//   già imparata con `CALCIO_STAGIONI`). Il campo `<description>` del
//   feed è già un estratto troncato da WordPress (termina con "[...]"),
//   distinto dal `<content:encoded>` col testo completo dell'articolo —
//   usato solo l'estratto, mai il testo integrale, stesso principio
//   "solo titolo+link+estratto, mai l'articolo intero" già applicato a
//   tutte le fonti Notizie del progetto (qui ancora più rilevante: il
//   sito porta un avviso esplicito "Copyright © Pazzi per il meteo
//   Goriziano" in fondo pagina). L'estratto porta anche un paragrafo
//   automatico di WordPress ("L'articolo ... proviene da ...") che va
//   ripulito prima di mostrarlo.
// ---------------------------------------------------------------------

const PAZZI_TELEGRAM_CANALE = "pazziperilmeteo";
const PAZZI_TELEGRAM_MAX_MESSAGGI = 8;
const PAZZI_PREVISIONI_FEED_URL = "https://pazziperilmeteo.fvg.it/category/previsioni-temporalesche/feed/";
const PAZZI_PREVISIONI_MAX_VOCI = 5;

async function ingestPazziTelegram() {
  const url = `https://t.me/s/${PAZZI_TELEGRAM_CANALE}`;
  const res = await fetchConRetry(url, {
    headers: { "User-Agent": "Mozilla/5.0 (compatible; FVGMonitorBot/1.0)" },
  });
  if (!res.ok) {
    console.warn(`Canale Telegram "Pazzi per il meteo" non disponibile (HTTP ${res.status})`);
    return;
  }
  const $ = cheerio.load(await res.text());
  const messaggi = [];

  $("div.tgme_widget_message[data-post]").each((_, el) => {
    const $el = $(el);
    const dataPost = $el.attr("data-post"); // es. "pazziperilmeteo/6321"
    const id = dataPost?.split("/")[1];
    if (!id) return;

    const $testo = $el.find(".tgme_widget_message_text").first();
    // <br> non produce testo con cheerio .text() — sostituito con \n
    // prima di estrarre, altrimenti righe diverse restano incollate.
    $testo.find("br").replaceWith("\n");
    const testoMessaggio = $testo.text().trim();
    if (!testoMessaggio) return; // messaggi solo-foto/video senza didascalia: saltati, niente da mostrare

    const datetime = $el.find("a.tgme_widget_message_date time").first().attr("datetime") ?? null;

    messaggi.push({
      id,
      testo: testoMessaggio,
      data: datetime,
      link: `https://t.me/${PAZZI_TELEGRAM_CANALE}/${id}`,
    });
  });

  if (messaggi.length === 0) {
    console.warn('Canale Telegram "Pazzi per il meteo": nessun messaggio estratto (markup cambiato o pagina vuota?)');
    return;
  }

  // Più recenti per primi (l'anteprima li elenca già così, ma non è
  // documentato che l'ordine sia garantito), poi tagliati al massimo
  // configurato.
  messaggi.sort((a, b) => (b.data ?? "").localeCompare(a.data ?? ""));

  await upsertSnapshot("meteo:pazzi-telegram", "meteo", null, {
    fonte: "Pazzi per il meteo Goriziano (Telegram)",
    fonte_url: `https://t.me/s/${PAZZI_TELEGRAM_CANALE}`,
    messaggi: messaggi.slice(0, PAZZI_TELEGRAM_MAX_MESSAGGI),
  });
  console.log(`Telegram "Pazzi per il meteo" aggiornato: ${messaggi.length} messaggi trovati`);
}

// Rimuove il paragrafo automatico che WordPress aggiunge in coda ad ogni
// estratto RSS ("L'articolo <a>Titolo</a> proviene da <a>Nome sito</a>."),
// poi ogni altro tag HTML residuo — l'estratto deve restare solo testo.
function pulisciEstrattoWordpress(html) {
  if (!html) return null;
  const senzaBoilerplate = html.replace(/<p>\s*L['’]articolo[\s\S]*?proviene da[\s\S]*?<\/p>\s*/i, "");
  const senzaTag = senzaBoilerplate.replace(/<[^>]+>/g, " ");
  return decodeEntitaHtml(senzaTag).replace(/\s+/g, " ").trim() || null;
}

async function ingestPazziPrevisioni() {
  const res = await fetchConRetry(PAZZI_PREVISIONI_FEED_URL);
  if (!res.ok) {
    console.warn(`Feed previsioni temporalesche "Pazzi per il meteo" non disponibile (HTTP ${res.status})`);
    return;
  }
  const parsed = xml.parse(await res.text());
  const itemsRaw = parsed.rss?.channel?.item || [];
  const items = (Array.isArray(itemsRaw) ? itemsRaw : [itemsRaw]).slice(0, PAZZI_PREVISIONI_MAX_VOCI).map((item) => ({
    titolo: testo(item.title),
    link: testo(item.link),
    data: testo(item.pubDate),
    autore: testo(item["dc:creator"]),
    estratto: pulisciEstrattoWordpress(item.description),
  }));

  await upsertSnapshot("meteo:pazzi-previsioni", "meteo", null, {
    fonte: "Pazzi per il meteo Goriziano",
    fonte_url: "https://pazziperilmeteo.fvg.it/category/previsioni-temporalesche/",
    items,
  });
  console.log(`Previsioni temporalesche "Pazzi per il meteo" aggiornate: ${items.length} voci`);
}

// ---------------------------------------------------------------------
// NOTIZIE — RSS ANSA Friuli Venezia Giulia
//
// NOTA: il feed ANSA riporta la dicitura "FOR PERSONAL USE ONLY".
// Per restare su un uso ragionevole e rispettoso della fonte,
// pubblichiamo SOLO titolo + link + data (mai il testo dell'articolo),
// con link diretto all'originale — lo stesso schema di un aggregatore
// RSS standard. Vale comunque la pena rivalutare questo punto,
// eventualmente contattando ANSA per un utilizzo esplicitamente
// autorizzato, se il progetto dovesse crescere.
// ---------------------------------------------------------------------

async function ingestNotizie() {
  const url = "https://www.ansa.it/friuliveneziagiulia/notizie/friuliveneziagiulia_rss.xml";
  const res = await fetchConRetry(url);
  if (!res.ok) {
    console.warn(`RSS ANSA non disponibile (HTTP ${res.status})`);
    return;
  }

  const parsed = xml.parse(await res.text());
  const itemsRaw = parsed.rss?.channel?.item || [];
  const items = (Array.isArray(itemsRaw) ? itemsRaw : [itemsRaw]).slice(0, 10).map((item) => ({
    titolo: testo(item.title),
    link: testo(item.link),
    data: testo(item.pubDate),
  }));

  await upsertSnapshot("notizie:ansa-fvg", "notizie", null, {
    fonte: "ANSA Friuli Venezia Giulia",
    fonte_url: "https://www.ansa.it/friuliveneziagiulia/",
    items,
  });
  console.log(`Notizie aggiornate: ${items.length} titoli`);
}

// ---------------------------------------------------------------------
// NOTIZIE LOCALI PER PROVINCIA (05/09/2026) — sezione nuova nel menu,
// distinta dal pannello ANSA regionale sopra (che resta invariato,
// homepage-only). Qui si aggregano fonti iper-locali per ciascuna delle
// 4 province, una provincia alla volta su richiesta dell'utente — si
// parte da Trieste (vedi sotto), Udine e Gorizia aggiunte il 06/09/2026
// (vedi più sotto), Pordenone arriverà in una sessione successiva.
//
// L'utente ha indicato 4 fonti per Trieste; verificate una per una
// prima di scrivere questo modulo (vedi claude/fvgmonitor-stato.md per
// il dettaglio completo). Risultato al 05/09/2026: **3 delle 4 sono
// integrate**, l'ultima resta bloccata per motivi verificati e non
// aggirabili da questa sessione, non per pigrizia:
//   - Trieste All News (triesteallnews.it/feed/): feed RSS 2.0 standard
//     confermato — INTEGRATA (05/09/2026).
//   - RaiNews TGR FVG: l'intero dominio rainews.it (e anche tgr.rai.it)
//     è bloccato sia dalla rete del sandbox sia dalla policy degli
//     strumenti di questa sessione — nessuna verifica autonoma
//     possibile. **Sbloccata il 05/09/2026 grazie all'utente**, che ha
//     fornito l'outerHTML reale della pagina di ricerca per tag
//     "Trieste" dal proprio browser — prima versione INTEGRATA via
//     scraping HTML (classi `.launch-item`/`rainews-card`). **Rivelatasi
//     completamente sbagliata il 06/09/2026**: l'utente ha segnalato
//     zero notizie RaiNews in produzione nonostante un fix del formato
//     data; un log diagnostico ha mostrato "RaiNews=0" senza alcun
//     errore HTTP; la sorgente HTML **grezza** (non l'outerHTML del
//     browser, questa volta "Visualizza sorgente pagina") fornita di
//     nuovo dall'utente ha rivelato la causa reale: la pagina è solo un
//     guscio `<rainews-search>` vuoto — tutto il contenuto (inclusi i
//     `.launch-item` usati dal parser precedente) viene iniettato **dopo**
//     da JavaScript lato client, MAI presente in un fetch Node senza
//     esecuzione JS. Nessun fix di parsing avrebbe mai potuto funzionare
//     su quella pagina. **Riscritta il 06/09/2026** per chiamare
//     direttamente l'API JSON di ricerca interna del sito
//     (`POST /atomatic/news-search-service/api/v3/search`, filtro per
//     dominio+tag), scoperta dall'utente via DevTools → Network → "Copia
//     come cURL" — stesso metodo già usato per Tennis/Sci/Autobus. Vedi
//     `ingestNotizieFonteRainews()` sotto per il dettaglio completo.
//   - TriestePrima.it (rete Citynews): nessun feed RSS individuato con
//     i tentativi fatti (diversi percorsi comuni, tutti 403 o
//     irraggiungibili). **Sbloccata il 05/09/2026 grazie all'utente**,
//     che ha fornito l'outerHTML reale della pagina "Ultim'ora Trieste"
//     (`/notizie/tutte/`) dal proprio browser — INTEGRATA via scraping
//     HTML, vedi `ingestNotizieFonteCitynews()` sotto (generalizzata il
//     06/09/2026 per essere riusata anche da UdineToday.it, vedi sotto).
//     **Rischio
//     concreto e non risolvibile da questa sessione**: un tentativo di
//     WebFetch diretto sulla stessa pagina, fatto per verificare se un
//     fetch server-side (come quello di GitHub Actions) riesce dove
//     WebFetch aveva già fallito in passato, ha restituito di nuovo
//     "403 client error" — il sito ha evidenti protezioni anti-bot
//     (rete Citynews, ad-tech pesante, fingerprinting). Non è quindi
//     garantito che il fetch reale su GitHub Actions abbia successo:
//     se fallisse, `fetchConRetry` restituirebbe una risposta non-ok e
//     la fonte verrebbe scartata con un avviso in log, senza rompere le
//     altre fonti (stesso fallback "array vuoto" già usato altrove) —
//     ma non è da escludere che serva un giorno uno User-Agent diverso
//     o altri header per sbloccarla davvero.
//   - TriesteCafe.it: nessun feed RSS trovato (CMS proprietario) —
//     richiede scraping HTML, mai verificato su markup reale.
// Per quest'ultima, WebFetch riesce a leggere la sola homepage in
// markdown (non l'HTML grezzo necessario per scrivere selettori cheerio
// corretti) — stessa lezione già annotata più volte nel progetto: serve
// l'outerHTML reale fornito dall'utente prima di scrivere un parser di
// produzione, non un selettore indovinato da un riassunto.
//
// Struttura pensata per l'estensione: ogni fonte è un oggetto
// { fonte, fonte_url, url?, tipo?, baseUrl? } (RaiNews usa `tagRainews`
// al posto di `url`, vedi sotto — non fa un fetch diretto su un
// indirizzo ma chiama un'API con un parametro; le fonti `tipo: "citynews"`
// hanno anche `baseUrl` per ricostruire i link relativi, vedi sotto),
// ogni provincia un array di fonti — `tipo: "rainews"` / `tipo:
// "citynews"` selezionano il gestore dedicato, altrimenti si assume un
// feed RSS standard. Per aggiungere una fonte o una provincia nuova
// basta estendere qui, nessuna modifica altrove.
const FONTI_NOTIZIE_TRIESTE = [
  {
    fonte: "Trieste All News",
    fonte_url: "https://www.triesteallnews.it/",
    url: "https://www.triesteallnews.it/feed/",
  },
  {
    fonte: "RaiNews TGR FVG",
    fonte_url: "https://www.rainews.it/tgr/fvg",
    // Tag interno usato dall'API di ricerca (vedi ingestNotizieFonteRainews
    // sotto) — non un URL da fetchare, a differenza delle altre fonti.
    tagRainews: "Trieste|Tag-2f11fc6a-35b4-4f6d-94c9-175480c94179",
    tipo: "rainews",
  },
  {
    fonte: "TriestePrima.it",
    fonte_url: "https://www.triesteprima.it/",
    url: "https://www.triesteprima.it/notizie/tutte/",
    baseUrl: "https://www.triesteprima.it",
    tipo: "citynews",
  },
];

// Udine (06/09/2026) — 5 fonti indicate dall'utente, verificate una per
// una prima di scrivere questo modulo (vedi claude/fvgmonitor-stato.md
// per il dettaglio completo):
//   - UdineToday.it: stessa rete Citynews di TriestePrima.it (stesso
//     tema, stessa identica struttura di URL "/notizie/tutte/") —
//     bloccata sia dal fetch/curl diretto di questo sandbox sia da
//     WebFetch stesso (403), esattamente come TriestePrima.it prima
//     dell'intervento dell'utente. **Riusati gli stessi selettori già
//     verificati su TriestePrima.it** (`ingestNotizieFonteCitynews`,
//     generalizzata dalla versione precedente specifica per
//     TriestePrima.it) come scommessa ragionevole data l'identità di
//     piattaforma — non ancora confermata su un outerHTML reale di
//     QUESTO dominio specifico. Se il primo run reale desse 0 elementi,
//     servirà l'outerHTML reale della pagina da questo dominio per
//     confermare/correggere i selettori (nessun rischio per le altre
//     fonti, stesso fallback "array vuoto" di sempre).
//   - UDINE.news (udineoggi.news): feed RSS 2.0 standard verificato via
//     WebFetch su `/feed/` — stesso gestore generico `ingestNotizieFonteRss`
//     già usato per ANSA/Trieste All News.
//   - Telefriuli.it: l'utente ha indicato la sola categoria "/cronaca/"
//     — verificato che esiste un feed RSS dedicato a quella categoria
//     (`/cronaca/feed/`, contenuto diverso dal feed generale del sito),
//     usato quello invece del feed sitewide.
//   - PrimaUdine.it: l'utente ha indicato la categoria "/category/in-evidenza"
//     ma il sito non pubblica un feed RSS per singola categoria (provato
//     sia `/category/in-evidenza/feed/` sia `?feed=rss2`, entrambi 404) —
//     esiste solo un feed unico per l'intero sito (`/feed/`, verificato
//     via WebFetch), usato come approssimazione più ampia della sola
//     "in evidenza". Se l'utente preferisce restare filtrato alla sola
//     categoria, servirà l'outerHTML reale della pagina categoria per
//     scrivere uno scraper cheerio dedicato (WebFetch non blocca qui,
//     ma riassume in markdown e non basta per selettori di produzione,
//     stessa lezione di sempre).
//   - RaiNews TGR FVG: stessa API di ricerca già integrata per Trieste
//     (vedi `ingestNotizieFonteRainews` sotto), solo `tagRainews`
//     diverso — l'utente ha fornito direttamente l'URL con il tag Udine.
const FONTI_NOTIZIE_UDINE = [
  {
    fonte: "UdineToday.it",
    fonte_url: "https://www.udinetoday.it/",
    url: "https://www.udinetoday.it/notizie/tutte/",
    baseUrl: "https://www.udinetoday.it",
    tipo: "citynews",
  },
  {
    fonte: "UDINE.news",
    fonte_url: "https://udineoggi.news/",
    url: "https://udineoggi.news/feed/",
  },
  {
    fonte: "Telefriuli",
    fonte_url: "https://www.telefriuli.it/cronaca/",
    url: "https://www.telefriuli.it/cronaca/feed/",
  },
  {
    fonte: "PrimaUdine.it",
    fonte_url: "https://primaudine.it/category/in-evidenza",
    url: "https://primaudine.it/feed/",
  },
  {
    fonte: "RaiNews TGR FVG",
    fonte_url: "https://www.rainews.it/tgr/fvg",
    tagRainews: "Udine|Tag-104004c3-3848-4a0e-b70b-470105b903e9",
    tipo: "rainews",
  },
];

// Gorizia (06/09/2026) — 4 fonti indicate dall'utente:
//   - GORIZIA.news (goriziaoggi.news): feed RSS 2.0 standard verificato
//     via WebFetch su `/feed/` — stessa rete "oggi.news" di UDINE.news.
//   - RaiNews TGR FVG: stessa API già integrata per Trieste/Udine, solo
//     `tagRainews` diverso — l'utente ha fornito l'URL con il tag
//     Gorizia già estratto.
//   - Il Goriziano (ilgoriziano.it): **dominio del tutto irraggiungibile
//     da questa sessione** (non solo 403 come la rete Citynews, ma
//     timeout già sul recupero di robots.txt, stesso blocco totale già
//     visto per `comitati.fisi.org`/`gare.lnd.it`/`realtime.tplfvg.it`) —
//     non è stato possibile verificare nemmeno l'esistenza di un feed
//     RSS. **Sbloccata lo stesso giorno**: l'utente ha incollato
//     l'outerHTML reale della pagina "/notizie/cronaca/" (salvato subito
//     su disco, stessa lezione operativa annotata sopra per RaiNews), che
//     ha permesso di scrivere uno scraper cheerio dedicato
//     (`ingestNotizieFonteIlGoriziano`) senza bisogno di raggiungere il
//     dominio da qui. Struttura verificata: un articolo "in evidenza"
//     (`article#copertina`, wrappato da un `<a>` invece di contenerlo) più
//     una griglia di `article.col-12.col-md-4` (ognuno con l'`<a>` come
//     figlio) — un solo selettore (`header h2, header h3`) copre entrambi
//     i casi per il titolo. **Nessuna data/ora esplicita vicino al
//     titolo** per gli articoli in griglia (solo per quello in evidenza,
//     e comunque solo il giorno, es. "05 Set 2026 • Salvatore Ferrara") —
//     l'unica data disponibile in modo uniforme per ogni notizia è quella
//     incorporata alla fine dello slug dell'URL (es. ".../scuola-venezian
//     -05-settembre-2026", ".../attivita-economiche-5-settembre-2026" —
//     giorno con o senza zero iniziale), usata come unica fonte con ora
//     fissata a mezzogiorno (12:00) Europe/Rome per mancanza di un dato
//     più preciso (`parseDataDaSlugIlGoriziano()` sotto). Verificato con
//     uno script cheerio a sé contro l'outerHTML reale fornito
//     dall'utente: 10/10 articoli estratti correttamente (titolo, link
//     assoluto senza doppio slash, data), incluso il caso giorno singolo.
//   - La Gazzetta di Gorizia (lagazzettadigorizia.it): stesso blocco
//     totale de Il Goriziano prima dello sblocco — **sbloccata anch'essa
//     lo stesso giorno**, ma con un percorso più semplice: l'utente ha
//     incollato direttamente l'XML grezzo di `/feed/`, rivelando che è un
//     feed RSS 2.0 WordPress standard (stesso identico formato di
//     UDINE.news/GORIZIA.news, `pubDate` in formato RFC 2822, già
//     parsabile da `new Date()`) — nessuno scraper dedicato necessario,
//     gestita da `ingestNotizieFonteRss()` come tutte le altre fonti RSS
//     del progetto. Verificato con un piccolo script a sé (fast-xml-parser
//     contro l'XML reale, incluse le entità numeriche nel titolo del
//     canale, es. "&#8211;", già gestite da `decodeEntitaHtml()`).
//     **Tutte e 4 le fonti richieste dall'utente sono ora attive.**
const FONTI_NOTIZIE_GORIZIA = [
  {
    fonte: "GORIZIA.news",
    fonte_url: "https://goriziaoggi.news/",
    url: "https://goriziaoggi.news/feed/",
  },
  {
    fonte: "RaiNews TGR FVG",
    fonte_url: "https://www.rainews.it/tgr/fvg",
    tagRainews: "Gorizia|Tag-77ba87cb-7f62-4d5f-9295-19ed21525cb4",
    tipo: "rainews",
  },
  {
    fonte: "Il Goriziano",
    fonte_url: "https://www.ilgoriziano.it/notizie/cronaca/",
    url: "https://www.ilgoriziano.it/notizie/cronaca/",
    tipo: "ilgoriziano",
  },
  {
    fonte: "La Gazzetta di Gorizia",
    fonte_url: "https://www.lagazzettadigorizia.it/",
    url: "https://www.lagazzettadigorizia.it/feed/",
  },
];

// Pordenone (08/09/2026) — 4 fonti indicate dall'utente, tutte verificate
// prima di scrivere questo modulo:
//   - PordenoneToday.it: stessa rete Citynews di TriestePrima.it/
//     UdineToday.it (stesso tema, stesso URL "/notizie/tutte/") —
//     irraggiungibile da questa sessione anche per WebFetch (timeout già
//     sul recupero di robots.txt, non solo un 403 — un blocco più severo
//     del solito per questa rete, mai visto per gli altri due domini
//     Citynews del progetto). **Riusato lo stesso scraper generalizzato**
//     `ingestNotizieFonteCitynews` (già usato per TriestePrima.it,
//     verificato su outerHTML reale, e per UdineToday.it, mai confermato)
//     come scommessa ragionevole data l'identità di piattaforma — se il
//     primo run reale desse 0 elementi, servirà l'outerHTML reale di
//     questo dominio, stesso percorso di sblocco già riuscito 3 volte in
//     questo progetto.
//   - PordenoneOggi.it: feed RSS 2.0 standard verificato via WebFetch su
//     `/feed/` — stessa famiglia di siti "oggi" di UDINE.news/GORIZIA.news
//     (qui però dominio proprio `.it`, non `oggi.news`), gestito allo
//     stesso modo da `ingestNotizieFonteRss()`.
//   - Telefriuli: qui l'utente ha indicato direttamente il tag
//     "/tag/pordenone/" (non una categoria come per Udine) — verificato
//     via WebFetch che esiste un feed RSS dedicato anche per il tag
//     (`/tag/pordenone/feed/`, titolo canale "pordenone - Telefriuli"),
//     non solo per le categorie: stessa convenzione URL WordPress
//     (`/tag/<slug>/feed/` oltre a `/category/<slug>/feed/`), non
//     visibile come `<link rel="alternate">` nella pagina HTML del tag
//     ma comunque raggiungibile direttamente.
//   - RaiNews TGR FVG: stessa API di ricerca già integrata per le altre 3
//     province, solo `tagRainews` diverso — l'utente ha fornito l'URL con
//     il tag Pordenone già estratto.
// Con Pordenone tutte e 4 le province del FVG hanno ora una sezione
// Notizie attiva (Trieste 05/09, Udine e Gorizia 06/09, Pordenone
// 08/09/2026) — rollout completato.
const FONTI_NOTIZIE_PORDENONE = [
  {
    fonte: "PordenoneToday.it",
    fonte_url: "https://www.pordenonetoday.it/",
    url: "https://www.pordenonetoday.it/notizie/tutte/",
    baseUrl: "https://www.pordenonetoday.it",
    tipo: "citynews",
  },
  {
    fonte: "PordenoneOggi.it",
    fonte_url: "https://pordenoneoggi.it/",
    url: "https://pordenoneoggi.it/feed/",
  },
  {
    fonte: "RaiNews TGR FVG",
    fonte_url: "https://www.rainews.it/tgr/fvg",
    tagRainews: "Pordenone|Tag-963bdf30-ed0f-43f9-978a-f5975cc07dc2",
    tipo: "rainews",
  },
  {
    fonte: "Telefriuli",
    fonte_url: "https://www.telefriuli.it/tag/pordenone/",
    url: "https://www.telefriuli.it/tag/pordenone/feed/",
  },
];

const PROVINCE_NOTIZIE = [
  { slug: "trieste", fonti: FONTI_NOTIZIE_TRIESTE },
  { slug: "udine", fonti: FONTI_NOTIZIE_UDINE },
  { slug: "gorizia", fonti: FONTI_NOTIZIE_GORIZIA },
  { slug: "pordenone", fonti: FONTI_NOTIZIE_PORDENONE },
];

// Stesso parsing RSS di ingestNotizie() (ANSA) sopra — le fonti locali
// finora verificate sono anch'esse feed RSS 2.0 standard, nessuna
// insidia di formato diversa da quella già gestita per ANSA.
async function ingestNotizieFonteRss(fonte) {
  const res = await fetchConRetry(fonte.url);
  if (!res.ok) {
    console.warn(`RSS ${fonte.fonte} non disponibile (HTTP ${res.status})`);
    return [];
  }
  const parsed = xml.parse(await res.text());
  const itemsRaw = parsed.rss?.channel?.item || [];
  return (Array.isArray(itemsRaw) ? itemsRaw : [itemsRaw]).map((item) => ({
    titolo: testo(item.title),
    link: testo(item.link),
    data: testo(item.pubDate),
    fonte: fonte.fonte,
  }));
}

// RaiNews TGR FVG — API JSON del motore di ricerca interno (06/09/2026,
// riscritta da zero dopo aver scoperto che lo scraping HTML della pagina
// tag "Trieste" non poteva funzionare in alcun modo: vedi commento sopra
// FONTI_NOTIZIE_TRIESTE per la storia completa (fix del formato data del
// 05/09/2026, poi log diagnostico che ha mostrato "RaiNews=0" nonostante
// nessun errore HTTP, poi la vera causa scoperta dalla sorgente HTML
// grezza fornita dall'utente il 06/09/2026: la pagina è solo un guscio
// `<rainews-search>` vuoto, il contenuto viene iniettato interamente da
// JavaScript lato client — un fetch Node non lo vedrà MAI, qualunque
// selettore si scriva). L'utente ha individuato via DevTools → Network
// la richiesta reale che il browser fa per popolare quella pagina:
// `POST /atomatic/news-search-service/api/v3/search`, corpo JSON con un
// filtro per dominio (FVG) e tag (es. "Trieste|Tag-...") — stesso
// endpoint usato internamente dal sito per ogni ricerca per tag/pagina
// regionale. Risposta verificata su dati reali (JSON completo incollato
// dall'utente, non un riassunto): `hits[]` con `title`, `weblink`
// (relativo, va anteposto `https://www.rainews.it`), `publication_date`
// già in ISO 8601 con offset esplicito (es. "2026-09-05T10:38:00+0000")
// — **nessun parsing di data manuale necessario**, a differenza di
// TriestePrima.it, perché qui la fonte è un'API pensata per essere
// consumata da codice, non una pagina pensata per un umano. `data_type`
// distingue "articolo"/"video"/"fotogallery"/ecc. — inclusi tutti, come
// già deciso per lo scraping HTML precedente (stessa redazione, stesso
// tag, nessun motivo di escludere i video). Nessun cookie di sessione
// incluso nella chiamata: quelli osservati nel cURL dell'utente
// (`_scor_uid`, `ak_bmsc`, `bm_sv`, questi ultimi due di Akamai) sembrano
// legati a fingerprinting/anti-bot generico del dominio, non a
// un'autenticazione richiesta per questo endpoint — se il fetch reale da
// GitHub Actions dovesse fallire per un blocco anti-bot, lo si vedrà dal
// prossimo log (`RaiNews ... non disponibile (HTTP ...)`) e andrà
// rivisto con header aggiuntivi.
const RAINEWS_SEARCH_URL = "https://www.rainews.it/atomatic/news-search-service/api/v3/search";
const RAINEWS_DOMINIO_FVG = [
  "Friuli Venezia Giulia|Category-66bfeea7-d64c-4d32-b8a7-88f0234da0ca",
  "TGR|Category-11ceef28-c189-4210-9959-881484ae5987",
];

// "+0000" (senza i due punti) non è garantito parsabile da ogni motore
// JS come offset ISO — normalizzato esplicitamente a "+00:00" prima di
// usare la stringa come `data` (stesso principio già seguito altrove nel
// file: mai affidarsi implicitamente a `new Date()` su un formato non
// verificato).
function normalizzaOffsetIso(dataIso) {
  return dataIso.replace(/([+-]\d{2})(\d{2})$/, "$1:$2");
}

async function ingestNotizieFonteRainews(fonte) {
  const res = await fetchConRetry(RAINEWS_SEARCH_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "*/*",
      "User-Agent": "Mozilla/5.0 (compatible; FVGMonitorBot/1.0)",
    },
    body: JSON.stringify({
      page: 0,
      pageSize: 16,
      filters: {
        dominio: RAINEWS_DOMINIO_FVG,
        tag: [fonte.tagRainews],
      },
      post_filters: null,
      mode: "searchPlain",
    }),
  });
  if (!res.ok) {
    console.warn(`RaiNews ${fonte.fonte} non disponibile (HTTP ${res.status})`);
    return [];
  }
  const json = await res.json();
  const hits = Array.isArray(json.hits) ? json.hits : [];
  return hits
    .filter((h) => h.title && h.weblink && h.publication_date)
    .map((h) => ({
      titolo: h.title.trim(),
      link: `https://www.rainews.it${h.weblink}`,
      data: normalizzaOffsetIso(h.publication_date),
      fonte: fonte.fonte,
    }));
}

// Rete Citynews (TriestePrima.it, verificata il 05/09/2026; UdineToday.it,
// stessa piattaforma, aggiunta il 06/09/2026 — vedi nota su
// FONTI_NOTIZIE_UDINE sopra) mostra l'ora in tre formati diversi,
// verificati sull'outerHTML reale di TriestePrima.it fornito dall'utente
// il 05/09/2026 (pagina "Ultim'ora Trieste", /notizie/tutte/): "HH:MM"
// per le notizie di oggi (nessuna data esplicita — risolta con la data
// odierna in Europe/Rome, dato che questo script gira su GitHub Actions
// in UTC), "gio, HH:MM" / "mer, HH:MM" ecc. per notizie di giorni
// precedenti nella stessa settimana (giorno abbreviato italiano,
// calcolato contando all'indietro dal giorno corrente), e "00:00" per le
// voci sindacate "/partner/.../....feed" ("Notizie dalla giunta",
// comunicati della Regione) — trattate come una notizia qualunque di
// oggi a mezzanotte, nessun filtro: sono comunque elencate dal sito
// nella stessa pagina "Ultim'ora", non è compito di questo aggregatore
// fare una scelta editoriale su cosa sia "vera" cronaca. Offset
// Italia/UTC approssimato per mese via `offsetItaliaPerMese()` sotto
// (+02:00 aprile-settembre, +01:00 il resto dell'anno) — sufficiente per
// ordinare le notizie fra loro, non per un orario al minuto esatto nei
// giorni di cambio ora legale. (RaiNews non usa più questa
// approssimazione dal 06/09/2026: la sua nuova fonte via API restituisce
// già un orario ISO esatto con offset — vedi `ingestNotizieFonteRainews()`
// sopra.)
const GIORNI_ABBR_ITA_NOTIZIE = { dom: 0, lun: 1, mar: 2, mer: 3, gio: 4, ven: 5, sab: 6 };

function offsetItaliaPerMese() {
  const meseIdx = new Date().getMonth();
  return meseIdx >= 3 && meseIdx <= 8 ? "+02:00" : "+01:00";
}

function parseDataCitynews(testoData) {
  if (!testoData) return null;
  const t = testoData.trim().toLowerCase().replace(/\s+/g, " ");

  const conGiorno = t.match(/^([a-zàèéìòù]{3}),\s*(\d{1,2}):(\d{2})$/);
  if (conGiorno) {
    const [, abbr, ore, minuti] = conGiorno;
    const targetDow = GIORNI_ABBR_ITA_NOTIZIE[abbr];
    if (targetDow === undefined) return null;
    const [anno, mese, giorno] = oggiEuropeRome().split("-").map(Number);
    const oggiUtc = new Date(Date.UTC(anno, mese - 1, giorno));
    let diff = oggiUtc.getUTCDay() - targetDow;
    if (diff <= 0) diff += 7;
    oggiUtc.setUTCDate(oggiUtc.getUTCDate() - diff);
    const dataStr = oggiUtc.toISOString().slice(0, 10);
    return `${dataStr}T${ore.padStart(2, "0")}:${minuti}:00${offsetItaliaPerMese()}`;
  }

  const soloOra = t.match(/^(\d{1,2}):(\d{2})$/);
  if (soloOra) {
    const [, ore, minuti] = soloOra;
    return `${oggiEuropeRome()}T${ore.padStart(2, "0")}:${minuti}:00${offsetItaliaPerMese()}`;
  }

  return null;
}

async function ingestNotizieFonteCitynews(fonte) {
  const res = await fetchConRetry(fonte.url, {
    headers: { "User-Agent": "Mozilla/5.0 (compatible; FVGMonitorBot/1.0)" },
  });
  if (!res.ok) {
    console.warn(`${fonte.fonte} non disponibile (HTTP ${res.status})`);
    return [];
  }
  const $ = cheerio.load(await res.text());
  const items = [];
  $("article.c-story").each((_, el) => {
    const $el = $(el);
    const $link = $el.find("a.o-link-text").first();
    const href = $link.attr("href");
    const titolo = $link.attr("aria-label")?.trim();
    const dataTesto = $el.find(".c-story__byline span").first().text();
    const data = parseDataCitynews(dataTesto);
    if (!href || !titolo || !data) return;
    items.push({
      titolo,
      link: href.startsWith("http") ? href : `${fonte.baseUrl}${href}`,
      data,
      fonte: fonte.fonte,
    });
  });
  return items;
}

const MESI_ITA_NOTIZIE = {
  gennaio: 0, febbraio: 1, marzo: 2, aprile: 3, maggio: 4, giugno: 5,
  luglio: 6, agosto: 7, settembre: 8, ottobre: 9, novembre: 10, dicembre: 11,
};

// Vedi il commento sopra FONTI_NOTIZIE_GORIZIA per il contesto completo
// di questa fonte (sbloccata il 06/09/2026 grazie all'outerHTML fornito
// dall'utente). Nessuna data/ora esplicita disponibile per gli articoli
// in griglia: si usa la data incorporata alla fine dello slug dell'URL
// (es. "-05-settembre-2026" o "-5-settembre-2026", giorno con o senza
// zero iniziale), con ora fissata a mezzogiorno Europe/Rome — sufficiente
// per l'ordinamento fra notizie, non per un "quanto tempo fa" preciso.
function parseDataDaSlugIlGoriziano(href) {
  if (!href) return null;
  const match = href.match(/-(\d{1,2})-([a-zàèéìòù]+)-(\d{4})\/?$/i);
  if (!match) return null;
  const [, giornoStr, meseNome, annoStr] = match;
  const mese = MESI_ITA_NOTIZIE[meseNome.toLowerCase()];
  if (mese === undefined) return null;
  const giorno = Number(giornoStr);
  const anno = Number(annoStr);
  const dataStr = `${anno}-${String(mese + 1).padStart(2, "0")}-${String(giorno).padStart(2, "0")}`;
  return `${dataStr}T12:00:00${offsetItaliaPerMese()}`;
}

// Il Goriziano — struttura verificata su outerHTML reale il 06/09/2026:
// un articolo "in evidenza" (`article#copertina`, wrappato da un `<a>`
// invece di contenerlo) più una griglia di `article.col-12.col-md-4`
// (ognuno con l'`<a>` come figlio) — gestiti con lo stesso selettore
// `main article` più un controllo su dove si trova il link.
async function ingestNotizieFonteIlGoriziano(fonte) {
  const res = await fetchConRetry(fonte.url, {
    headers: { "User-Agent": "Mozilla/5.0 (compatible; FVGMonitorBot/1.0)" },
  });
  if (!res.ok) {
    console.warn(`${fonte.fonte} non disponibile (HTTP ${res.status})`);
    return [];
  }
  const $ = cheerio.load(await res.text());
  const items = [];
  $("main article").each((_, el) => {
    const $article = $(el);
    const $parentLink = $article.parent("a");
    const href = $parentLink.length
      ? $parentLink.attr("href")
      : $article.find('a[href*="/articolo/"]').first().attr("href");
    const titolo = $article.find("header h2, header h3").first().text().trim();
    const data = parseDataDaSlugIlGoriziano(href);
    if (!href || !titolo || !data) return;
    items.push({
      titolo,
      // Il sito genera a volte un doppio slash dopo il dominio
      // (osservato sull'articolo "in evidenza" nell'outerHTML fornito
      // dall'utente) — normalizzato qui per pulizia del link mostrato.
      link: href.replace(/([^:]\/)\/+/g, "$1"),
      data,
      fonte: fonte.fonte,
    });
  });
  return items;
}

async function ingestNotizieProvincia(provinciaSlug, fonti) {
  const risultati = await Promise.allSettled(
    fonti.map((f) => {
      if (f.tipo === "rainews") return ingestNotizieFonteRainews(f);
      if (f.tipo === "citynews") return ingestNotizieFonteCitynews(f);
      if (f.tipo === "ilgoriziano") return ingestNotizieFonteIlGoriziano(f);
      return ingestNotizieFonteRss(f);
    })
  );

  risultati.forEach((r, i) => {
    if (r.status === "rejected") {
      console.warn(`Notizie ${provinciaSlug} — fonte "${fonti[i].fonte}" fallita:`, r.reason?.message ?? r.reason);
    }
  });

  // Log diagnostico temporaneo (06/09/2026) — introdotto per scoprire che
  // RaiNews TGR FVG restituiva 0 elementi (causa poi trovata: scraping
  // impossibile su una pagina svuotata di contenuto server-side, risolto
  // riscrivendo la fonte per usare l'API JSON del sito — vedi
  // ingestNotizieFonteRainews sopra). Lasciato per un'altra esecuzione
  // per confermare che il nuovo conteggio per RaiNews sia > 0; da
  // rimuovere una volta arrivata quella conferma.
  console.log(
    `Notizie ${provinciaSlug} — dettaglio per fonte: ` +
      risultati
        .map((r, i) => `${fonti[i].fonte}=${r.status === "fulfilled" ? r.value.length : "ERRORE"}`)
        .join(", ")
  );

  // Unione di tutte le fonti, ordinata cronologicamente (più recente
  // prima) — un'unica lista con la fonte indicata per ciascuna voce,
  // non un riquadro separato per fonte: per un aggregatore di notizie
  // locali l'ordine temporale conta più della provenienza (a differenza
  // di Piste Ciclabili, dove i cataloghi per fonte non si confrontano
  // fra loro). Nessuna deduplica fra fonti diverse: outlet diversi che
  // coprono la stessa notizia sono normali in un aggregatore, non un
  // difetto da correggere.
  const items = risultati
    .flatMap((r) => (r.status === "fulfilled" ? r.value : []))
    .filter((it) => it.titolo && it.link)
    .sort((a, b) => new Date(b.data).getTime() - new Date(a.data).getTime())
    .slice(0, 30);

  await upsertSnapshot(`notizie-provincia:${provinciaSlug}`, "notizie-provincia", provinciaSlug, {
    items,
    fonti: fonti.map((f) => ({ fonte: f.fonte, fonte_url: f.fonte_url })),
  });
  console.log(`Notizie ${provinciaSlug}: ${items.length} titoli da ${fonti.length} fonti`);
}

// ---------------------------------------------------------------------
// VENTO / BORA — API Monitoraggio Protezione Civile FVG
// Fonte: monitor.protezionecivile.fvg.it/api, licenza CC BY 4.0.
//
// Una stazione candidata per ciascuna provincia (scelte tra quelle con
// nome "meteo"/"S+M", più probabile abbiano un sensore vento — non
// verificato singolarmente come per Trieste). Per questo i sensori
// vengono risolti DINAMICAMENTE via /sensors invece di assumere ID
// fissi: se una stazione non ha il sensore vento, la ingestione per
// quella provincia viene saltata con un avviso, senza rompersi.
// ---------------------------------------------------------------------

const PC_API_BASE = "https://monitor.protezionecivile.fvg.it/api";

const STAZIONE_VENTO_PER_PROVINCIA = {
  trieste: 212, // "Trieste" — verificata
  udine: 558, // "Udine S+M" — verificata
  gorizia: 65, // "Gorizia aeroporto" — verificata
  pordenone: 131, // "Pordenone meteo" — verificata (567 "Pordenone S+M" ha il sensore ma nessuna misura recente)
};

const CODICI_SENSORE_VENTO = {
  direzione: "Dv",
  velocita: "Vv",
  raffica: "VvMax",
  direzioneRaffica: "DvMax",
};

async function sensoriStazione(stationId) {
  const res = await fetchConRetry(`${PC_API_BASE}/stations/${stationId}/sensors`);
  if (!res.ok) return [];
  const json = await res.json();
  return json.sensors ?? [];
}

async function ultimaMisura(stationId, sensorId) {
  const res = await fetchConRetry(`${PC_API_BASE}/stations/${stationId}/sensors/${sensorId}/measures/latest`);
  if (!res.ok) return null;
  const json = await res.json();
  return json.measures?.[0] ?? null;
}

// m/s → km/h, unità più familiare per il pubblico italiano
const msToKmh = (v) => (v == null ? null : Math.round(v * 3.6 * 10) / 10);

async function ingestVentoProvincia(provincia, stationId, nomeStazione, zona) {
  const sensori = await sensoriStazione(stationId);
  const trovaId = (codice) => sensori.find((s) => s.code === codice)?.id ?? null;

  const idVelocita = trovaId(CODICI_SENSORE_VENTO.velocita);
  if (!idVelocita) {
    console.warn(`Stazione "${nomeStazione}" (${provincia}) non ha un sensore vento — salto`);
    return;
  }

  const [direzione, velocita, raffica, direzioneRaffica] = await Promise.all([
    ultimaMisura(stationId, trovaId(CODICI_SENSORE_VENTO.direzione)),
    ultimaMisura(stationId, idVelocita),
    ultimaMisura(stationId, trovaId(CODICI_SENSORE_VENTO.raffica)),
    ultimaMisura(stationId, trovaId(CODICI_SENSORE_VENTO.direzioneRaffica)),
  ]);

  if (!velocita) {
    console.warn(`Nessuna misura vento disponibile per "${nomeStazione}" (${provincia})`);
    return;
  }

  const payload = {
    stazione: nomeStazione,
    aggiornato_al: velocita.dt,
    velocita_kmh: msToKmh(velocita.value),
    raffica_kmh: msToKmh(raffica?.value),
    direzione_gradi: direzione?.value ?? null,
    direzione_raffica_gradi: direzioneRaffica?.value ?? null,
  };

  await upsertSnapshot(`vento:${provincia}`, "vento", zona, payload);
  console.log(`Vento aggiornato (${provincia}):`, payload.velocita_kmh, "km/h");
}

async function ingestVento() {
  const ZONA_PER_PROVINCIA = { trieste: "C", udine: "B", gorizia: "C", pordenone: "A" };
  const nomiStazioni = { trieste: "Trieste", udine: "Udine S+M", gorizia: "Gorizia aeroporto", pordenone: "Pordenone meteo" };

  await Promise.all(
    Object.entries(STAZIONE_VENTO_PER_PROVINCIA).map(([provincia, stationId]) =>
      ingestVentoProvincia(provincia, stationId, nomiStazioni[provincia], ZONA_PER_PROVINCIA[provincia])
    )
  );
}

// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// VIABILITÀ — feed WFS pubblico di InfoViaggiando (Autostrade Alto
// Adriatico / rete BS-PD). Nessuna documentazione ufficiale trovata
// per questo endpoint (è quello usato internamente dalla loro mappa,
// non un'API dichiaratamente pubblica) — dato che i dati risultanti
// sono comunque informazioni di viabilità già mostrate pubblicamente
// sul loro sito, lo trattiamo con la stessa cautela riservata al feed
// ANSA: solo dati essenziali, nessuna rielaborazione oltre il
// filtraggio geografico, da rivalutare se il progetto cresce.
//
// Il feed copre una rete molto più ampia del FVG (fino a Brescia/
// Padova) — filtriamo per autostrade rilevanti E per area geografica.
// ---------------------------------------------------------------------

const AUTOSTRADE_FVG = new Set(["A4", "A23", "A28", "A34"]);
const BBOX_FVG = { latMin: 45.5, latMax: 46.7, lonMin: 12.3, lonMax: 13.9 };

function dentroFVG(lat, lon) {
  if (lat == null || lon == null) return false;
  return lat >= BBOX_FVG.latMin && lat <= BBOX_FVG.latMax && lon >= BBOX_FVG.lonMin && lon <= BBOX_FVG.lonMax;
}

async function ingestViabilita() {
  const url =
    "https://infoviaggiando.it/WFS/?service=WFS&request=GetFeature&version=1.1.0" +
    "&typename=PortaleWeb:EVENTI_LINEARI&outputFormat=application/json&CQL_FILTER=VIS_WEB=%27S%27";

  const res = await fetchConRetry(url);
  if (!res.ok) {
    console.warn(`Feed viabilità non disponibile (HTTP ${res.status})`);
    return;
  }

  const json = await res.json();
  const eventi = (json.features || [])
    .map((f) => f.properties)
    .filter(
      (p) =>
        AUTOSTRADE_FVG.has(p.AUTOSTRADA) &&
        (dentroFVG(p.LAT_INIZIO, p.LON_INIZIO) || dentroFVG(p.LAT_FINE, p.LON_FINE))
    )
    .map((p) => ({
      autostrada: p.AUTOSTRADA,
      carreggiata: p.CARREGGIATA,
      testo: p.TESTO_IT,
      inizio: p.DATA_INIZIO,
      fine: p.DATA_FINE,
      fonte: p.FONTE,
    }));

  await upsertSnapshot("viabilita:autostrade", "viabilita", null, {
    eventi,
    aggiornato_al: new Date().toISOString(),
  });
  console.log(`Viabilità aggiornata: ${eventi.length} eventi in FVG`);
}

// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// VIABILITÀ — Confini, lato sloveno: Promet.si "coreTileVector"
// (16/09/2026, sblocco richiesto dall'utente dopo la consegna MVP di
// Confini). Vedi il commento esteso in cima a lib/confini.ts per il
// contesto completo. Riassunto qui di cosa fa questo modulo e perché.
//
// Il sito pubblico Promet.si è una SPA che disegna la mappa con "vector
// tile" (formato Mapbox Vector Tile / protobuf) scaricate da
// `www.promet.si/coreTileVector{1,2,3}/tiles/prometsi_sl_SI/google4mb/
// {z}/{x}/{y}`. Analizzando un HAR fornito dall'utente (catturato dal
// suo browser reale) abbiamo scoperto che la tile z=7 x=68 y=45 contiene
// due livelli utili:
//  - `mejniprehodi`: anagrafica dei valichi sloveni (nome, strada,
//    tratto) — usata SOLO per verificare la corrispondenza coi nostri
//    valichi, non ri-ingerita qui (l'anagrafica statica è già in
//    lib/confini.ts).
//  - `dogodki_clustered` / `dogodki_nonclustered`: eventi di traffico
//    reali, con `Cesta` (codice strada), `IsZastoj` (coda), `QueueLength`
//    (lunghezza coda in metri), `DelaySeconds`, `IsRoadClosed`,
//    `isMejniPrehod`, `Title`/`Description`/`VzrokShortName` (causa).
//
// Confrontando i valori di `Cesta` con l'anagrafica `mejniprehodi`
// abbiamo trovato SOLO 4 dei nostri 11 valichi Italia-Slovenia in questa
// tile (le altre celle catturate nell'HAR, 68/44 e 69/44, non
// contenevano alcun valico nostro; 69/45 copre l'area Slovenia-Croazia,
// irrilevante): Fernetti (A3), Rabuiese/Škofije (H5), Sant'Andrea/
// Vrtojba (H4), Pesek/Kozina (probabilmente "G1-7", MAI osservato in un
// evento reale nel campione catturato — corrispondenza dedotta
// dall'anagrafica, da trattare con cautela). Gli altri 7 valichi verso
// la Slovenia (Basovizza, Lazzaretto, Casa Rossa, Stupizza, Uccea,
// Predil, Fusine) NON sono coperti: servirebbe una nuova cattura HAR con
// la mappa spostata più a nord (area Tarvisio/Bovec/Nova Gorica) per
// scoprire quali altre tile z/x/y li contengono.
//
// **Autenticazione**: a differenza dell'endpoint POST `/dc/agg` (che
// richiede un cookie `DARS_WAF` non ottenibile da uno script stateless),
// tutte le 52 richieste GET a `coreTileVector*` presenti nell'HAR
// (messe in sequenza dal browser ogni pochi secondi, stesse 4 tile
// ripetute) usano SOLO `User-Agent` + `Referer`, nessun cookie, e
// ricevono sempre HTTP 200 — nessuna eccezione. Per questo qui
// replichiamo esattamente quegli header (non lo User-Agent identificativo
// "FVGMonitorBot" usato altrove in questo file), invece di indovinare:
// è l'unica combinazione osservata funzionare davvero. **Non è però
// stato possibile testare la richiesta da questa sandbox di sviluppo
// (promet.si non raggiungibile direttamente da qui, stesso limite già
// visto altrove) — la prima conferma reale arriverà dai log della
// prossima esecuzione su GitHub Actions.** Se dovesse fallire (403/429/
// blocco WAF su user-agent non-browser), il fallback "mantieni l'ultimo
// dato valido e marca stale" sotto evita comunque di rompere la pagina.
//
// Nessuna libreria di decodifica protobuf/MVT è stata aggiunta come
// dipendenza: il formato (Mapbox Vector Tile, un semplice wrapper
// protobuf) è stato decodificato a mano e verificato contro dati reali
// catturati (vedi sessione di analisi), quindi il decoder qui sotto è
// volutamente minimale — legge solo i campi che usiamo davvero
// (mejniprehodi non viene nemmeno decodificato in produzione, solo i
// due livelli `dogodki_*`).
// ---------------------------------------------------------------------

const CONFINI_PROMETSI_TILE_URL =
  "https://www.promet.si/coreTileVector2/tiles/prometsi_sl_SI/google4mb/7/68/45";
const CONFINI_PROMETSI_HEADERS = {
  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36",
  Referer: "https://www.promet.si/sl/potovalni-casi",
};

// Corrispondenza valico → codice strada sloveno nel campo `Cesta` dei
// livelli `dogodki_*`, dedotta incrociando `mejniprehodi` (vedi sopra).
// Solo i 4 valichi confermati; tutti gli altri restano `null` (nessuna
// fonte sloveno-lato per loro, per ora).
const CONFINI_PROMETSI_STRADE = {
  fernetti: "A3",
  rabuiese: "H5",
  "sant-andrea-vrtojba": "H4",
  pesek: "G1-7", // dedotto dall'anagrafica, mai osservato in un evento reale — da riverificare
};

// --- decoder MVT/protobuf minimale (varint, zigzag, campi length-delimited) ---

function mvtLeggiVarint(buf, pos) {
  let result = 0;
  let shift = 0;
  let b;
  do {
    b = buf[pos++];
    result += (b & 0x7f) * 2 ** shift;
    shift += 7;
  } while (b & 0x80);
  return [result, pos];
}

function mvtZigzag(n) {
  return n % 2 === 0 ? n / 2 : -(n + 1) / 2;
}

function mvtLeggiCampo(buf, pos) {
  let tag;
  [tag, pos] = mvtLeggiVarint(buf, pos);
  const campo = Math.floor(tag / 8);
  const wireType = tag % 8;
  if (wireType === 0) {
    let val;
    [val, pos] = mvtLeggiVarint(buf, pos);
    return [campo, wireType, val, pos];
  } else if (wireType === 2) {
    let len;
    [len, pos] = mvtLeggiVarint(buf, pos);
    const val = buf.subarray(pos, pos + len);
    pos += len;
    return [campo, wireType, val, pos];
  } else if (wireType === 5) {
    const val = buf.subarray(pos, pos + 4);
    pos += 4;
    return [campo, wireType, val, pos];
  } else if (wireType === 1) {
    const val = buf.subarray(pos, pos + 8);
    pos += 8;
    return [campo, wireType, val, pos];
  }
  throw new Error(`wire type MVT non supportato: ${wireType}`);
}

function mvtDecodificaVarintImpacchettati(buf) {
  const out = [];
  let pos = 0;
  while (pos < buf.length) {
    let v;
    [v, pos] = mvtLeggiVarint(buf, pos);
    out.push(v);
  }
  return out;
}

function mvtDecodificaValore(buf) {
  let pos = 0;
  while (pos < buf.length) {
    let campo, wireType, val;
    [campo, wireType, val, pos] = mvtLeggiCampo(buf, pos);
    if (campo === 1) return Buffer.from(val).toString("utf-8"); // string_value
    if (campo === 4) return Number(val); // int_value (varint)
    if (campo === 5) return Number(val); // uint_value
    if (campo === 6) return mvtZigzag(val); // sint_value
    if (campo === 7) return Boolean(val); // bool_value
    // float_value/double_value (campo 2/3, wire type 5/1) non ci servono qui
  }
  return null;
}

function mvtDecodificaFeature(buf) {
  const feat = { tags: [] };
  let pos = 0;
  while (pos < buf.length) {
    let campo, wireType, val;
    [campo, wireType, val, pos] = mvtLeggiCampo(buf, pos);
    if (campo === 2) feat.tags = mvtDecodificaVarintImpacchettati(val);
  }
  return feat;
}

function mvtDecodificaLayer(buf) {
  const layer = { name: null, features: [], keys: [], values: [] };
  let pos = 0;
  while (pos < buf.length) {
    let campo, wireType, val;
    [campo, wireType, val, pos] = mvtLeggiCampo(buf, pos);
    if (campo === 1) layer.name = Buffer.from(val).toString("utf-8");
    else if (campo === 2) layer.features.push(mvtDecodificaFeature(val));
    else if (campo === 3) layer.keys.push(Buffer.from(val).toString("utf-8"));
    else if (campo === 4) layer.values.push(mvtDecodificaValore(val));
  }
  return layer;
}

function mvtDecodificaTile(buf) {
  const layers = [];
  let pos = 0;
  while (pos < buf.length) {
    let campo, wireType, val;
    [campo, wireType, val, pos] = mvtLeggiCampo(buf, pos);
    if (campo === 3) layers.push(mvtDecodificaLayer(val));
  }
  return layers;
}

function mvtFeatureATag(layer, feat) {
  const out = {};
  for (let i = 0; i < feat.tags.length; i += 2) {
    const chiave = layer.keys[feat.tags[i]];
    const valore = layer.values[feat.tags[i + 1]];
    if (chiave !== undefined) out[chiave] = valore;
  }
  return out;
}

// IMPORTANTE (verificato contro dati reali, vedi sessione di analisi):
// nei livelli `dogodki_*` di Promet.si, campi logicamente booleani/
// numerici come `IsZastoj`, `QueueLength`, `isMejniPrehod` sono codificati
// come STRINGHE letterali ("True"/"False", "0", "2000"), non come
// bool_value/int_value nativi del protobuf. Un `Boolean("False")`
// ingenuo in JS darebbe `true` (qualsiasi stringa non vuota è truthy) —
// serve un parsing esplicito.
function mvtValoreBooleano(v) {
  return v === "True" || v === true;
}
function mvtValoreNumerico(v) {
  if (typeof v === "number") return v;
  if (typeof v === "string" && v.trim() !== "") {
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  }
  return null;
}

async function ingestConfiniPrometsi() {
  const precedente = (await leggiSnapshotEsistente("confini-prometsi")) ?? { perValico: {} };
  const now = new Date().toISOString();

  let layers;
  try {
    const res = await fetchConRetry(CONFINI_PROMETSI_TILE_URL, { headers: CONFINI_PROMETSI_HEADERS });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const buf = Buffer.from(await res.arrayBuffer());
    layers = mvtDecodificaTile(buf);
  } catch (err) {
    // Fonte non disponibile: manteniamo l'ultimo dato valido (se c'è) e
    // lo marchiamo stale, stesso pattern di ingestNeveImpianti().
    const perValico = {};
    for (const id of Object.keys(CONFINI_PROMETSI_STRADE)) {
      const prec = precedente.perValico?.[id] ?? null;
      perValico[id] = prec
        ? { ...prec, controllatoIl: now, stale: true, errore: `${err.name ?? "Errore"}: ${err.message}` }
        : { eventi: [], osservatoIl: null, controllatoIl: now, stale: true, errore: `${err.name ?? "Errore"}: ${err.message}` };
    }
    await upsertSnapshot("confini-prometsi", "viabilita-confini", "SI", { generatoIl: now, perValico });
    console.warn(`Confini (Promet.si) non aggiornato: ${err.message}`);
    return;
  }

  const dogodkiClustered = layers.find((l) => l.name === "dogodki_clustered");
  const dogodkiNonClustered = layers.find((l) => l.name === "dogodki_nonclustered");
  const eventiGrezzi = [
    ...(dogodkiClustered ? dogodkiClustered.features.map((f) => mvtFeatureATag(dogodkiClustered, f)) : []),
    ...(dogodkiNonClustered ? dogodkiNonClustered.features.map((f) => mvtFeatureATag(dogodkiNonClustered, f)) : []),
  ];

  const perValico = {};
  for (const [id, codiceStrada] of Object.entries(CONFINI_PROMETSI_STRADE)) {
    const eventi = eventiGrezzi
      .filter((e) => e.Cesta === codiceStrada)
      .map((e) => ({
        titolo: testo(e.Title),
        descrizione: testo(e.Description),
        causa: testo(e.VzrokShortName),
        zastoj: mvtValoreBooleano(e.IsZastoj),
        codaM: mvtValoreNumerico(e.QueueLength),
        ritardoSec: mvtValoreNumerico(e.DelaySeconds),
        stradaChiusa: mvtValoreBooleano(e.IsRoadClosed),
        alValico: mvtValoreBooleano(e.isMejniPrehod),
      }));
    perValico[id] = { eventi, osservatoIl: now, controllatoIl: now, stale: false, errore: null };
  }

  await upsertSnapshot("confini-prometsi", "viabilita-confini", "SI", { generatoIl: now, perValico });
  console.log(
    `Confini (Promet.si) aggiornato: ${eventiGrezzi.length} eventi nella tile, ${Object.values(perValico).reduce((n, v) => n + v.eventi.length, 0)} rilevanti per i nostri valichi`
  );
}

// ---------------------------------------------------------------------
// CARBURANTI — prezzo medio regionale, fonte ufficiale MIMIT
// (Ministero delle Imprese e del Made in Italy), CSV pubblicato ogni
// mattina alle 8:00 con i prezzi medi di tutte le regioni italiane.
// A differenza di quasi tutti gli altri moduli, qui il dato è
// UN SOLO VALORE per l'intera regione (non per provincia) — è così
// che il ministero lo pubblica, non una nostra semplificazione.
//
// Benzina e gasolio self-service (self è l'unica modalità rilevante
// per questi due in Italia), GPL alla modalità servito (idem, il GPL
// non si fa self in Italia) — il file riporta anche il metano
// (servito), non ingerito perché non richiesto, ma stessa riga/
// formato: estendibile in futuro aggiungendo un'altra voce a
// CARBURANTI_TIPI.
//
// Formato CSV non standard: prima riga "Aggiornamento DD-MM-YYYY",
// seconda riga intestazione, poi un blocco di 4 righe per regione
// (Gasolio/Benzina self, GPL/Metano servito) in ordine alfabetico —
// verificato manualmente, nessun bisogno di una libreria CSV per un
// formato così semplice (solo ";" come separatore, nessun campo
// quotato).
// ---------------------------------------------------------------------

const CARBURANTI_CSV_URL = "https://www.mimit.gov.it/images/stories/carburanti/MediaRegionaleStradale.csv";
const REGIONE_CARBURANTI = "Friuli Venezia Giulia";

const CARBURANTI_TIPI = [
  { chiave: "benzina", tipologia: "Benzina", erogazione: "SELF" },
  { chiave: "gasolio", tipologia: "Gasolio", erogazione: "SELF" },
  { chiave: "gpl", tipologia: "GPL", erogazione: "SERVITO" },
];

async function ingestCarburanti() {
  const res = await fetchConRetry(CARBURANTI_CSV_URL);
  if (!res.ok) {
    console.warn(`CSV prezzi carburanti MIMIT non disponibile (HTTP ${res.status})`);
    return;
  }

  const testo = await res.text();
  const righe = testo.split("\n").map((r) => r.trim()).filter(Boolean);
  if (righe.length < 2) {
    console.warn("CSV prezzi carburanti vuoto o troppo corto");
    return;
  }

  const matchData = righe[0].match(/(\d{2})-(\d{2})-(\d{4})/);
  const aggiornatoAl = matchData ? `${matchData[3]}-${matchData[2]}-${matchData[1]}` : null;

  const righeDati = righe.slice(2).map((r) => r.split(";")); // salta "Aggiornamento ..." e l'intestazione

  const carburanti = {};
  for (const t of CARBURANTI_TIPI) {
    const riga = righeDati.find(
      ([regione, tipologia, erogazione]) =>
        regione === REGIONE_CARBURANTI && tipologia === t.tipologia && erogazione === t.erogazione
    );
    if (!riga) {
      console.warn(`Riga ${t.tipologia} non trovata per "${REGIONE_CARBURANTI}" nel CSV MIMIT`);
      continue;
    }
    const prezzo = Number(riga[3]);
    if (!Number.isFinite(prezzo)) {
      console.warn(`Prezzo ${t.tipologia} non numerico nel CSV MIMIT: "${riga[3]}"`);
      continue;
    }
    carburanti[t.chiave] = {
      prezzo_medio_eur_litro: Math.round(prezzo * 1000) / 1000,
      erogazione: t.erogazione === "SELF" ? "self" : "servito",
    };
  }

  if (Object.keys(carburanti).length === 0) {
    console.warn("Nessun prezzo carburante trovato nel CSV MIMIT");
    return;
  }

  await upsertSnapshot("carburanti", "carburanti", null, {
    carburanti,
    aggiornato_al: aggiornatoAl,
  });
  console.log(
    `Prezzi medi carburanti FVG aggiornati (${Object.keys(carburanti).length}): ${aggiornatoAl}`
  );
}

// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// EVENTI — scraping HTML della pagina eventi di turismofvg.it
// (portale ufficiale PromoTurismoFVG). La pagina è renderizzata
// server-side (verificato più volte: un semplice fetch restituisce già
// tutti gli eventi, senza bisogno di eseguire JavaScript), quindi
// niente browser headless necessario.
//
// Estesa il 17/09/2026 (richiesta esplicita dell'utente: pagina dedicata
// Eventi dentro Turismo). L'utente ha caricato un pacchetto generato con
// ChatGPT (`FVG_Monitor_Eventi_v2.zip`) che proponeva una pipeline
// separata (script TypeScript a sé via tsx, tabelle Supabase
// relazionali nuove — event_sources/event_locations/events/
// event_occurrences —, cron route Vercel) e uno scraping "a cascata" di
// TUTTE le ~450 schede evento (listing + apertura di ogni singola
// scheda) ad ogni sync. Architettura NON adottata: non coerente con
// questo progetto (un solo script, ingest-light.mjs, su GitHub Actions
// ogni 15 minuti, tabella `snapshots` singola) e troppo pesante per
// turismofvg.it (centinaia di richieste per esecuzione, ogni 15-30
// minuti, per sempre — il pacchetto stesso segnalava onestamente questo
// rischio). Scelta concordata con l'utente: solo i dati già visibili
// nella pagina elenco, nessuna apertura delle singole schede evento.
//
// **HTML reale fornito dall'utente prima di scrivere i selettori**
// (stessa disciplina già seguita per Agriturismi/bike routes/Sci — mai
// selettori scritti "a naso" da un riassunto WebFetch, che taglia via
// attributi/icone necessari qui). Scoperte rispetto ai selettori già in
// uso in precedenza:
// - Le card evento (`a.c-eventsResults__item`) esistono in 2 varianti,
//   "big" (una sola per pagina, la prima) e "small" (tutte le altre).
// - Categoria: variante big → testo diretto in `.info_category .col2`
//   ("Spettacoli teatrali"); variante small → attributo `title` di
//   `.info_date .col3` ("Musica") — entrambe leggibili direttamente,
//   nessun bisogno di decodificare lo slug dell'icona.
// - Immagine: presente su entrambe le varianti come
//   `background-image: url('...')` nello style dell'elemento `<a>`
//   stesso.
// - Orario: presente SOLO sulla variante big (`.info_hour .col2`).
// - **Nessuna data di fine evento nella card stessa** (né big né small),
//   solo un singolo giorno/mese. Un evento multi-giorno (es.
//   "Pordenonelegge", 16-20 settembre) sembra comparire con più card
//   distinte, una per ciascun giorno in cui è attivo, quando l'elenco è
//   filtrato su quell'intervallo — non con un'unica card che indica un
//   intervallo (il periodo completo è visibile solo nella sezione "in
//   evidenza" in cima alla pagina, 4 eventi scelti a mano dalla
//   redazione, non utile per uno scraping generico).
//
// **Filtro data lato server, dedotto dal form reale (NON verificato con
// una richiesta diretta da questa sessione)**: la pagina ha un form
// `GET /eventi` con campi `start`/`end` (date AAAA-MM-GG). Invece di
// scaricare l'elenco generico (finestra di default non chiara) e poi
// indovinare a quale giorno appartiene ciascuna card, qui interroghiamo
// SEMPRE esplicitamente una finestra nota di `EVENTI_FINESTRA_GIORNI`
// giorni (oggi→oggi+13, fuso Europe/Rome) — così ogni card restituita
// ha un giorno/mese risolvibile con certezza in una data ISO nota. Se
// un giorno/mese restituito non corrisponde a NESSUNA delle date
// attese, la card viene scartata con un avviso invece di essere
// ingerita con una data indovinata (mai inventare dati) — questo è
// anche il modo in cui ci accorgeremmo se l'assunzione sul filtro
// start/end si rivelasse sbagliata in produzione: controllare i log
// della prossima esecuzione GitHub Actions per l'avviso "card
// scartate". Stesso discorso per la combinazione `start`/`end` insieme
// a `page` (paginazione "carica altri" dentro un elenco già filtrato
// per data): non verificata con una richiesta reale da questa sessione,
// ma resa innocua dallo stesso controllo difensivo.
//
// Tetto di sicurezza `EVENTI_MAX_PAGINE_PER_FINESTRA` pagine (8
// card/pagina) sulla finestra di 14 giorni — un giorno eccezionalmente
// denso di eventi oltre il tetto semplicemente non compare per intero
// in quell'esecuzione (nessun errore, nessun dato inventato), invece di
// scaricare un numero di pagine potenzialmente enorme ad ogni run.
// ---------------------------------------------------------------------

const EVENTI_BASE_URL = "https://www.turismofvg.it/eventi";
const EVENTI_FINESTRA_GIORNI = 14; // oggi + 13 giorni successivi
const EVENTI_MAX_PAGINE_PER_FINESTRA = 12; // ~96 card, tetto di sicurezza

const EVENTI_MESI_ABBR_IT = ["GEN", "FEB", "MAR", "APR", "MAG", "GIU", "LUG", "AGO", "SET", "OTT", "NOV", "DIC"];

function eventiDataAggiungiGiorni(dataIso, giorni) {
  // Ancorato a mezzogiorno UTC per evitare che l'aggiunta di giorni
  // scavalchi un cambio di ora legale — stesso accorgimento già usato
  // altrove in questo file per calcoli di data.
  const d = new Date(`${dataIso}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() + giorni);
  return d.toISOString().slice(0, 10);
}

function eventiCostruisciFinestra(oggiIso) {
  const date = [];
  for (let i = 0; i < EVENTI_FINESTRA_GIORNI; i++) {
    const iso = eventiDataAggiungiGiorni(oggiIso, i);
    const [, meseNum, giornoNum] = iso.split("-").map(Number);
    date.push({ iso, giorno: String(giornoNum), mese: EVENTI_MESI_ABBR_IT[meseNum - 1] });
  }
  return date;
}

// Weekend "corrente" (sab+dom se oggi è già nel weekend) o il prossimo.
// Se oggi è domenica, il sabato del weekend in corso è ieri — fuori
// dalla finestra che interroghiamo (guardiamo solo in avanti nel
// tempo): in quel caso il weekend mostrato è solo la domenica odierna,
// limite intrinseco del non poter interrogare il passato, non un bug.
function eventiProssimoWeekend(oggiIso) {
  const giornoSettimana = new Date(`${oggiIso}T12:00:00Z`).getUTCDay(); // 0 domenica ... 6 sabato
  let giorniAlSabato;
  if (giornoSettimana === 6) giorniAlSabato = 0;
  else if (giornoSettimana === 0) giorniAlSabato = -1;
  else giorniAlSabato = 6 - giornoSettimana;
  const domenica = eventiDataAggiungiGiorni(oggiIso, giorniAlSabato + 1);
  return {
    sabato: giorniAlSabato < 0 ? null : eventiDataAggiungiGiorni(oggiIso, giorniAlSabato),
    domenica,
  };
}

function eventiUrlAssoluto(href) {
  if (!href) return null;
  return href.startsWith("http") ? href : `https://www.turismofvg.it${href}`;
}

function eventiEstraiImmagine($el) {
  const style = $el.attr("style") || "";
  const m = style.match(/background-image:\s*url\('([^']+)'\)/);
  return m ? eventiUrlAssoluto(m[1]) : null;
}

function eventiEstraiCard($, el) {
  const $el = $(el);
  const link = eventiUrlAssoluto($el.attr("href"));
  if (!link) return null;

  const giornoGrezzo = $el.find(".info_date .col1 strong").first().text().trim();
  const giorno = giornoGrezzo && !Number.isNaN(parseInt(giornoGrezzo, 10)) ? String(parseInt(giornoGrezzo, 10)) : "";
  const mese = $el.find(".info_date .col1 p").first().text().trim().toUpperCase();
  const luogo = $el.find(".info_location .col2, .info_date .col2").first().text().trim();
  const orario = $el.find(".info_hour .col2").first().text().trim();
  let categoria = $el.find(".info_category .col2").first().text().trim();
  if (!categoria) {
    const titleAttr = $el.find(".info_date .col3").first().attr("title");
    categoria = titleAttr ? titleAttr.trim() : "";
  }
  const titolo = $el.find(".item_title h1 strong, .item_title h2 strong").first().text().trim();
  const immagine = eventiEstraiImmagine($el);

  if (!titolo || !giorno || !mese) return null;
  return { titolo, luogo, giorno, mese, orario, categoria, immagine, link };
}

async function eventiFetchFinestra(startIso, endIso) {
  const card = [];
  for (let pagina = 0; pagina < EVENTI_MAX_PAGINE_PER_FINESTRA; pagina++) {
    const url = `${EVENTI_BASE_URL}?hidehighlights=true&start=${startIso}&end=${endIso}&page=${pagina}`;
    const res = await fetchConRetry(url, {
      headers: { "User-Agent": "Mozilla/5.0 (compatible; FVGMonitorBot/1.0)" },
    });
    if (!res.ok) {
      if (pagina === 0) throw new Error(`HTTP ${res.status}`);
      break; // pagina successiva non disponibile: fine paginazione, teniamo quanto raccolto finora
    }

    const $ = cheerio.load(await res.text());
    const trovate = $("a.c-eventsResults__item").toArray();
    if (trovate.length === 0) break;

    for (const el of trovate) {
      const c = eventiEstraiCard($, el);
      if (c) card.push(c);
    }

    if ($("a.js-loadmorebox__button").length === 0) break; // ultima pagina
  }
  return card;
}

async function ingestEventi() {
  const oggiIso = oggiEuropeRome();
  const finestra = eventiCostruisciFinestra(oggiIso);
  const ultimaIso = finestra[finestra.length - 1].iso;

  const card = await eventiFetchFinestra(oggiIso, ultimaIso);
  if (card.length === 0) {
    console.warn(
      "Eventi: nessuna card estratta — la struttura HTML potrebbe essere cambiata, oppure il filtro start/end non funziona come atteso"
    );
    return;
  }

  const finestraLookup = new Map(finestra.map((f) => [`${f.giorno}|${f.mese}`, f.iso]));

  const eventiConData = [];
  const visti = new Set();
  let scartate = 0;
  for (const c of card) {
    const dataIso = finestraLookup.get(`${c.giorno}|${c.mese}`);
    if (!dataIso) {
      scartate++;
      continue;
    }
    const chiave = `${c.link}|${dataIso}`;
    if (visti.has(chiave)) continue; // stessa card ripetuta da una pagina di "carica altri"
    visti.add(chiave);
    eventiConData.push({ ...c, dataIso });
  }

  if (scartate > 0) {
    console.warn(
      `Eventi: ${scartate} card scartate (giorno/mese fuori dalla finestra richiesta — possibile che il filtro start/end non funzioni come atteso)`
    );
  }

  eventiConData.sort((a, b) => (a.dataIso < b.dataIso ? -1 : a.dataIso > b.dataIso ? 1 : 0));

  const domaniIso = finestra[1]?.iso ?? null;
  const { sabato: sabatoIso, domenica: domenicaIso } = eventiProssimoWeekend(oggiIso);

  const oggi = eventiConData.filter((e) => e.dataIso === oggiIso);
  const domani = domaniIso ? eventiConData.filter((e) => e.dataIso === domaniIso) : [];
  const weekend = eventiConData.filter((e) => e.dataIso === sabatoIso || e.dataIso === domenicaIso);

  await upsertSnapshot("eventi:turismofvg", "eventi", null, {
    oggi,
    domani,
    weekend,
    prossimi: eventiConData,
    finestra: { da: oggiIso, a: ultimaIso },
    aggiornato_al: new Date().toISOString(),
  });
  console.log(
    `Eventi aggiornati: ${eventiConData.length} nella finestra ${oggiIso}→${ultimaIso} (oggi ${oggi.length}, domani ${domani.length}, weekend ${weekend.length})`
  );
}

// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// QUALITÀ ARIA — dataset PM10 su dati.friuliveneziagiulia.it (Socrata)
// Fonte: ARPA FVG, dataset "Aria - Particelle Sospese PM10" (id
// qp5k-6pvm). Dato giornaliero (non orario), con qualche giorno di
// ritardo per via del processo di validazione ARPA — normale, non un
// errore di ingestione.
//
// Come per il vento, cerchiamo dinamicamente una stazione per
// provincia (per nome contenente il capoluogo) invece di ID fissi,
// perché non sappiamo a priori quali stazioni saranno presenti nei
// dati più recenti.
// ---------------------------------------------------------------------

const ARIA_DATASET_URL = "https://www.dati.friuliveneziagiulia.it/resource/qp5k-6pvm.json";
const SOGLIA_PM10_UGM3 = 50; // limite giornaliero di legge

async function ingestQualitaAria() {
  const url = `${ARIA_DATASET_URL}?$order=data_misura DESC&$limit=300`;
  const res = await fetchConRetry(url);
  if (!res.ok) {
    console.warn(`Dataset qualità aria non disponibile (HTTP ${res.status})`);
    return;
  }

  const rows = await res.json();
  if (!Array.isArray(rows) || rows.length === 0) {
    console.warn("Dataset qualità aria vuoto");
    return;
  }

  // I dati più recenti disponibili (tutte le stazioni misurate quel giorno)
  const dataPiuRecente = rows[0].data_misura;
  const righeRecenti = rows.filter((r) => r.data_misura === dataPiuRecente);

  const NOMI_CITTA_PROVINCIA = { trieste: "Trieste", udine: "Udine", gorizia: "Gorizia", pordenone: "Pordenone" };

  const perProvincia = {};
  for (const provincia of Object.keys(NOMI_CITTA_PROVINCIA)) {
    const nomeCitta = NOMI_CITTA_PROVINCIA[provincia];
    const riga = righeRecenti.find((r) =>
      r.ubicazione?.toLowerCase().includes(nomeCitta.toLowerCase())
    );
    if (!riga) continue;

    const media = riga.media_giornaliera ? Number(riga.media_giornaliera) : null;
    perProvincia[provincia] = {
      stazione: riga.ubicazione,
      media_giornaliera: media,
      superamento: media !== null ? media > SOGLIA_PM10_UGM3 : null,
      dati_insufficienti: riga.dati_insuff === "True",
    };
  }

  if (Object.keys(perProvincia).length === 0) {
    console.warn("Nessuna stazione PM10 trovata per le 4 province");
    return;
  }

  await upsertSnapshot("aria:pm10", "aria", null, {
    data_misura: dataPiuRecente,
    soglia_ugm3: SOGLIA_PM10_UGM3,
    per_provincia: perProvincia,
  });
  console.log(`Qualità aria aggiornata (${Object.keys(perProvincia).length} province):`, dataPiuRecente);
}

// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// VOLI TRIESTE AIRPORT — scraping HTML, stesso approccio degli eventi:
// la pagina è renderizzata server-side (verificato), niente browser
// headless necessario. Struttura HTML verificata manualmente via
// devtools — se il sito cambia layout, questo parser andrà aggiornato.
// ---------------------------------------------------------------------

async function ingestVoli() {
  const res = await fetchConRetry("https://triesteairport.it/it/airport/voli-e-destinazioni/voli-in-tempo-reale/", {
    headers: { "User-Agent": "Mozilla/5.0 (compatible; FVGMonitorBot/1.0)" },
  });
  if (!res.ok) {
    console.warn(`Pagina voli non disponibile (HTTP ${res.status})`);
    return;
  }

  const html = await res.text();
  const $ = cheerio.load(html);

  const aggiornatoAlTesto = $(".updated-date").first().text().replace("Ultimo aggiornamento:", "").trim();

  const risultato = { partenze: [], arrivi: [] };
  $("table").each((_, table) => {
    const titolo = $(table).prevAll("h3").first().text().trim().toLowerCase();
    const chiave = titolo.includes("arriv") ? "arrivi" : titolo.includes("parten") ? "partenze" : null;
    if (!chiave) return;

    const righe = $(table).find("tr").slice(1); // salta l'intestazione (th)
    righe.each((_, tr) => {
      const celle = $(tr).find("td");
      if (celle.length < 5) return;
      risultato[chiave].push({
        volo: $(celle[0]).text().trim().replace(/\s+/g, " "),
        luogo: $(celle[1]).text().trim(),
        previsto: $(celle[2]).text().trim(),
        effettivo: $(celle[3]).text().trim(),
        note: $(celle[4]).text().trim(),
      });
    });
  });

  if (risultato.partenze.length === 0 && risultato.arrivi.length === 0) {
    console.warn("Nessun volo estratto — la struttura HTML della pagina potrebbe essere cambiata");
    return;
  }

  await upsertSnapshot("voli:trieste-airport", "voli", "C", {
    aggiornato_al_testo: aggiornatoAlTesto,
    aggiornato_al: new Date().toISOString(),
    ...risultato,
  });
  console.log(
    `Voli aggiornati: ${risultato.partenze.length} partenze, ${risultato.arrivi.length} arrivi`
  );
}

// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// PIOGGIA — stessa API PC FVG, stesse 4 stazioni già verificate per il
// vento (probabile abbiano anche il sensore pioggia, essendo stazioni
// meteo complete). Sensori risolti dinamicamente come per il vento.
// ---------------------------------------------------------------------

const CODICI_SENSORE_PIOGGIA = {
  ultimaOra: "P_1h",
  ultime24Ore: "Prec_24_ore",
};

async function ingestPioggiaProvincia(provincia, stationId, nomeStazione, zona) {
  const sensori = await sensoriStazione(stationId);
  const trovaId = (codice) => sensori.find((s) => s.code === codice)?.id ?? null;

  const idOra = trovaId(CODICI_SENSORE_PIOGGIA.ultimaOra);
  const id24Ore = trovaId(CODICI_SENSORE_PIOGGIA.ultime24Ore);
  if (!idOra && !id24Ore) {
    console.warn(`Stazione "${nomeStazione}" (${provincia}) non ha sensori pioggia — salto`);
    return;
  }

  const [ultimaOra, ultime24Ore] = await Promise.all([
    idOra ? ultimaMisura(stationId, idOra) : null,
    id24Ore ? ultimaMisura(stationId, id24Ore) : null,
  ]);

  if (!ultimaOra && !ultime24Ore) {
    console.warn(`Nessuna misura pioggia disponibile per "${nomeStazione}" (${provincia})`);
    return;
  }

  const payload = {
    stazione: nomeStazione,
    aggiornato_al: (ultimaOra || ultime24Ore).dt,
    pioggia_1h_mm: ultimaOra?.value !== undefined && ultimaOra?.value !== null ? Math.round(ultimaOra.value * 10) / 10 : null,
    pioggia_24h_mm: ultime24Ore?.value !== undefined && ultime24Ore?.value !== null ? Math.round(ultime24Ore.value * 10) / 10 : null,
  };

  await upsertSnapshot(`pioggia:${provincia}`, "pioggia", zona, payload);
  console.log(`Pioggia aggiornata (${provincia}):`, payload.pioggia_24h_mm, "mm/24h");
}

async function ingestPioggia() {
  const ZONA_PER_PROVINCIA = { trieste: "C", udine: "B", gorizia: "C", pordenone: "A" };
  const nomiStazioni = { trieste: "Trieste", udine: "Udine S+M", gorizia: "Gorizia aeroporto", pordenone: "Pordenone meteo" };

  await Promise.all(
    Object.entries(STAZIONE_VENTO_PER_PROVINCIA).map(([provincia, stationId]) =>
      ingestPioggiaProvincia(provincia, stationId, nomiStazioni[provincia], ZONA_PER_PROVINCIA[provincia])
    )
  );
}

// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// TEMPERATURA LIVE — stessa API PC FVG, stesse 4 stazioni di vento e
// pioggia (sensore "T"). A differenza del bollettino OSMER, questa
// fonte ha licenza CC BY 4.0 esplicita e non è soggetta al vincolo
// delle 24h sui dati real-time — possiamo mostrare la temperatura
// "adesso" legittimamente.
// ---------------------------------------------------------------------

async function ingestTemperaturaProvincia(provincia, stationId, nomeStazione, zona) {
  const sensori = await sensoriStazione(stationId);
  const idTemp = sensori.find((s) => s.code === "T")?.id ?? null;
  if (!idTemp) {
    console.warn(`Stazione "${nomeStazione}" (${provincia}) non ha un sensore temperatura — salto`);
    return;
  }

  const misura = await ultimaMisura(stationId, idTemp);
  if (!misura) {
    console.warn(`Nessuna misura temperatura disponibile per "${nomeStazione}" (${provincia})`);
    return;
  }

  await upsertSnapshot(`temperatura:${provincia}`, "temperatura", zona, {
    stazione: nomeStazione,
    aggiornato_al: misura.dt,
    temperatura_c: Math.round(misura.value * 10) / 10,
  });
  console.log(`Temperatura aggiornata (${provincia}):`, misura.value, "°C");
}

async function ingestTemperatura() {
  const ZONA_PER_PROVINCIA = { trieste: "C", udine: "B", gorizia: "C", pordenone: "A" };
  const nomiStazioni = { trieste: "Trieste", udine: "Udine S+M", gorizia: "Gorizia aeroporto", pordenone: "Pordenone meteo" };

  await Promise.all(
    Object.entries(STAZIONE_VENTO_PER_PROVINCIA).map(([provincia, stationId]) =>
      ingestTemperaturaProvincia(provincia, stationId, nomiStazioni[provincia], ZONA_PER_PROVINCIA[provincia])
    )
  );
}

// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// LIVELLI FIUMI — stessa API PC FVG, sensore "IDRO" (m). A differenza
// di vento/pioggia/temperatura, qui le stazioni NON sono le stesse 4
// meteo (i fiumi non passano per i capoluoghi) — stazioni idrometriche
// verificate singolarmente via /sensors: Gorizia idro (Isonzo),
// Latisana 1 idro (Tagliamento, provincia di Udine), Pordenone
// Noncello (il fiume che attraversa la città), Francovez Rosandra
// (Trieste non ha grandi fiumi, torrente Rosandra come rappresentante).
// ---------------------------------------------------------------------

const STAZIONE_IDRO_PER_PROVINCIA = {
  gorizia: { id: 66, nome: "Gorizia idro", fiume: "Isonzo" },
  udine: { id: 240, nome: "Latisana 1 idro", fiume: "Tagliamento" },
  pordenone: { id: 132, nome: "Pordenone Noncello", fiume: "Noncello" },
  trieste: { id: 602, nome: "Francovez Rosandra", fiume: "Rosandra" },
};

async function ingestFiumeProvincia(provincia, stazione, zona) {
  const sensori = await sensoriStazione(stazione.id);
  const idIdro = sensori.find((s) => s.code === "IDRO")?.id ?? null;
  if (!idIdro) {
    console.warn(`Stazione "${stazione.nome}" (${provincia}) non ha il sensore IDRO — salto`);
    return;
  }

  const misura = await ultimaMisura(stazione.id, idIdro);
  if (!misura) {
    console.warn(`Nessuna misura livello disponibile per "${stazione.nome}" (${provincia})`);
    return;
  }

  await upsertSnapshot(`fiume:${provincia}`, "fiume", zona, {
    stazione: stazione.nome,
    fiume: stazione.fiume,
    aggiornato_al: misura.dt,
    livello_m: Math.round(misura.value * 100) / 100,
  });
  console.log(`Livello fiume aggiornato (${provincia}, ${stazione.fiume}):`, misura.value, "m");
}

async function ingestFiumi() {
  const ZONA_PER_PROVINCIA = { trieste: "C", udine: "B", gorizia: "C", pordenone: "A" };

  await Promise.all(
    Object.entries(STAZIONE_IDRO_PER_PROVINCIA).map(([provincia, stazione]) =>
      ingestFiumeProvincia(provincia, stazione, ZONA_PER_PROVINCIA[provincia])
    )
  );
}

// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// LIVELLO MARE — stessa API PC FVG, sensore "LIV_MARE_IGM42" (m, datum
// geodetico IGM42). Rilevante soprattutto per Trieste (fenomeno
// dell'acqua alta), ma disponibile anche per Grado e Lignano — le 3
// stazioni costiere della regione. Sensore risolto dinamicamente per
// coerenza con gli altri moduli, anche se finora sempre con id 86.
// ---------------------------------------------------------------------

const STAZIONI_MARE = [
  { slug: "trieste", id: 502, nome: "Trieste" },
  { slug: "grado", id: 68, nome: "Grado" },
  { slug: "lignano", id: 77, nome: "Lignano" },
];

async function ingestMareStazione(stazione) {
  const sensori = await sensoriStazione(stazione.id);
  const idLivello = sensori.find((s) => s.code === "LIV_MARE_IGM42")?.id ?? null;
  if (!idLivello) {
    console.warn(`Stazione "${stazione.nome}" non ha il sensore livello mare — salto`);
    return;
  }

  const misura = await ultimaMisura(stazione.id, idLivello);
  if (!misura) {
    console.warn(`Nessuna misura livello mare disponibile per "${stazione.nome}"`);
    return;
  }

  await upsertSnapshot(`mare:${stazione.slug}`, "mare", null, {
    stazione: stazione.nome,
    aggiornato_al: misura.dt,
    livello_m: Math.round(misura.value * 100) / 100,
  });
  console.log(`Livello mare aggiornato (${stazione.nome}):`, misura.value, "m IGM42");
}

async function ingestMare() {
  await Promise.all(STAZIONI_MARE.map((s) => ingestMareStazione(s)));
}

// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// MAREE (02/10/2026, richiesto dall'utente il 13/09/2026) — due
// sotto-funzionalità distinte, con fonti e affidabilità diverse, perciò
// in snapshot separati (categoria "maree", id diversi da "mare:*" che
// resta il livello mare in tempo reale già esistente sopra):
//
// 1) "maree-osservate:{slug}" — picchi di alta/bassa marea REALMENTE
//    REGISTRATI oggi. Fonte: la stessa API Protezione Civile FVG già
//    usata per il livello mare in tempo reale, ma un endpoint diverso
//    e non documentato, scoperto per tentativi il 02/10/2026:
//    /stations/{id}/sensors/{id}/measures (SENZA "/latest") restituisce
//    l'intera serie della giornata corrente, un punto ogni 15 minuti,
//    invece della sola ultima misura. Stesso sensore LIV_MARE_IGM42
//    (id 86), confermato presente su tutte e 3 le stazioni costiere
//    (Trieste 502, Grado 68, Lignano 77). Dato 100% ufficiale e
//    gratuito, nessuna nuova fonte esterna.
//
// 2) "maree-previste:{slug}" — previsione di alta/bassa marea per i
//    prossimi giorni. In Italia non esiste una fonte ufficiale/gratuita
//    con previsioni astronomiche aggiornate per queste 3 località (vedi
//    ricerca del 02/10/2026: CNR-ISMAR è statico e fermo al 2015-2019,
//    le "Previsioni di marea per il Golfo di Trieste" dell'Università di
//    Trieste sono un PDF annuale e riguardano solo Trieste). Scelta
//    dell'utente ("procedi con lo scraping", 02/10/2026): tide-forecast.com,
//    sito commerciale senza API pubblica ma con pagine dedicate esatte per
//    Trieste/Grado/Lignano. Ogni pagina incorpora però, in uno <script>,
//    un oggetto JS strutturato `window.FCGON = {...}` con gli stessi dati
//    della tabella HTML (tideDays[].tides[], ognuno con timestamp/height/
//    type "high"|"low"|null) — estratto via regex + JSON.parse, non vero
//    e proprio DOM-scraping. Verificato manualmente (pagina incollata
//    dall'utente, il sandbox di sviluppo non raggiunge questo host) per
//    tutte e 3 le località il 02/10/2026: stesso schema, dato sempre
//    fresco (tideDays[0].date = oggi, serverTime coerente col footer
//    "Generated ... UTC" della pagina). Fonte non ufficiale e non
//    documentata: se tide-forecast.com cambia pagina, questo modulo può
//    smettere di funzionare senza preavviso — fallisce in modo silenzioso
//    (solo un warning in log), non blocca gli altri moduli.
// ---------------------------------------------------------------------

// Trova i picchi (massimi/minimi locali) in una serie di misure ordinate
// cronologicamente, confrontando ogni punto con il precedente e il
// successivo. I dati del sensore sono una curva di marea reale, quindi
// liscia su scala di ore — un confronto punto-a-punto è sufficiente senza
// bisogno di filtri anti-rumore più sofisticati. L'unico caso da gestire
// è un plateau (più punti identici consecutivi al vertice): si accorpano
// tenendo solo il valore più estremo, per non riportare due "alte" o due
// "basse" a pochi minuti di distanza l'una dall'altra.
function trovaPicchiMarea(punti) {
  if (punti.length < 3) return [];
  const grezzi = [];
  for (let i = 1; i < punti.length - 1; i++) {
    const prima = punti[i - 1].value;
    const centro = punti[i].value;
    const dopo = punti[i + 1].value;
    if (centro > prima && centro >= dopo) {
      grezzi.push({ ...punti[i], tipo: "alta" });
    } else if (centro < prima && centro <= dopo) {
      grezzi.push({ ...punti[i], tipo: "bassa" });
    }
  }
  const puliti = [];
  for (const p of grezzi) {
    const ultimo = puliti[puliti.length - 1];
    if (ultimo && ultimo.tipo === p.tipo) {
      const migliore =
        p.tipo === "alta" ? (p.value > ultimo.value ? p : ultimo) : p.value < ultimo.value ? p : ultimo;
      puliti[puliti.length - 1] = migliore;
    } else {
      puliti.push(p);
    }
  }
  return puliti;
}

async function serieOggiStazione(stationId, sensorId) {
  const res = await fetchConRetry(`${PC_API_BASE}/stations/${stationId}/sensors/${sensorId}/measures`);
  if (!res.ok) return [];
  const json = await res.json();
  return json.measures ?? [];
}

// Il campo `dt` di questa API è "YYYY-MM-DD HH:MM:SS" SENZA fuso
// indicato — non documentato, e qui NON va assunto. Verificato
// empiricamente il 02/10/2026 (non per deduzione): confrontando l'ora
// reale al momento della richiesta con `dt` dell'ultima misura di
// /measures/latest, lo scarto risultava di soli ~15 minuti se si
// interpreta `dt` come UTC (coerente con la cadenza di campionamento) —
// sarebbe stato di oltre 2 ore se `dt` fosse già ora locale italiana
// (CEST, UTC+2 in questo periodo), scarto implausibile per un endpoint
// "latest". `dt` è quindi UTC "nudo": qui si corregge solo il formato
// (serve T/Z per un parsing inequivocabile con `new Date()` in
// qualunque motore/fuso d'esecuzione — lo spazio al posto della "T" è
// interpretato in modo incoerente tra i vari browser), nessuna reale
// conversione di fuso.
function dtPcFvgAIso(dt) {
  return `${dt.replace(" ", "T")}Z`;
}

async function ingestMareeOsservateStazione(stazione) {
  const sensori = await sensoriStazione(stazione.id);
  const idLivello = sensori.find((s) => s.code === "LIV_MARE_IGM42")?.id ?? null;
  if (!idLivello) {
    console.warn(`Maree osservate: stazione "${stazione.nome}" non ha il sensore livello mare — salto`);
    return;
  }

  const misure = await serieOggiStazione(stazione.id, idLivello);
  if (misure.length < 3) {
    console.warn(`Maree osservate: serie di oggi insufficiente per "${stazione.nome}" (${misure.length} punti)`);
    return;
  }

  const punti = misure
    .map((m) => ({ dt: dtPcFvgAIso(m.dt), value: m.value }))
    .sort((a, b) => new Date(a.dt) - new Date(b.dt));

  const picchi = trovaPicchiMarea(punti).map((p) => ({
    ora: p.dt,
    altezza_m: Math.round(p.value * 100) / 100,
    tipo: p.tipo,
  }));

  // Serie completa (non solo i picchi) — usata dal grafico "Andamento di
  // oggi" (MareeGraficoOggi.tsx), aggiunta il 02/10/2026. ~60-96 punti
  // (ogni 15 minuti dalla mezzanotte a "adesso"), peso trascurabile.
  const serie = punti.map((p) => ({ ora: p.dt, altezza_m: Math.round(p.value * 100) / 100 }));

  await upsertSnapshot(`maree-osservate:${stazione.slug}`, "maree", null, {
    stazione: stazione.nome,
    aggiornato_al: punti[punti.length - 1].dt,
    picchi,
    serie,
  });
  console.log(`Maree osservate aggiornate (${stazione.nome}):`, picchi.length, "picchi,", serie.length, "punti serie");
}

async function ingestMareeOsservate() {
  await Promise.all(STAZIONI_MARE.map((s) => ingestMareeOsservateStazione(s)));
}

const STAZIONI_MAREE_PREVISTE = [
  { slug: "trieste", nome: "Trieste", url: "https://www.tide-forecast.com/tide/Trieste-Italy/tide-times" },
  { slug: "grado", nome: "Grado", url: "https://www.tide-forecast.com/tide/Grado-1/tide-times" },
  { slug: "lignano", nome: "Lignano", url: "https://www.tide-forecast.com/tide/Lignano-Sabbiadoro/tide-times" },
];

// Quante giornate di previsione salvare per stazione — la pagina ne offre
// fino a ~30, ma il frontend mostra solo i prossimi giorni ("Prossimi
// giorni (previsione)"): 10 è ampiamente sufficiente ed evita di
// appesantire lo snapshot senza motivo.
const MAREE_PREVISTE_GIORNI_MAX = 10;

// Estrae l'oggetto `window.FCGON = {...};` incorporato nella pagina.
// L'ancora sul delimitatore successivo (`//]]>`, chiusura del CDATA dello
// <script> che lo contiene in tutte le pagine verificate) rende il match
// univoco anche se il JSON stesso contenesse la sottostringa "};" al suo
// interno — il motore regex continua ad estendere il blocco catturato
// (lazy) finché non trova anche quel delimitatore, che compare una sola
// volta nella pagina.
function estraiFcgon(html) {
  const m = html.match(/window\.FCGON\s*=\s*(\{[\s\S]*?\});\s*\r?\n\s*\/\/\]\]>/);
  if (!m) return null;
  try {
    return JSON.parse(m[1]);
  } catch {
    return null;
  }
}

async function ingestMareePrevisteStazione(stazione) {
  let res;
  try {
    res = await fetchConRetry(stazione.url, {
      headers: { "User-Agent": "Mozilla/5.0 (compatible; fvgmonitor/1.0; +https://fvgmonitor.vercel.app)" },
    });
  } catch (err) {
    console.warn(`Maree previste: richiesta fallita per "${stazione.nome}" — ${err.message}`);
    return;
  }
  if (!res.ok) {
    console.warn(`Maree previste: risposta ${res.status} per "${stazione.nome}" — salto`);
    return;
  }

  const html = await res.text();
  const fcgon = estraiFcgon(html);
  if (!fcgon || !Array.isArray(fcgon.tideDays)) {
    console.warn(`Maree previste: blocco FCGON non trovato/non valido per "${stazione.nome}" — il sito potrebbe aver cambiato formato`);
    return;
  }

  const giorni = fcgon.tideDays.slice(0, MAREE_PREVISTE_GIORNI_MAX).map((giorno) => ({
    data: giorno.date,
    picchi: (giorno.tides ?? [])
      .filter((t) => t.type === "high" || t.type === "low")
      .map((t) => ({
        ora: new Date(t.timestamp * 1000).toISOString(),
        altezza_m: Math.round(t.height * 100) / 100,
        tipo: t.type === "high" ? "alta" : "bassa",
      })),
  }));

  // Curva completa di oggi (anche i punti intermedi con type:null, non
  // solo i picchi) — usata dal grafico "Andamento di oggi"
  // (MareeGraficoOggi.tsx, 02/10/2026), non dalla lista "Prossimi giorni"
  // sopra. `tideDays[0]` è sempre la giornata corrente (verificato per
  // tutte e 3 le località il 02/10/2026 — vedi sezione MAREE in
  // README.md). Punti ogni 10 minuti circa, ~150 al massimo: peso
  // trascurabile sullo snapshot.
  const serieOggi = (fcgon.tideDays[0]?.tides ?? [])
    .filter((t) => typeof t.height === "number" && typeof t.timestamp === "number")
    .map((t) => ({
      ora: new Date(t.timestamp * 1000).toISOString(),
      altezza_m: Math.round(t.height * 100) / 100,
    }))
    .sort((a, b) => new Date(a.ora) - new Date(b.ora));

  await upsertSnapshot(`maree-previste:${stazione.slug}`, "maree", null, {
    stazione: stazione.nome,
    aggiornato_al: new Date(fcgon.serverTime * 1000).toISOString(),
    fonte: "tide-forecast.com",
    giorni,
    serieOggi,
  });
  console.log(
    `Maree previste aggiornate (${stazione.nome}):`,
    giorni.length,
    "giorni,",
    serieOggi.length,
    "punti serie oggi"
  );
}

async function ingestMareePreviste() {
  await Promise.all(STAZIONI_MAREE_PREVISTE.map((s) => ingestMareePrevisteStazione(s)));
}

// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// BALNEAZIONE — qualità delle acque di balneazione, dataset Socrata
// "Acqua - Acque di Balneazione" (id fpj6-y9vk) su
// dati.friuliveneziagiulia.it, esiti dei prelievi ARPA FVG (rete
// ufficiale ex D.Lgs 116/2008). 66 punti di monitoraggio in tutta la
// regione, sia acque marino-costiere (mare) sia acque interne (laghi,
// fiumi torrenti) — non solo le 4 città capoluogo come quasi tutti gli
// altri moduli.
//
// Provincia ricavata dal codice `id_area_balneazione` stesso invece
// che dal nome (più affidabile, verificato manualmente sui 66 punti):
// formato "IT006" + codice provincia ISTAT a 3 cifre + comune + id
// progressivo, es. "IT006032001007" → 032 = Trieste. Codici FVG:
// 030 Udine, 031 Gorizia, 032 Trieste, 093 Pordenone.
//
// Esito "favorevole/sfavorevole" calcolato sul singolo prelievo più
// recente per ciascun punto, confrontando enterococchi intestinali ed
// Escherichia coli con i valori limite per singolo campione
// dell'Allegato A del D.Lgs 116/2008 (diversi tra acque marine e
// acque interne — verificati su testo del decreto e su una fonte
// indipendente per le sole acque marine, che coincide):
//   acque marino-costiere: enterococchi > 200 e/o E. coli > 500 UFC/100ml
//   acque interne:         enterococchi > 500 e/o E. coli > 1000 UFC/100ml
// Non è la classificazione stagionale eccellente/buona/sufficiente/
// scarsa (quella si basa sul 95°/90° percentile di 4 stagioni di
// prelievi, non riproducibile da qui) — è l'indicatore "si può fare il
// bagno adesso o no", lo stesso usato per i divieti temporanei
// comunali. Va comunque intesa come indicazione, non sostituisce
// un'eventuale ordinanza sindacale ufficiale.
//
// I valori dei parametri nel dataset sono stringhe tipo "< 10" (sotto
// il limite di rilevabilità) invece di numeri puri — estraiamo la
// parte numerica con una regex, sufficiente per il confronto con la
// soglia (un "< 10" è comunque ben sotto qualsiasi soglia rilevante).
// ---------------------------------------------------------------------

const BALNEAZIONE_DATASET_URL = "https://www.dati.friuliveneziagiulia.it/resource/fpj6-y9vk.json";

const PROVINCIA_DA_CODICE_ISTAT = { "030": "udine", "031": "gorizia", "032": "trieste", "093": "pordenone" };

const SOGLIE_BALNEAZIONE = {
  marine: { enterococchi: 200, ecoli: 500 },
  interne: { enterococchi: 500, ecoli: 1000 },
};

function parseValoreMicrobiologico(v) {
  if (v === null || v === undefined) return null;
  // Richiede almeno una cifra (non solo un punto) — valori come "N.D."
  // (non determinato) non devono essere interpretati come 0.
  const m = String(v).replace(",", ".").match(/\d+(\.\d+)?/);
  return m ? Number(m[0]) : null;
}

function provinciaDaIdBalneazione(id) {
  const m = /^IT006(\d{3})/.exec(id ?? "");
  return m ? PROVINCIA_DA_CODICE_ISTAT[m[1]] ?? null : null;
}

async function ingestBalneazione() {
  const url = `${BALNEAZIONE_DATASET_URL}?$order=data DESC&$limit=1000`;
  const res = await fetchConRetry(url);
  if (!res.ok) {
    console.warn(`Dataset balneazione non disponibile (HTTP ${res.status})`);
    return;
  }

  const rows = await res.json();
  if (!Array.isArray(rows) || rows.length === 0) {
    console.warn("Dataset balneazione vuoto");
    return;
  }

  // Un solo prelievo per punto — il più recente (righe già ordinate
  // per data decrescente, teniamo la prima occorrenza di ogni id)
  const puntiPerId = new Map();
  for (const r of rows) {
    if (!r.id_area_balneazione || puntiPerId.has(r.id_area_balneazione)) continue;
    puntiPerId.set(r.id_area_balneazione, r);
  }

  const perProvincia = {};
  for (const r of puntiPerId.values()) {
    const provincia = provinciaDaIdBalneazione(r.id_area_balneazione);
    if (!provincia) continue; // punto fuori regione o codice non riconosciuto — non dovrebbe capitare

    const interna = r.categoria_acque?.toLowerCase().includes("interna") ?? false;
    const soglie = interna ? SOGLIE_BALNEAZIONE.interne : SOGLIE_BALNEAZIONE.marine;

    const enterococchi = parseValoreMicrobiologico(r.enterococchi_intestinali);
    const ecoli = parseValoreMicrobiologico(r.escherichia_coli);

    let esito = "nd";
    if (enterococchi !== null || ecoli !== null) {
      const supera =
        (enterococchi !== null && enterococchi > soglie.enterococchi) ||
        (ecoli !== null && ecoli > soglie.ecoli);
      esito = supera ? "sfavorevole" : "favorevole";
    }

    if (!perProvincia[provincia]) {
      perProvincia[provincia] = { totale: 0, favorevoli: 0, sfavorevoli: 0, nd: 0, punti_sfavorevoli: [], aggiornato_al: r.data };
    }
    const p = perProvincia[provincia];
    p.totale++;
    p[esito === "nd" ? "nd" : esito === "favorevole" ? "favorevoli" : "sfavorevoli"]++;
    if (esito === "sfavorevole") {
      p.punti_sfavorevoli.push({ nome: r.nome, enterococchi, ecoli, data: r.data });
    }
    if (r.data > p.aggiornato_al) p.aggiornato_al = r.data;
  }

  if (Object.keys(perProvincia).length === 0) {
    console.warn("Nessun punto di balneazione trovato");
    return;
  }

  await upsertSnapshot("balneazione", "balneazione", null, { per_provincia: perProvincia });
  const puntiSfavorevoli = Object.values(perProvincia).reduce((n, p) => n + p.sfavorevoli, 0);
  console.log(
    `Balneazione aggiornata: ${puntiPerId.size} punti, ${puntiSfavorevoli} sfavorevoli`
  );
}

// ---------------------------------------------------------------------
// FARMACIE — dataset Socrata "Farmacie di turno" (id jbxd-m6xe) su
// dati.friuliveneziagiulia.it: elenco completo delle farmacie aperte al
// pubblico in FVG, con le fasce di apertura straordinaria (turno) oltre
// a quelle ordinarie. Aggiornato dalla Regione ogni giorno alle 01:00,
// 417 farmacie totali. La finestra dati copre "oggi + domani mattina"
// (verificato: min/max di orari_0_da sono risultati rispettivamente
// oggi 00:00 e domani ~09:00 nello stesso giorno di interrogazione) —
// **non** una tabella oraria settimanale permanente: è uno snapshot che
// dà solo le fasce (normali e turno) di OGGI per ciascuna farmacia,
// aggiornato ogni giorno. Per questo l'orario "ordinario" mostrato in
// `/farmacie-tutte` (26/08/2026, vedi sotto) è "l'orario di oggi", non
// un orario settimanale fisso — la distinzione va tenuta chiara in UI,
// non è un dato inventato ma nemmeno un vero orario "Lun-Sab" completo.
//
// Ogni farmacia ha fino a 17 fasce orarie (orari_0_* … orari_16_*: campi
// *_da, *_a, *_tipo), con tipo "normale" (orario ordinario) o "turno"
// (apertura straordinaria: sabato pomeriggio, festivo, notturno...).
// Una farmacia è "di turno oggi" se ha almeno una fascia tipo "turno"
// che INIZIA oggi (data di orari_N_da == oggi) — la finestra è
// autosufficiente per ciascun giorno: un turno notturno che finisce
// domani mattina compare comunque nel record di "oggi" con orari_N_da
// che parte esattamente da oggi 00:00, non serve incrociare col giorno
// prima. I valori *_da/*_a sono trattati come stringa (confronto sui
// primi 10 caratteri "YYYY-MM-DD"), senza passare da new Date(): non è
// documentato se il dataset esprime l'ora in UTC o già in orario locale
// italiano, e gli orari osservati (es. turno serale-notturno 20:00–08:30
// del giorno dopo) sono coerenti solo con un'interpretazione "ora
// locale già inclusa nella stringa" — usare Date rischierebbe di
// applicare un fuso sbagliato due volte.
//
// "Oggi" va comunque calcolato in fuso orario Europe/Rome (questo
// script gira su GitHub Actions in UTC) per sapere QUALE giorno stiamo
// cercando nel dataset — stessa cautela già documentata per
// formattaOrarioRichiesta() in app/api/treni/[tipo]/[stazione]/route.ts.
//
// Provincia ricavata dal campo idcomune (codice ISTAT del comune, senza
// zero iniziale, es. "30049" Udine, "93033" Pordenone) — prefisso a 2
// cifre della provincia ISTAT: 30 Udine, 31 Gorizia, 32 Trieste, 93
// Pordenone. Stesso schema di provinciaDaIdBalneazione ma formato
// diverso (qui il codice non ha il prefisso "IT006").
//
// Estensione 26/08/2026: la snapshot ora contiene TUTTE le farmacie
// (non solo quelle di turno oggi), ciascuna con TUTTE le proprie fasce
// di oggi (`orariOggi`, normali E turno, non solo turno) — richiesto
// dall'utente per una pagina "Tutte le farmacie" (`/farmacie-tutte`)
// accanto a quella già esistente "Farmacie di turno" (`/farmacie-di-
// turno`), sullo stesso modello hub+pagine di Sport e Strutture
// ricettive. Un'unica ingestione, un'unica snapshot Supabase — le due
// pagine filtrano client-side lo stesso dato (`diTurnoOggi()` in
// `lib/farmacie.ts`), nessun bisogno di due fetch separati.
// ---------------------------------------------------------------------

const FARMACIE_DATASET_URL = "https://www.dati.friuliveneziagiulia.it/resource/jbxd-m6xe.json";

const PROVINCIA_DA_PREFISSO_ISTAT_COMUNE = { "30": "udine", "31": "gorizia", "32": "trieste", "93": "pordenone" };

function provinciaDaIdComuneFarmacia(idcomune) {
  // BUG corretto il 26/08/2026: un `.padStart(6, "0")` qui prima dello
  // slice prependeva uno zero spurio — verificato con dati reali
  // (`$select=idcomune&$group=idcomune`) che idcomune è SEMPRE lungo
  // esattamente 5 caratteri (es. "32006" Trieste, "30129" Udine, "31007"
  // Gorizia, "93033" Pordenone), mai 6. Il padStart trasformava "30129"
  // in "030129" e lo slice(0,2) prendeva "03" invece di "30" — nessuna
  // provincia veniva MAI riconosciuta, ogni riga del dataset scartata
  // silenziosamente (`if (!provincia...) continue`), zero farmacie in
  // ogni pagina. Bug latente fin dall'implementazione originale (mai
  // stato notato prima perché il modulo non era ancora stato verificato
  // in produzione) — trovato dall'utente che segnalava pagine vuote.
  const s = String(idcomune ?? "");
  return PROVINCIA_DA_PREFISSO_ISTAT_COMUNE[s.slice(0, 2)] ?? null;
}

// en-CA produce direttamente "YYYY-MM-DD", comodo per il confronto per
// prefisso con i valori orari_N_da del dataset.
function oggiEuropeRome() {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Rome" }).format(new Date());
}

async function ingestFarmacie() {
  const url = `${FARMACIE_DATASET_URL}?$limit=1000`;
  const res = await fetchConRetry(url);
  if (!res.ok) {
    console.warn(`Dataset farmacie non disponibile (HTTP ${res.status})`);
    return;
  }

  const rows = await res.json();
  if (!Array.isArray(rows) || rows.length === 0) {
    console.warn("Dataset farmacie vuoto");
    return;
  }

  const oggi = oggiEuropeRome();
  const perProvincia = {};

  for (const r of rows) {
    const provincia = provinciaDaIdComuneFarmacia(r.idcomune);
    const nome = testo(r.insegna) ?? testo(r.ragionesociale);
    if (!provincia || !nome) continue; // comune fuori regione, o riga senza nome — non dovrebbe capitare

    // Fino a 17 fasce orarie per farmacia (orari_0_* … orari_16_*): tutte
    // quelle che iniziano oggi, normali E turno (non solo turno — vedi
    // nota sopra, serve anche alla pagina "Tutte le farmacie").
    const orariOggi = [];
    for (let i = 0; i <= 16; i++) {
      const tipo = r[`orari_${i}_tipo`];
      const da = r[`orari_${i}_da`];
      if ((tipo === "normale" || tipo === "turno") && typeof da === "string" && da.slice(0, 10) === oggi) {
        orariOggi.push({ da, a: r[`orari_${i}_a`] ?? null, tipo });
      }
    }
    orariOggi.sort((a, b) => a.da.localeCompare(b.da));

    if (!perProvincia[provincia]) perProvincia[provincia] = { totale: 0, farmacie: [] };
    const p = perProvincia[provincia];
    p.totale++;
    p.farmacie.push({
      nome,
      comune: testo(r.comune),
      indirizzo: testo(r.indirizzo),
      telefono: testo(r.telefono),
      lat: r.latitudine ? Number(r.latitudine) : null,
      lon: r.longitudine ? Number(r.longitudine) : null,
      orariOggi,
    });
  }

  for (const p of Object.values(perProvincia)) {
    p.farmacie.sort(
      (a, b) => (a.comune ?? "").localeCompare(b.comune ?? "", "it") || a.nome.localeCompare(b.nome, "it")
    );
  }

  if (Object.keys(perProvincia).length === 0) {
    console.warn(`Nessuna farmacia trovata per oggi (${oggi})`);
  }

  await upsertSnapshot("farmacie", "farmacie", null, { data: oggi, per_provincia: perProvincia });
  const totaleFarmacie = Object.values(perProvincia).reduce((n, p) => n + p.totale, 0);
  console.log(`Farmacie aggiornate (${oggi}): ${totaleFarmacie} farmacie totali`);
}

// ---------------------------------------------------------------------
// PRONTO SOCCORSO — tempi di attesa in tempo reale (16/09/2026,
// richiesto dall'utente). Endpoint pubblico NON documentato di
// servizionline.sanita.fvg.it, individuato dall'utente stesso via
// DevTools → Rete del proprio browser (la pagina ufficiale
// https://servizionline.sanita.fvg.it/psonline/ è una SPA il cui HTML
// iniziale non contiene alcun dato — vedi il commento esteso in
// lib/prontosoccorso.ts per il dettaglio completo della ricerca e
// della struttura del payload).
//
// `datetime` è un cache-buster (epoch ms), non un parametro di
// filtro — passato ad ogni chiamata solo per coerenza con l'URL
// osservato nel browser dell'utente.
// ---------------------------------------------------------------------

const PRONTO_SOCCORSO_URL = "https://servizionline.sanita.fvg.it/tempiAttesaService/tempiAttesaPs";

async function ingestProntoSoccorso() {
  const res = await fetchConRetry(`${PRONTO_SOCCORSO_URL}?datetime=${Date.now()}`);
  if (!res.ok) {
    console.warn(`Pronto Soccorso non disponibile (HTTP ${res.status})`);
    return;
  }

  const payload = await res.json();
  if (!payload || !Array.isArray(payload.aziende)) {
    console.warn("Risposta Pronto Soccorso inattesa (chiave 'aziende' mancante)");
    return;
  }

  // Appiattisce aziende → prontoSoccorsi → dipartimenti in un unico
  // array: il raggruppamento per azienda sanitaria non serve al
  // frontend (vedi lib/prontosoccorso.ts), solo le sedi fisiche
  // (dipartimenti) contano.
  const dipartimenti = [];
  for (const azienda of payload.aziende) {
    for (const ps of azienda.prontoSoccorsi ?? []) {
      for (const dip of ps.dipartimenti ?? []) {
        dipartimenti.push({
          id: dip.id,
          nome: testo(dip.descrizione),
          info: testo(dip.info),
          lat: typeof dip.latitudine === "number" ? dip.latitudine : null,
          lon: typeof dip.longitudine === "number" ? dip.longitudine : null,
          indirizzo: testo(dip.indirizzo),
          localita: testo(dip.localita),
          comune: testo(dip.comune),
          codiciColore: (dip.codiciColore ?? []).map((c) => ({
            id: c.id,
            descrizione: testo(c.descrizione),
            rgb: c.rgb,
            priorita: c.priorita,
            situazionePazienti: {
              numeroPazienti: c.situazionePazienti?.numeroPazienti ?? 0,
              numeroPazientiInVisita: c.situazionePazienti?.numeroPazientiInVisita ?? 0,
              numeroPazientiInAttesa: c.situazionePazienti?.numeroPazientiInAttesa ?? 0,
              mediaAttesa: c.situazionePazienti?.mediaAttesa ?? "00:00",
            },
          })),
          totalePazienti: dip.numeroPazienti ?? 0,
        });
      }
    }
  }

  if (dipartimenti.length === 0) {
    console.warn("Nessun dipartimento Pronto Soccorso trovato nella risposta");
    return;
  }

  dipartimenti.sort((a, b) => (a.nome ?? "").localeCompare(b.nome ?? "", "it"));

  await upsertSnapshot("pronto-soccorso", "pronto-soccorso", null, {
    dataAggiornamento: typeof payload.dataAggiornamento === "number" ? payload.dataAggiornamento : Date.now(),
    dipartimenti,
  });
  console.log(`Pronto Soccorso aggiornato: ${dipartimenti.length} sedi`);
}

// ---------------------------------------------------------------------
// TURISMO — Neve & Impianti (16/09/2026). L'utente ha fornito un
// pacchetto di partenza generato con ChatGPT (schema SQLite, CSV
// anagrafica dei 7 poli sciistici, script Python di aggiornamento,
// note sulle route verificate). Nessuna API JSON pubblica documentata
// per questa fonte (confermato dal pacchetto e riverificato qui) — a
// differenza di Pronto Soccorso, qui la fonte è testo visibile di
// pagine HTML server-rendered pubbliche di TurismoFVG, non un endpoint
// dedicato.
//
// Base: https://www.turismofvg.it/montagna/infoneve?day=today&hub=<hub>&type=1
// (un valore `hub` per polo, elenco in NEVE_IMPIANTI_POLI sotto — vedi
// anche `infosummer` per la stagione estiva, non ancora integrata).
// Testata pagina già nel testo visibile: "<Polo> meteo X°C neve in
// pista Y Orari Z impianti aperti A/B piste aperte C% tappeti aperti
// D/E Strutture F/G Fondo H/I" per OGNI polo (la stessa striscia
// riepilogativa compare su ogni pagina, indipendentemente dal `hub`
// richiesto) seguita dal dettaglio piste/impianti del solo polo
// richiesto (non ancora utilizzato qui, solo la striscia
// riepilogativa).
//
// **Due bug reali trovati e corretti nello script Python fornito
// dall'utente** (per questo riscritto qui in JavaScript, stesso stile
// del resto del file, invece di eseguire quello — verificato tutto
// contro il testo reale della pagina prima di scrivere questo codice):
// 1. Cercava la PRIMA occorrenza del nome del polo in TUTTO il testo
//    della pagina per delimitare il blocco dati — ma il nome di ogni
//    polo compare anche nel menù di navigazione, PRIMA della striscia
//    dati vera e propria. Risultato verificato: ogni singolo polo
//    restituiva gli identici valori di "Forni di Sopra" (il primo
//    della lista), sempre — bug silenzioso, nessun errore lanciato.
//    Corretto ancorando la ricerca a "<nome> meteo" (compare SOLO nel
//    blocco dati reale).
// 2. Anche con l'ancora corretta, un limite fisso di caratteri per
//    delimitare il blocco lascia trapelare i campi del polo successivo
//    in quello corrente ogni volta che un campo manca nel proprio
//    blocco (es. quando un polo non ha l'orario pubblicato, il pattern
//    "salta" fino a trovare il prossimo "Orari ... impianti aperti"
//    utile, che appartiene al polo successivo) — verificato: succedeva
//    per temperatura e orari. Corretto delimitando ogni blocco fino
//    alla prossima occorrenza di " meteo" (inizio del polo successivo)
//    invece che a un numero fisso di caratteri, così nessun campo può
//    più "sconfinare".
//
// **Comportamento richiesto esplicitamente dall'utente**: se la fonte
// non risponde (o il blocco dati non si trova più nella pagina), NON
// si cancella mai l'ultimo dato valido di quel polo — si mantiene,
// marcato `stale: true`, per evitare che il sito mostri improvvisamente
// tutti i comprensori a zero per un problema temporaneo della fonte.
// Per questo, a differenza della maggior parte dei moduli di questo
// file, l'ingestione qui legge prima lo snapshot precedente
// (`leggiSnapshotEsistente`) e fa un fetch/merge indipendente per
// ciascun polo, non un unico payload sostituito in blocco.
//
// **Corretto anche un piccolo errore nei dati anagrafici statici del
// pacchetto fornito dall'utente**: Sappada/Forni Avoltri era indicato
// con 9 impianti — la striscia riepilogativa reale della fonte mostra
// invece un totale di 8 (`impianti aperti 0/8`), verificato più volte.
// Corretto in lib/neveImpianti.ts, segnalato nel README.
// ---------------------------------------------------------------------

const NEVE_IMPIANTI_BASE = "https://www.turismofvg.it/montagna/infoneve";

const NEVE_IMPIANTI_POLI = [
  { slug: "tarvisio", nome: "Tarvisio", hub: "tarvisio" },
  { slug: "sella-nevea", nome: "Sella Nevea", hub: "sella" },
  { slug: "ravascletto-zoncolan", nome: "Ravascletto / Zoncolan", hub: "zoncolan" },
  { slug: "piancavallo", nome: "Piancavallo", hub: "piancavallo" },
  { slug: "forni-di-sopra", nome: "Forni di Sopra", hub: "forni" },
  { slug: "sappada-forni-avoltri", nome: "Sappada / Forni Avoltri", hub: "sappada" },
  { slug: "sauris", nome: "Sauris", hub: "sauris" },
];

function neveImpiantiNorm(s) {
  return (s ?? "").replace(/\s+/g, " ").trim();
}

function neveImpiantiEstraiBlocco(testoPagina, nome) {
  const text = neveImpiantiNorm(testoPagina);
  const ancora = `${nome} meteo`;
  const idx = text.toLowerCase().indexOf(ancora.toLowerCase());
  if (idx < 0) return null;

  // Delimita il blocco alla prossima occorrenza di " meteo" (inizio del
  // polo successivo nella striscia), mai a un numero fisso di
  // caratteri — vedi commento esteso sopra ingestNeveImpianti().
  const idxProssimo = text.toLowerCase().indexOf(" meteo", idx + ancora.length);
  const fine = idxProssimo >= 0 ? idxProssimo : Math.min(text.length, idx + 400);
  const segmento = text.slice(idx, fine);

  const coppia = (patterns) => {
    for (const pat of patterns) {
      const m = segmento.match(pat);
      if (m) return [parseInt(m[1], 10), parseInt(m[2], 10)];
    }
    return [null, null];
  };

  let temperaturaC = null;
  let m = segmento.match(/(?:meteo|weather)\s+(-?\d+(?:[.,]\d+)?)\s*°C/i);
  if (m) temperaturaC = parseFloat(m[1].replace(",", "."));

  let neveSuPista = null;
  m = segmento.match(/(?:neve in pista|snow on the slopes)\s*(.*?)\s*(?:orari|opening hours)/i);
  if (m) {
    const v = neveImpiantiNorm(m[1]);
    if (v && v !== "---" && v !== "-" && v.length <= 40 && !/meteo/i.test(v)) neveSuPista = v;
  }

  const [impiantiAperti, impiantiTotali] = coppia([
    /impianti aperti\s*(\d+)\s*\/\s*(\d+)/i,
    /open skilifts\s*(\d+)\s*\/\s*(\d+)/i,
  ]);
  const [tappetiAperti, tappetiTotali] = coppia([
    /tappeti aperti\s*(\d+)\s*\/\s*(\d+)/i,
    /conveyor belts\s*(\d+)\s*\/\s*(\d+)/i,
  ]);
  const [struttureAperte, struttureTotali] = coppia([
    /strutture\s*(\d+)\s*\/\s*(\d+)/i,
    /facility\s*(\d+)\s*\/\s*(\d+)/i,
  ]);
  const [fondoAperto, fondoTotale] = coppia([
    /fondo\s*(\d+)\s*\/\s*(\d+)/i,
    /cross-country ski\s*(\d+)\s*\/\s*(\d+)/i,
  ]);

  let pisteApertePct = null;
  for (const pat of [/piste aperte\s*(\d+)\s*%/i, /open slopes\s*(\d+)\s*%/i]) {
    m = segmento.match(pat);
    if (m) {
      pisteApertePct = parseInt(m[1], 10);
      break;
    }
  }

  let orari = null;
  m = segmento.match(/(?:orari|opening hours)\s*(.*?)\s*(?:impianti aperti|open skilifts)/i);
  if (m) {
    const v = neveImpiantiNorm(m[1]);
    if (v && v.length <= 60 && !/meteo|neve in pista/i.test(v)) orari = v;
  }

  let neveMinCm = null;
  let neveMaxCm = null;
  if (neveSuPista) {
    const numeri = (neveSuPista.match(/\d+(?:[.,]\d+)?/g) || [])
      .map((n) => parseFloat(n.replace(",", ".")))
      .filter((n) => !Number.isNaN(n));
    if (numeri.length) {
      neveMinCm = Math.min(...numeri);
      neveMaxCm = Math.max(...numeri);
    }
  }

  let stato;
  if (impiantiTotali === null) stato = "sconosciuto";
  else if (impiantiTotali === 0 || impiantiAperti === 0) stato = "chiuso";
  else if (impiantiAperti === impiantiTotali) stato = "aperto";
  else stato = "parziale";

  return {
    stato,
    temperaturaC,
    neveSuPista,
    neveMinCm,
    neveMaxCm,
    impiantiAperti,
    impiantiTotali,
    pisteApertePct,
    tappetiAperti,
    tappetiTotali,
    struttureAperte,
    struttureTotali,
    fondoAperto,
    fondoTotale,
    orari,
  };
}

async function ingestNeveImpianti() {
  const precedente = (await leggiSnapshotEsistente("neve-impianti")) ?? { perComprensorio: {} };
  const now = new Date().toISOString();
  const perComprensorio = {};

  for (const polo of NEVE_IMPIANTI_POLI) {
    const precedenteLive = precedente.perComprensorio?.[polo.slug] ?? null;
    const url = `${NEVE_IMPIANTI_BASE}?day=today&hub=${polo.hub}&type=1`;
    try {
      const res = await fetchConRetry(url);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const $ = cheerio.load(await res.text());
      const testoPagina = $.root().text();
      const estratto = neveImpiantiEstraiBlocco(testoPagina, polo.nome);
      if (!estratto) throw new Error("blocco dati non trovato nella pagina");

      perComprensorio[polo.slug] = {
        ...estratto,
        osservatoIl: now,
        controllatoIl: now,
        stale: false,
        errore: null,
      };
    } catch (err) {
      // Non cancelliamo mai l'ultimo dato valido: lo manteniamo e lo
      // marchiamo "stale", come richiesto esplicitamente dall'utente.
      if (precedenteLive) {
        perComprensorio[polo.slug] = {
          ...precedenteLive,
          controllatoIl: now,
          stale: true,
          errore: `${err.name ?? "Errore"}: ${err.message}`,
        };
      } else {
        perComprensorio[polo.slug] = {
          stato: "sconosciuto",
          temperaturaC: null,
          neveSuPista: null,
          neveMinCm: null,
          neveMaxCm: null,
          impiantiAperti: null,
          impiantiTotali: null,
          pisteApertePct: null,
          tappetiAperti: null,
          tappetiTotali: null,
          struttureAperte: null,
          struttureTotali: null,
          fondoAperto: null,
          fondoTotale: null,
          orari: null,
          osservatoIl: null,
          controllatoIl: now,
          stale: true,
          errore: `${err.name ?? "Errore"}: ${err.message}`,
        };
      }
      console.warn(`Neve & Impianti — ${polo.nome} non aggiornato: ${err.message}`);
    }
  }

  await upsertSnapshot("neve-impianti", "neve-impianti", null, {
    generatoIl: now,
    perComprensorio,
  });
  console.log(`Neve & Impianti aggiornato: ${Object.keys(perComprensorio).length} poli`);
}

// ---------------------------------------------------------------------
// STRUTTURE RICETTIVE — 8 registri regionali distinti (Bed & Breakfast,
// Affittacamere, Campeggi/Villaggi Turistici, Alloggi Agrituristici,
// Alberghi Diffusi, Strutture Ricettive a carattere Sociale, Dry
// Marina/Marina Resort, Rifugi Alpini Escursionistici), tutti dataset
// Socrata separati su dati.friuliveneziagiulia.it con lo STESSO schema
// minimale: provincia, comune, denominazione, email (opzionale), sito
// (opzionale, oggetto `{ url }`). NESSUN indirizzo, telefono o
// coordinata pubblicati dalla fonte — limite del dato stesso (verificato
// sulla metadata di 2 degli 8 dataset), non un'omissione nostra: niente
// mappa possibile con questi dati, solo elenco.
//
// Registri "certificati dai Comuni e dalla Direzione centrale attività
// produttive", aggiornati raramente (metadata di 2 degli 8 dataset
// verificata: entrambi fermi a settembre 2024 al momento di questa
// ingestione, 26/08/2026) — nella sostanza un dato quasi-statico, ma con
// una vera API Socrata dietro (a differenza di Aviazione, che ha
// richiesto raccolta manuale via WebFetch pagina per pagina): usiamo
// comunque il pattern di ingestione standard invece del file statico
// `lib/xxx.ts` una tantum — nessuno sforzo in più, e si aggiorna da solo
// se la Regione pubblica nuove voci, invece di restare fermo alla
// sessione in cui è stato raccolto.
//
// Un'unica funzione ingerisce tutti e 8 i tipi in parallelo e scrive
// un'UNICA snapshot Supabase ("strutture-ricettive") con tutti i tipi
// dentro (`{ aggiornato_al, tipi: { bb: {...}, affittacamere: {...},
// ... } }`) invece di 8 snapshot separate — un solo job, una sola riga
// di storico per esecuzione, ogni pagina di tipo legge la propria
// chiave dalla stessa snapshot condivisa.
// ---------------------------------------------------------------------

const DATASET_STRUTTURE_RICETTIVE = {
  bb: "jzsu-f86x",
  affittacamere: "6var-2hht",
  campeggi: "c2n8-qhph",
  agriturismi: "yg8e-47jy",
  "alberghi-diffusi": "69j3-9hcp",
  sociali: "csiv-njht",
  marina: "6xk5-2p3e",
  rifugi: "qnwt-cjvq",
};

// -----------------------------------------------------------------------
// Arricchimento contatti (indirizzo/telefono/sito/coordinate) — 26/08/2026
//
// I registri Socrata sopra non hanno indirizzo/telefono/coordinate (solo
// provincia/comune/denominazione/email/sito, verificato riga per riga).
// Su richiesta dell'utente, arricchiamo con OpenStreetMap (dati aperti,
// licenza ODbL) tramite abbinamento nome+comune — nessun ID condiviso
// con i dataset regionali, quindi il match è per forza euristico, non
// certo. `data/osm-strutture-ricettive.json` è un estratto statico,
// preparato UNA TANTUM in questa sessione da un export Overpass caricato
// dall'utente (1418 elementi OSM in FVG con tag tourism=hotel/apartment/
// guest_house/hostel/camp_site/alpine_hut/wilderness_hut/chalet/motel o
// leisure=marina, filtrato ai ~843 con almeno indirizzo/telefono/sito/
// email) — NON viene riscaricato ad ogni esecuzione (OSM non ha un'API
// raggiungibile da qui, vedi nota architettura in claude/fvgmonitor-
// stato.md): se l'utente vorrà dati OSM più freschi in futuro, andrà
// ripetuta la stessa procedura (query Overpass Turbo → nuovo export →
// sostituire questo file).
//
// Il campo `tipoOsm` del match NON viene usato per filtrare — un B&B e
// un affittacamere sono indistinguibili su OSM (nessun tag dedicato per
// molti dei nostri 8 tipi), quindi si accetta un match di qualunque tipo
// OSM purché nome+comune combacino abbastanza.
// -----------------------------------------------------------------------

const OSM_STRUTTURE_RICETTIVE = JSON.parse(
  readFileSync(path.join(__dirname, "data", "osm-strutture-ricettive.json"), "utf8")
);

// Parole troppo generiche per contare come "prova" di corrispondenza tra
// due nomi (es. "Casa Rossa" vs "Casa Bianca" non devono combaciare solo
// perché condividono "Casa") — rimosse da entrambi i lati prima del
// confronto. Include le forme tipiche della sintassi Socrata "NOME di
// COGNOME NOME" (il "di" del titolare, non il "di" del nome del posto).
const PAROLE_GENERICHE_NOME = new Set([
  "DI", "DA", "DEL", "DELLA", "DEI", "DELLE", "DEGLI", "IN", "E", "ED", "&",
  "B", "BB", "BED", "BREAKFAST", "HOTEL", "ALBERGO", "CASA", "VILLA",
  "AZIENDA", "AGRICOLA", "AGRITURISMO", "FATTORIA", "RIFUGIO", "CAMPING",
  "CAMPEGGIO", "MARINA", "RESORT", "HOUSE", "HOME", "SOCIETA", "SRL", "SAS",
  "SNC", "DIFFUSO", "ALBERGHI",
]);

function normalizzaTesto(s) {
  return (s ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "") // rimuove accenti
    .toUpperCase()
    .replace(/[^A-Z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

// `extraStopwords` porta anche le parole del COMUNE (es. "TRIESTE",
// "LIGNANO", "SABBIADORO") — trovato con dati reali: quasi ogni nome che
// contiene il nome del comune ("Trieste Plus", "Bora di Trieste", "BB
// Trieste"...) veniva abbinato a "B&B Hotel Trieste" su OSM, il cui unico
// token dopo aver tolto le parole generiche restava "TRIESTE" — lungo
// abbastanza da superare la soglia di 6 caratteri, ma senza alcun valore
// distintivo perché è solo il nome della città, non del locale.
function tokenSignificativi(nome, extraStopwords) {
  return normalizzaTesto(nome)
    .split(" ")
    .filter((t) => t && !PAROLE_GENERICHE_NOME.has(t) && !extraStopwords?.has(t));
}

// true se il nome (probabilmente più corto/pulito) di OSM è "contenuto"
// nel nome Socrata (spesso più lungo, con titolare incluso) — richiede
// che TUTTI i token significativi del lato più corto compaiano nell'altro,
// e almeno un token significativo da confrontare (altrimenti "Villa" da
// solo, dopo la rimozione delle parole generiche, matcherebbe con tutto).
function nomiCorrispondono(nomeSocrata, nomeOsm, comuneStopwords) {
  const tA = tokenSignificativi(nomeSocrata, comuneStopwords);
  const tB = tokenSignificativi(nomeOsm, comuneStopwords);
  if (tA.length === 0 || tB.length === 0) return false;
  const [corti, lunghi] = tA.length <= tB.length ? [tA, tB] : [tB, tA];
  const insiemeLunghi = new Set(lunghi);
  if (!corti.every((t) => insiemeLunghi.has(t))) return false;
  // Un solo token in comune è una prova debole se quel token è corto —
  // trovato con dati reali: "PINO MARE" (Lignano) veniva abbinato a un
  // "Hotel Mare" non correlato solo perché condividevano "MARE" (4
  // lettere) dopo aver tolto "HOTEL" dalle parole generiche. Con un solo
  // token di prova, richiediamo che sia abbastanza lungo da essere
  // distintivo (soglia scelta empiricamente, non una scienza esatta).
  if (corti.length === 1 && corti[0].length < 6) return false;
  return true;
}

// Indice per comune normalizzato, costruito una sola volta (non ad ogni
// riga) — l'elenco OSM è piccolo (843 voci) ma questo evita di rifare la
// normalizzazione ad ogni confronto.
const INDICE_OSM_PER_COMUNE = (() => {
  const indice = new Map();
  for (const voce of OSM_STRUTTURE_RICETTIVE) {
    if (!voce.comune) continue;
    const chiave = normalizzaTesto(voce.comune);
    if (!indice.has(chiave)) indice.set(chiave, []);
    indice.get(chiave).push(voce);
  }
  return indice;
})();

function trovaArricchimentoOsm(nome, comune) {
  const candidati = INDICE_OSM_PER_COMUNE.get(normalizzaTesto(comune));
  if (!candidati) return null;
  const comuneStopwords = new Set(normalizzaTesto(comune).split(" ").filter(Boolean));
  const match = candidati.find((c) => nomiCorrispondono(nome, c.nome, comuneStopwords));
  if (!match) return null;
  const contatti = { fonte: "osm" };
  if (match.indirizzo) contatti.indirizzo = match.cap ? `${match.indirizzo}, ${match.cap}` : match.indirizzo;
  if (match.telefono) contatti.telefono = match.telefono;
  if (match.email) contatti.email = match.email;
  if (match.sito) contatti.sito = match.sito;
  if (match.lat != null && match.lon != null) {
    contatti.lat = match.lat;
    contatti.lon = match.lon;
  }
  return contatti;
}

// I 4 valori osservati per il campo "provincia" sono già il nome per
// esteso in maiuscolo (non un codice ISTAT come altrove) — basta il
// lowercase per combaciare con ProvinciaSlug, verificato con una query
// $select=distinct provincia su uno degli 8 dataset.
const PROVINCE_STRUTTURE_RICETTIVE = { UDINE: "udine", GORIZIA: "gorizia", TRIESTE: "trieste", PORDENONE: "pordenone" };

// -----------------------------------------------------------------------
// Arricchimento contatti — turismofvg.it (26/08/2026)
//
// Fonte più ricca di OSM (indirizzo, telefono, email, sito, titolare, CIN
// quando presente) e aggiornata dagli operatori stessi, non un estratto
// di terzi — quando disponibile ha PRECEDENZA sul match OSM (vedi
// `trovaContattiArricchiti` più sotto e il commento su `fonte` nel tipo
// `ContattiArricchiti` in lib/struttureRicettive.ts).
//
// Struttura del sito, verificata su HTML reale fornito dall'utente (una
// pagina elenco e una scheda di dettaglio, non solo via WebFetch che
// restituisce markdown e non l'HTML grezzo servito ai selettori cheerio):
//   - Ogni categoria ha una pagina elenco "/{Categoria}/Search" che
//     supporta paginazione semplice (?filters.PageIndex=N, GET
//     server-rendered, NESSUN endpoint AJAX/JSON come ipotizzato in una
//     fase di ricerca precedente — corretto grazie ai dati reali).
//   - La stessa pagina elenco (già alla pagina 1, qualunque PageIndex)
//     contiene un campo nascosto <input id="mapdata" value="[...]">
//     con l'INTERO indice della categoria in JSON (Id, Name, Url, Type,
//     City, Latitude, Longitude) — un solo fetch invece di scorrere
//     tutte le pagine, valido per qualunque categoria.
//   - La scheda di dettaglio ha i dati di contatto in una sezione
//     <section class="c-poi__auxtexts"> con coppie ripetute
//     <strong>Etichetta</strong><br>Valore<br><br> (Valore a volte è un
//     link, es. la Pec come mailto:) — vedi `estraiCampiAuxTexts`.
//
// SOLO Agriturismi è verificato sulla struttura HTML reale per ora — le
// altre 7 categorie del sito potrebbero avere URL o etichette diverse
// (es. "Telefono" invece di "Cellulare", un campo "Sito web"/"CIN" non
// presenti sulla scheda campione). Il parser sotto è generico (legge
// qualunque etichetta trovi, non un elenco fisso), quindi dovrebbe
// reggere variazioni ragionevoli, ma l'espansione alle altre categorie
// va comunque validata con un altro campione reale prima di aggiungerle
// a TURISMOFVG_CATEGORIE — vedi "Idee future" in claude/fvgmonitor-stato.md.
//
// Volume di richieste: 1 fetch per l'indice (sempre, è economico ed è
// l'unico modo di sapere quali schede sono nuove) + al massimo
// TURISMOFVG_MAX_NUOVE_SCHEDE_PER_ESECUZIONE schede di dettaglio nuove
// per esecuzione, con cache permanente (una scheda già scaricata non
// cambia spesso, non viene mai ripetuta) — stesso pattern già collaudato
// per i risultati gara Sci più sotto in questo file.
// -----------------------------------------------------------------------

const TURISMOFVG_MAX_NUOVE_SCHEDE_PER_ESECUZIONE = 20;

const TURISMOFVG_CATEGORIE = {
  agriturismi: "Agriturismi",
};

// Spezza il contenuto HTML di <section class="c-poi__auxtexts"> sulle
// coppie di <br> consecutivi (il separatore osservato tra un campo e il
// successivo) e, per ciascun blocco, legge l'etichetta dal primo
// <strong> e il valore dal testo restante — oppure dal testo di un
// eventuale link (es. la Pec, che sulla pagina è un <a href="mailto:...">).
// Generico apposta: non presuppone un elenco fisso di etichette, quindi
// regge campi come "Sito web" o "CIN" anche se non osservati sul
// campione usato per scrivere questa funzione.
function estraiCampiAuxTexts($aux) {
  const html = $aux.html() || "";
  const blocchi = html
    .replace(/<br\s*\/?>/gi, "<br>")
    .split(/<br><br>/i)
    .map((b) => b.trim())
    .filter(Boolean);

  const campi = {};
  for (const blocco of blocchi) {
    const $b = cheerio.load(`<div id="campo">${blocco}</div>`);
    const label = $b("strong").first().text().trim();
    if (!label) continue;

    const link = $b("a").first();
    let valore = null;
    if (link.length) {
      const href = link.attr("href") || "";
      valore = href.toLowerCase().startsWith("mailto:") ? href.slice(7).trim() : link.text().trim();
    } else {
      $b("strong").remove();
      valore = $b("#campo").text().trim();
    }
    if (valore) campi[label] = valore;
  }
  return campi;
}

async function fetchIndiceTurismoFvg(segmentoCategoria) {
  const res = await fetchConRetry(`https://www.turismofvg.it/${segmentoCategoria}/Search`, {
    headers: { "User-Agent": "Mozilla/5.0 (compatible; FVGMonitorBot/1.0)" },
  });
  if (!res.ok) throw new Error(`Indice turismofvg.it/${segmentoCategoria} HTTP ${res.status}`);

  const $ = cheerio.load(await res.text());
  const raw = $("#mapdata").attr("value");
  if (!raw) throw new Error(`turismofvg.it/${segmentoCategoria}: campo #mapdata non trovato — struttura pagina cambiata?`);

  let voci;
  try {
    voci = JSON.parse(raw);
  } catch {
    throw new Error(`turismofvg.it/${segmentoCategoria}: JSON in #mapdata non valido`);
  }
  if (!Array.isArray(voci)) throw new Error(`turismofvg.it/${segmentoCategoria}: formato #mapdata inatteso`);

  return voci
    .map((v) => ({
      id: v.Id != null ? String(v.Id) : null,
      nome: testo(v.Name),
      url: typeof v.Url === "string" ? v.Url : null,
      comune: testo(v.City),
      lat: typeof v.Latitude === "number" ? v.Latitude : null,
      lon: typeof v.Longitude === "number" ? v.Longitude : null,
    }))
    .filter((v) => v.id && v.nome && v.url);
}

async function fetchDettaglioTurismoFvg(urlAssoluto) {
  const res = await fetchConRetry(urlAssoluto, {
    headers: { "User-Agent": "Mozilla/5.0 (compatible; FVGMonitorBot/1.0)" },
  });
  if (!res.ok) throw new Error(`Scheda ${urlAssoluto} HTTP ${res.status}`);

  const $ = cheerio.load(await res.text());
  const $aux = $(".c-poi__auxtexts").first();
  const campi = $aux.length ? estraiCampiAuxTexts($aux) : {};

  const telefono = campi["Telefono"] || campi["Cellulare"] || null;
  const email = campi["Email"] || campi["E-mail"] || campi["Pec"] || null;
  const sito = campi["Sito web"] || campi["Sito"] || campi["Web"] || null;
  const indirizzo = campi["Indirizzo"] || null;
  const cap = campi["CAP"] || null;
  const titolare = campi["Titolare"] || null;
  const cin = campi["CIN"] || null;

  // Coordinate di riserva dal link "Indicazioni" verso Google Maps —
  // indipendenti dall'indice mapdata, utile come controincrocio o
  // fallback se in futuro una scheda avesse coordinate diverse.
  let lat = null;
  let lon = null;
  const hrefMappa = $(".c-poi_map").first().attr("href") || "";
  const mMappa = /loc:(-?\d+\.?\d*),(-?\d+\.?\d*)/.exec(hrefMappa);
  if (mMappa) {
    lat = Number(mMappa[1]);
    lon = Number(mMappa[2]);
  }

  return {
    telefono,
    email,
    sito,
    indirizzo: indirizzo ? (cap ? `${indirizzo}, ${cap}` : indirizzo) : null,
    titolare,
    cin,
    lat,
    lon,
  };
}

async function ingestTurismoFvgCategoria(tipoSlug, segmentoCategoria) {
  const idSnapshot = `turismofvg:${tipoSlug}`;

  let indice;
  try {
    indice = await fetchIndiceTurismoFvg(segmentoCategoria);
  } catch (err) {
    console.warn(`TurismoFVG ${tipoSlug}: indice non scaricato, riuso la cache se presente — ${err.message}`);
    return await leggiSnapshotEsistente(idSnapshot);
  }

  const cacheEsistente = await leggiSnapshotEsistente(idSnapshot);
  const dettagliCache = { ...(cacheEsistente?.dettagli || {}) };

  let nuoveScaricate = 0;
  let rimandate = 0;
  for (const voce of indice) {
    if (dettagliCache[voce.id]) continue; // già in cache, mai ri-scaricata

    if (nuoveScaricate >= TURISMOFVG_MAX_NUOVE_SCHEDE_PER_ESECUZIONE) {
      rimandate++;
      continue; // ripresa alla prossima esecuzione
    }

    try {
      const urlAssoluto = voce.url.startsWith("http")
        ? voce.url
        : `https://www.turismofvg.it${voce.url.startsWith("/") ? "" : "/"}${voce.url}`;
      const dettaglio = await fetchDettaglioTurismoFvg(urlAssoluto);
      dettagliCache[voce.id] = { ...dettaglio, aggiornato_al: new Date().toISOString() };
      nuoveScaricate++;
    } catch (err) {
      console.warn(`TurismoFVG ${tipoSlug}: scheda ${voce.id} (${voce.nome}) non scaricata — ${err.message}`);
      // non salvata in cache: ritentata automaticamente alla prossima esecuzione
    }
  }

  if (rimandate > 0) {
    console.log(`TurismoFVG ${tipoSlug}: ${rimandate} schede rimandate alla prossima esecuzione (limite ${TURISMOFVG_MAX_NUOVE_SCHEDE_PER_ESECUZIONE}/esecuzione)`);
  }

  const risultato = { indice, dettagli: dettagliCache, aggiornato_al: new Date().toISOString() };

  // Come per lo sci: nessuna scrittura (né riga di storico) se non è
  // cambiato nulla di rilevante — qui approssimato con "nessuna scheda
  // nuova e la dimensione dell'indice non è cambiata", sufficiente a
  // evitare righe identiche ogni 15 minuti senza la complessità di un
  // confronto profondo.
  if (nuoveScaricate === 0 && cacheEsistente && cacheEsistente.indice?.length === indice.length) {
    console.log(`TurismoFVG ${tipoSlug}: nessuna novità, snapshot non riscritto`);
    return cacheEsistente;
  }

  try {
    await upsertSnapshot(idSnapshot, "turismofvg", null, risultato);
  } catch (err) {
    console.warn(`TurismoFVG ${tipoSlug}: snapshot non salvato — ${err.message}`);
  }

  console.log(
    `TurismoFVG ${tipoSlug} aggiornato: ${indice.length} in indice, ${Object.keys(dettagliCache).length} schede con dettaglio (${nuoveScaricate} nuove questa esecuzione)`
  );
  return risultato;
}

// -----------------------------------------------------------------------
// Arricchimento contatti — turismofvg.it, motore booking TFVGB (28/08/2026)
//
// Le altre 7 categorie di Strutture Ricettive (B&B, Affittacamere,
// Campeggi e Villaggi Turistici, Alberghi Diffusi, Strutture a carattere
// Sociale, Dry Marina e Marina Resort, Rifugi) NON vivono nelle stesse
// pagine CMS di Agriturismi (niente #mapdata, niente .c-poi__auxtexts):
// sono gestite dal motore di prenotazione legacy TFVGB
// (turismofvg.it/TFVGB/..., piattaforma Ikon/Insiel), una sezione del
// sito strutturalmente diversa, verificata su HTML reale fornito
// dall'utente — sia una pagina elenco filtrata per categoria
// (search_fromurl?Cat=N) sia una scheda di dettaglio (Affittacamere
// "Nadia", id 218). Due differenze sostanziali rispetto al pattern CMS:
//
//   1. NESSUN indice JSON in un colpo solo: l'elenco di una categoria è
//      paginato (~8 strutture a pagina, es. Affittacamere = 549
//      strutture / 69 pagine) tramite
//      /TFVGB/Booking/Paginazione_New?pagina=N&ordine=0&asc=1.
//   2. Il filtro categoria (Cat=N) e la paginazione dipendono da uno
//      STATO DI SESSIONE (cookie), non dall'URL: verificato richiedendo
//      Paginazione_New senza prima passare da search_fromurl (e senza
//      cookie) — risposta vuota (0 strutture, "pagina 2/0"). Per questo
//      ogni categoria richiede di aprire una sessione con
//      apriSessioneTfvgb() e riusare lo stesso cookie per le pagine
//      successive, cosa che nessun'altra fonte di questo progetto deve
//      fare (tutte le altre chiamate a fetchConRetry sono stateless).
//
// Costo per esecuzione: paginare TUTTE le pagine di ogni categoria ad
// ogni esecuzione (ogni 15 minuti, Affittacamere da sola ne avrebbe 69)
// non è sostenibile insieme a tutto il resto che fa questo script nello
// stesso timeout di 10 minuti. Si avanza quindi con un CURSORE per
// categoria (persistito nello snapshot, campo `paginazione`), un tot di
// pagine nuove per esecuzione (TFVGB_MAX_PAGINE_INDICE_PER_ESECUZIONE) —
// una volta raggiunta l'ultima pagina l'indice è "completo" e le
// esecuzioni successive ricontrollano solo la pagina 1 (già inclusa
// gratis nell'apertura sessione) per accorgersi di nuove strutture in
// testa all'elenco o di un numero di pagine cambiato (nel qual caso la
// paginazione riparte da capo). Le schede di DETTAGLIO restano capped e
// cachate per sempre come per Agriturismi/le serie bike
// (TFVGB_MAX_NUOVE_SCHEDE_PER_ESECUZIONE).
//
// La pagina elenco non viene usata per estrarre nome/tipologia/indirizzo
// (selettori non riverificati da campione fresco per le 6 categorie
// diverse da Affittacamere) — solo per scoprire id+URL di ogni scheda,
// tramite i link /TFVGB/Strutture/{id}/{slug}, presenti in qualunque
// categoria. Nome/comune/contatti vengono SEMPRE dalla scheda di
// dettaglio, la cui struttura (blocco <div class="indirizzo">, righe
// separate da <br> con prefissi "Tel "/"Cell. "/"CIN ", link
// <a class="link_web"> per il sito, link "Richiesta informazioni" con
// mailTo/localita in query string) è verificata solo su Affittacamere
// (Nadia) — le altre 6 categorie condividono lo stesso motore booking
// quindi dovrebbero avere la stessa struttura, ma non ancora confermato
// scheda per scheda: se una categoria desse sistematicamente 0 contatti
// va rivista con un campione reale di quella categoria specifica.
//
// "Campeggi e Villaggi Turistici" nel registro Regione è UN tipo, ma sul
// motore TFVGB sono due categorie distinte (Cat=6 "Campeggi" e Cat=14
// "Villaggi Turistici") — entrambe vengono interrogate e unite sotto lo
// stesso tipoSlug "campeggi", nessuna delle due esclusa.
// -----------------------------------------------------------------------

const TFVGB_MAX_PAGINE_INDICE_PER_ESECUZIONE = 6;
const TFVGB_MAX_NUOVE_SCHEDE_PER_ESECUZIONE = 10;

// tipoSlug (vedi TIPI_STRUTTURA in lib/struttureRicettive.ts) → uno o
// più codici Cat= del motore TFVGB, confermati dal menu "Dove dormire"
// incollato dall'utente (28/08/2026).
const TFVGB_CATEGORIE = {
  affittacamere: [1],
  bb: [5],
  campeggi: [6, 14],
  "alberghi-diffusi": [3],
  sociali: [15],
  marina: [8],
  rifugi: [13],
};

// Node 22 (undici): Headers.get("set-cookie") restituisce un solo valore
// anche con più header Set-Cookie nella risposta (limite della Fetch
// spec) — getSetCookie() li restituisce tutti, necessario qui perché
// TFVGB ne manda più d'uno per l'apertura sessione.
function estraiCookieSessione(res) {
  const set = typeof res.headers.getSetCookie === "function" ? res.headers.getSetCookie() : [];
  return set.map((c) => c.split(";")[0]).join("; ");
}

async function apriSessioneTfvgb(cat) {
  const res = await fetchConRetry(`https://www.turismofvg.it/tfvgb/booking/search_fromurl?deciso=on&Cat=${cat}`, {
    headers: { "User-Agent": "Mozilla/5.0 (compatible; FVGMonitorBot/1.0)" },
  });
  if (!res.ok) throw new Error(`Apertura sessione Cat=${cat} HTTP ${res.status}`);
  const cookie = estraiCookieSessione(res);
  if (!cookie) throw new Error(`Apertura sessione Cat=${cat}: nessun cookie di sessione ricevuto`);
  return { cookie, html: await res.text() };
}

async function fetchPaginaTfvgb(cookie, pagina) {
  const res = await fetchConRetry(
    `https://www.turismofvg.it/TFVGB/Booking/Paginazione_New?pagina=${pagina}&ordine=0&asc=1`,
    { headers: { "User-Agent": "Mozilla/5.0 (compatible; FVGMonitorBot/1.0)", Cookie: cookie } }
  );
  if (!res.ok) throw new Error(`Pagina ${pagina} HTTP ${res.status}`);
  return await res.text();
}

// Solo scoperta id+URL (vedi nota architettura sopra) — non tenta di
// leggere nome/tipologia/indirizzo da questa pagina.
function estraiVociListaTfvgb(html) {
  const $ = cheerio.load(html);
  const trovate = new Map();
  $('a[href*="/TFVGB/Strutture"], a[href*="/TFVGB/Struttura/"]').each((_, el) => {
    const href = $(el).attr("href") || "";
    const m = /\/TFVGB\/Strutture?\/\d+\/[^/?"'#]+/i.exec(href);
    if (!m) return;
    const idMatch = /\/(\d+)\//.exec(m[0]);
    const id = idMatch?.[1];
    if (!id || trovate.has(id)) return;
    const path = m[0].startsWith("/") ? m[0] : `/${m[0]}`;
    trovate.set(id, { id, url: `https://www.turismofvg.it${path}?sez=0` });
  });
  return [...trovate.values()];
}

// Il numero di pagina più alto tra tutti i link pagina=N presenti (frecce
// iniziale/precedente/successiva/finale) — robusto ai nomi di classe,
// serve solo un numero, non serve interpretare i controlli di paginazione.
function estraiTotalePagineTfvgb(html) {
  let max = 1;
  const re = /[?&]pagina=(\d+)/gi;
  let m;
  while ((m = re.exec(html))) {
    const n = Number(m[1]);
    if (n > max) max = n;
  }
  return max;
}

// Legge il blocco <div class="indirizzo"> di una scheda TFVGB (vedi nota
// architettura sopra): le righe PRIMA del primo campo riconosciuto sono
// l'indirizzo (spesso due righe: via/civico e CAP+comune), quelle dopo
// sono telefono/cellulare/sito/CIN in un ordine non fisso.
function estraiCampiIndirizzoTfvgb($indirizzo) {
  // Il div contiene anche l'intestazione <h3>Indirizzo</h3> (etichetta,
  // non dato) subito prima della prima riga utile, senza un <br> a
  // separarla — va tolta prima di spezzare sulle righe, altrimenti
  // finisce incollata al primo campo (verificato sul campione Nadia).
  $indirizzo.find("h3").remove();
  const righe = ($indirizzo.html() || "")
    .split(/<br\s*\/?>/i)
    .map((r) => r.trim())
    .filter(Boolean);

  const campi = {};
  const indirizzoRighe = [];
  let vistoCampo = false;
  for (const riga of righe) {
    const $r = cheerio.load(`<div id="r">${riga}</div>`);
    const link = $r("a.link_web").first();
    if (link.length) {
      // Bug reale trovato dall'utente (categoria Marina, 28/08/2026): la
      // stessa classe "link_web" viene riusata anche per un link
      // "contattaci via email" quando la struttura non ha un sito vero
      // (es. Marina Portopiccolo, Marina Resort "Punta Faro") — l'href in
      // quel caso è un mailto:, non un URL. Senza questo controllo finiva
      // salvato come "sito" un indirizzo email, mostrato con l'etichetta
      // "Sito" in UI. Un mailto: qui diventa un'email di ripiego, mai un
      // sito.
      const href = (link.attr("href") || "").trim();
      if (href.toLowerCase().startsWith("mailto:")) {
        campi.emailDaLinkWeb = href.slice(7).trim();
      } else if (href) {
        campi.sito = href;
      }
      vistoCampo = true;
      continue;
    }
    const testoRiga = $r("#r").text().trim();
    if (!testoRiga) continue;
    if (/^Tel\.?\s/i.test(testoRiga)) {
      campi.telefono = testoRiga.replace(/^Tel\.?\s*/i, "").trim();
      vistoCampo = true;
    } else if (/^Cell\.?\s/i.test(testoRiga)) {
      campi.cellulare = testoRiga.replace(/^Cell\.?\s*/i, "").trim();
      vistoCampo = true;
    } else if (/^CIN\s/i.test(testoRiga)) {
      campi.cin = testoRiga.replace(/^CIN\s*/i, "").trim();
      vistoCampo = true;
    } else if (!vistoCampo) {
      indirizzoRighe.push(testoRiga);
    }
    // righe non riconosciute DOPO l'inizio dei campi (es. note extra) —
    // ignorate, non fanno parte né dell'indirizzo né di un campo noto
  }
  campi.indirizzo = indirizzoRighe.join(", ") || null;
  return campi;
}

async function fetchDettaglioTfvgb(urlAssoluto) {
  const res = await fetchConRetry(urlAssoluto, {
    headers: { "User-Agent": "Mozilla/5.0 (compatible; FVGMonitorBot/1.0)" },
  });
  if (!res.ok) throw new Error(`Scheda TFVGB ${urlAssoluto} HTTP ${res.status}`);

  const $ = cheerio.load(await res.text());
  const nome = $(".content-title-det h1").first().text().trim() || null;

  const $indirizzo = $(".indirizzo").first();
  const campi = $indirizzo.length ? estraiCampiIndirizzoTfvgb($indirizzo) : {};

  // Nessun campo "comune" dedicato sulla scheda: si ricava dal CAP+nome
  // città in fondo all'indirizzo (es. "33010 Venzone") o, in mancanza, dal
  // parametro `localita` del link "Richiesta informazioni" (stesso dato,
  // fonte alternativa — coincidono sul campione Nadia).
  let comune = null;
  if (campi.indirizzo) {
    const m = /\d{5}\s+(.+)$/.exec(campi.indirizzo);
    if (m) comune = m[1].trim();
  }

  let email = null;
  const linkInfo = $('a.js-openformpopup[href*="InfoRequest/InfoAlloggi"]').first();
  if (linkInfo.length) {
    try {
      const params = new URL(linkInfo.attr("href"), "https://www.turismofvg.it").searchParams;
      email = params.get("mailTo") || null;
      if (!comune) comune = params.get("localita") || null;
    } catch {
      // href malformato — email/comune restano quello che erano (spesso già null)
    }
  }
  // Ripiego: se il link "Richiesta informazioni" non dà un'email (o non
  // esiste), ma il blocco indirizzo aveva un mailto: al posto del sito
  // (vedi commento in estraiCampiIndirizzoTfvgb), usa quella.
  if (!email && campi.emailDaLinkWeb) email = campi.emailDaLinkWeb;

  return {
    nome,
    comune,
    telefono: campi.telefono || campi.cellulare || null,
    email,
    sito: campi.sito || null,
    indirizzo: campi.indirizzo || null,
    cin: campi.cin || null,
    // Nessuna coordinata pubblicata sulla scheda base (la tab "Mappa" è
    // caricata via script, non presente nell'HTML servito) — a differenza
    // di Agriturismi/OSM, le voci arricchite da TFVGB restano senza lat/lon.
    lat: null,
    lon: null,
  };
}

// Avanza il cursore di paginazione di ogni Cat= richiesto per questo
// tipoSlug, entro il limite pagine/esecuzione — vedi nota architettura
// sopra per la logica "completo" e la sua ri-verifica ad ogni esecuzione.
async function aggiornaIndiceTfvgb(tipoSlug, listaCat, idUrlEsistenti, paginazioneEsistente) {
  const idUrl = { ...idUrlEsistenti };
  const paginazione = { ...paginazioneEsistente };

  for (const cat of listaCat) {
    const stato = paginazione[cat] ? { ...paginazione[cat] } : { paginaSuccessiva: 2, totalePagine: null, completo: false };

    let sessione;
    try {
      sessione = await apriSessioneTfvgb(cat);
    } catch (err) {
      console.warn(`TFVGB ${tipoSlug} (Cat=${cat}): sessione non aperta, indice non aggiornato questa esecuzione — ${err.message}`);
      paginazione[cat] = stato;
      continue;
    }

    for (const v of estraiVociListaTfvgb(sessione.html)) idUrl[v.id] = v.url;
    const totalePagine = estraiTotalePagineTfvgb(sessione.html);

    if (stato.completo && stato.totalePagine === totalePagine) {
      // Indice già completo e pagine totali invariate: la pagina 1 (sopra,
      // gratis con l'apertura sessione) basta per intercettare novità.
      stato.totalePagine = totalePagine;
      paginazione[cat] = stato;
      continue;
    }

    let pagina = stato.completo ? 2 : Math.min(stato.paginaSuccessiva, totalePagine + 1);
    let pagineLette = 0;
    while (pagina <= totalePagine && pagineLette < TFVGB_MAX_PAGINE_INDICE_PER_ESECUZIONE) {
      try {
        const html = await fetchPaginaTfvgb(sessione.cookie, pagina);
        for (const v of estraiVociListaTfvgb(html)) idUrl[v.id] = v.url;
        pagina++;
        pagineLette++;
      } catch (err) {
        console.warn(`TFVGB ${tipoSlug} (Cat=${cat}) pagina ${pagina}: non scaricata, riprovo alla prossima esecuzione — ${err.message}`);
        break;
      }
    }
    stato.totalePagine = totalePagine;
    stato.completo = pagina > totalePagine;
    stato.paginaSuccessiva = stato.completo ? 2 : pagina;
    paginazione[cat] = stato;
  }

  return { idUrl, paginazione };
}

async function ingestTfvgbCategoria(tipoSlug, listaCat) {
  const idSnapshot = `turismofvg:${tipoSlug}`;
  const cacheEsistente = await leggiSnapshotEsistente(idSnapshot);

  const { idUrl, paginazione } = await aggiornaIndiceTfvgb(
    tipoSlug,
    listaCat,
    cacheEsistente?.idUrl || {},
    cacheEsistente?.paginazione || {}
  );

  const dettagliCache = { ...(cacheEsistente?.dettagli || {}) };

  // Fix 28/08/2026, bug segnalato dall'utente con screenshot reale
  // (categoria Marina): prima della correzione in
  // estraiCampiIndirizzoTfvgb, un mailto: dentro il link "link_web"
  // (usato da alcune schede al posto di un sito vero) veniva salvato
  // come "sito" — es. "Sito → marina@ppst.it" mostrato in UI. La cache
  // è permanente (una scheda scaricata non viene mai ripetuta), quindi
  // le schede già affette dal bug non si sarebbero corrette da sole:
  // qui vengono invalidate una tantum (tornano "nuove") così da essere
  // ri-scaricate con la correzione, nei limiti per esecuzione come per
  // qualunque scheda nuova — non serve intervenire a mano su Supabase.
  const RE_SITO_CHE_SEMBRA_EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  let invalidate = 0;
  for (const id of Object.keys(dettagliCache)) {
    if (dettagliCache[id]?.sito && RE_SITO_CHE_SEMBRA_EMAIL.test(dettagliCache[id].sito)) {
      delete dettagliCache[id];
      invalidate++;
    }
  }
  if (invalidate > 0) {
    console.log(`TFVGB ${tipoSlug}: ${invalidate} schede con "sito" che era in realtà un'email, invalidate e da ri-scaricare`);
  }

  let nuoveScaricate = 0;
  let rimandate = 0;
  for (const id of Object.keys(idUrl)) {
    if (dettagliCache[id]) continue; // già in cache, mai ri-scaricata

    if (nuoveScaricate >= TFVGB_MAX_NUOVE_SCHEDE_PER_ESECUZIONE) {
      rimandate++;
      continue;
    }

    try {
      const dettaglio = await fetchDettaglioTfvgb(idUrl[id]);
      dettagliCache[id] = { ...dettaglio, aggiornato_al: new Date().toISOString() };
      nuoveScaricate++;
    } catch (err) {
      console.warn(`TFVGB ${tipoSlug}: scheda ${id} non scaricata — ${err.message}`);
    }
  }
  if (rimandate > 0) {
    console.log(`TFVGB ${tipoSlug}: ${rimandate} schede rimandate alla prossima esecuzione (limite ${TFVGB_MAX_NUOVE_SCHEDE_PER_ESECUZIONE}/esecuzione)`);
  }

  // Solo le voci con scheda scaricata finiscono nell'indice pubblico
  // (nome/comune vengono solo da lì) — stessa convenzione già in uso per
  // Agriturismi in costruisceIndiceTurismoFvgPerComune.
  const indice = Object.entries(dettagliCache)
    .filter(([, d]) => d.nome && d.comune)
    .map(([id, d]) => ({ id, nome: d.nome, url: idUrl[id] ?? null, comune: d.comune, lat: d.lat, lon: d.lon }));

  const risultato = { indice, dettagli: dettagliCache, idUrl, paginazione, aggiornato_al: new Date().toISOString() };

  if (
    nuoveScaricate === 0 &&
    cacheEsistente &&
    Object.keys(idUrl).length === Object.keys(cacheEsistente.idUrl || {}).length
  ) {
    console.log(`TFVGB ${tipoSlug}: nessuna novità, snapshot non riscritto`);
    return cacheEsistente;
  }

  try {
    await upsertSnapshot(idSnapshot, "turismofvg", null, risultato);
  } catch (err) {
    console.warn(`TFVGB ${tipoSlug}: snapshot non salvato — ${err.message}`);
  }

  const indiceCompletato = listaCat.every((cat) => paginazione[cat]?.completo);
  console.log(
    `TFVGB ${tipoSlug} aggiornato: ${Object.keys(idUrl).length} id noti (${indiceCompletato ? "indice completo" : "indice in costruzione"}), ${Object.keys(dettagliCache).length} schede con dettaglio (${nuoveScaricate} nuove questa esecuzione)`
  );
  return risultato;
}

async function ingestTurismoFvg() {
  const risultati = {};
  for (const [tipoSlug, segmento] of Object.entries(TURISMOFVG_CATEGORIE)) {
    try {
      risultati[tipoSlug] = await ingestTurismoFvgCategoria(tipoSlug, segmento);
    } catch (err) {
      console.warn(`TurismoFVG ${tipoSlug}: ingestione fallita — ${err.message}`);
    }
  }
  for (const [tipoSlug, listaCat] of Object.entries(TFVGB_CATEGORIE)) {
    try {
      risultati[tipoSlug] = await ingestTfvgbCategoria(tipoSlug, listaCat);
    } catch (err) {
      console.warn(`TFVGB ${tipoSlug}: ingestione fallita — ${err.message}`);
    }
  }
  return risultati;
}

// Indice per comune normalizzato dei dati turismofvg.it di UNA categoria
// (costruito ad ogni esecuzione, i dati vengono dalla rete non da un
// file statico) — solo le voci con scheda di dettaglio già in cache
// (`dettagli[id]`) entrano nell'indice: una voce presente solo
// nell'indice mapdata ma non ancora scaricata (limite per esecuzione)
// non ha ancora contatti da offrire, verrà ripresa da sola quando pronta.
function costruisceIndiceTurismoFvgPerComune(datiCategoria) {
  const indice = new Map();
  if (!datiCategoria) return indice;
  for (const voce of datiCategoria.indice) {
    const dettaglio = datiCategoria.dettagli[voce.id];
    if (!voce.comune || !dettaglio) continue;
    const chiave = normalizzaTesto(voce.comune);
    if (!indice.has(chiave)) indice.set(chiave, []);
    indice.get(chiave).push({ nome: voce.nome, dettaglio, lat: voce.lat, lon: voce.lon });
  }
  return indice;
}

function trovaArricchimentoTurismoFvg(nome, comune, indicePerComune) {
  const candidati = indicePerComune.get(normalizzaTesto(comune));
  if (!candidati) return null;
  const comuneStopwords = new Set(normalizzaTesto(comune).split(" ").filter(Boolean));
  const match = candidati.find((c) => nomiCorrispondono(nome, c.nome, comuneStopwords));
  if (!match) return null;

  const d = match.dettaglio;
  const contatti = { fonte: "turismofvg" };
  if (d.indirizzo) contatti.indirizzo = d.indirizzo;
  if (d.telefono) contatti.telefono = d.telefono;
  if (d.email) contatti.email = d.email;
  if (d.sito) contatti.sito = d.sito;
  if (d.titolare) contatti.titolare = d.titolare;
  if (d.cin) contatti.cin = d.cin;
  const lat = d.lat ?? match.lat;
  const lon = d.lon ?? match.lon;
  if (lat != null && lon != null) {
    contatti.lat = lat;
    contatti.lon = lon;
  }
  return contatti;
}

// Prova prima turismofvg.it (più ricco, quando disponibile per questa
// categoria e questa voce), poi ripiega su OSM — mai i due combinati,
// per non mischiare in un'unica voce dati di provenienza diversa senza
// modo di distinguerli in UI.
function trovaContattiArricchiti(nome, comune, indiceTurismoFvgPerComune) {
  if (indiceTurismoFvgPerComune) {
    const daTurismoFvg = trovaArricchimentoTurismoFvg(nome, comune, indiceTurismoFvgPerComune);
    if (daTurismoFvg) return daTurismoFvg;
  }
  return trovaArricchimentoOsm(nome, comune);
}

async function ingestTipoStrutturaRicettiva(datasetId, indiceTurismoFvgPerComune) {
  const url = `https://www.dati.friuliveneziagiulia.it/resource/${datasetId}.json?$limit=5000`;
  const res = await fetchConRetry(url);
  if (!res.ok) throw new Error(`Dataset ${datasetId} non disponibile (HTTP ${res.status})`);

  const rows = await res.json();
  if (!Array.isArray(rows)) throw new Error(`Dataset ${datasetId}: risposta inattesa`);

  const perProvincia = {};
  for (const r of rows) {
    const provincia = PROVINCE_STRUTTURE_RICETTIVE[(r.provincia ?? "").toUpperCase()];
    if (!provincia || !r.denominazione) continue; // comune fuori regione o riga senza nome — non dovrebbe capitare
    if (!perProvincia[provincia]) perProvincia[provincia] = [];
    const nome = testo(r.denominazione);
    const comune = testo(r.comune);
    perProvincia[provincia].push({
      nome,
      comune,
      email: testo(r.email),
      sito: r.sito?.url ?? null,
      // Arricchimento best-effort — turismofvg.it quando disponibile per
      // questo tipo, altrimenti OpenStreetMap (vedi note sopra). Sempre
      // null se non troviamo un abbinamento nome+comune sufficientemente
      // sicuro, mai un dato inventato o approssimato.
      contatti: trovaContattiArricchiti(nome, comune, indiceTurismoFvgPerComune),
    });
  }
  for (const lista of Object.values(perProvincia)) {
    lista.sort((a, b) => a.nome.localeCompare(b.nome, "it"));
  }

  const totale = Object.values(perProvincia).reduce((n, l) => n + l.length, 0);
  return { totale, per_provincia: perProvincia };
}

async function ingestStruttureRicettive() {
  // turismofvg.it prima di OSM: i suoi indici per comune (uno per tipo
  // coperto — agriturismi via CMS, le altre 7 categorie via TFVGB, vedi
  // rispettivamente TURISMOFVG_CATEGORIE e TFVGB_CATEGORIE) devono essere
  // pronti prima di ingerire i dataset Socrata, che li usano per
  // l'arricchimento contatti.
  const risultatiTurismoFvg = await ingestTurismoFvg();
  const indiciTurismoFvgPerTipo = {};
  for (const [tipoSlug, dati] of Object.entries(risultatiTurismoFvg)) {
    indiciTurismoFvgPerTipo[tipoSlug] = costruisceIndiceTurismoFvgPerComune(dati);
  }

  const chiavi = Object.keys(DATASET_STRUTTURE_RICETTIVE);
  const risultati = await Promise.allSettled(
    chiavi.map((chiave) =>
      ingestTipoStrutturaRicettiva(DATASET_STRUTTURE_RICETTIVE[chiave], indiciTurismoFvgPerTipo[chiave] ?? null)
    )
  );

  const tipi = {};
  let falliti = 0;
  risultati.forEach((r, i) => {
    const chiave = chiavi[i];
    if (r.status === "fulfilled") {
      tipi[chiave] = r.value;
    } else {
      falliti++;
      console.warn(`Strutture ricettive — tipo "${chiave}" fallito:`, r.reason);
    }
  });

  if (Object.keys(tipi).length === 0) {
    console.warn("Strutture ricettive: nessun tipo ingerito con successo, snapshot non aggiornata");
    return;
  }

  await upsertSnapshot("strutture-ricettive", "strutture-ricettive", null, {
    aggiornato_al: new Date().toISOString(),
    tipi,
  });
  const totale = Object.values(tipi).reduce((n, t) => n + t.totale, 0);
  console.log(
    `Strutture ricettive aggiornate: ${totale} strutture in ${Object.keys(tipi).length}/${chiavi.length} tipi` +
      (falliti > 0 ? ` (${falliti} tipi falliti)` : "")
  );
}

// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// QUALITÀ ARIA — OZONO — dataset "Aria - Ozono" (id 7vnx-28uy) sullo
// stesso portale Socrata del PM10. Il campo "rete" corrisponde
// direttamente al nome provincia (più affidabile del confronto per
// nome stazione usato per il PM10). Soglia di legge: 120 µg/m³ media
// mobile 8h (obiettivo di protezione della salute).
// ---------------------------------------------------------------------

const OZONO_DATASET_URL = "https://www.dati.friuliveneziagiulia.it/resource/7vnx-28uy.json";
const SOGLIA_OZONO_UGM3 = 120;

async function ingestOzono() {
  const url = `${OZONO_DATASET_URL}?$order=data_misura DESC&$limit=300`;
  const res = await fetchConRetry(url);
  if (!res.ok) {
    console.warn(`Dataset ozono non disponibile (HTTP ${res.status})`);
    return;
  }

  const rows = await res.json();
  if (!Array.isArray(rows) || rows.length === 0) {
    console.warn("Dataset ozono vuoto");
    return;
  }

  const dataPiuRecente = rows[0].data_misura;
  const righeRecenti = rows.filter((r) => r.data_misura === dataPiuRecente);

  const NOMI_CITTA_PROVINCIA = { trieste: "Trieste", udine: "Udine", gorizia: "Gorizia", pordenone: "Pordenone" };

  const perProvincia = {};
  for (const [provincia, nomeCitta] of Object.entries(NOMI_CITTA_PROVINCIA)) {
    const riga = righeRecenti.find((r) => r.ubicazione?.toLowerCase().includes(nomeCitta.toLowerCase()));
    if (!riga) continue;

    const media8h = riga.media_mobile_8h_max ? Number(riga.media_mobile_8h_max) : null;
    perProvincia[provincia] = {
      stazione: riga.ubicazione,
      media_mobile_8h_max: media8h !== null ? Math.round(media8h) : null,
      superamento: media8h !== null ? media8h > SOGLIA_OZONO_UGM3 : null,
      dati_insufficienti: riga.dati_insuff === "True",
    };
  }

  if (Object.keys(perProvincia).length === 0) {
    console.warn("Nessuna stazione ozono trovata per le 4 province");
    return;
  }

  await upsertSnapshot("aria:ozono", "aria", null, {
    data_misura: dataPiuRecente,
    soglia_ugm3: SOGLIA_OZONO_UGM3,
    per_provincia: perProvincia,
  });
  console.log(`Ozono aggiornato (${Object.keys(perProvincia).length} province):`, dataPiuRecente);
}

// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// QUALITÀ ARIA — BIOSSIDO DI AZOTO (NO2) — dataset "Aria - Biossido
// d'Azoto" (id ke9b-p6z2), stesso portale Socrata. Soglia di legge:
// 200 µg/m³ media oraria massima. Stesso approccio di match per nome
// città in "ubicazione" usato per ozono e PM10 (niente campo "rete"
// nei dati recenti).
// ---------------------------------------------------------------------

const NO2_DATASET_URL = "https://www.dati.friuliveneziagiulia.it/resource/ke9b-p6z2.json";
const SOGLIA_NO2_UGM3 = 200;

async function ingestNo2() {
  const url = `${NO2_DATASET_URL}?$order=data_misura DESC&$limit=300`;
  const res = await fetchConRetry(url);
  if (!res.ok) {
    console.warn(`Dataset NO2 non disponibile (HTTP ${res.status})`);
    return;
  }

  const rows = await res.json();
  if (!Array.isArray(rows) || rows.length === 0) {
    console.warn("Dataset NO2 vuoto");
    return;
  }

  const dataPiuRecente = rows[0].data_misura;
  const righeRecenti = rows.filter((r) => r.data_misura === dataPiuRecente);

  const NOMI_CITTA_PROVINCIA = { trieste: "Trieste", udine: "Udine", gorizia: "Gorizia", pordenone: "Pordenone" };

  const perProvincia = {};
  for (const [provincia, nomeCitta] of Object.entries(NOMI_CITTA_PROVINCIA)) {
    const riga = righeRecenti.find((r) => r.ubicazione?.toLowerCase().includes(nomeCitta.toLowerCase()));
    if (!riga) continue;

    const media = riga.media_oraria_max ? Number(riga.media_oraria_max) : null;
    perProvincia[provincia] = {
      stazione: riga.ubicazione,
      media_oraria_max: media !== null ? Math.round(media) : null,
      superamento: media !== null ? media > SOGLIA_NO2_UGM3 : null,
      dati_insufficienti: riga.dati_insuff === "True",
    };
  }

  if (Object.keys(perProvincia).length === 0) {
    console.warn("Nessuna stazione NO2 trovata per le 4 province");
    return;
  }

  await upsertSnapshot("aria:no2", "aria", null, {
    data_misura: dataPiuRecente,
    soglia_ugm3: SOGLIA_NO2_UGM3,
    per_provincia: perProvincia,
  });
  console.log(`NO2 aggiornato (${Object.keys(perProvincia).length} province):`, dataPiuRecente);
}

// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// QUALITÀ ARIA — PM2.5 — dataset "Aria - Particelle Sospese PM2.5"
// (id d63p-pqpr), stessa struttura del PM10. La normativa italiana
// fissa solo un limite ANNUALE per il PM2.5 (25 µg/m³), non uno
// giornaliero — usiamo quindi la linea guida OMS per le 24h
// (15 µg/m³) come riferimento indicativo, non un vero limite di legge.
// ---------------------------------------------------------------------

const PM25_DATASET_URL = "https://www.dati.friuliveneziagiulia.it/resource/d63p-pqpr.json";
const SOGLIA_PM25_OMS_UGM3 = 15;

async function ingestPm25() {
  const url = `${PM25_DATASET_URL}?$order=data_misura DESC&$limit=300`;
  const res = await fetchConRetry(url);
  if (!res.ok) {
    console.warn(`Dataset PM2.5 non disponibile (HTTP ${res.status})`);
    return;
  }

  const rows = await res.json();
  if (!Array.isArray(rows) || rows.length === 0) {
    console.warn("Dataset PM2.5 vuoto");
    return;
  }

  const dataPiuRecente = rows[0].data_misura;
  const righeRecenti = rows.filter((r) => r.data_misura === dataPiuRecente);

  const NOMI_CITTA_PROVINCIA = { trieste: "Trieste", udine: "Udine", gorizia: "Gorizia", pordenone: "Pordenone" };

  const perProvincia = {};
  for (const [provincia, nomeCitta] of Object.entries(NOMI_CITTA_PROVINCIA)) {
    const riga = righeRecenti.find((r) => r.ubicazione?.toLowerCase().includes(nomeCitta.toLowerCase()));
    if (!riga) continue;

    const media = riga.media_giornaliera ? Number(riga.media_giornaliera) : null;
    perProvincia[provincia] = {
      stazione: riga.ubicazione,
      media_giornaliera: media,
      superamento_oms: media !== null ? media > SOGLIA_PM25_OMS_UGM3 : null,
      dati_insufficienti: riga.dati_insuff === "True",
    };
  }

  if (Object.keys(perProvincia).length === 0) {
    console.warn("Nessuna stazione PM2.5 trovata per le 4 province");
    return;
  }

  await upsertSnapshot("aria:pm25", "aria", null, {
    data_misura: dataPiuRecente,
    soglia_oms_ugm3: SOGLIA_PM25_OMS_UGM3,
    per_provincia: perProvincia,
  });
  console.log(`PM2.5 aggiornato (${Object.keys(perProvincia).length} province):`, dataPiuRecente);
}

// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// POLLINI — rete aerobiologica POLLnet, dataset "Aria - Pollini" (id
// rnci-smsu) sullo stesso portale Socrata delle altre matrici aria.
// A differenza di PM10/PM2.5/Ozono/NO2, qui non c'è un solo valore
// per provincia ma decine di generi pollinici per stazione — teniamo
// solo i generi con presenza rilevata questa settimana (media > 0),
// i più alti per primi.
//
// Il dataset contiene insieme stazioni storiche dismesse e stazioni
// attive (stesso "sito", ma dati fermi ad anni diversi) — le
// associamo a provincia per nome e le consideriamo attive solo se
// compaiono nella settimana più recente (stesso "al" della riga più
// recente in assoluto). Verificato manualmente (agosto 2026): 4
// stazioni attive — Trieste (Castello di S. Giusto), Lignano
// Sabbiadoro e Tolmezzo (entrambe provincia di Udine), Pordenone.
// **Nessuna stazione attiva in provincia di Gorizia** (Monfalcone,
// l'unica storica lì, ferma al 2011) — gap noto e reale della rete
// regionale, non un bug: stesso trattamento "n.d." già usato altrove
// nel progetto (es. ozono a Pordenone, stazione dismessa dal 2013).
//
// Nessuna classificazione di rischio (assente/scarsa/media/alta):
// ARPA FVG la pubblica ma con soglie diverse per ciascun genere,
// documentate solo in una pagina che non è stato possibile estrarre
// in modo affidabile in formato tabellare — mostriamo il dato grezzo
// (media giornaliera della settimana, granuli/m³) rimandando al
// bollettino ufficiale per l'interpretazione clinica.
// ---------------------------------------------------------------------

const POLLINI_DATASET_URL = "https://www.dati.friuliveneziagiulia.it/resource/rnci-smsu.json";

const STAZIONI_POLLINI = [
  { match: "trieste 1", provincia: "trieste", nome: "Trieste — Castello di S. Giusto" },
  { match: "lignano", provincia: "udine", nome: "Lignano Sabbiadoro" },
  { match: "tolmezzo", provincia: "udine", nome: "Tolmezzo" },
  { match: "pordenone 1", provincia: "pordenone", nome: "Pordenone" },
];

async function ingestPollini() {
  const url = `${POLLINI_DATASET_URL}?$order=al DESC&$limit=1000`;
  const res = await fetchConRetry(url);
  if (!res.ok) {
    console.warn(`Dataset pollini non disponibile (HTTP ${res.status})`);
    return;
  }

  const rows = await res.json();
  if (!Array.isArray(rows) || rows.length === 0) {
    console.warn("Dataset pollini vuoto");
    return;
  }

  const alPiuRecente = rows[0].al;
  const righeRecenti = rows.filter((r) => r.al === alPiuRecente);
  const dalSettimana = righeRecenti[0]?.dal ?? null;

  const perProvincia = {};
  for (const staz of STAZIONI_POLLINI) {
    const righeStazione = righeRecenti.filter((r) => r.sito?.toLowerCase().includes(staz.match));
    if (righeStazione.length === 0) continue; // stazione non presente questa settimana

    const pollini = righeStazione
      .map((r) => ({
        famiglia: r.famiglia ?? null,
        genere: r.genere ?? null,
        media: r.media !== undefined && r.media !== null ? Number(r.media) : null,
      }))
      .filter((p) => p.media !== null && p.media > 0 && p.genere)
      .sort((a, b) => b.media - a.media)
      .slice(0, 6)
      .map((p) => ({ ...p, media: Math.round(p.media * 10) / 10 }));

    if (!perProvincia[staz.provincia]) perProvincia[staz.provincia] = [];
    perProvincia[staz.provincia].push({ stazione: staz.nome, pollini });
  }

  if (Object.keys(perProvincia).length === 0) {
    console.warn("Nessuna stazione pollini attiva trovata nella settimana più recente");
    return;
  }

  await upsertSnapshot("pollini", "pollini", null, {
    dal: dalSettimana,
    al: alPiuRecente,
    per_provincia: perProvincia,
  });
  console.log(
    `Pollini aggiornati (${Object.keys(perProvincia).length} province, settimana fino al ${alPiuRecente})`
  );
}

// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// AMBIENTE → SERVIZI → RIFIUTI — calendario raccolta differenziata,
// Isontina Ambiente (17/09/2026, richiesto dall'utente: nuova sezione
// "Servizi" dentro Ambiente, si parte con la raccolta rifiuti).
//
// L'utente ha allegato un pacchetto generato con ChatGPT
// (FVG_Monitor_Rifiuti_Isontina_v3.zip): uno script di sync separato
// (sync_isontina_ambiente.ts, da eseguire con npx tsx), un proprio
// schema Supabase relazionale (waste_municipalities/
// waste_address_options/waste_collection_occurrences + vista
// waste_next_collections), e un set di "regole standard Area A-E" come
// fallback quando l'HTML non si riesce a leggere. **Questa architettura
// non è stata adottata**, stesso principio già seguito per Eventi: il
// progetto usa un solo ingest-light.mjs + tabella snapshots, non una
// pipeline/schema a parte. Le "regole standard Area A-E" del pacchetto,
// inoltre, citano come fonte dei PDF calendario del **2022** (vedi
// isontina_area_rules_2026.json → meta.sources, URL con
// "A4_2022_STAMPA_..." nonostante il nome del file), quindi NON sono
// state usate come fallback autoritativo: se il parser HTML non trova
// nulla per un giorno, questo modulo lo lascia semplicemente vuoto
// invece di inventare un pattern.
//
// Verifica con HTML reale (WebFetch, come già successo con
// gare.lnd.it/turismofvg.it in questo progetto, vede il calendario ma
// non l'associazione giorno→tipo di rifiuto: è in <div class="dot
// COLORE"> senza testo, perso dalla conversione in markdown) — l'utente
// ha fornito il sorgente pagina reale di Gorizia (comune con PIÙ aree:
// ha un <select name="indirizzo"> con centinaia di vie, ciascuna con
// una etichetta "VIA X , Gorizia Area B") e di Sagrado (comune con
// UN'AREA sola: nessun <select>, il calendario compare direttamente).
// Da questi due esempi reali:
// - tabella `table.calendar`, celle `td` con il numero del giorno come
//   unico testo e zero o più `<div class="dot COLORE"></div>` per i
//   tipi di rifiuto raccolti quel giorno (nessun altro testo nella
//   cella, quindi `clean($td.text())` dà esattamente il numero);
// - legenda in `.legend > div` (`<span class="dot COLORE"></span>
//   ETICHETTA`) — usata per costruire la mappa colore→tipo invece di
//   fissarla via codice, più robusta a variazioni;
// - intestazione mese "<h3>Settembre 2026</h3>" per validare che la
//   pagina restituita corrisponda davvero al mese/anno richiesti;
// - link "Scarica il Calendario porta a porta (Area X)" per leggere
//   l'area quando non c'è un select (comune a area unica);
// - blocco "Conferimenti ingombranti e verde" (tabella th/td: Indirizzo
//   / Apertura+materiali) e "Campane del vetro" (lista `<ul><li>`).
//
// **Non verificato**: il comportamento delle altre 26 pagine comune
// (solo Gorizia e Sagrado sono state controllate con HTML reale) — il
// parser assume che tutte condividano lo stesso template (stessa
// piattaforma, stesse classi CSS), ragionevole ma non confermato da
// questa sandbox (isontinambiente.it non è raggiungibile con una
// richiesta diretta da qui, stesso limite già visto per altri domini in
// questo progetto). Confermato solo da un'esecuzione reale su GitHub
// Actions.
//
// **Livello di dettaglio (scelto dall'utente)**: "solo comune", niente
// ricerca per via/indirizzo come nel pacchetto originale — troppo
// complesso da costruire e verificare per centinaia di indirizzi su 28
// comuni. Il dato reale mostra però che un comune può avere PIÙ aree al
// suo interno (Gorizia ne ha 6, A-F, a seconda della via); per restare
// corretti senza costruire una ricerca per via, quando un comune ha più
// aree questo modulo le tiene TUTTE (una per area, usando il primo
// indirizzo trovato in quell'area come rappresentante) — il frontend
// mostra poi un piccolo selettore di area solo per i comuni che ne
// hanno più di una, non una ricerca fra centinaia di vie.
//
// **Frequenza**: i calendari di raccolta non cambiano quasi mai (il
// pacchetto originale raccomandava "1 volta al giorno") — a differenza
// del resto del sito, che gira ogni 15 minuti via cron, questo modulo
// esegue il fetch reale solo una volta al giorno (finestra 03:00-03:14
// Europe/Rome) per non sovraccaricare isontinambiente.it con ~28 comuni
// × fino a 2 richieste per area ad ogni esecuzione da 15 minuti. Un
// avvio manuale (workflow_dispatch da GitHub Actions) bypassa la
// finestra oraria, utile per verificare subito dopo il deploy.
// ---------------------------------------------------------------------

const RIFIUTI_ORA_SYNC = 3; // 03:00 Europe/Rome, una volta al giorno
const RIFIUTI_CONCORRENZA = 4; // richieste in parallelo verso isontinambiente.it

const RIFIUTI_COMUNI = [
  { slug: "capriva-del-friuli", nome: "Capriva del Friuli", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/capriva-del-friuli/", provincia: "gorizia", gestore: "Isontina Ambiente" },
  { slug: "cormons", nome: "Cormons", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/cormons/", provincia: "gorizia", gestore: "Isontina Ambiente" },
  { slug: "doberdo-del-lago", nome: "Doberdò del Lago", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/doberdo-del-lago/", provincia: "gorizia", gestore: "Isontina Ambiente" },
  { slug: "dolegna-del-collio", nome: "Dolegna del Collio", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/dolegna-del-collio/", provincia: "gorizia", gestore: "Isontina Ambiente" },
  { slug: "duino-aurisina", nome: "Duino Aurisina", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/duino-aurisina/", provincia: "trieste", gestore: "Isontina Ambiente" },
  { slug: "farra-disonzo", nome: "Farra d’Isonzo", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/farra-disonzo/", provincia: "gorizia", gestore: "Isontina Ambiente" },
  { slug: "fogliano-redipuglia", nome: "Fogliano Redipuglia", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/fogliano-redipuglia/", provincia: "gorizia", gestore: "Isontina Ambiente" },
  { slug: "gorizia", nome: "Gorizia", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/gorizia/", provincia: "gorizia", gestore: "Isontina Ambiente" },
  { slug: "gradisca-disonzo", nome: "Gradisca d’Isonzo", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/gradisca-disonzo/", provincia: "gorizia", gestore: "Isontina Ambiente" },
  { slug: "grado", nome: "Grado", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/grado/", provincia: "gorizia", gestore: "Isontina Ambiente" },
  { slug: "mariano-del-friuli", nome: "Mariano del Friuli", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/mariano-del-friuli/", provincia: "gorizia", gestore: "Isontina Ambiente" },
  { slug: "medea", nome: "Medea", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/medea/", provincia: "gorizia", gestore: "Isontina Ambiente" },
  { slug: "monfalcone", nome: "Monfalcone", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/monfalcone/", provincia: "gorizia", gestore: "Isontina Ambiente" },
  { slug: "monrupino", nome: "Monrupino", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/monrupino/", provincia: "trieste", gestore: "Isontina Ambiente" },
  { slug: "moraro", nome: "Moraro", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/moraro/", provincia: "gorizia", gestore: "Isontina Ambiente" },
  { slug: "mossa", nome: "Mossa", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/mossa/", provincia: "gorizia", gestore: "Isontina Ambiente" },
  { slug: "romans-disonzo", nome: "Romans d’Isonzo", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/romans-disonzo/", provincia: "gorizia", gestore: "Isontina Ambiente" },
  { slug: "ronchi-dei-legionari", nome: "Ronchi dei Legionari", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/ronchi-dei-legionari/", provincia: "gorizia", gestore: "Isontina Ambiente" },
  { slug: "sagrado", nome: "Sagrado", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/sagrado/", provincia: "gorizia", gestore: "Isontina Ambiente" },
  { slug: "san-canzian-disonzo", nome: "San Canzian d’Isonzo", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/san-canzian-disonzo/", provincia: "gorizia", gestore: "Isontina Ambiente" },
  { slug: "san-floriano-del-collio", nome: "San Floriano del Collio", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/san-floriano-del-collio/", provincia: "gorizia", gestore: "Isontina Ambiente" },
  { slug: "san-lorenzo-isontino", nome: "San Lorenzo Isontino", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/san-lorenzo-isontino/", provincia: "gorizia", gestore: "Isontina Ambiente" },
  { slug: "san-pier-disonzo", nome: "San Pier d’Isonzo", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/san-pier-disonzo/", provincia: "gorizia", gestore: "Isontina Ambiente" },
  { slug: "savogna-disonzo", nome: "Savogna d’Isonzo", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/savogna-disonzo/", provincia: "gorizia", gestore: "Isontina Ambiente" },
  { slug: "sgonico-zgonik", nome: "Sgonico - Zgonik", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/sgonico-zgonik/", provincia: "trieste", gestore: "Isontina Ambiente" },
  { slug: "staranzano", nome: "Staranzano", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/staranzano/", provincia: "gorizia", gestore: "Isontina Ambiente" },
  { slug: "turriaco", nome: "Turriaco", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/turriaco/", provincia: "gorizia", gestore: "Isontina Ambiente" },
  { slug: "villesse", nome: "Villesse", url: "https://isontinambiente.it/it/servizi/servizi-per-il-tuo-comune/villesse/", provincia: "gorizia", gestore: "Isontina Ambiente" },
];

const RIFIUTI_MESI_IT = [
  "gennaio", "febbraio", "marzo", "aprile", "maggio", "giugno",
  "luglio", "agosto", "settembre", "ottobre", "novembre", "dicembre",
];

// Normalizza spazi/a-capo del testo estratto — a differenza di altre
// sezioni di questo file, qui il markup della fonte (tabelle/liste con
// molta indentazione) rende questo helper necessario in quasi ogni
// funzione di parsing sotto, quindi lo definiamo una sola volta invece
// di ripetere .replace(/\s+/g," ").trim() ad ogni chiamata.
function clean(s = "") {
  return (s ?? "").replace(/\s+/g, " ").trim();
}

// Fallback fisso se per qualche motivo la legenda non si riesce a
// leggere dalla pagina — i colori osservati nell'HTML reale di Gorizia
// e Sagrado (17/09/2026).
const RIFIUTI_COLORI_DEFAULT = new Map([
  ["viola", "paper"],
  ["marrone", "organic"],
  ["giallo", "plastic_metals"],
  ["grigio", "residual"],
]);

function rifiutiTipoDaEtichetta(s = "") {
  const n = s.normalize("NFKD").replace(/[̀-ͯ]/g, "").toLowerCase();
  if (n.includes("carta") || n.includes("cartone")) return "paper";
  if (n.includes("organico") || n.includes("umido")) return "organic";
  if (n.includes("plastica") || n.includes("lattine")) return "plastic_metals";
  if (n.includes("secco") || n.includes("residuo") || n.includes("indifferenzi")) return "residual";
  if (n.includes("vetro")) return "glass";
  return null;
}

function oraEuropeRome() {
  const parti = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Europe/Rome",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).formatToParts(new Date());
  return {
    ora: Number(parti.find((p) => p.type === "hour")?.value ?? 0),
    minuti: Number(parti.find((p) => p.type === "minute")?.value ?? 0),
  };
}

function rifiutiMeseSuccessivo(anno, mese) {
  return mese === 12 ? { anno: anno + 1, mese: 1 } : { anno, mese: mese + 1 };
}

async function rifiutiGetHtml(url) {
  const res = await fetchConRetry(url, {
    headers: { "User-Agent": "Mozilla/5.0 (compatible; FVGMonitorBot/1.0)" },
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return cheerio.load(await res.text());
}

function rifiutiParseLegenda($) {
  const map = new Map();
  $(".legend > div").each((_, div) => {
    const $div = $(div);
    const dot = $div.find(".dot").first();
    if (!dot.length) return;
    const classi = (dot.attr("class") || "").split(/\s+/).filter(Boolean);
    const colore = classi.find((c) => c !== "dot");
    if (!colore) return;
    const tipo = rifiutiTipoDaEtichetta(clean($div.text()));
    if (tipo) map.set(colore, tipo);
  });
  return map.size > 0 ? map : RIFIUTI_COLORI_DEFAULT;
}

// Corretto il 18/09/2026 — bug reale, non solo teorico: la vecchia
// regex `/Area\s+([A-Za-z0-9]+)\s*$/i` catturava una sola parola dopo
// "Area", andava bene per Gorizia/Ronchi dei Legionari ("...Area B",
// "...Area C" — verificati su HTML reale/WebFetch) ma falliva in
// silenzio (nessun match, `area: null` per OGNI indirizzo) su comuni
// dove l'etichetta ripete il nome del comune prima della zona, es.
// Monfalcone ("...Area Monfalcone Nord/Est/Sud/Ovest", 4 zone — confermato
// via WebFetch) e Grado ("...Area Grado Fossalon Boscat"/"...Area Grado
// Cavarera", 2 zone). Con `area: null` per tutti gli indirizzi, il
// raggruppamento in rifiutiFetchComune() li collassava tutti sotto la
// stessa chiave "?" e teneva SOLO il primo indirizzo trovato in tutto il
// comune come rappresentante — Monfalcone e Grado mostravano quindi UNA
// sola area invece delle 4/2 reali, silenziosamente (nessun errore in
// log, semplicemente un comune multi-zona trattato come se fosse a zona
// unica). Individuato da una segnalazione dell'utente (pacchetto
// "correzione multizona" generato con ChatGPT, con la sua solita
// architettura a schema Supabase separato — MAI adottata, stesso
// principio di questo intero modulo — ma lo spunto sulla regex è stato
// verificato in modo indipendente con WebFetch reale su Monfalcone,
// Ronchi dei Legionari e Grado prima di scrivere questo fix, non preso
// per buono dal pacchetto). Ora la regex cattura tutto il resto
// dell'etichetta dopo "Area" (non solo una parola), e
// rifiutiNormalizzaAreaLabel() toglie l'eventuale ripetizione del nome
// del comune davanti alla zona, per restare coerenti con lo stile
// "Nord"/"Sud" già usato per Tolmezzo (AET2000) invece di mostrare
// "Area Monfalcone Nord" in un selettore che ha già "Monfalcone" scelto
// come comune.
function rifiutiNormalizzaAreaLabel(testoArea, nomeComune) {
  let area = clean(testoArea).replace(/\)\s*$/, "");
  if (!area) return null;
  if (nomeComune) {
    const prefisso = new RegExp(`^${nomeComune.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\s+`, "i");
    area = area.replace(prefisso, "").trim();
  }
  if (!area) return null;
  // Codici corti tipo lettera (Gorizia "A".."F", Ronchi dei Legionari
  // "B"/"C"/"F") restano in maiuscolo come prima; nomi di zona più
  // lunghi (Monfalcone Nord/Est/Sud/Ovest, Grado Fossalon Boscat/
  // Cavarera) restano scritti come nella pagina.
  return /^[A-Za-z0-9]{1,3}$/.test(area) ? area.toUpperCase() : area;
}

function rifiutiParseIndirizzi($, nomeComune) {
  const sel = $('select[name="indirizzo"]');
  if (!sel.length) return [];
  const out = [];
  sel.find("option").each((_, opt) => {
    const value = clean($(opt).attr("value") || "");
    const label = clean($(opt).text());
    if (!value || !label) return;
    const m = label.match(/Area\s+(.+)$/i);
    out.push({ id: value, label, area: m ? rifiutiNormalizzaAreaLabel(m[1], nomeComune) : null });
  });
  return out;
}

function rifiutiParseAreaDaIntestazione($, nomeComune) {
  const h2 = $("h2")
    .filter((_, el) => /calendario porta a porta/i.test(clean($(el).text())))
    .first();
  if (!h2.length) return null;
  const m = clean(h2.text()).match(/Area\s+([^)]+)\)?/i);
  return m ? rifiutiNormalizzaAreaLabel(m[1], nomeComune) : null;
}

function rifiutiPaginaCorrispondeAMese($, anno, mese) {
  const h3 = clean($("h3").first().text()).toLowerCase();
  return h3.includes(RIFIUTI_MESI_IT[mese - 1]) && h3.includes(String(anno));
}

function rifiutiParseCalendario($, anno, mese, mappaColori) {
  if (!rifiutiPaginaCorrispondeAMese($, anno, mese)) return [];
  const giorni = [];
  $("table.calendar tbody td").each((_, td) => {
    const $td = $(td);
    const giornoNum = parseInt(clean($td.text()), 10);
    if (!giornoNum || giornoNum < 1 || giornoNum > 31) return;
    const tipi = new Set();
    $td.find("div.dot").each((_, dot) => {
      const classi = ($(dot).attr("class") || "").split(/\s+/).filter(Boolean);
      const colore = classi.find((c) => c !== "dot");
      const tipo = colore ? mappaColori.get(colore) : null;
      if (tipo) tipi.add(tipo);
    });
    if (tipi.size === 0) return;
    giorni.push({ data: `${anno}-${pad2(mese)}-${pad2(giornoNum)}`, tipi: [...tipi] });
  });
  return giorni;
}

function rifiutiParseCentro($) {
  const h2 = $("h2")
    .filter((_, el) => /conferimenti ingombranti/i.test(clean($(el).text())))
    .first();
  if (!h2.length) return null;
  const tabella = h2.nextAll("table").first();
  if (!tabella.length) return null;

  let indirizzo = null;
  let aperturaHtml = null;
  tabella.find("tr").each((_, tr) => {
    const etichetta = clean($(tr).find("th").text()).toLowerCase();
    const cella = $(tr).find("td").first();
    if (etichetta === "indirizzo") indirizzo = clean(cella.text());
    if (etichetta === "apertura") aperturaHtml = cella;
  });

  // La cella "Apertura" contiene sia gli orari sia, dopo un <h3>"Cosa
  // puoi portare", l'elenco materiali — come paragrafi <p> fratelli,
  // non un unico blocco di testo. Estrarre child per child (invece di
  // un'unica .text() + substring) evita due problemi visti nei primi
  // test contro l'HTML reale: paragrafi che si accostano senza spazio
  // ("...venerdìdalle 14:30...") e materiali con una virgola interna fra
  // parentesi (es. "Verde (ramaglie, potature, sfalci)") spezzati in tre
  // voci separate da uno split ingenuo sulla virgola.
  let apertura = null;
  let materiali = [];
  if (aperturaHtml) {
    const h3PuoiPortare = aperturaHtml
      .find("h3")
      .filter((_, el) => /cosa puoi portare/i.test(clean($(el).text())))
      .first();
    const paragrafiApertura = [];
    const paragrafiMateriali = [];
    let dopoIntestazione = false;
    aperturaHtml.children().each((_, el) => {
      if (h3PuoiPortare.length && el === h3PuoiPortare.get(0)) {
        dopoIntestazione = true;
        return;
      }
      // cheerio .text() non inserisce uno spazio ai <br> (es. "<b>Dal
      // lunedì al venerdì</b><br/>dalle 14:30..." darebbe
      // "venerdìdalle 14:30" senza spazio) — sostituiti con uno spazio
      // su un clone prima di leggere il testo.
      const $clone = $(el).clone();
      $clone.find("br").replaceWith(" ");
      const t = clean($clone.text());
      if (!t) return;
      (dopoIntestazione ? paragrafiMateriali : paragrafiApertura).push(t);
    });
    apertura = paragrafiApertura.join(" ") || null;
    materiali = paragrafiMateriali
      .join(", ")
      .split(/,(?![^(]*\))/) // non spezzare una virgola dentro le parentesi
      .map(clean)
      .filter(Boolean);
  }

  if (!indirizzo && !apertura && materiali.length === 0) return null;
  return { indirizzo, apertura, materiali };
}

function rifiutiParseCampaneVetro($) {
  const h2 = $("h2")
    .filter((_, el) => /campane del vetro/i.test(clean($(el).text())))
    .first();
  if (!h2.length) return [];
  const ul = h2.nextAll("ul").first();
  if (!ul.length) return [];
  return ul
    .find("li")
    .map((_, li) => clean($(li).text()))
    .get()
    .filter(Boolean);
}

// Esegue un elenco di funzioni async con un massimo di `limite` in volo
// contemporaneamente — nessuna libreria esterna, elenco piccolo
// (qualche decina di richieste verso lo stesso sito, una volta al
// giorno): non vale la pena aggiungere una dipendenza per questo.
async function rifiutiConLimiteConcorrenza(elementi, limite, fn) {
  const risultati = new Array(elementi.length);
  let indice = 0;
  async function worker() {
    while (indice < elementi.length) {
      const i = indice++;
      risultati[i] = await fn(elementi[i], i);
    }
  }
  await Promise.all(Array.from({ length: Math.min(limite, elementi.length) }, worker));
  return risultati;
}

async function rifiutiFetchComune(comune, anno, mese) {
  const prossimo = rifiutiMeseSuccessivo(anno, mese);

  const urlBase = new URL(comune.url);
  urlBase.searchParams.set("month", String(mese));
  urlBase.searchParams.set("year", String(anno));
  const $base = await rifiutiGetHtml(urlBase.toString());

  const mappaColori = rifiutiParseLegenda($base);
  const indirizzi = rifiutiParseIndirizzi($base, comune.nome);
  const centro = rifiutiParseCentro($base);
  const campaneVetro = rifiutiParseCampaneVetro($base);

  const aree = [];

  if (indirizzi.length === 0) {
    // Comune a area unica: nessun <select>, il calendario compare già
    // nella pagina base senza bisogno di un indirizzo specifico.
    const area = rifiutiParseAreaDaIntestazione($base, comune.nome);
    const giorniMese1 = rifiutiParseCalendario($base, anno, mese, mappaColori);

    const urlMese2 = new URL(comune.url);
    urlMese2.searchParams.set("month", String(prossimo.mese));
    urlMese2.searchParams.set("year", String(prossimo.anno));
    const $mese2 = await rifiutiGetHtml(urlMese2.toString());
    const giorniMese2 = rifiutiParseCalendario($mese2, prossimo.anno, prossimo.mese, mappaColori);

    aree.push({ area, giorni: [...giorniMese1, ...giorniMese2] });
  } else {
    // Comune con più indirizzi: raggruppa per area (etichetta "Area X"
    // già presente nel testo di ogni opzione) e usa il primo indirizzo
    // trovato in ciascuna area come rappresentante — niente ricerca per
    // via, solo le aree distinte presenti nel comune (v. commento sopra
    // la sezione).
    const primoIndirizzoPerArea = new Map();
    for (const opt of indirizzi) {
      const chiave = opt.area || "?";
      if (!primoIndirizzoPerArea.has(chiave)) primoIndirizzoPerArea.set(chiave, opt.id);
    }

    await rifiutiConLimiteConcorrenza(
      [...primoIndirizzoPerArea.entries()],
      RIFIUTI_CONCORRENZA,
      async ([area, indirizzoId]) => {
        const url1 = new URL(comune.url);
        url1.searchParams.set("indirizzo", indirizzoId);
        url1.searchParams.set("month", String(mese));
        url1.searchParams.set("year", String(anno));
        const $1 = await rifiutiGetHtml(url1.toString());
        const giorniMese1 = rifiutiParseCalendario($1, anno, mese, mappaColori);

        const url2 = new URL(comune.url);
        url2.searchParams.set("indirizzo", indirizzoId);
        url2.searchParams.set("month", String(prossimo.mese));
        url2.searchParams.set("year", String(prossimo.anno));
        const $2 = await rifiutiGetHtml(url2.toString());
        const giorniMese2 = rifiutiParseCalendario($2, prossimo.anno, prossimo.mese, mappaColori);

        aree.push({ area: area === "?" ? null : area, giorni: [...giorniMese1, ...giorniMese2] });
      }
    );
  }

  return {
    slug: comune.slug,
    nome: comune.nome,
    provincia: comune.provincia,
    gestore: comune.gestore,
    aree,
    centro_raccolta: centro,
    campane_vetro: campaneVetro,
    stale: false,
  };
}

// Recupera i comuni gestiti da Isontina Ambiente. Non scrive lo
// snapshot — restituisce solo l'elenco comuni, così ingestRifiuti()
// può unirlo con quelli degli altri gestori (es. AET2000, provincia di
// Udine) prima di un unico upsertSnapshot() sullo snapshot condiviso
// "rifiuti". Tenere i fetch dei vari gestori come funzioni separate ma
// il salvataggio unificato è intenzionale: evita che due scritture
// concorrenti sullo stesso snapshot si sovrascrivano a vicenda.
// V.A.SCO. ("Veicolo Anti SCOvazze"), Monfalcone — segnalato
// dall'utente il 19/09/2026 con il link alla pagina reale del Comune
// (sezione "Trasparenza nel servizio di gestione dei rifiuti urbani e
// assimilati" → V.A.SCO.). Verificato con la pagina reale (accessibility
// tree + innerText, non solo WebFetch: la pagina è una SPA e WebFetch da
// solo restituiva l'errore "serve JavaScript", mai il contenuto —
// stesso limite già incontrato altrove in questo progetto per siti
// client-side-rendered). **Non un fetch ad ogni esecuzione**: è
// contenuto statico pubblicato dal Comune (ultima modifica pagina
// dichiarata: 18 mag 2026), stesso principio già usato per i dati GEA
// (PDF annuali trascritti a mano) — un valore che cambia raramente non
// giustifica un fetch live ad ogni run, soprattutto per una singola
// pagina di un solo comune su 28 di questo gestore.
//
// **Cos'è**: un container mobile di Isontina Ambiente pensato per chi
// ha difficoltà a usare il sistema di raccolta "porta a porta" — sosta
// in punti diversi della città secondo un doppio turno settimanale
// (lun/mer/gio in 4 punti, mar/ven/sab in 5 punti), NON un centro fisso
// né un calendario per tipo di rifiuto: v. i nuovi tipi
// `VeicoloMobileRifiuti`/`SostaVeicoloMobile` in lib/rifiuti.ts. Accetta
// carta e cartone, imballaggi in plastica e lattine, umido e secco
// residuo — testualmente NON il vetro (coerente con il resto di
// Isontina, dove il vetro è sempre e solo tramite campane stradali, mai
// porta a porta né in un punto di conferimento come questo).
const VASCO_MONFALCONE = {
  nome: "V.A.SCO. — Veicolo Anti SCOvazze",
  descrizione:
    "Container mobile di Isontina Ambiente per chi ha difficoltà a usare il sistema di raccolta porta a porta.",
  materiali: ["paper", "plastic_metals", "organic", "residual"],
  soste: [
    { luogo: "Piazzale Tommaseo", giorni: "Lunedì, mercoledì e giovedì", orario: "15:00–18:00" },
    { luogo: "Park via Valentinis/Tonzar", giorni: "Lunedì, mercoledì e giovedì", orario: "18:30–21:00" },
    { luogo: "Via Rosselli int. Duomo", giorni: "Lunedì, mercoledì e giovedì", orario: "15:30–19:00" },
    { luogo: "Via Don P. Fanin", giorni: "Lunedì, mercoledì e giovedì", orario: "19:30–21:30" },
    { luogo: "Via Napoli", giorni: "Martedì, venerdì, sabato", orario: "15:30–19:00" },
    { luogo: "Via Giarrette – Marina Julia", giorni: "Martedì, venerdì, sabato", orario: "19:30–20:30" },
    { luogo: "Via Gramsci", giorni: "Martedì, venerdì, sabato", orario: "17:00–18:00" },
    { luogo: "Park via Aquileia", giorni: "Martedì, venerdì, sabato", orario: "15:00–16:30" },
    { luogo: "Park via I Maggio – Via Pocar", giorni: "Martedì, venerdì, sabato", orario: "18:30–21:00" },
  ],
};

async function rifiutiIngestIsontina(annoCorrente, meseCorrente, precedentePerSlug) {
  const risultati = await rifiutiConLimiteConcorrenza(RIFIUTI_COMUNI, RIFIUTI_CONCORRENZA, async (comune) => {
    try {
      return await rifiutiFetchComune(comune, annoCorrente, meseCorrente);
    } catch (err) {
      console.warn(`Rifiuti (Isontina): errore comune ${comune.nome}: ${err.message}`);
      const vecchio = precedentePerSlug.get(comune.slug);
      return vecchio ? { ...vecchio, stale: true } : null;
    }
  });
  const comuni = risultati.filter(Boolean);
  // Innestato qui, non nel fetch di rete: VASCO non arriva dal sito
  // isontinambiente.it (fonte del calendario/centro/campane sopra), ma
  // dal sito del Comune di Monfalcone — v. commento esteso su
  // VASCO_MONFALCONE sopra.
  const monfalcone = comuni.find((c) => c.slug === "monfalcone");
  if (monfalcone) monfalcone.veicolo_mobile = VASCO_MONFALCONE;
  const falliti = RIFIUTI_COMUNI.length - comuni.filter((c) => !c.stale).length;
  console.log(
    `Rifiuti (Isontina) aggiornati: ${comuni.length}/${RIFIUTI_COMUNI.length} comuni` +
      (falliti > 0 ? ` (${falliti} da cache/stale per errori di rete)` : "")
  );
  return comuni;
}

// ---------------------------------------------------------------------
// Rifiuti — A&T 2000 (secondo gestore, provincia di Udine)
// ---------------------------------------------------------------------
//
// Pacchetto ChatGPT ricevuto (FVG_Monitor_Rifiuti_AET2000_v1.zip): uno
// script sync_aet2000.ts a parte con proprio client Supabase e scoperta
// dinamica dei comuni da https://aet2000.it/comuni/. Stessa architettura
// NON adottata di Isontina/GEA: resta un solo ingest-light.mjs + tabella
// snapshots. La scoperta dinamica dei comuni NON è stata adottata
// nemmeno come idea, per lo stesso motivo per cui non si è mai scritto
// un selettore di produzione basato solo su WebFetch in questo
// progetto: la pagina indice /comuni/ è stata vista solo via WebFetch
// (80 comuni, alcuni slug non banali — vedi sotto), mai come HTML
// reale, e WebFetch si è già dimostrato inaffidabile su liste in questo
// stesso progetto (GEA: "26 comuni" nel riassunto contro 24 nell'elenco
// puntato dello stesso risultato).
//
// **HTML reale ricevuto e usato per questo parser** (18/09/2026): San
// Daniele del Friuli (comune a area unica) e Tolmezzo (comune con DUE
// calendari sulla stessa pagina, Nord e Sud) per modalita-di-raccolta/,
// più una pagina centro-di-raccolta/ di Tolmezzo. Struttura scoperta:
// - `<table class="calendar-table">` con celle `<td class="text-center">`
//   → `<div class="giorno ...">` (quelle del mese precedente/successivo
//   hanno la classe aggiuntiva "not_current_month" e vengono scartate,
//   altrimenti si costruirebbe una data inesistente tipo 31 settembre)
//   → zero o più bottoni dentro `.raccolto`, ciascuno con `<div
//   class="rifiuto icon"><img alt="umido|plastica|vetro|secco|carta">`
//   — l'attributo `alt` (5 valori fissi, verificati nell'HTML reale)
//   basta da solo per il tipo di rifiuto, senza bisogno di leggere
//   colori o testo. Ogni bottone ha anche un modal con un secondo
//   `<img>` dello stesso `alt` (per l'etichetta estesa): il selettore
//   `.raccolto button .rifiuto.icon img` prende solo l'icona visibile
//   del bottone, non quella duplicata dentro il modal;
// - intestazione `<h3>` dentro `div#calendar` (sempre il fratello
//   immediatamente precedente della `table.calendar-table` dello stesso
//   blocco) con "Mese AAAA" e, quando il comune ha più calendari sulla
//   stessa pagina (finora solo Tolmezzo), un prefisso "NomeComune - Zona
//   X |" prima del mese. Invece di hardcodare "Tolmezzo Nord/Sud", il
//   parser estrae ogni `table.calendar-table` della pagina come blocco
//   a sé (un comune può averne 1 o più) e usa "Zona X" come etichetta
//   d'area quando presente nell'intestazione, null quando assente (area
//   unica) — funziona automaticamente anche per un futuro comune con
//   3+ zone, senza modifiche;
// - navigazione mese `?month=X&year=Y` sulla stessa URL (script inline
//   della pagina, `fetch(url + "?month="+...)"`), stessa convenzione già
//   verificata per Isontina — qui è stata solo dedotta dal codice JS
//   della pagina (non da una vera richiesta di rete, dato che questa
//   sandbox non raggiunge aet2000.it), con lo stesso fallback stale/
//   cache di Isontina in caso si rivelasse sbagliata su GitHub Actions;
// - pagina centro-di-raccolta/: indirizzo in `.row.indirizzo
//   p.blockquote`; orari in due elenchi `<ul class="opening-list">` (uno
//   per "Invernale", uno per "Estivo", individuati da `.period-title`),
//   con le date di validità delle due stagioni lette da `#opening-notes
//   li` e anteposte all'elenco orari di quella stagione; materiali
//   accettati nell'accordion la cui intestazione (`.large-text`) è
//   "Rifiuti conferibili" — due `<ul>` dentro il suo `.accordion-body`,
//   generali e (quando presente un secondo elenco) riservati alle
//   utenze domestiche, marcati con un suffisso "(solo utenze
//   domestiche)". Diversamente da Isontina, qui non c'è una sezione
//   "Campane del vetro": il vetro è raccolta porta a porta (tipo
//   "vetro" nel calendario stesso), quindi `campane_vetro` resta un
//   array vuoto per questo gestore.
//
// **Non verificato con HTML reale**: l'elenco dei comuni e i relativi
// slug — solo WebFetch nella sessione precedente (vedi README). Per
// questo la v1 include SOLO i due comuni di cui si è visto l'HTML reale
// (San Daniele del Friuli e Tolmezzo; slug dedotti per kebab-case
// standard del nome, coerente con l'URL pattern `/comuni/{slug}/...`
// del pacchetto e con gli altri gestori di questo progetto, ma non
// confermato da un link/canonical nell'HTML ricevuto). Tarcento (comune
// non servito per il porta a porta, solo centro di raccolta secondo
// WebFetch) e San Dorligo della Valle - Dolina (provincia di Trieste,
// slug con tre trattini secondo WebFetch) restano fuori dalla v1: prima
// di aggiungerli serve l'HTML reale della pagina indice
// https://aet2000.it/comuni/ (per lo slug esatto di tutti gli ~80
// comuni) oppure l'HTML reale comune per comune.
// ---------------------------------------------------------------------

const RIFIUTI_COMUNI_AET2000 = [
  {
    slug: "san-daniele-del-friuli",
    nome: "San Daniele del Friuli",
    url: "https://aet2000.it/comuni/san-daniele-del-friuli/modalita-di-raccolta/",
    urlCentro: "https://aet2000.it/comuni/san-daniele-del-friuli/centro-di-raccolta/",
    provincia: "udine",
    gestore: "A&T 2000",
  },
  {
    slug: "tolmezzo",
    nome: "Tolmezzo",
    url: "https://aet2000.it/comuni/tolmezzo/modalita-di-raccolta/",
    urlCentro: "https://aet2000.it/comuni/tolmezzo/centro-di-raccolta/",
    provincia: "udine",
    gestore: "A&T 2000",
  },
];

const RIFIUTI_AET2000_TIPO_DA_ALT = new Map([
  ["umido", "organic"],
  ["plastica", "plastic_metals"],
  ["vetro", "glass"],
  ["secco", "residual"],
  ["carta", "paper"],
]);

// Interpreta il testo (già pulito) dell'intestazione <h3> di un blocco
// calendario: "[NomeComune - Zona X |] Mese AAAA". Restituisce null se
// il mese/anno non corrispondono a quelli richiesti (pagina/blocco da
// scartare), altrimenti { area } (null se non c'è "Zona X").
function rifiutiAet2000ParseIntestazione(testo, anno, mese) {
  const meseAtteso = RIFIUTI_MESI_IT[mese - 1];
  const meseRegex = new RegExp(`(${RIFIUTI_MESI_IT.join("|")})\\s+(\\d{4})\\s*$`, "i");
  const m = testo.match(meseRegex);
  if (!m) return null;
  if (m[1].toLowerCase() !== meseAtteso || Number(m[2]) !== anno) return null;
  const resto = clean(testo.slice(0, m.index).replace(/\|\s*$/, ""));
  const zm = resto.match(/Zona\s+([A-Za-zÀ-ÖØ-öø-ÿ]+)\s*$/i);
  const area = zm ? zm[1].charAt(0).toUpperCase() + zm[1].slice(1).toLowerCase() : null;
  return { area };
}

// Estrae tutti i blocchi calendario presenti nella pagina (1 per i
// comuni a area unica, 2+ per un comune come Tolmezzo) e per ciascuno i
// giorni del mese/anno richiesti con i tipi di rifiuto raccolti.
function rifiutiAet2000ParseCalendario($, anno, mese) {
  const aree = [];
  $("table.calendar-table").each((_, table) => {
    const $table = $(table);
    const $header = $table.prevAll("#calendar").first();
    const testo = clean($header.find("h3").text());
    const intestazione = rifiutiAet2000ParseIntestazione(testo, anno, mese);
    if (!intestazione) return;

    const giorni = [];
    $table.find("td.text-center").each((_, td) => {
      const $giorno = $(td).find(".giorno").first();
      if (!$giorno.length || $giorno.hasClass("not_current_month")) return;
      const giornoNum = parseInt(clean($giorno.find(".small-text").first().text()), 10);
      if (!giornoNum || giornoNum < 1 || giornoNum > 31) return;
      const tipi = new Set();
      $giorno.find(".raccolto button .rifiuto.icon img[alt]").each((_, img) => {
        const alt = clean($(img).attr("alt") || "").toLowerCase();
        const tipo = RIFIUTI_AET2000_TIPO_DA_ALT.get(alt);
        if (tipo) tipi.add(tipo);
      });
      if (tipi.size === 0) return;
      giorni.push({ data: `${anno}-${pad2(mese)}-${pad2(giornoNum)}`, tipi: [...tipi] });
    });

    aree.push({ area: intestazione.area, giorni });
  });
  return aree;
}

function rifiutiAet2000ParseMateriali($) {
  const $header = $(".large-text")
    .filter((_, el) => /rifiuti conferibili/i.test(clean($(el).text())))
    .first();
  if (!$header.length) return [];
  const $body = $header.closest(".accordion-item").find(".accordion-body").first();
  if (!$body.length) return [];
  const liste = $body.find("ul").toArray();
  const generali = liste[0]
    ? $(liste[0]).find("li").map((_, li) => clean($(li).text())).get().filter(Boolean)
    : [];
  const domestici = liste[1]
    ? $(liste[1]).find("li").map((_, li) => clean($(li).text())).get().filter(Boolean)
    : [];
  return [...generali, ...domestici.map((m) => `${m} (solo utenze domestiche)`)];
}

function rifiutiAet2000ParseCentro($) {
  const $riga = $(".row.indirizzo").first();
  if (!$riga.length) return null;
  const indirizzo = clean($riga.find("p.blockquote").first().text()) || null;

  // "Orario estivo (dal 16 marzo al 31 ottobre)" / "Orario invernale
  // (dal 1 novembre al 15 marzo)" — date di validità delle due stagioni,
  // usate come etichetta davanti al rispettivo elenco orari invece del
  // solo nome della stagione.
  const noteStagioni = new Map();
  $("#opening-notes li").each((_, li) => {
    const testo = clean($(li).text());
    if (/invernale/i.test(testo)) noteStagioni.set("invernale", testo);
    else if (/estivo/i.test(testo)) noteStagioni.set("estivo", testo);
  });

  const blocchiOrari = [];
  $(".period-title").each((_, el) => {
    const $titolo = $(el);
    const stagione = clean($titolo.text());
    const chiave = /invernale/i.test(stagione) ? "invernale" : /estivo/i.test(stagione) ? "estivo" : null;
    const $ul = $titolo.closest(".d-flex").nextAll("ul.opening-list").first();
    if (!$ul.length) return;
    const righe = [];
    $ul.find("li.opening-slot").each((_, li) => {
      const $li = $(li);
      const giorno = clean($li.find(".opening-date p.font-semibold").first().text());
      // cheerio .text() non inserisce uno spazio ai <br> — clonato e
      // sostituito con ", " prima di leggere il testo, stesso problema
      // già risolto per il centro di raccolta di Isontina.
      const $clone = $li.find(".opening-date").first().clone();
      $clone.find("p.font-semibold").remove();
      $clone.find("br").replaceWith(", ");
      const orari = clean($clone.text()).replace(/^,\s*/, "").replace(/\s+,/g, ",");
      if (giorno && orari) righe.push(`${giorno} ${orari}`);
    });
    if (righe.length === 0) return;
    const etichetta = (chiave && noteStagioni.get(chiave)) || stagione;
    blocchiOrari.push(`${etichetta}: ${righe.join("; ")}`);
  });
  const apertura = blocchiOrari.length > 0 ? blocchiOrari.join(". ") : null;

  const materiali = rifiutiAet2000ParseMateriali($);

  if (!indirizzo && !apertura && materiali.length === 0) return null;
  return { indirizzo, apertura, materiali };
}

async function rifiutiAet2000FetchComune(comune, anno, mese) {
  const prossimo = rifiutiMeseSuccessivo(anno, mese);

  const urlMese1 = new URL(comune.url);
  urlMese1.searchParams.set("month", String(mese));
  urlMese1.searchParams.set("year", String(anno));
  const $mese1 = await rifiutiGetHtml(urlMese1.toString());
  const areeMese1 = rifiutiAet2000ParseCalendario($mese1, anno, mese);

  const urlMese2 = new URL(comune.url);
  urlMese2.searchParams.set("month", String(prossimo.mese));
  urlMese2.searchParams.set("year", String(prossimo.anno));
  const $mese2 = await rifiutiGetHtml(urlMese2.toString());
  const areeMese2 = rifiutiAet2000ParseCalendario($mese2, prossimo.anno, prossimo.mese);

  // Unisce i giorni dei due mesi per ciascuna area (stessa etichetta —
  // null per un comune a area unica, "Nord"/"Sud" per Tolmezzo — sui
  // due mesi, assumendo che l'insieme delle aree non cambi da un mese
  // all'altro).
  const areePerEtichetta = new Map();
  for (const { area, giorni } of [...areeMese1, ...areeMese2]) {
    const chiave = area ?? "?";
    if (!areePerEtichetta.has(chiave)) areePerEtichetta.set(chiave, { area, giorni: [] });
    areePerEtichetta.get(chiave).giorni.push(...giorni);
  }
  const aree = [...areePerEtichetta.values()];

  let centro = null;
  if (comune.urlCentro) {
    try {
      const $centro = await rifiutiGetHtml(comune.urlCentro);
      centro = rifiutiAet2000ParseCentro($centro);
    } catch (err) {
      console.warn(`Rifiuti (AET2000): errore centro di raccolta ${comune.nome}: ${err.message}`);
    }
  }

  return {
    slug: comune.slug,
    nome: comune.nome,
    provincia: comune.provincia,
    gestore: comune.gestore,
    aree,
    centro_raccolta: centro,
    campane_vetro: [],
    stale: false,
  };
}

// Recupera i comuni gestiti da A&T 2000. Come rifiutiIngestIsontina(),
// non scrive lo snapshot — vedi il commento sopra quella funzione.
async function rifiutiIngestAet2000(annoCorrente, meseCorrente, precedentePerSlug) {
  const risultati = await rifiutiConLimiteConcorrenza(RIFIUTI_COMUNI_AET2000, RIFIUTI_CONCORRENZA, async (comune) => {
    try {
      return await rifiutiAet2000FetchComune(comune, annoCorrente, meseCorrente);
    } catch (err) {
      console.warn(`Rifiuti (AET2000): errore comune ${comune.nome}: ${err.message}`);
      const vecchio = precedentePerSlug.get(comune.slug);
      return vecchio ? { ...vecchio, stale: true } : null;
    }
  });
  const comuni = risultati.filter(Boolean);
  const falliti = RIFIUTI_COMUNI_AET2000.length - comuni.filter((c) => !c.stale).length;
  console.log(
    `Rifiuti (AET2000) aggiornati: ${comuni.length}/${RIFIUTI_COMUNI_AET2000.length} comuni` +
      (falliti > 0 ? ` (${falliti} da cache/stale per errori di rete)` : "")
  );
  return comuni;
}

// ---------------------------------------------------------------------
// Rifiuti, terzo gestore: GEA - Gestioni Ecologiche e Ambientali S.p.A.
// (provincia di Pordenone). Aggiunto il 18/09/2026, stessa sessione in
// cui è arrivato A&T 2000 per Udine.
//
// **Fonte fondamentalmente diversa dagli altri due gestori**: Isontina e
// A&T 2000 pubblicano il calendario come HTML rifetchabile ogni run
// (`?month=&year=` sulla stessa pagina). GEA pubblica invece un PDF
// annuale per comune/gruppo di comuni (es.
// https://gea-pn.it/download/ecocalendari/), con le indicazioni di
// raccolta come badge grafici colorati/con lettera, non testo in un
// markup analizzabile — non è quindi realisticamente possibile scrivere
// un parser che "legge" il PDF a ogni run come per gli altri due
// gestori. La scelta (confermata dall'utente via domanda esplicita:
// "Dati esatti giorno per giorno (Consigliato)", invece di una regola
// settimanale approssimata) è stata di **trascrivere a mano i PDF reali
// e incorporare il risultato come dato statico**, sullo stesso principio
// già usato per lib/aviostrutture.ts ("dati quasi statici"): qui però il
// dato resta dentro ingestRifiuti() (rifiutiIngestGea() sotto restituisce
// l'array direttamente, senza fetch di rete) così lo snapshot "rifiuti"
// resta un'unica scrittura come per gli altri gestori.
//
// **PDF reali usati per la trascrizione** (caricati dall'utente,
// 18/09/2026): Calendario-Aviano-2026 (24 pagine) e
// Calendario-Pordenone-2026-def (28 pagine, il più complesso: 6 zone).
// Un terzo PDF ricevuto insieme ai primi due, "Calendario Ecocentro
// Mobile" (8 zone a rotazione per il conferimento di rifiuti
// pericolosi), è un servizio diverso dal porta a porta e NON è stato
// incorporato in questa v1 — resta fuori scope, da valutare in futuro.
//
// **Metodo di trascrizione**: dato il volume (12-13 mesi × fino a 6
// zone) e la posta in gioco (dati usati da persone reali per sapere
// quando portare fuori i sacchi), la trascrizione pagina-per-pagina è
// stata delegata a sub-agent dedicati (uno per Aviano, due per
// Pordenone gennaio-giugno/luglio-gennaio 2027), ciascuno con: la
// mappatura esatta lettera/icona → tipo di rifiuto, le regole di
// esclusione (vedi sotto), lo schema JSON di output, e l'istruzione
// esplicita di segnalare con una nota i giorni letti con incertezza
// invece di indovinare in silenzio. Le note di incertezza raccolte sono
// elencate in fondo a questo commento — nessuna cancellata, per
// trasparenza in caso di verifica futura contro il calendario cartaceo.
//
// **Mappatura badge → tipo**:
// - Aviano (5 icone): umido→organic, carta→paper, plastica→plastic_metals,
//   secco→residual, vetro→glass (raccolta porta a porta anche per il
//   vetro, come A&T 2000 — a differenza di Isontina).
// - Pordenone (lettere): S→residual (secco), C→paper (carta e cartone),
//   P→plastic_metals (plastica e metalli). Umido e vetro a Pordenone
//   NON sono nel calendario porta a porta: sono raccolta stradale con
//   tessera magnetica (cassonetti aperti con tessera, non "campane"
//   pubbliche) — per questo i comuni di Pordenone qui sotto non hanno
//   mai i tipi "organic"/"glass" e campane_vetro resta [] (non essendo
//   note le posizioni dei cassonetti magnetici, fuori scope v1).
//
// **Esclusioni deliberate** (confermate dalla legenda reale del PDF di
// Pordenone, pagina 10): il codice "SR" (sfalci e ramaglie/verde) è a
// adesione volontaria su richiesta, mai incluso; l'icona blu "a onda"
// indica raccolta cartone riservata alle attività commerciali/produttive
// del centro storico (servizio separato, non residenziale) ed è sempre
// ignorata anche quando compare nella stessa cella di una lettera
// valida (la lettera viene comunque registrata).
//
// **Marcatori di eccezione nel PDF di Pordenone** (usati dai sub-agent
// per decidere cosa registrare):
// - un cerchio/ovale rosso con "!" ("raccolta modificata") accanto a un
//   badge → il giorno su cui è disegnato il badge È il giorno effettivo
//   di raccolta (spostato dal solito giorno della settimana): registrato
//   normalmente, il "!" stesso viene ignorato;
// - un cerchio rosso con una riga diagonale sopra un badge → raccolta
//   annullata quel giorno (tipicamente festività): non registrato, e non
//   si inventa un giorno sostitutivo se non ne compare uno disegnato
//   altrove nel calendario.
//
// **Periodo coperto**: Aviano, gennaio-dicembre 2026 (12 mesi, tutto
// quanto pubblicato nel PDF). Pordenone, gennaio 2026-gennaio 2027 (13
// mesi: il PDF include un tredicesimo mese "bonus", gennaio 2027, oltre
// ai 12 del 2026) — utile per non restare "scoperti" a inizio gennaio
// 2027 quando arriverà un nuovo PDF che questa v1 statica non potrà
// ovviamente recepire da sola.
//
// **Manutenzione**: essendo dati statici trascritti da un PDF annuale,
// vanno ri-trascritti a mano quando GEA pubblica il calendario
// dell'anno successivo — nessun meccanismo automatico li aggiorna. Da
// tenere presente per una sessione futura (probabilmente fine 2026/
// inizio 2027).
//
// **Scope ridotto rispetto a GEA nel suo complesso**: GEA serve un
// gruppo di comuni della provincia di Pordenone più ampio di quelli
// coperti qui (una ricerca precedente, non basata su HTML/PDF reale,
// aveva indicato una ventina di comuni) — coerente con la disciplina già
// seguita per A&T 2000, questo file include SOLO i comuni di cui si è
// vista la fonte reale (i PDF caricati dall'utente). Alla v1 (Aviano,
// Pordenone) si sono aggiunti il 30/09/2026 Budoia, Andreis e Barcis
// (v. il blocco di commento dedicato più sotto, subito prima delle
// relative costanti, per fonti/metodo/particolarità di questi tre). Gli
// altri comuni GEA restano fuori finché non arriva il loro PDF/
// calendario reale.
//
// **Note di incertezza raccolte dai sub-agent di trascrizione**
// (Pordenone; nessuna per Aviano):
// - Blu 2026-05-04, 2026-12-28, 2027-01-02: badge di "raccolta
//   modificata" con una sola lettera visibile invece della coppia
//   abituale — letti come "makeup" parziale di una raccolta annullata
//   per festività, l'altra metà risulta persa senza sostituto visibile.
// - Gialla 2026-04-10: idem, "raccolta modificata" di venerdì (giorno
//   non abituale per questa zona) con una sola lettera "P" visibile.
// - Rossa 2026-01-02: "raccolta modificata" di venerdì per la carta,
//   normalmente di giovedì — registrato come mostrato.
// - Marrone 2026-12-23/24 e 2027-01-01: cluster di eccezioni attorno al
//   Natale/Capodanno, lettura resa più incerta dalla risoluzione della
//   scansione — vedi il testo delle note nei dati stessi (campo `note`
//   nei file sorgente .scratch/gea_data/, non incorporato nel runtime).
// - Verde Sud 2026-01-03/08: due "raccolta modificata" nella prima
//   settimana di gennaio, incluso un caso anomalo (carta il giovedì,
//   zona che normalmente non la riceve mai).
// - Verde Sud 2026-07-09/23: le uniche due letture risolte per pattern
//   (alternanza quindicinale della lettera S su questa zona, confermata
//   su tutti gli altri mesi) invece che per lettura diretta certa
//   dell'immagine.
// ---------------------------------------------------------------------

const RIFIUTI_GEA_AVIANO_BLU = [
  { data: "2026-01-05", tipi: ["organic"] },
  { data: "2026-01-06", tipi: ["paper"] },
  { data: "2026-01-07", tipi: ["residual", "glass"] },
  { data: "2026-01-12", tipi: ["organic"] },
  { data: "2026-01-13", tipi: ["plastic_metals"] },
  { data: "2026-01-19", tipi: ["organic"] },
  { data: "2026-01-20", tipi: ["paper"] },
  { data: "2026-01-21", tipi: ["residual", "glass"] },
  { data: "2026-01-26", tipi: ["organic"] },
  { data: "2026-01-27", tipi: ["plastic_metals"] },
  { data: "2026-02-02", tipi: ["organic"] },
  { data: "2026-02-03", tipi: ["paper"] },
  { data: "2026-02-04", tipi: ["residual", "glass"] },
  { data: "2026-02-09", tipi: ["organic"] },
  { data: "2026-02-10", tipi: ["plastic_metals"] },
  { data: "2026-02-16", tipi: ["organic"] },
  { data: "2026-02-17", tipi: ["paper"] },
  { data: "2026-02-18", tipi: ["residual", "glass"] },
  { data: "2026-02-23", tipi: ["organic"] },
  { data: "2026-02-24", tipi: ["plastic_metals"] },
  { data: "2026-03-02", tipi: ["organic"] },
  { data: "2026-03-03", tipi: ["paper"] },
  { data: "2026-03-04", tipi: ["residual", "glass"] },
  { data: "2026-03-09", tipi: ["organic"] },
  { data: "2026-03-10", tipi: ["plastic_metals"] },
  { data: "2026-03-16", tipi: ["organic"] },
  { data: "2026-03-17", tipi: ["paper"] },
  { data: "2026-03-18", tipi: ["residual", "glass"] },
  { data: "2026-03-23", tipi: ["organic"] },
  { data: "2026-03-24", tipi: ["plastic_metals"] },
  { data: "2026-03-30", tipi: ["organic"] },
  { data: "2026-03-31", tipi: ["paper"] },
  { data: "2026-04-01", tipi: ["residual", "glass"] },
  { data: "2026-04-04", tipi: ["organic"] },
  { data: "2026-04-07", tipi: ["plastic_metals"] },
  { data: "2026-04-13", tipi: ["organic"] },
  { data: "2026-04-14", tipi: ["paper"] },
  { data: "2026-04-15", tipi: ["residual", "glass"] },
  { data: "2026-04-20", tipi: ["organic"] },
  { data: "2026-04-21", tipi: ["plastic_metals"] },
  { data: "2026-04-27", tipi: ["organic"] },
  { data: "2026-04-28", tipi: ["paper"] },
  { data: "2026-04-29", tipi: ["residual", "glass"] },
  { data: "2026-05-04", tipi: ["organic"] },
  { data: "2026-05-05", tipi: ["plastic_metals"] },
  { data: "2026-05-11", tipi: ["organic"] },
  { data: "2026-05-12", tipi: ["paper"] },
  { data: "2026-05-13", tipi: ["residual", "glass"] },
  { data: "2026-05-18", tipi: ["organic"] },
  { data: "2026-05-19", tipi: ["plastic_metals"] },
  { data: "2026-05-25", tipi: ["organic"] },
  { data: "2026-05-26", tipi: ["paper"] },
  { data: "2026-05-27", tipi: ["residual", "glass"] },
  { data: "2026-06-01", tipi: ["organic"] },
  { data: "2026-06-02", tipi: ["plastic_metals"] },
  { data: "2026-06-04", tipi: ["organic"] },
  { data: "2026-06-08", tipi: ["organic"] },
  { data: "2026-06-09", tipi: ["paper"] },
  { data: "2026-06-10", tipi: ["residual", "glass"] },
  { data: "2026-06-11", tipi: ["organic"] },
  { data: "2026-06-15", tipi: ["organic"] },
  { data: "2026-06-16", tipi: ["plastic_metals"] },
  { data: "2026-06-18", tipi: ["organic"] },
  { data: "2026-06-22", tipi: ["organic"] },
  { data: "2026-06-23", tipi: ["paper"] },
  { data: "2026-06-24", tipi: ["residual", "glass"] },
  { data: "2026-06-25", tipi: ["organic"] },
  { data: "2026-06-29", tipi: ["organic"] },
  { data: "2026-06-30", tipi: ["plastic_metals"] },
  { data: "2026-07-02", tipi: ["organic"] },
  { data: "2026-07-06", tipi: ["organic"] },
  { data: "2026-07-07", tipi: ["paper"] },
  { data: "2026-07-08", tipi: ["residual", "glass"] },
  { data: "2026-07-09", tipi: ["organic"] },
  { data: "2026-07-13", tipi: ["organic"] },
  { data: "2026-07-14", tipi: ["plastic_metals"] },
  { data: "2026-07-16", tipi: ["organic"] },
  { data: "2026-07-20", tipi: ["organic"] },
  { data: "2026-07-21", tipi: ["paper"] },
  { data: "2026-07-22", tipi: ["residual", "glass"] },
  { data: "2026-07-23", tipi: ["organic"] },
  { data: "2026-07-27", tipi: ["organic"] },
  { data: "2026-07-28", tipi: ["plastic_metals"] },
  { data: "2026-07-30", tipi: ["organic"] },
  { data: "2026-08-03", tipi: ["organic"] },
  { data: "2026-08-04", tipi: ["paper"] },
  { data: "2026-08-05", tipi: ["residual", "glass"] },
  { data: "2026-08-06", tipi: ["organic"] },
  { data: "2026-08-10", tipi: ["organic"] },
  { data: "2026-08-11", tipi: ["plastic_metals"] },
  { data: "2026-08-13", tipi: ["organic"] },
  { data: "2026-08-17", tipi: ["organic"] },
  { data: "2026-08-18", tipi: ["paper"] },
  { data: "2026-08-19", tipi: ["residual", "glass"] },
  { data: "2026-08-20", tipi: ["organic"] },
  { data: "2026-08-24", tipi: ["organic"] },
  { data: "2026-08-25", tipi: ["plastic_metals"] },
  { data: "2026-08-27", tipi: ["organic"] },
  { data: "2026-08-31", tipi: ["organic"] },
  { data: "2026-09-01", tipi: ["paper"] },
  { data: "2026-09-02", tipi: ["residual", "glass"] },
  { data: "2026-09-03", tipi: ["organic"] },
  { data: "2026-09-07", tipi: ["organic"] },
  { data: "2026-09-08", tipi: ["plastic_metals"] },
  { data: "2026-09-10", tipi: ["organic"] },
  { data: "2026-09-14", tipi: ["organic"] },
  { data: "2026-09-15", tipi: ["paper"] },
  { data: "2026-09-16", tipi: ["residual", "glass"] },
  { data: "2026-09-17", tipi: ["organic"] },
  { data: "2026-09-21", tipi: ["organic"] },
  { data: "2026-09-22", tipi: ["plastic_metals"] },
  { data: "2026-09-24", tipi: ["organic"] },
  { data: "2026-09-28", tipi: ["organic"] },
  { data: "2026-09-29", tipi: ["paper"] },
  { data: "2026-09-30", tipi: ["residual", "glass"] },
  { data: "2026-10-05", tipi: ["organic"] },
  { data: "2026-10-06", tipi: ["plastic_metals"] },
  { data: "2026-10-12", tipi: ["organic"] },
  { data: "2026-10-13", tipi: ["paper"] },
  { data: "2026-10-14", tipi: ["residual", "glass"] },
  { data: "2026-10-19", tipi: ["organic"] },
  { data: "2026-10-20", tipi: ["plastic_metals"] },
  { data: "2026-10-26", tipi: ["organic"] },
  { data: "2026-10-27", tipi: ["paper"] },
  { data: "2026-10-28", tipi: ["residual", "glass"] },
  { data: "2026-11-02", tipi: ["organic"] },
  { data: "2026-11-03", tipi: ["plastic_metals"] },
  { data: "2026-11-09", tipi: ["organic"] },
  { data: "2026-11-10", tipi: ["paper"] },
  { data: "2026-11-11", tipi: ["residual", "glass"] },
  { data: "2026-11-16", tipi: ["organic"] },
  { data: "2026-11-17", tipi: ["plastic_metals"] },
  { data: "2026-11-23", tipi: ["organic"] },
  { data: "2026-11-24", tipi: ["paper"] },
  { data: "2026-11-25", tipi: ["residual", "glass"] },
  { data: "2026-11-30", tipi: ["organic"] },
  { data: "2026-12-01", tipi: ["plastic_metals"] },
  { data: "2026-12-07", tipi: ["organic"] },
  { data: "2026-12-08", tipi: ["paper"] },
  { data: "2026-12-09", tipi: ["residual", "glass"] },
  { data: "2026-12-14", tipi: ["organic"] },
  { data: "2026-12-15", tipi: ["plastic_metals"] },
  { data: "2026-12-21", tipi: ["organic"] },
  { data: "2026-12-22", tipi: ["paper"] },
  { data: "2026-12-23", tipi: ["residual", "glass"] },
  { data: "2026-12-28", tipi: ["organic"] },
  { data: "2026-12-29", tipi: ["plastic_metals"] },
];

const RIFIUTI_GEA_AVIANO_GIALLA = [
  { data: "2026-01-02", tipi: ["organic"] },
  { data: "2026-01-06", tipi: ["plastic_metals"] },
  { data: "2026-01-09", tipi: ["organic"] },
  { data: "2026-01-13", tipi: ["paper"] },
  { data: "2026-01-14", tipi: ["residual", "glass"] },
  { data: "2026-01-16", tipi: ["organic"] },
  { data: "2026-01-20", tipi: ["plastic_metals"] },
  { data: "2026-01-23", tipi: ["organic"] },
  { data: "2026-01-27", tipi: ["paper"] },
  { data: "2026-01-28", tipi: ["residual", "glass"] },
  { data: "2026-01-30", tipi: ["organic"] },
  { data: "2026-02-03", tipi: ["plastic_metals"] },
  { data: "2026-02-06", tipi: ["organic"] },
  { data: "2026-02-10", tipi: ["paper"] },
  { data: "2026-02-11", tipi: ["residual", "glass"] },
  { data: "2026-02-13", tipi: ["organic"] },
  { data: "2026-02-17", tipi: ["plastic_metals"] },
  { data: "2026-02-20", tipi: ["organic"] },
  { data: "2026-02-24", tipi: ["paper"] },
  { data: "2026-02-25", tipi: ["residual", "glass"] },
  { data: "2026-02-27", tipi: ["organic"] },
  { data: "2026-03-03", tipi: ["plastic_metals"] },
  { data: "2026-03-06", tipi: ["organic"] },
  { data: "2026-03-10", tipi: ["paper"] },
  { data: "2026-03-11", tipi: ["residual", "glass"] },
  { data: "2026-03-13", tipi: ["organic"] },
  { data: "2026-03-17", tipi: ["plastic_metals"] },
  { data: "2026-03-20", tipi: ["organic"] },
  { data: "2026-03-24", tipi: ["paper"] },
  { data: "2026-03-25", tipi: ["residual", "glass"] },
  { data: "2026-03-27", tipi: ["organic"] },
  { data: "2026-03-31", tipi: ["plastic_metals"] },
  { data: "2026-04-03", tipi: ["organic"] },
  { data: "2026-04-07", tipi: ["paper"] },
  { data: "2026-04-08", tipi: ["residual", "glass"] },
  { data: "2026-04-10", tipi: ["organic"] },
  { data: "2026-04-14", tipi: ["plastic_metals"] },
  { data: "2026-04-17", tipi: ["organic"] },
  { data: "2026-04-21", tipi: ["paper"] },
  { data: "2026-04-22", tipi: ["residual", "glass"] },
  { data: "2026-04-24", tipi: ["organic"] },
  { data: "2026-04-28", tipi: ["plastic_metals"] },
  { data: "2026-05-02", tipi: ["organic"] },
  { data: "2026-05-05", tipi: ["paper"] },
  { data: "2026-05-06", tipi: ["residual", "glass"] },
  { data: "2026-05-08", tipi: ["organic"] },
  { data: "2026-05-12", tipi: ["plastic_metals"] },
  { data: "2026-05-15", tipi: ["organic"] },
  { data: "2026-05-19", tipi: ["paper"] },
  { data: "2026-05-20", tipi: ["residual", "glass"] },
  { data: "2026-05-22", tipi: ["organic"] },
  { data: "2026-05-26", tipi: ["plastic_metals"] },
  { data: "2026-05-29", tipi: ["organic"] },
  { data: "2026-06-02", tipi: ["paper"] },
  { data: "2026-06-03", tipi: ["residual", "glass"] },
  { data: "2026-06-05", tipi: ["organic"] },
  { data: "2026-06-09", tipi: ["organic", "plastic_metals"] },
  { data: "2026-06-12", tipi: ["organic"] },
  { data: "2026-06-16", tipi: ["organic", "paper"] },
  { data: "2026-06-17", tipi: ["residual", "glass"] },
  { data: "2026-06-19", tipi: ["organic"] },
  { data: "2026-06-23", tipi: ["organic", "plastic_metals"] },
  { data: "2026-06-26", tipi: ["organic"] },
  { data: "2026-06-30", tipi: ["organic", "paper"] },
  { data: "2026-07-01", tipi: ["residual", "glass"] },
  { data: "2026-07-03", tipi: ["organic"] },
  { data: "2026-07-07", tipi: ["organic", "plastic_metals"] },
  { data: "2026-07-10", tipi: ["organic"] },
  { data: "2026-07-14", tipi: ["organic", "paper"] },
  { data: "2026-07-15", tipi: ["residual", "glass"] },
  { data: "2026-07-17", tipi: ["organic"] },
  { data: "2026-07-21", tipi: ["organic", "plastic_metals"] },
  { data: "2026-07-24", tipi: ["organic"] },
  { data: "2026-07-28", tipi: ["organic", "paper"] },
  { data: "2026-07-29", tipi: ["residual", "glass"] },
  { data: "2026-07-31", tipi: ["organic"] },
  { data: "2026-08-04", tipi: ["organic", "plastic_metals"] },
  { data: "2026-08-07", tipi: ["organic"] },
  { data: "2026-08-11", tipi: ["organic", "paper"] },
  { data: "2026-08-12", tipi: ["residual", "glass"] },
  { data: "2026-08-14", tipi: ["organic"] },
  { data: "2026-08-18", tipi: ["organic", "plastic_metals"] },
  { data: "2026-08-21", tipi: ["organic"] },
  { data: "2026-08-25", tipi: ["organic", "paper"] },
  { data: "2026-08-26", tipi: ["residual", "glass"] },
  { data: "2026-08-28", tipi: ["organic"] },
  { data: "2026-09-01", tipi: ["organic", "plastic_metals"] },
  { data: "2026-09-04", tipi: ["organic"] },
  { data: "2026-09-08", tipi: ["organic", "paper"] },
  { data: "2026-09-09", tipi: ["residual", "glass"] },
  { data: "2026-09-11", tipi: ["organic"] },
  { data: "2026-09-15", tipi: ["organic", "plastic_metals"] },
  { data: "2026-09-18", tipi: ["organic"] },
  { data: "2026-09-22", tipi: ["organic", "paper"] },
  { data: "2026-09-23", tipi: ["residual", "glass"] },
  { data: "2026-09-25", tipi: ["organic"] },
  { data: "2026-09-29", tipi: ["organic", "plastic_metals"] },
  { data: "2026-10-02", tipi: ["organic"] },
  { data: "2026-10-06", tipi: ["paper"] },
  { data: "2026-10-07", tipi: ["residual", "glass"] },
  { data: "2026-10-09", tipi: ["organic"] },
  { data: "2026-10-13", tipi: ["plastic_metals"] },
  { data: "2026-10-16", tipi: ["organic"] },
  { data: "2026-10-20", tipi: ["paper"] },
  { data: "2026-10-21", tipi: ["residual", "glass"] },
  { data: "2026-10-23", tipi: ["organic"] },
  { data: "2026-10-27", tipi: ["plastic_metals"] },
  { data: "2026-10-30", tipi: ["organic"] },
  { data: "2026-11-03", tipi: ["paper"] },
  { data: "2026-11-04", tipi: ["residual", "glass"] },
  { data: "2026-11-06", tipi: ["organic"] },
  { data: "2026-11-10", tipi: ["plastic_metals"] },
  { data: "2026-11-13", tipi: ["organic"] },
  { data: "2026-11-17", tipi: ["paper"] },
  { data: "2026-11-18", tipi: ["residual", "glass"] },
  { data: "2026-11-20", tipi: ["organic"] },
  { data: "2026-11-24", tipi: ["plastic_metals"] },
  { data: "2026-11-27", tipi: ["organic"] },
  { data: "2026-12-01", tipi: ["paper"] },
  { data: "2026-12-02", tipi: ["residual", "glass"] },
  { data: "2026-12-04", tipi: ["organic"] },
  { data: "2026-12-08", tipi: ["plastic_metals"] },
  { data: "2026-12-11", tipi: ["organic"] },
  { data: "2026-12-15", tipi: ["paper"] },
  { data: "2026-12-16", tipi: ["residual", "glass"] },
  { data: "2026-12-18", tipi: ["organic"] },
  { data: "2026-12-22", tipi: ["plastic_metals"] },
  { data: "2026-12-26", tipi: ["organic"] },
  { data: "2026-12-29", tipi: ["paper"] },
  { data: "2026-12-30", tipi: ["residual", "glass"] },
];

const RIFIUTI_GEA_PORDENONE_BLU = [
  { data: "2026-01-02", tipi: ["residual", "plastic_metals"] },
  { data: "2026-01-03", tipi: ["paper"] },
  { data: "2026-01-09", tipi: ["residual", "plastic_metals"] },
  { data: "2026-01-10", tipi: ["paper"] },
  { data: "2026-01-16", tipi: ["residual", "plastic_metals"] },
  { data: "2026-01-17", tipi: ["paper"] },
  { data: "2026-01-23", tipi: ["residual", "plastic_metals"] },
  { data: "2026-01-24", tipi: ["paper"] },
  { data: "2026-01-30", tipi: ["residual", "plastic_metals"] },
  { data: "2026-01-31", tipi: ["paper"] },
  { data: "2026-02-06", tipi: ["residual", "plastic_metals"] },
  { data: "2026-02-07", tipi: ["paper"] },
  { data: "2026-02-13", tipi: ["residual", "plastic_metals"] },
  { data: "2026-02-14", tipi: ["paper"] },
  { data: "2026-02-20", tipi: ["residual", "plastic_metals"] },
  { data: "2026-02-21", tipi: ["paper"] },
  { data: "2026-02-27", tipi: ["residual", "plastic_metals"] },
  { data: "2026-02-28", tipi: ["paper"] },
  { data: "2026-03-06", tipi: ["residual", "plastic_metals"] },
  { data: "2026-03-07", tipi: ["paper"] },
  { data: "2026-03-13", tipi: ["residual", "plastic_metals"] },
  { data: "2026-03-14", tipi: ["paper"] },
  { data: "2026-03-20", tipi: ["residual", "plastic_metals"] },
  { data: "2026-03-21", tipi: ["paper"] },
  { data: "2026-03-27", tipi: ["residual", "plastic_metals"] },
  { data: "2026-03-28", tipi: ["paper"] },
  { data: "2026-04-03", tipi: ["residual", "plastic_metals"] },
  { data: "2026-04-04", tipi: ["paper"] },
  { data: "2026-04-10", tipi: ["residual", "plastic_metals"] },
  { data: "2026-04-11", tipi: ["paper"] },
  { data: "2026-04-17", tipi: ["residual", "plastic_metals"] },
  { data: "2026-04-18", tipi: ["paper"] },
  { data: "2026-04-24", tipi: ["residual", "plastic_metals"] },
  { data: "2026-04-25", tipi: ["paper"] },
  { data: "2026-05-02", tipi: ["paper"] },
  { data: "2026-05-04", tipi: ["plastic_metals"] },
  { data: "2026-05-08", tipi: ["residual", "plastic_metals"] },
  { data: "2026-05-09", tipi: ["paper"] },
  { data: "2026-05-15", tipi: ["residual", "plastic_metals"] },
  { data: "2026-05-16", tipi: ["paper"] },
  { data: "2026-05-22", tipi: ["residual", "plastic_metals"] },
  { data: "2026-05-23", tipi: ["paper"] },
  { data: "2026-05-29", tipi: ["residual", "plastic_metals"] },
  { data: "2026-05-30", tipi: ["paper"] },
  { data: "2026-06-05", tipi: ["residual", "plastic_metals"] },
  { data: "2026-06-06", tipi: ["paper"] },
  { data: "2026-06-12", tipi: ["residual", "plastic_metals"] },
  { data: "2026-06-13", tipi: ["paper"] },
  { data: "2026-06-19", tipi: ["residual", "plastic_metals"] },
  { data: "2026-06-20", tipi: ["paper"] },
  { data: "2026-06-26", tipi: ["residual", "plastic_metals"] },
  { data: "2026-06-27", tipi: ["paper"] },
  { data: "2026-07-03", tipi: ["residual", "plastic_metals"] },
  { data: "2026-07-04", tipi: ["paper"] },
  { data: "2026-07-10", tipi: ["residual", "plastic_metals"] },
  { data: "2026-07-11", tipi: ["paper"] },
  { data: "2026-07-17", tipi: ["residual", "plastic_metals"] },
  { data: "2026-07-18", tipi: ["paper"] },
  { data: "2026-07-24", tipi: ["residual", "plastic_metals"] },
  { data: "2026-07-25", tipi: ["paper"] },
  { data: "2026-07-31", tipi: ["residual", "plastic_metals"] },
  { data: "2026-08-01", tipi: ["paper"] },
  { data: "2026-08-07", tipi: ["residual", "plastic_metals"] },
  { data: "2026-08-08", tipi: ["paper"] },
  { data: "2026-08-14", tipi: ["residual", "plastic_metals"] },
  { data: "2026-08-21", tipi: ["residual", "plastic_metals"] },
  { data: "2026-08-22", tipi: ["paper"] },
  { data: "2026-08-28", tipi: ["residual", "plastic_metals"] },
  { data: "2026-08-29", tipi: ["paper"] },
  { data: "2026-09-04", tipi: ["residual", "plastic_metals"] },
  { data: "2026-09-05", tipi: ["paper"] },
  { data: "2026-09-11", tipi: ["residual", "plastic_metals"] },
  { data: "2026-09-12", tipi: ["paper"] },
  { data: "2026-09-18", tipi: ["residual", "plastic_metals"] },
  { data: "2026-09-19", tipi: ["paper"] },
  { data: "2026-09-25", tipi: ["residual", "plastic_metals"] },
  { data: "2026-09-26", tipi: ["paper"] },
  { data: "2026-10-02", tipi: ["residual", "plastic_metals"] },
  { data: "2026-10-03", tipi: ["paper"] },
  { data: "2026-10-09", tipi: ["residual", "plastic_metals"] },
  { data: "2026-10-10", tipi: ["paper"] },
  { data: "2026-10-16", tipi: ["residual", "plastic_metals"] },
  { data: "2026-10-17", tipi: ["paper"] },
  { data: "2026-10-23", tipi: ["residual", "plastic_metals"] },
  { data: "2026-10-24", tipi: ["paper"] },
  { data: "2026-10-30", tipi: ["residual", "plastic_metals"] },
  { data: "2026-10-31", tipi: ["paper"] },
  { data: "2026-11-06", tipi: ["residual", "plastic_metals"] },
  { data: "2026-11-07", tipi: ["paper"] },
  { data: "2026-11-13", tipi: ["residual", "plastic_metals"] },
  { data: "2026-11-14", tipi: ["paper"] },
  { data: "2026-11-20", tipi: ["residual", "plastic_metals"] },
  { data: "2026-11-21", tipi: ["paper"] },
  { data: "2026-11-27", tipi: ["residual", "plastic_metals"] },
  { data: "2026-11-28", tipi: ["paper"] },
  { data: "2026-12-04", tipi: ["residual", "plastic_metals"] },
  { data: "2026-12-05", tipi: ["paper"] },
  { data: "2026-12-11", tipi: ["residual", "plastic_metals"] },
  { data: "2026-12-12", tipi: ["paper"] },
  { data: "2026-12-18", tipi: ["residual", "plastic_metals"] },
  { data: "2026-12-19", tipi: ["paper"] },
  { data: "2026-12-26", tipi: ["paper"] },
  { data: "2026-12-28", tipi: ["plastic_metals"] },
  { data: "2027-01-02", tipi: ["paper", "residual"] },
  { data: "2027-01-08", tipi: ["residual", "plastic_metals"] },
  { data: "2027-01-09", tipi: ["paper"] },
  { data: "2027-01-15", tipi: ["residual", "plastic_metals"] },
  { data: "2027-01-16", tipi: ["paper"] },
  { data: "2027-01-22", tipi: ["residual", "plastic_metals"] },
  { data: "2027-01-23", tipi: ["paper"] },
  { data: "2027-01-29", tipi: ["residual", "plastic_metals"] },
  { data: "2027-01-30", tipi: ["paper"] },
];

const RIFIUTI_GEA_PORDENONE_GIALLA = [
  { data: "2026-01-05", tipi: ["residual", "plastic_metals"] },
  { data: "2026-01-06", tipi: ["paper"] },
  { data: "2026-01-12", tipi: ["residual", "plastic_metals"] },
  { data: "2026-01-13", tipi: ["paper"] },
  { data: "2026-01-19", tipi: ["residual", "plastic_metals"] },
  { data: "2026-01-20", tipi: ["paper"] },
  { data: "2026-01-26", tipi: ["residual", "plastic_metals"] },
  { data: "2026-01-27", tipi: ["paper"] },
  { data: "2026-02-02", tipi: ["residual", "plastic_metals"] },
  { data: "2026-02-03", tipi: ["paper"] },
  { data: "2026-02-09", tipi: ["residual", "plastic_metals"] },
  { data: "2026-02-10", tipi: ["paper"] },
  { data: "2026-02-16", tipi: ["residual", "plastic_metals"] },
  { data: "2026-02-17", tipi: ["paper"] },
  { data: "2026-02-23", tipi: ["residual", "plastic_metals"] },
  { data: "2026-02-24", tipi: ["paper"] },
  { data: "2026-03-02", tipi: ["residual", "plastic_metals"] },
  { data: "2026-03-03", tipi: ["paper"] },
  { data: "2026-03-09", tipi: ["residual", "plastic_metals"] },
  { data: "2026-03-10", tipi: ["paper"] },
  { data: "2026-03-16", tipi: ["residual", "plastic_metals"] },
  { data: "2026-03-17", tipi: ["paper"] },
  { data: "2026-03-23", tipi: ["residual", "plastic_metals"] },
  { data: "2026-03-24", tipi: ["paper"] },
  { data: "2026-03-30", tipi: ["residual", "plastic_metals"] },
  { data: "2026-03-31", tipi: ["paper"] },
  { data: "2026-04-07", tipi: ["paper"] },
  { data: "2026-04-10", tipi: ["plastic_metals"] },
  { data: "2026-04-13", tipi: ["residual", "plastic_metals"] },
  { data: "2026-04-14", tipi: ["paper"] },
  { data: "2026-04-20", tipi: ["residual", "plastic_metals"] },
  { data: "2026-04-21", tipi: ["paper"] },
  { data: "2026-04-27", tipi: ["residual", "plastic_metals"] },
  { data: "2026-04-28", tipi: ["paper"] },
  { data: "2026-05-04", tipi: ["residual", "plastic_metals"] },
  { data: "2026-05-05", tipi: ["paper"] },
  { data: "2026-05-11", tipi: ["residual", "plastic_metals"] },
  { data: "2026-05-12", tipi: ["paper"] },
  { data: "2026-05-18", tipi: ["residual", "plastic_metals"] },
  { data: "2026-05-19", tipi: ["paper"] },
  { data: "2026-05-25", tipi: ["residual", "plastic_metals"] },
  { data: "2026-05-26", tipi: ["paper"] },
  { data: "2026-06-01", tipi: ["residual", "plastic_metals"] },
  { data: "2026-06-02", tipi: ["paper"] },
  { data: "2026-06-08", tipi: ["residual", "plastic_metals"] },
  { data: "2026-06-09", tipi: ["paper"] },
  { data: "2026-06-15", tipi: ["residual", "plastic_metals"] },
  { data: "2026-06-16", tipi: ["paper"] },
  { data: "2026-06-22", tipi: ["residual", "plastic_metals"] },
  { data: "2026-06-23", tipi: ["paper"] },
  { data: "2026-06-29", tipi: ["residual", "plastic_metals"] },
  { data: "2026-06-30", tipi: ["paper"] },
  { data: "2026-07-06", tipi: ["residual", "plastic_metals"] },
  { data: "2026-07-07", tipi: ["paper"] },
  { data: "2026-07-13", tipi: ["residual", "plastic_metals"] },
  { data: "2026-07-14", tipi: ["paper"] },
  { data: "2026-07-20", tipi: ["residual", "plastic_metals"] },
  { data: "2026-07-21", tipi: ["paper"] },
  { data: "2026-07-27", tipi: ["residual", "plastic_metals"] },
  { data: "2026-07-28", tipi: ["paper"] },
  { data: "2026-08-03", tipi: ["residual", "plastic_metals"] },
  { data: "2026-08-04", tipi: ["paper"] },
  { data: "2026-08-10", tipi: ["residual", "plastic_metals"] },
  { data: "2026-08-11", tipi: ["paper"] },
  { data: "2026-08-17", tipi: ["residual", "plastic_metals"] },
  { data: "2026-08-18", tipi: ["paper"] },
  { data: "2026-08-24", tipi: ["residual", "plastic_metals"] },
  { data: "2026-08-25", tipi: ["paper"] },
  { data: "2026-08-31", tipi: ["residual", "plastic_metals"] },
  { data: "2026-09-01", tipi: ["paper"] },
  { data: "2026-09-07", tipi: ["residual", "plastic_metals"] },
  { data: "2026-09-08", tipi: ["paper"] },
  { data: "2026-09-14", tipi: ["residual", "plastic_metals"] },
  { data: "2026-09-15", tipi: ["paper"] },
  { data: "2026-09-21", tipi: ["residual", "plastic_metals"] },
  { data: "2026-09-22", tipi: ["paper"] },
  { data: "2026-09-28", tipi: ["residual", "plastic_metals"] },
  { data: "2026-09-29", tipi: ["paper"] },
  { data: "2026-10-05", tipi: ["residual", "plastic_metals"] },
  { data: "2026-10-06", tipi: ["paper"] },
  { data: "2026-10-12", tipi: ["residual", "plastic_metals"] },
  { data: "2026-10-13", tipi: ["paper"] },
  { data: "2026-10-19", tipi: ["residual", "plastic_metals"] },
  { data: "2026-10-20", tipi: ["paper"] },
  { data: "2026-10-26", tipi: ["residual", "plastic_metals"] },
  { data: "2026-10-27", tipi: ["paper"] },
  { data: "2026-11-02", tipi: ["residual", "plastic_metals"] },
  { data: "2026-11-03", tipi: ["paper"] },
  { data: "2026-11-09", tipi: ["residual", "plastic_metals"] },
  { data: "2026-11-10", tipi: ["paper"] },
  { data: "2026-11-16", tipi: ["residual", "plastic_metals"] },
  { data: "2026-11-17", tipi: ["paper"] },
  { data: "2026-11-23", tipi: ["residual", "plastic_metals"] },
  { data: "2026-11-24", tipi: ["paper"] },
  { data: "2026-11-30", tipi: ["residual", "plastic_metals"] },
  { data: "2026-12-01", tipi: ["paper"] },
  { data: "2026-12-07", tipi: ["residual", "plastic_metals"] },
  { data: "2026-12-08", tipi: ["paper"] },
  { data: "2026-12-14", tipi: ["residual", "plastic_metals"] },
  { data: "2026-12-15", tipi: ["paper"] },
  { data: "2026-12-21", tipi: ["residual", "plastic_metals"] },
  { data: "2026-12-22", tipi: ["paper"] },
  { data: "2026-12-28", tipi: ["residual", "plastic_metals"] },
  { data: "2026-12-29", tipi: ["paper"] },
  { data: "2027-01-04", tipi: ["residual", "plastic_metals"] },
  { data: "2027-01-05", tipi: ["paper"] },
  { data: "2027-01-11", tipi: ["residual", "plastic_metals"] },
  { data: "2027-01-12", tipi: ["paper"] },
  { data: "2027-01-18", tipi: ["residual", "plastic_metals"] },
  { data: "2027-01-19", tipi: ["paper"] },
  { data: "2027-01-25", tipi: ["residual", "plastic_metals"] },
  { data: "2027-01-26", tipi: ["paper"] },
];

const RIFIUTI_GEA_PORDENONE_ROSSA = [
  { data: "2026-01-02", tipi: ["paper"] },
  { data: "2026-01-07", tipi: ["residual", "plastic_metals"] },
  { data: "2026-01-08", tipi: ["paper"] },
  { data: "2026-01-14", tipi: ["residual", "plastic_metals"] },
  { data: "2026-01-15", tipi: ["paper"] },
  { data: "2026-01-21", tipi: ["residual", "plastic_metals"] },
  { data: "2026-01-22", tipi: ["paper"] },
  { data: "2026-01-28", tipi: ["residual", "plastic_metals"] },
  { data: "2026-01-29", tipi: ["paper"] },
  { data: "2026-02-04", tipi: ["residual", "plastic_metals"] },
  { data: "2026-02-05", tipi: ["paper"] },
  { data: "2026-02-11", tipi: ["residual", "plastic_metals"] },
  { data: "2026-02-12", tipi: ["paper"] },
  { data: "2026-02-18", tipi: ["residual", "plastic_metals"] },
  { data: "2026-02-19", tipi: ["paper"] },
  { data: "2026-02-25", tipi: ["residual", "plastic_metals"] },
  { data: "2026-02-26", tipi: ["paper"] },
  { data: "2026-03-04", tipi: ["residual", "plastic_metals"] },
  { data: "2026-03-05", tipi: ["paper"] },
  { data: "2026-03-11", tipi: ["residual", "plastic_metals"] },
  { data: "2026-03-12", tipi: ["paper"] },
  { data: "2026-03-18", tipi: ["residual", "plastic_metals"] },
  { data: "2026-03-19", tipi: ["paper"] },
  { data: "2026-03-25", tipi: ["residual", "plastic_metals"] },
  { data: "2026-03-26", tipi: ["paper"] },
  { data: "2026-04-01", tipi: ["residual", "plastic_metals"] },
  { data: "2026-04-02", tipi: ["paper"] },
  { data: "2026-04-08", tipi: ["residual", "plastic_metals"] },
  { data: "2026-04-09", tipi: ["paper"] },
  { data: "2026-04-15", tipi: ["residual", "plastic_metals"] },
  { data: "2026-04-16", tipi: ["paper"] },
  { data: "2026-04-22", tipi: ["residual", "plastic_metals"] },
  { data: "2026-04-23", tipi: ["paper"] },
  { data: "2026-04-29", tipi: ["residual", "plastic_metals"] },
  { data: "2026-04-30", tipi: ["paper"] },
  { data: "2026-05-06", tipi: ["residual", "plastic_metals"] },
  { data: "2026-05-07", tipi: ["paper"] },
  { data: "2026-05-13", tipi: ["residual", "plastic_metals"] },
  { data: "2026-05-14", tipi: ["paper"] },
  { data: "2026-05-20", tipi: ["residual", "plastic_metals"] },
  { data: "2026-05-21", tipi: ["paper"] },
  { data: "2026-05-27", tipi: ["residual", "plastic_metals"] },
  { data: "2026-05-28", tipi: ["paper"] },
  { data: "2026-06-03", tipi: ["residual", "plastic_metals"] },
  { data: "2026-06-04", tipi: ["paper"] },
  { data: "2026-06-10", tipi: ["residual", "plastic_metals"] },
  { data: "2026-06-11", tipi: ["paper"] },
  { data: "2026-06-17", tipi: ["residual", "plastic_metals"] },
  { data: "2026-06-18", tipi: ["paper"] },
  { data: "2026-06-24", tipi: ["residual", "plastic_metals"] },
  { data: "2026-06-25", tipi: ["paper"] },
  { data: "2026-07-01", tipi: ["residual", "plastic_metals"] },
  { data: "2026-07-02", tipi: ["paper"] },
  { data: "2026-07-08", tipi: ["residual", "plastic_metals"] },
  { data: "2026-07-09", tipi: ["paper"] },
  { data: "2026-07-15", tipi: ["residual", "plastic_metals"] },
  { data: "2026-07-16", tipi: ["paper"] },
  { data: "2026-07-22", tipi: ["residual", "plastic_metals"] },
  { data: "2026-07-23", tipi: ["paper"] },
  { data: "2026-07-29", tipi: ["residual", "plastic_metals"] },
  { data: "2026-07-30", tipi: ["paper"] },
  { data: "2026-08-05", tipi: ["residual", "plastic_metals"] },
  { data: "2026-08-06", tipi: ["paper"] },
  { data: "2026-08-12", tipi: ["residual", "plastic_metals"] },
  { data: "2026-08-13", tipi: ["paper"] },
  { data: "2026-08-19", tipi: ["residual", "plastic_metals"] },
  { data: "2026-08-20", tipi: ["paper"] },
  { data: "2026-08-26", tipi: ["residual", "plastic_metals"] },
  { data: "2026-08-27", tipi: ["paper"] },
  { data: "2026-09-02", tipi: ["residual", "plastic_metals"] },
  { data: "2026-09-03", tipi: ["paper"] },
  { data: "2026-09-09", tipi: ["residual", "plastic_metals"] },
  { data: "2026-09-10", tipi: ["paper"] },
  { data: "2026-09-16", tipi: ["residual", "plastic_metals"] },
  { data: "2026-09-17", tipi: ["paper"] },
  { data: "2026-09-23", tipi: ["residual", "plastic_metals"] },
  { data: "2026-09-24", tipi: ["paper"] },
  { data: "2026-09-30", tipi: ["residual", "plastic_metals"] },
  { data: "2026-10-01", tipi: ["paper"] },
  { data: "2026-10-07", tipi: ["residual", "plastic_metals"] },
  { data: "2026-10-08", tipi: ["paper"] },
  { data: "2026-10-14", tipi: ["residual", "plastic_metals"] },
  { data: "2026-10-15", tipi: ["paper"] },
  { data: "2026-10-21", tipi: ["residual", "plastic_metals"] },
  { data: "2026-10-22", tipi: ["paper"] },
  { data: "2026-10-28", tipi: ["residual", "plastic_metals"] },
  { data: "2026-10-29", tipi: ["paper"] },
  { data: "2026-11-04", tipi: ["residual", "plastic_metals"] },
  { data: "2026-11-05", tipi: ["paper"] },
  { data: "2026-11-11", tipi: ["residual", "plastic_metals"] },
  { data: "2026-11-12", tipi: ["paper"] },
  { data: "2026-11-18", tipi: ["residual", "plastic_metals"] },
  { data: "2026-11-19", tipi: ["paper"] },
  { data: "2026-11-25", tipi: ["residual", "plastic_metals"] },
  { data: "2026-11-26", tipi: ["paper"] },
  { data: "2026-12-02", tipi: ["residual", "plastic_metals"] },
  { data: "2026-12-03", tipi: ["paper"] },
  { data: "2026-12-09", tipi: ["residual", "plastic_metals"] },
  { data: "2026-12-10", tipi: ["paper"] },
  { data: "2026-12-16", tipi: ["residual", "plastic_metals"] },
  { data: "2026-12-17", tipi: ["paper"] },
  { data: "2026-12-23", tipi: ["residual", "plastic_metals"] },
  { data: "2026-12-24", tipi: ["paper"] },
  { data: "2026-12-30", tipi: ["residual", "plastic_metals"] },
  { data: "2027-01-06", tipi: ["residual", "plastic_metals"] },
  { data: "2027-01-07", tipi: ["paper"] },
  { data: "2027-01-13", tipi: ["residual", "plastic_metals"] },
  { data: "2027-01-14", tipi: ["paper"] },
  { data: "2027-01-20", tipi: ["residual", "plastic_metals"] },
  { data: "2027-01-21", tipi: ["paper"] },
  { data: "2027-01-27", tipi: ["residual", "plastic_metals"] },
  { data: "2027-01-28", tipi: ["paper"] },
];

const RIFIUTI_GEA_PORDENONE_MARRONE = [
  { data: "2026-01-02", tipi: ["residual", "plastic_metals"] },
  { data: "2026-01-08", tipi: ["paper"] },
  { data: "2026-01-09", tipi: ["residual", "plastic_metals"] },
  { data: "2026-01-15", tipi: ["paper"] },
  { data: "2026-01-16", tipi: ["residual", "plastic_metals"] },
  { data: "2026-01-22", tipi: ["paper"] },
  { data: "2026-01-23", tipi: ["residual", "plastic_metals"] },
  { data: "2026-01-29", tipi: ["paper"] },
  { data: "2026-01-30", tipi: ["residual", "plastic_metals"] },
  { data: "2026-02-05", tipi: ["paper"] },
  { data: "2026-02-06", tipi: ["residual", "plastic_metals"] },
  { data: "2026-02-12", tipi: ["paper"] },
  { data: "2026-02-13", tipi: ["residual", "plastic_metals"] },
  { data: "2026-02-19", tipi: ["paper"] },
  { data: "2026-02-20", tipi: ["residual", "plastic_metals"] },
  { data: "2026-02-26", tipi: ["paper"] },
  { data: "2026-02-27", tipi: ["residual", "plastic_metals"] },
  { data: "2026-03-05", tipi: ["paper"] },
  { data: "2026-03-06", tipi: ["residual", "plastic_metals"] },
  { data: "2026-03-12", tipi: ["paper"] },
  { data: "2026-03-13", tipi: ["residual", "plastic_metals"] },
  { data: "2026-03-19", tipi: ["paper"] },
  { data: "2026-03-20", tipi: ["residual", "plastic_metals"] },
  { data: "2026-03-26", tipi: ["paper"] },
  { data: "2026-03-27", tipi: ["residual", "plastic_metals"] },
  { data: "2026-04-02", tipi: ["paper"] },
  { data: "2026-04-03", tipi: ["residual", "plastic_metals"] },
  { data: "2026-04-09", tipi: ["paper"] },
  { data: "2026-04-10", tipi: ["residual", "plastic_metals"] },
  { data: "2026-04-16", tipi: ["paper"] },
  { data: "2026-04-17", tipi: ["residual", "plastic_metals"] },
  { data: "2026-04-23", tipi: ["paper"] },
  { data: "2026-04-24", tipi: ["residual", "plastic_metals"] },
  { data: "2026-04-30", tipi: ["paper"] },
  { data: "2026-05-07", tipi: ["paper"] },
  { data: "2026-05-08", tipi: ["residual", "plastic_metals"] },
  { data: "2026-05-14", tipi: ["paper"] },
  { data: "2026-05-15", tipi: ["residual", "plastic_metals"] },
  { data: "2026-05-21", tipi: ["paper"] },
  { data: "2026-05-22", tipi: ["residual", "plastic_metals"] },
  { data: "2026-05-28", tipi: ["paper"] },
  { data: "2026-05-29", tipi: ["residual", "plastic_metals"] },
  { data: "2026-06-04", tipi: ["paper"] },
  { data: "2026-06-05", tipi: ["residual", "plastic_metals"] },
  { data: "2026-06-11", tipi: ["paper"] },
  { data: "2026-06-12", tipi: ["residual", "plastic_metals"] },
  { data: "2026-06-18", tipi: ["paper"] },
  { data: "2026-06-19", tipi: ["residual", "plastic_metals"] },
  { data: "2026-06-25", tipi: ["paper"] },
  { data: "2026-06-26", tipi: ["residual", "plastic_metals"] },
  { data: "2026-07-02", tipi: ["paper"] },
  { data: "2026-07-03", tipi: ["residual", "plastic_metals"] },
  { data: "2026-07-09", tipi: ["paper"] },
  { data: "2026-07-10", tipi: ["residual", "plastic_metals"] },
  { data: "2026-07-16", tipi: ["paper"] },
  { data: "2026-07-17", tipi: ["residual", "plastic_metals"] },
  { data: "2026-07-23", tipi: ["paper"] },
  { data: "2026-07-24", tipi: ["residual", "plastic_metals"] },
  { data: "2026-07-30", tipi: ["paper"] },
  { data: "2026-07-31", tipi: ["residual", "plastic_metals"] },
  { data: "2026-08-06", tipi: ["paper"] },
  { data: "2026-08-07", tipi: ["residual", "plastic_metals"] },
  { data: "2026-08-13", tipi: ["paper"] },
  { data: "2026-08-14", tipi: ["residual", "plastic_metals"] },
  { data: "2026-08-20", tipi: ["paper"] },
  { data: "2026-08-21", tipi: ["residual", "plastic_metals"] },
  { data: "2026-08-27", tipi: ["paper"] },
  { data: "2026-08-28", tipi: ["residual", "plastic_metals"] },
  { data: "2026-09-03", tipi: ["paper"] },
  { data: "2026-09-04", tipi: ["residual", "plastic_metals"] },
  { data: "2026-09-10", tipi: ["paper"] },
  { data: "2026-09-11", tipi: ["residual", "plastic_metals"] },
  { data: "2026-09-17", tipi: ["paper"] },
  { data: "2026-09-18", tipi: ["residual", "plastic_metals"] },
  { data: "2026-09-24", tipi: ["paper"] },
  { data: "2026-09-25", tipi: ["residual", "plastic_metals"] },
  { data: "2026-10-01", tipi: ["paper"] },
  { data: "2026-10-02", tipi: ["residual", "plastic_metals"] },
  { data: "2026-10-08", tipi: ["paper"] },
  { data: "2026-10-09", tipi: ["residual", "plastic_metals"] },
  { data: "2026-10-15", tipi: ["paper"] },
  { data: "2026-10-16", tipi: ["residual", "plastic_metals"] },
  { data: "2026-10-22", tipi: ["paper"] },
  { data: "2026-10-23", tipi: ["residual", "plastic_metals"] },
  { data: "2026-10-29", tipi: ["paper"] },
  { data: "2026-10-30", tipi: ["residual", "plastic_metals"] },
  { data: "2026-11-05", tipi: ["paper"] },
  { data: "2026-11-06", tipi: ["residual", "plastic_metals"] },
  { data: "2026-11-12", tipi: ["paper"] },
  { data: "2026-11-13", tipi: ["residual", "plastic_metals"] },
  { data: "2026-11-19", tipi: ["paper"] },
  { data: "2026-11-20", tipi: ["residual", "plastic_metals"] },
  { data: "2026-11-26", tipi: ["paper"] },
  { data: "2026-11-27", tipi: ["residual", "plastic_metals"] },
  { data: "2026-12-03", tipi: ["paper"] },
  { data: "2026-12-04", tipi: ["residual", "plastic_metals"] },
  { data: "2026-12-10", tipi: ["paper"] },
  { data: "2026-12-11", tipi: ["residual", "plastic_metals"] },
  { data: "2026-12-17", tipi: ["paper"] },
  { data: "2026-12-18", tipi: ["residual", "plastic_metals"] },
  { data: "2026-12-23", tipi: ["residual"] },
  { data: "2026-12-24", tipi: ["paper"] },
  { data: "2027-01-01", tipi: ["residual"] },
  { data: "2027-01-07", tipi: ["paper"] },
  { data: "2027-01-08", tipi: ["residual", "plastic_metals"] },
  { data: "2027-01-14", tipi: ["paper"] },
  { data: "2027-01-15", tipi: ["residual", "plastic_metals"] },
  { data: "2027-01-21", tipi: ["paper"] },
  { data: "2027-01-22", tipi: ["residual", "plastic_metals"] },
  { data: "2027-01-28", tipi: ["paper"] },
  { data: "2027-01-29", tipi: ["residual", "plastic_metals"] },
];

const RIFIUTI_GEA_PORDENONE_VERDE_NORD = [
  { data: "2026-01-05", tipi: ["plastic_metals"] },
  { data: "2026-01-06", tipi: ["paper"] },
  { data: "2026-01-12", tipi: ["plastic_metals"] },
  { data: "2026-01-13", tipi: ["paper", "residual"] },
  { data: "2026-01-19", tipi: ["plastic_metals"] },
  { data: "2026-01-20", tipi: ["paper"] },
  { data: "2026-01-26", tipi: ["plastic_metals"] },
  { data: "2026-01-27", tipi: ["paper", "residual"] },
  { data: "2026-02-02", tipi: ["plastic_metals"] },
  { data: "2026-02-03", tipi: ["paper"] },
  { data: "2026-02-09", tipi: ["plastic_metals"] },
  { data: "2026-02-10", tipi: ["paper", "residual"] },
  { data: "2026-02-16", tipi: ["plastic_metals"] },
  { data: "2026-02-17", tipi: ["paper"] },
  { data: "2026-02-23", tipi: ["plastic_metals"] },
  { data: "2026-02-24", tipi: ["paper", "residual"] },
  { data: "2026-03-02", tipi: ["plastic_metals"] },
  { data: "2026-03-03", tipi: ["paper"] },
  { data: "2026-03-09", tipi: ["plastic_metals"] },
  { data: "2026-03-10", tipi: ["paper", "residual"] },
  { data: "2026-03-16", tipi: ["plastic_metals"] },
  { data: "2026-03-17", tipi: ["paper"] },
  { data: "2026-03-23", tipi: ["plastic_metals"] },
  { data: "2026-03-24", tipi: ["paper", "residual"] },
  { data: "2026-03-30", tipi: ["plastic_metals"] },
  { data: "2026-03-31", tipi: ["paper"] },
  { data: "2026-04-13", tipi: ["plastic_metals"] },
  { data: "2026-04-14", tipi: ["paper", "residual"] },
  { data: "2026-04-20", tipi: ["plastic_metals"] },
  { data: "2026-04-21", tipi: ["paper", "residual"] },
  { data: "2026-04-27", tipi: ["plastic_metals"] },
  { data: "2026-04-28", tipi: ["paper"] },
  { data: "2026-05-04", tipi: ["plastic_metals"] },
  { data: "2026-05-05", tipi: ["paper", "residual"] },
  { data: "2026-05-11", tipi: ["plastic_metals"] },
  { data: "2026-05-12", tipi: ["paper"] },
  { data: "2026-05-18", tipi: ["plastic_metals"] },
  { data: "2026-05-19", tipi: ["paper", "residual"] },
  { data: "2026-05-25", tipi: ["plastic_metals"] },
  { data: "2026-05-26", tipi: ["paper"] },
  { data: "2026-06-01", tipi: ["plastic_metals"] },
  { data: "2026-06-02", tipi: ["paper", "residual"] },
  { data: "2026-06-08", tipi: ["plastic_metals"] },
  { data: "2026-06-09", tipi: ["paper"] },
  { data: "2026-06-15", tipi: ["plastic_metals"] },
  { data: "2026-06-16", tipi: ["paper", "residual"] },
  { data: "2026-06-22", tipi: ["plastic_metals"] },
  { data: "2026-06-23", tipi: ["paper"] },
  { data: "2026-06-29", tipi: ["plastic_metals"] },
  { data: "2026-06-30", tipi: ["paper", "residual"] },
  { data: "2026-07-06", tipi: ["plastic_metals"] },
  { data: "2026-07-07", tipi: ["paper"] },
  { data: "2026-07-13", tipi: ["plastic_metals"] },
  { data: "2026-07-14", tipi: ["paper", "residual"] },
  { data: "2026-07-20", tipi: ["plastic_metals"] },
  { data: "2026-07-21", tipi: ["paper"] },
  { data: "2026-07-27", tipi: ["plastic_metals"] },
  { data: "2026-07-28", tipi: ["paper", "residual"] },
  { data: "2026-08-03", tipi: ["plastic_metals"] },
  { data: "2026-08-04", tipi: ["paper"] },
  { data: "2026-08-10", tipi: ["plastic_metals"] },
  { data: "2026-08-11", tipi: ["paper", "residual"] },
  { data: "2026-08-17", tipi: ["plastic_metals"] },
  { data: "2026-08-18", tipi: ["paper"] },
  { data: "2026-08-24", tipi: ["plastic_metals"] },
  { data: "2026-08-25", tipi: ["paper", "residual"] },
  { data: "2026-08-31", tipi: ["plastic_metals"] },
  { data: "2026-09-01", tipi: ["paper"] },
  { data: "2026-09-07", tipi: ["plastic_metals"] },
  { data: "2026-09-08", tipi: ["paper", "residual"] },
  { data: "2026-09-14", tipi: ["plastic_metals"] },
  { data: "2026-09-15", tipi: ["paper"] },
  { data: "2026-09-21", tipi: ["plastic_metals"] },
  { data: "2026-09-22", tipi: ["paper", "residual"] },
  { data: "2026-09-28", tipi: ["plastic_metals"] },
  { data: "2026-09-29", tipi: ["paper"] },
  { data: "2026-10-05", tipi: ["plastic_metals"] },
  { data: "2026-10-06", tipi: ["paper", "residual"] },
  { data: "2026-10-12", tipi: ["plastic_metals"] },
  { data: "2026-10-13", tipi: ["paper"] },
  { data: "2026-10-19", tipi: ["plastic_metals"] },
  { data: "2026-10-20", tipi: ["paper", "residual"] },
  { data: "2026-10-26", tipi: ["plastic_metals"] },
  { data: "2026-10-27", tipi: ["paper"] },
  { data: "2026-11-02", tipi: ["plastic_metals"] },
  { data: "2026-11-03", tipi: ["paper", "residual"] },
  { data: "2026-11-09", tipi: ["plastic_metals"] },
  { data: "2026-11-10", tipi: ["paper"] },
  { data: "2026-11-16", tipi: ["plastic_metals"] },
  { data: "2026-11-17", tipi: ["paper", "residual"] },
  { data: "2026-11-23", tipi: ["plastic_metals"] },
  { data: "2026-11-24", tipi: ["paper"] },
  { data: "2026-11-30", tipi: ["plastic_metals"] },
  { data: "2026-12-01", tipi: ["paper", "residual"] },
  { data: "2026-12-07", tipi: ["plastic_metals"] },
  { data: "2026-12-08", tipi: ["paper"] },
  { data: "2026-12-14", tipi: ["plastic_metals"] },
  { data: "2026-12-15", tipi: ["paper", "residual"] },
  { data: "2026-12-21", tipi: ["plastic_metals"] },
  { data: "2026-12-22", tipi: ["paper"] },
  { data: "2026-12-28", tipi: ["plastic_metals"] },
  { data: "2026-12-29", tipi: ["paper", "residual"] },
  { data: "2027-01-04", tipi: ["plastic_metals"] },
  { data: "2027-01-05", tipi: ["paper"] },
  { data: "2027-01-11", tipi: ["plastic_metals"] },
  { data: "2027-01-12", tipi: ["paper", "residual"] },
  { data: "2027-01-18", tipi: ["plastic_metals"] },
  { data: "2027-01-19", tipi: ["paper"] },
  { data: "2027-01-25", tipi: ["plastic_metals"] },
  { data: "2027-01-26", tipi: ["paper", "residual"] },
];

const RIFIUTI_GEA_PORDENONE_VERDE_SUD = [
  { data: "2026-01-03", tipi: ["residual", "plastic_metals"] },
  { data: "2026-01-08", tipi: ["paper", "plastic_metals"] },
  { data: "2026-01-15", tipi: ["residual", "plastic_metals"] },
  { data: "2026-01-22", tipi: ["plastic_metals"] },
  { data: "2026-01-29", tipi: ["residual", "plastic_metals"] },
  { data: "2026-02-03", tipi: ["paper"] },
  { data: "2026-02-05", tipi: ["plastic_metals"] },
  { data: "2026-02-10", tipi: ["paper"] },
  { data: "2026-02-12", tipi: ["residual", "plastic_metals"] },
  { data: "2026-02-17", tipi: ["paper"] },
  { data: "2026-02-19", tipi: ["plastic_metals"] },
  { data: "2026-02-24", tipi: ["paper"] },
  { data: "2026-02-26", tipi: ["residual", "plastic_metals"] },
  { data: "2026-03-03", tipi: ["paper"] },
  { data: "2026-03-05", tipi: ["plastic_metals"] },
  { data: "2026-03-10", tipi: ["paper"] },
  { data: "2026-03-12", tipi: ["residual", "plastic_metals"] },
  { data: "2026-03-17", tipi: ["paper"] },
  { data: "2026-03-19", tipi: ["plastic_metals"] },
  { data: "2026-03-24", tipi: ["paper"] },
  { data: "2026-03-26", tipi: ["residual", "plastic_metals"] },
  { data: "2026-04-02", tipi: ["plastic_metals"] },
  { data: "2026-04-07", tipi: ["paper"] },
  { data: "2026-04-09", tipi: ["residual", "plastic_metals"] },
  { data: "2026-04-14", tipi: ["paper"] },
  { data: "2026-04-16", tipi: ["plastic_metals"] },
  { data: "2026-04-21", tipi: ["paper"] },
  { data: "2026-04-23", tipi: ["residual", "plastic_metals"] },
  { data: "2026-04-28", tipi: ["paper"] },
  { data: "2026-04-30", tipi: ["plastic_metals"] },
  { data: "2026-05-05", tipi: ["paper"] },
  { data: "2026-05-07", tipi: ["residual", "plastic_metals"] },
  { data: "2026-05-12", tipi: ["paper"] },
  { data: "2026-05-14", tipi: ["plastic_metals"] },
  { data: "2026-05-19", tipi: ["paper"] },
  { data: "2026-05-21", tipi: ["residual", "plastic_metals"] },
  { data: "2026-05-26", tipi: ["paper"] },
  { data: "2026-05-28", tipi: ["plastic_metals"] },
  { data: "2026-06-02", tipi: ["paper"] },
  { data: "2026-06-04", tipi: ["residual", "plastic_metals"] },
  { data: "2026-06-09", tipi: ["paper"] },
  { data: "2026-06-11", tipi: ["plastic_metals"] },
  { data: "2026-06-16", tipi: ["paper"] },
  { data: "2026-06-18", tipi: ["residual", "plastic_metals"] },
  { data: "2026-06-23", tipi: ["paper"] },
  { data: "2026-06-25", tipi: ["plastic_metals"] },
  { data: "2026-06-30", tipi: ["paper"] },
  { data: "2026-07-02", tipi: ["residual", "plastic_metals"] },
  { data: "2026-07-07", tipi: ["paper"] },
  { data: "2026-07-09", tipi: ["plastic_metals"] },
  { data: "2026-07-14", tipi: ["paper"] },
  { data: "2026-07-16", tipi: ["residual", "plastic_metals"] },
  { data: "2026-07-21", tipi: ["paper"] },
  { data: "2026-07-23", tipi: ["plastic_metals"] },
  { data: "2026-07-28", tipi: ["paper"] },
  { data: "2026-07-30", tipi: ["residual", "plastic_metals"] },
  { data: "2026-08-04", tipi: ["paper"] },
  { data: "2026-08-06", tipi: ["plastic_metals"] },
  { data: "2026-08-11", tipi: ["paper"] },
  { data: "2026-08-13", tipi: ["residual", "plastic_metals"] },
  { data: "2026-08-18", tipi: ["paper"] },
  { data: "2026-08-20", tipi: ["plastic_metals"] },
  { data: "2026-08-25", tipi: ["paper"] },
  { data: "2026-08-27", tipi: ["residual", "plastic_metals"] },
  { data: "2026-09-01", tipi: ["paper"] },
  { data: "2026-09-03", tipi: ["plastic_metals"] },
  { data: "2026-09-08", tipi: ["paper"] },
  { data: "2026-09-10", tipi: ["residual", "plastic_metals"] },
  { data: "2026-09-15", tipi: ["paper"] },
  { data: "2026-09-17", tipi: ["plastic_metals"] },
  { data: "2026-09-22", tipi: ["paper"] },
  { data: "2026-09-24", tipi: ["residual", "plastic_metals"] },
  { data: "2026-09-29", tipi: ["paper"] },
  { data: "2026-10-01", tipi: ["plastic_metals"] },
  { data: "2026-10-06", tipi: ["paper"] },
  { data: "2026-10-08", tipi: ["residual", "plastic_metals"] },
  { data: "2026-10-13", tipi: ["paper"] },
  { data: "2026-10-15", tipi: ["plastic_metals"] },
  { data: "2026-10-20", tipi: ["paper"] },
  { data: "2026-10-22", tipi: ["residual", "plastic_metals"] },
  { data: "2026-10-27", tipi: ["paper"] },
  { data: "2026-10-29", tipi: ["plastic_metals"] },
  { data: "2026-11-03", tipi: ["paper"] },
  { data: "2026-11-05", tipi: ["residual", "plastic_metals"] },
  { data: "2026-11-10", tipi: ["paper"] },
  { data: "2026-11-12", tipi: ["plastic_metals"] },
  { data: "2026-11-17", tipi: ["paper"] },
  { data: "2026-11-19", tipi: ["residual", "plastic_metals"] },
  { data: "2026-11-24", tipi: ["paper"] },
  { data: "2026-11-26", tipi: ["plastic_metals"] },
  { data: "2026-12-01", tipi: ["paper"] },
  { data: "2026-12-03", tipi: ["residual", "plastic_metals"] },
  { data: "2026-12-08", tipi: ["paper"] },
  { data: "2026-12-10", tipi: ["plastic_metals"] },
  { data: "2026-12-15", tipi: ["paper"] },
  { data: "2026-12-17", tipi: ["residual", "plastic_metals"] },
  { data: "2026-12-22", tipi: ["paper"] },
  { data: "2026-12-24", tipi: ["plastic_metals"] },
  { data: "2026-12-29", tipi: ["paper"] },
  { data: "2026-12-31", tipi: ["residual", "plastic_metals"] },
  { data: "2027-01-05", tipi: ["paper"] },
  { data: "2027-01-07", tipi: ["plastic_metals"] },
  { data: "2027-01-12", tipi: ["paper"] },
  { data: "2027-01-14", tipi: ["residual", "plastic_metals"] },
  { data: "2027-01-19", tipi: ["paper"] },
  { data: "2027-01-21", tipi: ["plastic_metals"] },
  { data: "2027-01-26", tipi: ["paper"] },
  { data: "2027-01-28", tipi: ["residual", "plastic_metals"] },
];


// ---------------------------------------------------------------------
// GEA, estensione comuni provincia di Pordenone (30/09/2026) — Budoia,
// Andreis, Barcis. Stessa fonte/metodo di Aviano/Pordenone: PDF annuali
// GEA caricati dall'utente (Calendario-Budoia-2026, Calendario-Andreis-2026,
// Calendario-Barcis-2026, 24 pagine ciascuno), trascritti a mano e
// incorporati come dato statico (nessun fetch di rete).
//
// **Budoia** ha una particolarità rispetto ad Aviano/Pordenone: SECCO
// RESIDUO (e, nei mesi estivi, UMIDO quando abbinato allo stesso giro)
// non sono comune-wide ma alternano settimanalmente fra due frazioni/
// zone ("Budoia centro e Zona Ind." e "Dardago e S.Lucia") — le altre
// raccolte (carta, plastica, umido "puro" infrasettimanale, vetro) sono
// invece uguali per tutto il comune. Modellato con due `aree` (come
// Pordenone), ciascuna con l'intero calendario dell'anno: le date
// comuni a entrambe le zone sono duplicate identiche nei due array,
// le date di SECCO/UMIDO+SECCO differiscono per zona. Da giugno a
// settembre il PDF mostra una frequenza estiva più alta per l'umido
// (abbinato al secco il lunedì di zona, più infrasettimanale come nel
// resto dell'anno) — trascritto letteralmente giorno per giorno, nessuna
// regola generalizzata.
//
// **Andreis e Barcis** sono invece a zona unica (`aree` con una sola
// voce, area: null) — **e, verificato pagina per pagina su tutti e 12 i
// mesi, hanno esattamente lo stesso calendario di raccolta** (stesso
// giro GEA per i due comuni limitrofi): stessa rotazione settimanale
// (secco+vetro una settimana, umido ogni mercoledì, carta+plastica la
// settimana successiva), stessa frequenza estiva (umido anche il sabato,
// giugno-settembre), stessa eccezione del 15 agosto. I due array restano
// separati (non un'unica costante condivisa) per coerenza con il resto
// del file e in caso un futuro PDF li differenzi.
//
// **Centro di raccolta**: nessuno dei tre comuni ha un ecocentro fisso
// attivo (il PDF lo conferma esplicitamente, "il centro di raccolta non
// è ancora attivo"). Andreis segnala che è comunque utilizzabile
// l'ecocentro di Montereale Valcellina (Zona Industriale, indirizzo
// reale nel PDF) — riportato qui come `centro_raccolta`. Barcis non
// segnala alcun centro alternativo (solo servizio ingombranti/RAEE
// porta a porta su prenotazione) — `centro_raccolta: null`, stesso
// pattern già usato per i comuni Isontina senza centro fisso.
//
// **Eccezioni festive**: Capodanno (01/01) e, per Budoia, anche Festa
// del Lavoro (01/05) e Natale (25/12) mostrano nel PDF la raccolta
// annullata con un badge "posticipato" sul giorno di recupero — la
// singola raccolta è registrata solo sulla data di recupero effettiva,
// come già fatto per le "raccolte modificate" di Aviano/Pordenone. Per
// Andreis/Barcis, il 15 agosto (Ferragosto) mostra l'umido annullato
// **senza** alcun badge di recupero visibile altrove nel calendario:
// trascritto come raccolta persa quella settimana, nessuna data
// inventata (nota di incertezza, coerente con la disciplina già usata
// per Pordenone).
// ---------------------------------------------------------------------

const RIFIUTI_GEA_BUDOIA_CENTRO = [
  { data: "2026-01-02", tipi: ["organic"] },
  { data: "2026-01-03", tipi: ["paper"] },
  { data: "2026-01-05", tipi: ["residual"] },
  { data: "2026-01-08", tipi: ["plastic_metals"] },
  { data: "2026-01-09", tipi: ["organic", "glass"] },
  { data: "2026-01-15", tipi: ["paper"] },
  { data: "2026-01-16", tipi: ["organic"] },
  { data: "2026-01-19", tipi: ["residual"] },
  { data: "2026-01-22", tipi: ["plastic_metals"] },
  { data: "2026-01-23", tipi: ["organic", "glass"] },
  { data: "2026-01-29", tipi: ["paper"] },
  { data: "2026-01-30", tipi: ["organic"] },
  { data: "2026-02-02", tipi: ["residual"] },
  { data: "2026-02-05", tipi: ["plastic_metals"] },
  { data: "2026-02-06", tipi: ["organic", "glass"] },
  { data: "2026-02-12", tipi: ["paper"] },
  { data: "2026-02-13", tipi: ["organic"] },
  { data: "2026-02-16", tipi: ["residual"] },
  { data: "2026-02-19", tipi: ["plastic_metals"] },
  { data: "2026-02-20", tipi: ["organic", "glass"] },
  { data: "2026-02-26", tipi: ["paper"] },
  { data: "2026-02-27", tipi: ["organic"] },
  { data: "2026-03-02", tipi: ["residual"] },
  { data: "2026-03-05", tipi: ["plastic_metals"] },
  { data: "2026-03-06", tipi: ["organic", "glass"] },
  { data: "2026-03-12", tipi: ["paper"] },
  { data: "2026-03-13", tipi: ["organic"] },
  { data: "2026-03-16", tipi: ["residual"] },
  { data: "2026-03-19", tipi: ["plastic_metals"] },
  { data: "2026-03-20", tipi: ["organic", "glass"] },
  { data: "2026-03-26", tipi: ["paper"] },
  { data: "2026-03-27", tipi: ["organic"] },
  { data: "2026-03-30", tipi: ["residual"] },
  { data: "2026-04-02", tipi: ["plastic_metals"] },
  { data: "2026-04-03", tipi: ["organic", "glass"] },
  { data: "2026-04-09", tipi: ["paper"] },
  { data: "2026-04-10", tipi: ["organic"] },
  { data: "2026-04-13", tipi: ["residual"] },
  { data: "2026-04-16", tipi: ["plastic_metals"] },
  { data: "2026-04-17", tipi: ["organic", "glass"] },
  { data: "2026-04-23", tipi: ["paper"] },
  { data: "2026-04-24", tipi: ["organic"] },
  { data: "2026-04-27", tipi: ["residual"] },
  { data: "2026-04-30", tipi: ["plastic_metals"] },
  { data: "2026-05-02", tipi: ["organic", "glass"] },
  { data: "2026-05-07", tipi: ["paper"] },
  { data: "2026-05-08", tipi: ["organic"] },
  { data: "2026-05-11", tipi: ["residual"] },
  { data: "2026-05-14", tipi: ["plastic_metals"] },
  { data: "2026-05-15", tipi: ["organic", "glass"] },
  { data: "2026-05-21", tipi: ["paper"] },
  { data: "2026-05-22", tipi: ["organic"] },
  { data: "2026-05-25", tipi: ["residual"] },
  { data: "2026-05-28", tipi: ["plastic_metals"] },
  { data: "2026-05-29", tipi: ["organic", "glass"] },
  { data: "2026-06-04", tipi: ["paper"] },
  { data: "2026-06-05", tipi: ["organic"] },
  { data: "2026-06-08", tipi: ["organic", "residual"] },
  { data: "2026-06-11", tipi: ["plastic_metals"] },
  { data: "2026-06-12", tipi: ["organic", "glass"] },
  { data: "2026-06-18", tipi: ["paper"] },
  { data: "2026-06-19", tipi: ["organic"] },
  { data: "2026-06-22", tipi: ["organic", "residual"] },
  { data: "2026-06-25", tipi: ["plastic_metals"] },
  { data: "2026-06-26", tipi: ["organic", "glass"] },
  { data: "2026-07-02", tipi: ["paper"] },
  { data: "2026-07-03", tipi: ["organic"] },
  { data: "2026-07-06", tipi: ["organic", "residual"] },
  { data: "2026-07-09", tipi: ["plastic_metals"] },
  { data: "2026-07-10", tipi: ["organic", "glass"] },
  { data: "2026-07-16", tipi: ["paper"] },
  { data: "2026-07-17", tipi: ["organic"] },
  { data: "2026-07-20", tipi: ["organic", "residual"] },
  { data: "2026-07-23", tipi: ["plastic_metals"] },
  { data: "2026-07-24", tipi: ["organic", "glass"] },
  { data: "2026-07-30", tipi: ["paper"] },
  { data: "2026-07-31", tipi: ["organic"] },
  { data: "2026-08-03", tipi: ["organic", "residual"] },
  { data: "2026-08-06", tipi: ["plastic_metals"] },
  { data: "2026-08-07", tipi: ["organic", "glass"] },
  { data: "2026-08-13", tipi: ["paper"] },
  { data: "2026-08-14", tipi: ["organic"] },
  { data: "2026-08-17", tipi: ["organic", "residual"] },
  { data: "2026-08-20", tipi: ["plastic_metals"] },
  { data: "2026-08-21", tipi: ["organic", "glass"] },
  { data: "2026-08-27", tipi: ["paper"] },
  { data: "2026-08-28", tipi: ["organic"] },
  { data: "2026-08-31", tipi: ["organic", "residual"] },
  { data: "2026-09-03", tipi: ["plastic_metals"] },
  { data: "2026-09-04", tipi: ["organic", "glass"] },
  { data: "2026-09-10", tipi: ["paper"] },
  { data: "2026-09-11", tipi: ["organic"] },
  { data: "2026-09-14", tipi: ["organic", "residual"] },
  { data: "2026-09-17", tipi: ["plastic_metals"] },
  { data: "2026-09-18", tipi: ["organic", "glass"] },
  { data: "2026-09-24", tipi: ["paper"] },
  { data: "2026-09-25", tipi: ["organic"] },
  { data: "2026-09-28", tipi: ["organic", "residual"] },
  { data: "2026-10-01", tipi: ["plastic_metals"] },
  { data: "2026-10-02", tipi: ["organic", "glass"] },
  { data: "2026-10-08", tipi: ["paper"] },
  { data: "2026-10-09", tipi: ["organic"] },
  { data: "2026-10-12", tipi: ["residual"] },
  { data: "2026-10-15", tipi: ["plastic_metals"] },
  { data: "2026-10-16", tipi: ["organic", "glass"] },
  { data: "2026-10-22", tipi: ["paper"] },
  { data: "2026-10-23", tipi: ["organic"] },
  { data: "2026-10-26", tipi: ["residual"] },
  { data: "2026-10-29", tipi: ["plastic_metals"] },
  { data: "2026-10-30", tipi: ["organic", "glass"] },
  { data: "2026-11-05", tipi: ["paper"] },
  { data: "2026-11-06", tipi: ["organic"] },
  { data: "2026-11-09", tipi: ["residual"] },
  { data: "2026-11-12", tipi: ["plastic_metals"] },
  { data: "2026-11-13", tipi: ["organic", "glass"] },
  { data: "2026-11-19", tipi: ["paper"] },
  { data: "2026-11-20", tipi: ["organic"] },
  { data: "2026-11-23", tipi: ["residual"] },
  { data: "2026-11-26", tipi: ["plastic_metals"] },
  { data: "2026-11-27", tipi: ["organic", "glass"] },
  { data: "2026-12-03", tipi: ["paper"] },
  { data: "2026-12-04", tipi: ["organic"] },
  { data: "2026-12-07", tipi: ["residual"] },
  { data: "2026-12-10", tipi: ["plastic_metals"] },
  { data: "2026-12-11", tipi: ["organic", "glass"] },
  { data: "2026-12-17", tipi: ["paper"] },
  { data: "2026-12-18", tipi: ["organic"] },
  { data: "2026-12-21", tipi: ["residual"] },
  { data: "2026-12-24", tipi: ["plastic_metals"] },
  { data: "2026-12-26", tipi: ["organic", "glass"] },
  { data: "2026-12-31", tipi: ["paper"] },
];

const RIFIUTI_GEA_BUDOIA_DARDAGO = [
  { data: "2026-01-02", tipi: ["organic"] },
  { data: "2026-01-03", tipi: ["paper"] },
  { data: "2026-01-08", tipi: ["plastic_metals"] },
  { data: "2026-01-09", tipi: ["organic", "glass"] },
  { data: "2026-01-12", tipi: ["residual"] },
  { data: "2026-01-15", tipi: ["paper"] },
  { data: "2026-01-16", tipi: ["organic"] },
  { data: "2026-01-22", tipi: ["plastic_metals"] },
  { data: "2026-01-23", tipi: ["organic", "glass"] },
  { data: "2026-01-26", tipi: ["residual"] },
  { data: "2026-01-29", tipi: ["paper"] },
  { data: "2026-01-30", tipi: ["organic"] },
  { data: "2026-02-05", tipi: ["plastic_metals"] },
  { data: "2026-02-06", tipi: ["organic", "glass"] },
  { data: "2026-02-09", tipi: ["residual"] },
  { data: "2026-02-12", tipi: ["paper"] },
  { data: "2026-02-13", tipi: ["organic"] },
  { data: "2026-02-19", tipi: ["plastic_metals"] },
  { data: "2026-02-20", tipi: ["organic", "glass"] },
  { data: "2026-02-23", tipi: ["residual"] },
  { data: "2026-02-26", tipi: ["paper"] },
  { data: "2026-02-27", tipi: ["organic"] },
  { data: "2026-03-05", tipi: ["plastic_metals"] },
  { data: "2026-03-06", tipi: ["organic", "glass"] },
  { data: "2026-03-09", tipi: ["residual"] },
  { data: "2026-03-12", tipi: ["paper"] },
  { data: "2026-03-13", tipi: ["organic"] },
  { data: "2026-03-19", tipi: ["plastic_metals"] },
  { data: "2026-03-20", tipi: ["organic", "glass"] },
  { data: "2026-03-23", tipi: ["residual"] },
  { data: "2026-03-26", tipi: ["paper"] },
  { data: "2026-03-27", tipi: ["organic"] },
  { data: "2026-04-02", tipi: ["plastic_metals"] },
  { data: "2026-04-03", tipi: ["organic", "glass"] },
  { data: "2026-04-06", tipi: ["residual"] },
  { data: "2026-04-09", tipi: ["paper"] },
  { data: "2026-04-10", tipi: ["organic"] },
  { data: "2026-04-16", tipi: ["plastic_metals"] },
  { data: "2026-04-17", tipi: ["organic", "glass"] },
  { data: "2026-04-20", tipi: ["residual"] },
  { data: "2026-04-23", tipi: ["paper"] },
  { data: "2026-04-24", tipi: ["organic"] },
  { data: "2026-04-30", tipi: ["plastic_metals"] },
  { data: "2026-05-02", tipi: ["organic", "glass"] },
  { data: "2026-05-04", tipi: ["residual"] },
  { data: "2026-05-07", tipi: ["paper"] },
  { data: "2026-05-08", tipi: ["organic"] },
  { data: "2026-05-14", tipi: ["plastic_metals"] },
  { data: "2026-05-15", tipi: ["organic", "glass"] },
  { data: "2026-05-18", tipi: ["residual"] },
  { data: "2026-05-21", tipi: ["paper"] },
  { data: "2026-05-22", tipi: ["organic"] },
  { data: "2026-05-28", tipi: ["plastic_metals"] },
  { data: "2026-05-29", tipi: ["organic", "glass"] },
  { data: "2026-06-01", tipi: ["organic", "residual"] },
  { data: "2026-06-04", tipi: ["paper"] },
  { data: "2026-06-05", tipi: ["organic"] },
  { data: "2026-06-11", tipi: ["plastic_metals"] },
  { data: "2026-06-12", tipi: ["organic", "glass"] },
  { data: "2026-06-15", tipi: ["organic", "residual"] },
  { data: "2026-06-18", tipi: ["paper"] },
  { data: "2026-06-19", tipi: ["organic"] },
  { data: "2026-06-25", tipi: ["plastic_metals"] },
  { data: "2026-06-26", tipi: ["organic", "glass"] },
  { data: "2026-06-29", tipi: ["organic", "residual"] },
  { data: "2026-07-02", tipi: ["paper"] },
  { data: "2026-07-03", tipi: ["organic"] },
  { data: "2026-07-09", tipi: ["plastic_metals"] },
  { data: "2026-07-10", tipi: ["organic", "glass"] },
  { data: "2026-07-13", tipi: ["organic", "residual"] },
  { data: "2026-07-16", tipi: ["paper"] },
  { data: "2026-07-17", tipi: ["organic"] },
  { data: "2026-07-23", tipi: ["plastic_metals"] },
  { data: "2026-07-24", tipi: ["organic", "glass"] },
  { data: "2026-07-27", tipi: ["organic", "residual"] },
  { data: "2026-07-30", tipi: ["paper"] },
  { data: "2026-07-31", tipi: ["organic"] },
  { data: "2026-08-06", tipi: ["plastic_metals"] },
  { data: "2026-08-07", tipi: ["organic", "glass"] },
  { data: "2026-08-10", tipi: ["organic", "residual"] },
  { data: "2026-08-13", tipi: ["paper"] },
  { data: "2026-08-14", tipi: ["organic"] },
  { data: "2026-08-20", tipi: ["plastic_metals"] },
  { data: "2026-08-21", tipi: ["organic", "glass"] },
  { data: "2026-08-24", tipi: ["organic", "residual"] },
  { data: "2026-08-27", tipi: ["paper"] },
  { data: "2026-08-28", tipi: ["organic"] },
  { data: "2026-09-03", tipi: ["plastic_metals"] },
  { data: "2026-09-04", tipi: ["organic", "glass"] },
  { data: "2026-09-07", tipi: ["organic", "residual"] },
  { data: "2026-09-10", tipi: ["paper"] },
  { data: "2026-09-11", tipi: ["organic"] },
  { data: "2026-09-17", tipi: ["plastic_metals"] },
  { data: "2026-09-18", tipi: ["organic", "glass"] },
  { data: "2026-09-21", tipi: ["organic", "residual"] },
  { data: "2026-09-24", tipi: ["paper"] },
  { data: "2026-09-25", tipi: ["organic"] },
  { data: "2026-10-01", tipi: ["plastic_metals"] },
  { data: "2026-10-02", tipi: ["organic", "glass"] },
  { data: "2026-10-05", tipi: ["residual"] },
  { data: "2026-10-08", tipi: ["paper"] },
  { data: "2026-10-09", tipi: ["organic"] },
  { data: "2026-10-15", tipi: ["plastic_metals"] },
  { data: "2026-10-16", tipi: ["organic", "glass"] },
  { data: "2026-10-19", tipi: ["residual"] },
  { data: "2026-10-22", tipi: ["paper"] },
  { data: "2026-10-23", tipi: ["organic"] },
  { data: "2026-10-29", tipi: ["plastic_metals"] },
  { data: "2026-10-30", tipi: ["organic", "glass"] },
  { data: "2026-11-02", tipi: ["residual"] },
  { data: "2026-11-05", tipi: ["paper"] },
  { data: "2026-11-06", tipi: ["organic"] },
  { data: "2026-11-12", tipi: ["plastic_metals"] },
  { data: "2026-11-13", tipi: ["organic", "glass"] },
  { data: "2026-11-16", tipi: ["residual"] },
  { data: "2026-11-19", tipi: ["paper"] },
  { data: "2026-11-20", tipi: ["organic"] },
  { data: "2026-11-26", tipi: ["plastic_metals"] },
  { data: "2026-11-27", tipi: ["organic", "glass"] },
  { data: "2026-11-30", tipi: ["residual"] },
  { data: "2026-12-03", tipi: ["paper"] },
  { data: "2026-12-04", tipi: ["organic"] },
  { data: "2026-12-10", tipi: ["plastic_metals"] },
  { data: "2026-12-11", tipi: ["organic", "glass"] },
  { data: "2026-12-14", tipi: ["residual"] },
  { data: "2026-12-17", tipi: ["paper"] },
  { data: "2026-12-18", tipi: ["organic"] },
  { data: "2026-12-24", tipi: ["plastic_metals"] },
  { data: "2026-12-26", tipi: ["organic", "glass"] },
  { data: "2026-12-28", tipi: ["residual"] },
  { data: "2026-12-31", tipi: ["paper"] },
];

const RIFIUTI_GEA_ANDREIS = [
  { data: "2026-01-02", tipi: ["plastic_metals"] },
  { data: "2026-01-03", tipi: ["paper"] },
  { data: "2026-01-05", tipi: ["residual"] },
  { data: "2026-01-06", tipi: ["glass"] },
  { data: "2026-01-07", tipi: ["organic"] },
  { data: "2026-01-14", tipi: ["organic"] },
  { data: "2026-01-15", tipi: ["paper"] },
  { data: "2026-01-16", tipi: ["plastic_metals"] },
  { data: "2026-01-19", tipi: ["residual"] },
  { data: "2026-01-20", tipi: ["glass"] },
  { data: "2026-01-21", tipi: ["organic"] },
  { data: "2026-01-28", tipi: ["organic"] },
  { data: "2026-01-29", tipi: ["paper"] },
  { data: "2026-01-30", tipi: ["plastic_metals"] },
  { data: "2026-02-02", tipi: ["residual"] },
  { data: "2026-02-03", tipi: ["glass"] },
  { data: "2026-02-04", tipi: ["organic"] },
  { data: "2026-02-11", tipi: ["organic"] },
  { data: "2026-02-12", tipi: ["paper"] },
  { data: "2026-02-13", tipi: ["plastic_metals"] },
  { data: "2026-02-16", tipi: ["residual"] },
  { data: "2026-02-17", tipi: ["glass"] },
  { data: "2026-02-18", tipi: ["organic"] },
  { data: "2026-02-25", tipi: ["organic"] },
  { data: "2026-02-26", tipi: ["paper"] },
  { data: "2026-02-27", tipi: ["plastic_metals"] },
  { data: "2026-03-02", tipi: ["residual"] },
  { data: "2026-03-03", tipi: ["glass"] },
  { data: "2026-03-04", tipi: ["organic"] },
  { data: "2026-03-11", tipi: ["organic"] },
  { data: "2026-03-12", tipi: ["paper"] },
  { data: "2026-03-13", tipi: ["plastic_metals"] },
  { data: "2026-03-16", tipi: ["residual"] },
  { data: "2026-03-17", tipi: ["glass"] },
  { data: "2026-03-18", tipi: ["organic"] },
  { data: "2026-03-25", tipi: ["organic"] },
  { data: "2026-03-26", tipi: ["paper"] },
  { data: "2026-03-27", tipi: ["plastic_metals"] },
  { data: "2026-03-30", tipi: ["residual"] },
  { data: "2026-03-31", tipi: ["glass"] },
  { data: "2026-04-01", tipi: ["organic"] },
  { data: "2026-04-08", tipi: ["organic"] },
  { data: "2026-04-09", tipi: ["paper"] },
  { data: "2026-04-10", tipi: ["plastic_metals"] },
  { data: "2026-04-13", tipi: ["residual"] },
  { data: "2026-04-14", tipi: ["glass"] },
  { data: "2026-04-15", tipi: ["organic"] },
  { data: "2026-04-22", tipi: ["organic"] },
  { data: "2026-04-23", tipi: ["paper"] },
  { data: "2026-04-24", tipi: ["plastic_metals"] },
  { data: "2026-04-27", tipi: ["residual"] },
  { data: "2026-04-28", tipi: ["glass"] },
  { data: "2026-04-29", tipi: ["organic"] },
  { data: "2026-05-06", tipi: ["organic"] },
  { data: "2026-05-07", tipi: ["paper"] },
  { data: "2026-05-08", tipi: ["plastic_metals"] },
  { data: "2026-05-11", tipi: ["residual"] },
  { data: "2026-05-12", tipi: ["glass"] },
  { data: "2026-05-13", tipi: ["organic"] },
  { data: "2026-05-20", tipi: ["organic"] },
  { data: "2026-05-21", tipi: ["paper"] },
  { data: "2026-05-22", tipi: ["plastic_metals"] },
  { data: "2026-05-25", tipi: ["residual"] },
  { data: "2026-05-26", tipi: ["glass"] },
  { data: "2026-05-27", tipi: ["organic"] },
  { data: "2026-06-03", tipi: ["organic"] },
  { data: "2026-06-04", tipi: ["paper"] },
  { data: "2026-06-05", tipi: ["plastic_metals"] },
  { data: "2026-06-06", tipi: ["organic"] },
  { data: "2026-06-08", tipi: ["residual"] },
  { data: "2026-06-09", tipi: ["glass"] },
  { data: "2026-06-10", tipi: ["organic"] },
  { data: "2026-06-13", tipi: ["organic"] },
  { data: "2026-06-17", tipi: ["organic"] },
  { data: "2026-06-18", tipi: ["paper"] },
  { data: "2026-06-19", tipi: ["plastic_metals"] },
  { data: "2026-06-20", tipi: ["organic"] },
  { data: "2026-06-22", tipi: ["residual"] },
  { data: "2026-06-23", tipi: ["glass"] },
  { data: "2026-06-24", tipi: ["organic"] },
  { data: "2026-06-27", tipi: ["organic"] },
  { data: "2026-07-01", tipi: ["organic"] },
  { data: "2026-07-02", tipi: ["paper"] },
  { data: "2026-07-03", tipi: ["plastic_metals"] },
  { data: "2026-07-04", tipi: ["organic"] },
  { data: "2026-07-06", tipi: ["residual"] },
  { data: "2026-07-07", tipi: ["glass"] },
  { data: "2026-07-08", tipi: ["organic"] },
  { data: "2026-07-11", tipi: ["organic"] },
  { data: "2026-07-15", tipi: ["organic"] },
  { data: "2026-07-16", tipi: ["paper"] },
  { data: "2026-07-17", tipi: ["plastic_metals"] },
  { data: "2026-07-18", tipi: ["organic"] },
  { data: "2026-07-20", tipi: ["residual"] },
  { data: "2026-07-21", tipi: ["glass"] },
  { data: "2026-07-22", tipi: ["organic"] },
  { data: "2026-07-25", tipi: ["organic"] },
  { data: "2026-07-29", tipi: ["organic"] },
  { data: "2026-07-30", tipi: ["paper"] },
  { data: "2026-07-31", tipi: ["plastic_metals"] },
  { data: "2026-08-01", tipi: ["organic"] },
  { data: "2026-08-03", tipi: ["residual"] },
  { data: "2026-08-04", tipi: ["glass"] },
  { data: "2026-08-05", tipi: ["organic"] },
  { data: "2026-08-08", tipi: ["organic"] },
  { data: "2026-08-12", tipi: ["organic"] },
  { data: "2026-08-13", tipi: ["paper"] },
  { data: "2026-08-14", tipi: ["plastic_metals"] },
  { data: "2026-08-17", tipi: ["residual"] },
  { data: "2026-08-18", tipi: ["glass"] },
  { data: "2026-08-19", tipi: ["organic"] },
  { data: "2026-08-22", tipi: ["organic"] },
  { data: "2026-08-26", tipi: ["organic"] },
  { data: "2026-08-27", tipi: ["paper"] },
  { data: "2026-08-28", tipi: ["plastic_metals"] },
  { data: "2026-08-29", tipi: ["organic"] },
  { data: "2026-08-31", tipi: ["residual"] },
  { data: "2026-09-01", tipi: ["glass"] },
  { data: "2026-09-02", tipi: ["organic"] },
  { data: "2026-09-05", tipi: ["organic"] },
  { data: "2026-09-09", tipi: ["organic"] },
  { data: "2026-09-10", tipi: ["paper"] },
  { data: "2026-09-11", tipi: ["plastic_metals"] },
  { data: "2026-09-12", tipi: ["organic"] },
  { data: "2026-09-14", tipi: ["residual"] },
  { data: "2026-09-15", tipi: ["glass"] },
  { data: "2026-09-16", tipi: ["organic"] },
  { data: "2026-09-19", tipi: ["organic"] },
  { data: "2026-09-23", tipi: ["organic"] },
  { data: "2026-09-24", tipi: ["paper"] },
  { data: "2026-09-25", tipi: ["plastic_metals"] },
  { data: "2026-09-26", tipi: ["organic"] },
  { data: "2026-09-28", tipi: ["residual"] },
  { data: "2026-09-29", tipi: ["glass"] },
  { data: "2026-09-30", tipi: ["organic"] },
  { data: "2026-10-07", tipi: ["organic"] },
  { data: "2026-10-08", tipi: ["paper"] },
  { data: "2026-10-09", tipi: ["plastic_metals"] },
  { data: "2026-10-12", tipi: ["residual"] },
  { data: "2026-10-13", tipi: ["glass"] },
  { data: "2026-10-14", tipi: ["organic"] },
  { data: "2026-10-21", tipi: ["organic"] },
  { data: "2026-10-22", tipi: ["paper"] },
  { data: "2026-10-23", tipi: ["plastic_metals"] },
  { data: "2026-10-26", tipi: ["residual"] },
  { data: "2026-10-27", tipi: ["glass"] },
  { data: "2026-10-28", tipi: ["organic"] },
  { data: "2026-11-04", tipi: ["organic"] },
  { data: "2026-11-05", tipi: ["paper"] },
  { data: "2026-11-06", tipi: ["plastic_metals"] },
  { data: "2026-11-09", tipi: ["residual"] },
  { data: "2026-11-10", tipi: ["glass"] },
  { data: "2026-11-11", tipi: ["organic"] },
  { data: "2026-11-18", tipi: ["organic"] },
  { data: "2026-11-19", tipi: ["paper"] },
  { data: "2026-11-20", tipi: ["plastic_metals"] },
  { data: "2026-11-23", tipi: ["residual"] },
  { data: "2026-11-24", tipi: ["glass"] },
  { data: "2026-11-25", tipi: ["organic"] },
  { data: "2026-12-02", tipi: ["organic"] },
  { data: "2026-12-03", tipi: ["paper"] },
  { data: "2026-12-04", tipi: ["plastic_metals"] },
  { data: "2026-12-07", tipi: ["residual"] },
  { data: "2026-12-08", tipi: ["glass"] },
  { data: "2026-12-09", tipi: ["organic"] },
  { data: "2026-12-16", tipi: ["organic"] },
  { data: "2026-12-17", tipi: ["paper"] },
  { data: "2026-12-18", tipi: ["plastic_metals"] },
  { data: "2026-12-21", tipi: ["residual"] },
  { data: "2026-12-22", tipi: ["glass"] },
  { data: "2026-12-23", tipi: ["organic"] },
  { data: "2026-12-30", tipi: ["organic"] },
  { data: "2026-12-31", tipi: ["paper"] },
];

const RIFIUTI_GEA_BARCIS = [
  { data: "2026-01-02", tipi: ["plastic_metals"] },
  { data: "2026-01-03", tipi: ["paper"] },
  { data: "2026-01-05", tipi: ["residual"] },
  { data: "2026-01-06", tipi: ["glass"] },
  { data: "2026-01-07", tipi: ["organic"] },
  { data: "2026-01-14", tipi: ["organic"] },
  { data: "2026-01-15", tipi: ["paper"] },
  { data: "2026-01-16", tipi: ["plastic_metals"] },
  { data: "2026-01-19", tipi: ["residual"] },
  { data: "2026-01-20", tipi: ["glass"] },
  { data: "2026-01-21", tipi: ["organic"] },
  { data: "2026-01-28", tipi: ["organic"] },
  { data: "2026-01-29", tipi: ["paper"] },
  { data: "2026-01-30", tipi: ["plastic_metals"] },
  { data: "2026-02-02", tipi: ["residual"] },
  { data: "2026-02-03", tipi: ["glass"] },
  { data: "2026-02-04", tipi: ["organic"] },
  { data: "2026-02-11", tipi: ["organic"] },
  { data: "2026-02-12", tipi: ["paper"] },
  { data: "2026-02-13", tipi: ["plastic_metals"] },
  { data: "2026-02-16", tipi: ["residual"] },
  { data: "2026-02-17", tipi: ["glass"] },
  { data: "2026-02-18", tipi: ["organic"] },
  { data: "2026-02-25", tipi: ["organic"] },
  { data: "2026-02-26", tipi: ["paper"] },
  { data: "2026-02-27", tipi: ["plastic_metals"] },
  { data: "2026-03-02", tipi: ["residual"] },
  { data: "2026-03-03", tipi: ["glass"] },
  { data: "2026-03-04", tipi: ["organic"] },
  { data: "2026-03-11", tipi: ["organic"] },
  { data: "2026-03-12", tipi: ["paper"] },
  { data: "2026-03-13", tipi: ["plastic_metals"] },
  { data: "2026-03-16", tipi: ["residual"] },
  { data: "2026-03-17", tipi: ["glass"] },
  { data: "2026-03-18", tipi: ["organic"] },
  { data: "2026-03-25", tipi: ["organic"] },
  { data: "2026-03-26", tipi: ["paper"] },
  { data: "2026-03-27", tipi: ["plastic_metals"] },
  { data: "2026-03-30", tipi: ["residual"] },
  { data: "2026-03-31", tipi: ["glass"] },
  { data: "2026-04-01", tipi: ["organic"] },
  { data: "2026-04-08", tipi: ["organic"] },
  { data: "2026-04-09", tipi: ["paper"] },
  { data: "2026-04-10", tipi: ["plastic_metals"] },
  { data: "2026-04-13", tipi: ["residual"] },
  { data: "2026-04-14", tipi: ["glass"] },
  { data: "2026-04-15", tipi: ["organic"] },
  { data: "2026-04-22", tipi: ["organic"] },
  { data: "2026-04-23", tipi: ["paper"] },
  { data: "2026-04-24", tipi: ["plastic_metals"] },
  { data: "2026-04-27", tipi: ["residual"] },
  { data: "2026-04-28", tipi: ["glass"] },
  { data: "2026-04-29", tipi: ["organic"] },
  { data: "2026-05-06", tipi: ["organic"] },
  { data: "2026-05-07", tipi: ["paper"] },
  { data: "2026-05-08", tipi: ["plastic_metals"] },
  { data: "2026-05-11", tipi: ["residual"] },
  { data: "2026-05-12", tipi: ["glass"] },
  { data: "2026-05-13", tipi: ["organic"] },
  { data: "2026-05-20", tipi: ["organic"] },
  { data: "2026-05-21", tipi: ["paper"] },
  { data: "2026-05-22", tipi: ["plastic_metals"] },
  { data: "2026-05-25", tipi: ["residual"] },
  { data: "2026-05-26", tipi: ["glass"] },
  { data: "2026-05-27", tipi: ["organic"] },
  { data: "2026-06-03", tipi: ["organic"] },
  { data: "2026-06-04", tipi: ["paper"] },
  { data: "2026-06-05", tipi: ["plastic_metals"] },
  { data: "2026-06-06", tipi: ["organic"] },
  { data: "2026-06-08", tipi: ["residual"] },
  { data: "2026-06-09", tipi: ["glass"] },
  { data: "2026-06-10", tipi: ["organic"] },
  { data: "2026-06-13", tipi: ["organic"] },
  { data: "2026-06-17", tipi: ["organic"] },
  { data: "2026-06-18", tipi: ["paper"] },
  { data: "2026-06-19", tipi: ["plastic_metals"] },
  { data: "2026-06-20", tipi: ["organic"] },
  { data: "2026-06-22", tipi: ["residual"] },
  { data: "2026-06-23", tipi: ["glass"] },
  { data: "2026-06-24", tipi: ["organic"] },
  { data: "2026-06-27", tipi: ["organic"] },
  { data: "2026-07-01", tipi: ["organic"] },
  { data: "2026-07-02", tipi: ["paper"] },
  { data: "2026-07-03", tipi: ["plastic_metals"] },
  { data: "2026-07-04", tipi: ["organic"] },
  { data: "2026-07-06", tipi: ["residual"] },
  { data: "2026-07-07", tipi: ["glass"] },
  { data: "2026-07-08", tipi: ["organic"] },
  { data: "2026-07-11", tipi: ["organic"] },
  { data: "2026-07-15", tipi: ["organic"] },
  { data: "2026-07-16", tipi: ["paper"] },
  { data: "2026-07-17", tipi: ["plastic_metals"] },
  { data: "2026-07-18", tipi: ["organic"] },
  { data: "2026-07-20", tipi: ["residual"] },
  { data: "2026-07-21", tipi: ["glass"] },
  { data: "2026-07-22", tipi: ["organic"] },
  { data: "2026-07-25", tipi: ["organic"] },
  { data: "2026-07-29", tipi: ["organic"] },
  { data: "2026-07-30", tipi: ["paper"] },
  { data: "2026-07-31", tipi: ["plastic_metals"] },
  { data: "2026-08-01", tipi: ["organic"] },
  { data: "2026-08-03", tipi: ["residual"] },
  { data: "2026-08-04", tipi: ["glass"] },
  { data: "2026-08-05", tipi: ["organic"] },
  { data: "2026-08-08", tipi: ["organic"] },
  { data: "2026-08-12", tipi: ["organic"] },
  { data: "2026-08-13", tipi: ["paper"] },
  { data: "2026-08-14", tipi: ["plastic_metals"] },
  { data: "2026-08-17", tipi: ["residual"] },
  { data: "2026-08-18", tipi: ["glass"] },
  { data: "2026-08-19", tipi: ["organic"] },
  { data: "2026-08-22", tipi: ["organic"] },
  { data: "2026-08-26", tipi: ["organic"] },
  { data: "2026-08-27", tipi: ["paper"] },
  { data: "2026-08-28", tipi: ["plastic_metals"] },
  { data: "2026-08-29", tipi: ["organic"] },
  { data: "2026-08-31", tipi: ["residual"] },
  { data: "2026-09-01", tipi: ["glass"] },
  { data: "2026-09-02", tipi: ["organic"] },
  { data: "2026-09-05", tipi: ["organic"] },
  { data: "2026-09-09", tipi: ["organic"] },
  { data: "2026-09-10", tipi: ["paper"] },
  { data: "2026-09-11", tipi: ["plastic_metals"] },
  { data: "2026-09-12", tipi: ["organic"] },
  { data: "2026-09-14", tipi: ["residual"] },
  { data: "2026-09-15", tipi: ["glass"] },
  { data: "2026-09-16", tipi: ["organic"] },
  { data: "2026-09-19", tipi: ["organic"] },
  { data: "2026-09-23", tipi: ["organic"] },
  { data: "2026-09-24", tipi: ["paper"] },
  { data: "2026-09-25", tipi: ["plastic_metals"] },
  { data: "2026-09-26", tipi: ["organic"] },
  { data: "2026-09-28", tipi: ["residual"] },
  { data: "2026-09-29", tipi: ["glass"] },
  { data: "2026-09-30", tipi: ["organic"] },
  { data: "2026-10-07", tipi: ["organic"] },
  { data: "2026-10-08", tipi: ["paper"] },
  { data: "2026-10-09", tipi: ["plastic_metals"] },
  { data: "2026-10-12", tipi: ["residual"] },
  { data: "2026-10-13", tipi: ["glass"] },
  { data: "2026-10-14", tipi: ["organic"] },
  { data: "2026-10-21", tipi: ["organic"] },
  { data: "2026-10-22", tipi: ["paper"] },
  { data: "2026-10-23", tipi: ["plastic_metals"] },
  { data: "2026-10-26", tipi: ["residual"] },
  { data: "2026-10-27", tipi: ["glass"] },
  { data: "2026-10-28", tipi: ["organic"] },
  { data: "2026-11-04", tipi: ["organic"] },
  { data: "2026-11-05", tipi: ["paper"] },
  { data: "2026-11-06", tipi: ["plastic_metals"] },
  { data: "2026-11-09", tipi: ["residual"] },
  { data: "2026-11-10", tipi: ["glass"] },
  { data: "2026-11-11", tipi: ["organic"] },
  { data: "2026-11-18", tipi: ["organic"] },
  { data: "2026-11-19", tipi: ["paper"] },
  { data: "2026-11-20", tipi: ["plastic_metals"] },
  { data: "2026-11-23", tipi: ["residual"] },
  { data: "2026-11-24", tipi: ["glass"] },
  { data: "2026-11-25", tipi: ["organic"] },
  { data: "2026-12-02", tipi: ["organic"] },
  { data: "2026-12-03", tipi: ["paper"] },
  { data: "2026-12-04", tipi: ["plastic_metals"] },
  { data: "2026-12-07", tipi: ["residual"] },
  { data: "2026-12-08", tipi: ["glass"] },
  { data: "2026-12-09", tipi: ["organic"] },
  { data: "2026-12-16", tipi: ["organic"] },
  { data: "2026-12-17", tipi: ["paper"] },
  { data: "2026-12-18", tipi: ["plastic_metals"] },
  { data: "2026-12-21", tipi: ["residual"] },
  { data: "2026-12-22", tipi: ["glass"] },
  { data: "2026-12-23", tipi: ["organic"] },
  { data: "2026-12-30", tipi: ["organic"] },
  { data: "2026-12-31", tipi: ["paper"] },
];


// ---------------------------------------------------------------------
// GEA, seconda estensione comuni provincia di Pordenone (30/09/2026,
// stessa sessione dell'estensione a Budoia/Andreis/Barcis sopra) — Claut,
// Clauzetto, Erto e Casso, Fanna, Frisanco, Caneva, Cimolais. Stessa
// fonte/metodo: PDF annuali GEA caricati dall'utente, 24 pagine
// ciascuno, badge testuali (non solo icone) come per Budoia.
//
// **Metodo di trascrizione**: dato il volume (7 comuni × 12 mesi),
// delegata a sub-agent dedicati (uno per comune), ciascuno con la stessa
// mappatura badge/tipo, le stesse regole per zone/frazioni ed eccezioni
// festive già rodate su Budoia/Andreis/Barcis, e l'istruzione esplicita
// di controllare tutti e 12 i mesi per eventuali etichette di zona prima
// di concludere che un comune è a zona unica. **Verifica indipendente**:
// ho ri-controllato personalmente, rendendo alcune pagine PDF a 250dpi e
// confrontandole pixel per pixel con l'output dei sub-agent, un campione
// di mesi per più comuni — per Caneva (l'unico multi-zona di questo
// gruppo) ho trovato e corretto 4 errori di attribuzione zona che il
// sub-agent aveva assegnato in modo scorretto nonostante dichiarasse di
// aver verificato "pixel-perfect" (2 date di troppo/mancanti, 2 date
// attribuite alla zona sbagliata — dettagli nella nota della singola
// costante) — promemoria che una dichiarazione di rigore del sub-agent
// non sostituisce una verifica indipendente sui dati che contano di più
// (qui, l'unico comune a due zone). Per gli altri 6 comuni (zona unica)
// il campione controllato (Claut, Cimolais) ha corrisposto esattamente.
//
// **Claut, Clauzetto, Erto e Casso, Cimolais**: zona unica, stesso
// pattern base di Andreis/Barcis (secco+vetro e carta+plastica quindicinali
// sfasati di una settimana, umido settimanale), frequenza estiva
// dell'umido raddoppiata giugno-settembre (anche di sabato). Erto e
// Casso è risultato a zona unica nonostante le due frazioni storiche nel
// nome — verificato esplicitamente su tutti i 12 mesi, nessuna etichetta
// di località mai comparsa.
//
// **Fanna**: pattern diverso dagli altri — un solo giorno/settimana
// (mercoledì) che alterna fra "umido+secco+carta" e "umido+plastica+vetro",
// non i 4-5 giorni distinti degli altri comuni. Frisanco: umido
// raddoppiato (lunedì+giovedì anziché solo giovedì) in estate, non il
// sabato aggiuntivo visto altrove.
//
// **Caneva**: unico comune di questo gruppo a due zone (Zona A / Zona
// B, con mappa nel PDF — Zona A a sud dell'abitato, Zona B verso
// Sarone/Fiaschetti/Ronchis a nord-est), stesso pattern di due `aree`
// complete già usato per Budoia. A differenza di Budoia, qui TUTTI i
// tipi zona-esclusivi (secco, carta, plastica, vetro) alternano
// settimanalmente fra le due zone (non solo il secco) — solo l'umido è
// comune-wide (stesso giorno per entrambe le zone, con frequenza
// raddoppiata lunedì+giovedì in estate).
//
// **Eccezioni festive**: stesso trattamento "posticipato/anticipato" già
// usato per Budoia — raccolta registrata solo sulla data di recupero
// mostrata nel PDF. Il 15 agosto (Ferragosto) è risultato sistematicamente
// SENZA badge di recupero visibile in tutti e 7 questi comuni (a
// differenza di Capodanno/Pasquetta/Festa del Lavoro/Natale, sempre con
// recupero) — la raccolta dell'umido di quel giorno è stata omessa
// ovunque anziché inventata, con nota nel commento della singola costante.
//
// **Centro di raccolta**: nessuno di questi 7 comuni ha un ecocentro
// comunale dedicato già attivo. Claut e Fanna/Frisanco hanno comunque
// punti di conferimento reali con indirizzo/orari (rispettivamente:
// centro condiviso Val Settimana, piazzole comunali) riportati come
// `centro_raccolta`. Clauzetto non ha alcuna alternativa indicata
// (`centro_raccolta: null`, come Barcis). Erto e Casso e Caneva hanno
// punti fissi/ecocentro mobile con dettagli parziali, riportati per
// intero nel testo libero di `indirizzo`/`apertura` quando il PDF non
// fornisce una struttura più pulita (non tutti i comuni pubblicano gli
// orari per ogni punto).
// ---------------------------------------------------------------------

const RIFIUTI_GEA_CLAUT = [
  { data: "2026-01-02", tipi: ["plastic_metals"] },
  { data: "2026-01-03", tipi: ["paper"] },
  { data: "2026-01-05", tipi: ["residual"] },
  { data: "2026-01-06", tipi: ["glass"] },
  { data: "2026-01-07", tipi: ["organic"] },
  { data: "2026-01-14", tipi: ["organic"] },
  { data: "2026-01-15", tipi: ["paper"] },
  { data: "2026-01-16", tipi: ["plastic_metals"] },
  { data: "2026-01-19", tipi: ["residual"] },
  { data: "2026-01-20", tipi: ["glass"] },
  { data: "2026-01-21", tipi: ["organic"] },
  { data: "2026-01-28", tipi: ["organic"] },
  { data: "2026-01-29", tipi: ["paper"] },
  { data: "2026-01-30", tipi: ["plastic_metals"] },
  { data: "2026-02-02", tipi: ["residual"] },
  { data: "2026-02-03", tipi: ["glass"] },
  { data: "2026-02-04", tipi: ["organic"] },
  { data: "2026-02-11", tipi: ["organic"] },
  { data: "2026-02-12", tipi: ["paper"] },
  { data: "2026-02-13", tipi: ["plastic_metals"] },
  { data: "2026-02-16", tipi: ["residual"] },
  { data: "2026-02-17", tipi: ["glass"] },
  { data: "2026-02-18", tipi: ["organic"] },
  { data: "2026-02-25", tipi: ["organic"] },
  { data: "2026-02-26", tipi: ["paper"] },
  { data: "2026-02-27", tipi: ["plastic_metals"] },
  { data: "2026-03-02", tipi: ["residual"] },
  { data: "2026-03-03", tipi: ["glass"] },
  { data: "2026-03-04", tipi: ["organic"] },
  { data: "2026-03-11", tipi: ["organic"] },
  { data: "2026-03-12", tipi: ["paper"] },
  { data: "2026-03-13", tipi: ["plastic_metals"] },
  { data: "2026-03-16", tipi: ["residual"] },
  { data: "2026-03-17", tipi: ["glass"] },
  { data: "2026-03-18", tipi: ["organic"] },
  { data: "2026-03-25", tipi: ["organic"] },
  { data: "2026-03-26", tipi: ["paper"] },
  { data: "2026-03-27", tipi: ["plastic_metals"] },
  { data: "2026-03-30", tipi: ["residual"] },
  { data: "2026-03-31", tipi: ["glass"] },
  { data: "2026-04-01", tipi: ["organic"] },
  { data: "2026-04-08", tipi: ["organic"] },
  { data: "2026-04-09", tipi: ["paper"] },
  { data: "2026-04-10", tipi: ["plastic_metals"] },
  { data: "2026-04-13", tipi: ["residual"] },
  { data: "2026-04-14", tipi: ["glass"] },
  { data: "2026-04-15", tipi: ["organic"] },
  { data: "2026-04-22", tipi: ["organic"] },
  { data: "2026-04-23", tipi: ["paper"] },
  { data: "2026-04-24", tipi: ["plastic_metals"] },
  { data: "2026-04-27", tipi: ["residual"] },
  { data: "2026-04-28", tipi: ["glass"] },
  { data: "2026-04-29", tipi: ["organic"] },
  { data: "2026-05-06", tipi: ["organic"] },
  { data: "2026-05-07", tipi: ["paper"] },
  { data: "2026-05-08", tipi: ["plastic_metals"] },
  { data: "2026-05-11", tipi: ["residual"] },
  { data: "2026-05-12", tipi: ["glass"] },
  { data: "2026-05-13", tipi: ["organic"] },
  { data: "2026-05-20", tipi: ["organic"] },
  { data: "2026-05-21", tipi: ["paper"] },
  { data: "2026-05-22", tipi: ["plastic_metals"] },
  { data: "2026-05-25", tipi: ["residual"] },
  { data: "2026-05-26", tipi: ["glass"] },
  { data: "2026-05-27", tipi: ["organic"] },
  { data: "2026-06-03", tipi: ["organic"] },
  { data: "2026-06-04", tipi: ["paper"] },
  { data: "2026-06-05", tipi: ["plastic_metals"] },
  { data: "2026-06-06", tipi: ["organic"] },
  { data: "2026-06-08", tipi: ["residual"] },
  { data: "2026-06-09", tipi: ["glass"] },
  { data: "2026-06-10", tipi: ["organic"] },
  { data: "2026-06-13", tipi: ["organic"] },
  { data: "2026-06-17", tipi: ["organic"] },
  { data: "2026-06-18", tipi: ["paper"] },
  { data: "2026-06-19", tipi: ["plastic_metals"] },
  { data: "2026-06-20", tipi: ["organic"] },
  { data: "2026-06-22", tipi: ["residual"] },
  { data: "2026-06-23", tipi: ["glass"] },
  { data: "2026-06-24", tipi: ["organic"] },
  { data: "2026-06-27", tipi: ["organic"] },
  { data: "2026-07-01", tipi: ["organic"] },
  { data: "2026-07-02", tipi: ["paper"] },
  { data: "2026-07-03", tipi: ["plastic_metals"] },
  { data: "2026-07-04", tipi: ["organic"] },
  { data: "2026-07-06", tipi: ["residual"] },
  { data: "2026-07-07", tipi: ["glass"] },
  { data: "2026-07-08", tipi: ["organic"] },
  { data: "2026-07-11", tipi: ["organic"] },
  { data: "2026-07-15", tipi: ["organic"] },
  { data: "2026-07-16", tipi: ["paper"] },
  { data: "2026-07-17", tipi: ["plastic_metals"] },
  { data: "2026-07-18", tipi: ["organic"] },
  { data: "2026-07-20", tipi: ["residual"] },
  { data: "2026-07-21", tipi: ["glass"] },
  { data: "2026-07-22", tipi: ["organic"] },
  { data: "2026-07-25", tipi: ["organic"] },
  { data: "2026-07-29", tipi: ["organic"] },
  { data: "2026-07-30", tipi: ["paper"] },
  { data: "2026-07-31", tipi: ["plastic_metals"] },
  { data: "2026-08-01", tipi: ["organic"] },
  { data: "2026-08-03", tipi: ["residual"] },
  { data: "2026-08-04", tipi: ["glass"] },
  { data: "2026-08-05", tipi: ["organic"] },
  { data: "2026-08-08", tipi: ["organic"] },
  { data: "2026-08-12", tipi: ["organic"] },
  { data: "2026-08-13", tipi: ["paper"] },
  { data: "2026-08-14", tipi: ["plastic_metals"] },
  { data: "2026-08-17", tipi: ["residual"] },
  { data: "2026-08-18", tipi: ["glass"] },
  { data: "2026-08-19", tipi: ["organic"] },
  { data: "2026-08-22", tipi: ["organic"] },
  { data: "2026-08-26", tipi: ["organic"] },
  { data: "2026-08-27", tipi: ["paper"] },
  { data: "2026-08-28", tipi: ["plastic_metals"] },
  { data: "2026-08-29", tipi: ["organic"] },
  { data: "2026-08-31", tipi: ["residual"] },
  { data: "2026-09-01", tipi: ["glass"] },
  { data: "2026-09-02", tipi: ["organic"] },
  { data: "2026-09-05", tipi: ["organic"] },
  { data: "2026-09-09", tipi: ["organic"] },
  { data: "2026-09-10", tipi: ["paper"] },
  { data: "2026-09-11", tipi: ["plastic_metals"] },
  { data: "2026-09-12", tipi: ["organic"] },
  { data: "2026-09-14", tipi: ["residual"] },
  { data: "2026-09-15", tipi: ["glass"] },
  { data: "2026-09-16", tipi: ["organic"] },
  { data: "2026-09-19", tipi: ["organic"] },
  { data: "2026-09-23", tipi: ["organic"] },
  { data: "2026-09-24", tipi: ["paper"] },
  { data: "2026-09-25", tipi: ["plastic_metals"] },
  { data: "2026-09-26", tipi: ["organic"] },
  { data: "2026-09-28", tipi: ["residual"] },
  { data: "2026-09-29", tipi: ["glass"] },
  { data: "2026-09-30", tipi: ["organic"] },
  { data: "2026-10-07", tipi: ["organic"] },
  { data: "2026-10-08", tipi: ["paper"] },
  { data: "2026-10-09", tipi: ["plastic_metals"] },
  { data: "2026-10-12", tipi: ["residual"] },
  { data: "2026-10-13", tipi: ["glass"] },
  { data: "2026-10-14", tipi: ["organic"] },
  { data: "2026-10-21", tipi: ["organic"] },
  { data: "2026-10-22", tipi: ["paper"] },
  { data: "2026-10-23", tipi: ["plastic_metals"] },
  { data: "2026-10-26", tipi: ["residual"] },
  { data: "2026-10-27", tipi: ["glass"] },
  { data: "2026-10-28", tipi: ["organic"] },
  { data: "2026-11-04", tipi: ["organic"] },
  { data: "2026-11-05", tipi: ["paper"] },
  { data: "2026-11-06", tipi: ["plastic_metals"] },
  { data: "2026-11-09", tipi: ["residual"] },
  { data: "2026-11-10", tipi: ["glass"] },
  { data: "2026-11-11", tipi: ["organic"] },
  { data: "2026-11-18", tipi: ["organic"] },
  { data: "2026-11-19", tipi: ["paper"] },
  { data: "2026-11-20", tipi: ["plastic_metals"] },
  { data: "2026-11-23", tipi: ["residual"] },
  { data: "2026-11-24", tipi: ["glass"] },
  { data: "2026-11-25", tipi: ["organic"] },
  { data: "2026-12-02", tipi: ["organic"] },
  { data: "2026-12-03", tipi: ["paper"] },
  { data: "2026-12-04", tipi: ["plastic_metals"] },
  { data: "2026-12-07", tipi: ["residual"] },
  { data: "2026-12-08", tipi: ["glass"] },
  { data: "2026-12-09", tipi: ["organic"] },
  { data: "2026-12-16", tipi: ["organic"] },
  { data: "2026-12-17", tipi: ["paper"] },
  { data: "2026-12-18", tipi: ["plastic_metals"] },
  { data: "2026-12-21", tipi: ["residual"] },
  { data: "2026-12-22", tipi: ["glass"] },
  { data: "2026-12-23", tipi: ["organic"] },
  { data: "2026-12-30", tipi: ["organic"] },
  { data: "2026-12-31", tipi: ["paper"] },
];

const RIFIUTI_GEA_CLAUZETTO = [
  { data: "2026-01-02", tipi: ["plastic_metals"] },
  { data: "2026-01-05", tipi: ["residual"] },
  { data: "2026-01-07", tipi: ["organic", "glass"] },
  { data: "2026-01-09", tipi: ["paper"] },
  { data: "2026-01-14", tipi: ["organic"] },
  { data: "2026-01-16", tipi: ["plastic_metals"] },
  { data: "2026-01-19", tipi: ["residual"] },
  { data: "2026-01-21", tipi: ["organic", "glass"] },
  { data: "2026-01-23", tipi: ["paper"] },
  { data: "2026-01-28", tipi: ["organic"] },
  { data: "2026-01-30", tipi: ["plastic_metals"] },
  { data: "2026-02-02", tipi: ["residual"] },
  { data: "2026-02-04", tipi: ["organic", "glass"] },
  { data: "2026-02-06", tipi: ["paper"] },
  { data: "2026-02-11", tipi: ["organic"] },
  { data: "2026-02-13", tipi: ["plastic_metals"] },
  { data: "2026-02-16", tipi: ["residual"] },
  { data: "2026-02-18", tipi: ["organic", "glass"] },
  { data: "2026-02-20", tipi: ["paper"] },
  { data: "2026-02-25", tipi: ["organic"] },
  { data: "2026-02-27", tipi: ["plastic_metals"] },
  { data: "2026-03-02", tipi: ["residual"] },
  { data: "2026-03-04", tipi: ["organic", "glass"] },
  { data: "2026-03-06", tipi: ["paper"] },
  { data: "2026-03-11", tipi: ["organic"] },
  { data: "2026-03-13", tipi: ["plastic_metals"] },
  { data: "2026-03-16", tipi: ["residual"] },
  { data: "2026-03-18", tipi: ["organic", "glass"] },
  { data: "2026-03-20", tipi: ["paper"] },
  { data: "2026-03-25", tipi: ["organic"] },
  { data: "2026-03-27", tipi: ["plastic_metals"] },
  { data: "2026-03-30", tipi: ["residual"] },
  { data: "2026-04-01", tipi: ["organic", "glass"] },
  { data: "2026-04-03", tipi: ["paper"] },
  { data: "2026-04-08", tipi: ["organic"] },
  { data: "2026-04-10", tipi: ["plastic_metals"] },
  { data: "2026-04-13", tipi: ["residual"] },
  { data: "2026-04-15", tipi: ["organic", "glass"] },
  { data: "2026-04-17", tipi: ["paper"] },
  { data: "2026-04-22", tipi: ["organic"] },
  { data: "2026-04-24", tipi: ["plastic_metals"] },
  { data: "2026-04-27", tipi: ["residual"] },
  { data: "2026-04-29", tipi: ["organic", "glass"] },
  { data: "2026-05-02", tipi: ["paper"] },
  { data: "2026-05-06", tipi: ["organic"] },
  { data: "2026-05-08", tipi: ["plastic_metals"] },
  { data: "2026-05-11", tipi: ["residual"] },
  { data: "2026-05-13", tipi: ["organic", "glass"] },
  { data: "2026-05-15", tipi: ["paper"] },
  { data: "2026-05-20", tipi: ["organic"] },
  { data: "2026-05-22", tipi: ["plastic_metals"] },
  { data: "2026-05-25", tipi: ["residual"] },
  { data: "2026-05-27", tipi: ["organic", "glass"] },
  { data: "2026-05-29", tipi: ["paper"] },
  { data: "2026-06-03", tipi: ["organic"] },
  { data: "2026-06-05", tipi: ["plastic_metals"] },
  { data: "2026-06-06", tipi: ["organic"] },
  { data: "2026-06-08", tipi: ["residual"] },
  { data: "2026-06-10", tipi: ["organic", "glass"] },
  { data: "2026-06-12", tipi: ["paper"] },
  { data: "2026-06-13", tipi: ["organic"] },
  { data: "2026-06-17", tipi: ["organic"] },
  { data: "2026-06-19", tipi: ["plastic_metals"] },
  { data: "2026-06-20", tipi: ["organic"] },
  { data: "2026-06-22", tipi: ["residual"] },
  { data: "2026-06-24", tipi: ["organic", "glass"] },
  { data: "2026-06-26", tipi: ["paper"] },
  { data: "2026-06-27", tipi: ["organic"] },
  { data: "2026-07-01", tipi: ["organic"] },
  { data: "2026-07-03", tipi: ["plastic_metals"] },
  { data: "2026-07-04", tipi: ["organic"] },
  { data: "2026-07-06", tipi: ["residual"] },
  { data: "2026-07-08", tipi: ["organic", "glass"] },
  { data: "2026-07-10", tipi: ["paper"] },
  { data: "2026-07-11", tipi: ["organic"] },
  { data: "2026-07-15", tipi: ["organic"] },
  { data: "2026-07-17", tipi: ["plastic_metals"] },
  { data: "2026-07-18", tipi: ["organic"] },
  { data: "2026-07-20", tipi: ["residual"] },
  { data: "2026-07-22", tipi: ["organic", "glass"] },
  { data: "2026-07-24", tipi: ["paper"] },
  { data: "2026-07-25", tipi: ["organic"] },
  { data: "2026-07-29", tipi: ["organic"] },
  { data: "2026-07-31", tipi: ["plastic_metals"] },
  { data: "2026-08-01", tipi: ["organic"] },
  { data: "2026-08-03", tipi: ["residual"] },
  { data: "2026-08-05", tipi: ["organic", "glass"] },
  { data: "2026-08-07", tipi: ["paper"] },
  { data: "2026-08-08", tipi: ["organic"] },
  { data: "2026-08-12", tipi: ["organic"] },
  { data: "2026-08-14", tipi: ["plastic_metals"] },
  { data: "2026-08-17", tipi: ["residual"] },
  { data: "2026-08-19", tipi: ["organic", "glass"] },
  { data: "2026-08-21", tipi: ["paper"] },
  { data: "2026-08-22", tipi: ["organic"] },
  { data: "2026-08-26", tipi: ["organic"] },
  { data: "2026-08-28", tipi: ["plastic_metals"] },
  { data: "2026-08-29", tipi: ["organic"] },
  { data: "2026-08-31", tipi: ["residual"] },
  { data: "2026-09-02", tipi: ["organic", "glass"] },
  { data: "2026-09-04", tipi: ["paper"] },
  { data: "2026-09-05", tipi: ["organic"] },
  { data: "2026-09-09", tipi: ["organic"] },
  { data: "2026-09-11", tipi: ["plastic_metals"] },
  { data: "2026-09-12", tipi: ["organic"] },
  { data: "2026-09-14", tipi: ["residual"] },
  { data: "2026-09-16", tipi: ["organic", "glass"] },
  { data: "2026-09-18", tipi: ["paper"] },
  { data: "2026-09-19", tipi: ["organic"] },
  { data: "2026-09-23", tipi: ["organic"] },
  { data: "2026-09-25", tipi: ["plastic_metals"] },
  { data: "2026-09-26", tipi: ["organic"] },
  { data: "2026-09-28", tipi: ["residual"] },
  { data: "2026-09-30", tipi: ["organic", "glass"] },
  { data: "2026-10-02", tipi: ["paper"] },
  { data: "2026-10-07", tipi: ["organic", "glass"] },
  { data: "2026-10-09", tipi: ["plastic_metals"] },
  { data: "2026-10-12", tipi: ["residual"] },
  { data: "2026-10-14", tipi: ["organic", "glass"] },
  { data: "2026-10-16", tipi: ["paper"] },
  { data: "2026-10-21", tipi: ["organic"] },
  { data: "2026-10-23", tipi: ["plastic_metals"] },
  { data: "2026-10-26", tipi: ["residual"] },
  { data: "2026-10-28", tipi: ["organic", "glass"] },
  { data: "2026-10-30", tipi: ["paper"] },
  { data: "2026-11-04", tipi: ["organic"] },
  { data: "2026-11-06", tipi: ["plastic_metals"] },
  { data: "2026-11-09", tipi: ["residual"] },
  { data: "2026-11-11", tipi: ["organic", "glass"] },
  { data: "2026-11-13", tipi: ["paper"] },
  { data: "2026-11-18", tipi: ["organic"] },
  { data: "2026-11-20", tipi: ["plastic_metals"] },
  { data: "2026-11-23", tipi: ["residual"] },
  { data: "2026-11-25", tipi: ["organic", "glass"] },
  { data: "2026-11-27", tipi: ["paper"] },
  { data: "2026-12-02", tipi: ["organic"] },
  { data: "2026-12-04", tipi: ["plastic_metals"] },
  { data: "2026-12-07", tipi: ["residual"] },
  { data: "2026-12-09", tipi: ["organic", "glass"] },
  { data: "2026-12-11", tipi: ["paper"] },
  { data: "2026-12-16", tipi: ["organic"] },
  { data: "2026-12-18", tipi: ["plastic_metals"] },
  { data: "2026-12-21", tipi: ["residual"] },
  { data: "2026-12-23", tipi: ["organic", "glass"] },
  { data: "2026-12-26", tipi: ["paper"] },
  { data: "2026-12-30", tipi: ["organic"] },
];

const RIFIUTI_GEA_ERTO_E_CASSO = [
  { data: "2026-01-02", tipi: ["plastic_metals"] },
  { data: "2026-01-03", tipi: ["paper"] },
  { data: "2026-01-05", tipi: ["residual"] },
  { data: "2026-01-06", tipi: ["glass"] },
  { data: "2026-01-07", tipi: ["organic"] },
  { data: "2026-01-14", tipi: ["organic"] },
  { data: "2026-01-15", tipi: ["paper"] },
  { data: "2026-01-16", tipi: ["plastic_metals"] },
  { data: "2026-01-19", tipi: ["residual"] },
  { data: "2026-01-20", tipi: ["glass"] },
  { data: "2026-01-21", tipi: ["organic"] },
  { data: "2026-01-28", tipi: ["organic"] },
  { data: "2026-01-29", tipi: ["paper"] },
  { data: "2026-01-30", tipi: ["plastic_metals"] },
  { data: "2026-02-02", tipi: ["residual"] },
  { data: "2026-02-03", tipi: ["glass"] },
  { data: "2026-02-04", tipi: ["organic"] },
  { data: "2026-02-11", tipi: ["organic"] },
  { data: "2026-02-12", tipi: ["paper"] },
  { data: "2026-02-13", tipi: ["plastic_metals"] },
  { data: "2026-02-16", tipi: ["residual"] },
  { data: "2026-02-17", tipi: ["glass"] },
  { data: "2026-02-18", tipi: ["organic"] },
  { data: "2026-02-25", tipi: ["organic"] },
  { data: "2026-02-26", tipi: ["paper"] },
  { data: "2026-02-27", tipi: ["plastic_metals"] },
  { data: "2026-03-02", tipi: ["residual"] },
  { data: "2026-03-03", tipi: ["glass"] },
  { data: "2026-03-04", tipi: ["organic"] },
  { data: "2026-03-11", tipi: ["organic"] },
  { data: "2026-03-12", tipi: ["paper"] },
  { data: "2026-03-13", tipi: ["plastic_metals"] },
  { data: "2026-03-16", tipi: ["residual"] },
  { data: "2026-03-17", tipi: ["glass"] },
  { data: "2026-03-18", tipi: ["organic"] },
  { data: "2026-03-25", tipi: ["organic"] },
  { data: "2026-03-26", tipi: ["paper"] },
  { data: "2026-03-27", tipi: ["plastic_metals"] },
  { data: "2026-03-30", tipi: ["residual"] },
  { data: "2026-03-31", tipi: ["glass"] },
  { data: "2026-04-01", tipi: ["organic"] },
  { data: "2026-04-08", tipi: ["organic"] },
  { data: "2026-04-09", tipi: ["paper"] },
  { data: "2026-04-10", tipi: ["plastic_metals"] },
  { data: "2026-04-13", tipi: ["residual"] },
  { data: "2026-04-14", tipi: ["glass"] },
  { data: "2026-04-15", tipi: ["organic"] },
  { data: "2026-04-22", tipi: ["organic"] },
  { data: "2026-04-23", tipi: ["paper"] },
  { data: "2026-04-24", tipi: ["plastic_metals"] },
  { data: "2026-04-27", tipi: ["residual"] },
  { data: "2026-04-28", tipi: ["glass"] },
  { data: "2026-04-29", tipi: ["organic"] },
  { data: "2026-05-06", tipi: ["organic"] },
  { data: "2026-05-07", tipi: ["paper"] },
  { data: "2026-05-08", tipi: ["plastic_metals"] },
  { data: "2026-05-11", tipi: ["residual"] },
  { data: "2026-05-12", tipi: ["glass"] },
  { data: "2026-05-13", tipi: ["organic"] },
  { data: "2026-05-20", tipi: ["organic"] },
  { data: "2026-05-21", tipi: ["paper"] },
  { data: "2026-05-22", tipi: ["plastic_metals"] },
  { data: "2026-05-25", tipi: ["residual"] },
  { data: "2026-05-26", tipi: ["glass"] },
  { data: "2026-05-27", tipi: ["organic"] },
  { data: "2026-06-03", tipi: ["organic"] },
  { data: "2026-06-04", tipi: ["paper"] },
  { data: "2026-06-05", tipi: ["plastic_metals"] },
  { data: "2026-06-06", tipi: ["organic"] },
  { data: "2026-06-08", tipi: ["residual"] },
  { data: "2026-06-09", tipi: ["glass"] },
  { data: "2026-06-10", tipi: ["organic"] },
  { data: "2026-06-13", tipi: ["organic"] },
  { data: "2026-06-17", tipi: ["organic"] },
  { data: "2026-06-18", tipi: ["paper"] },
  { data: "2026-06-19", tipi: ["plastic_metals"] },
  { data: "2026-06-20", tipi: ["organic"] },
  { data: "2026-06-22", tipi: ["residual"] },
  { data: "2026-06-23", tipi: ["glass"] },
  { data: "2026-06-24", tipi: ["organic"] },
  { data: "2026-06-27", tipi: ["organic"] },
  { data: "2026-07-01", tipi: ["organic"] },
  { data: "2026-07-02", tipi: ["paper"] },
  { data: "2026-07-03", tipi: ["plastic_metals"] },
  { data: "2026-07-04", tipi: ["organic"] },
  { data: "2026-07-06", tipi: ["residual"] },
  { data: "2026-07-07", tipi: ["glass"] },
  { data: "2026-07-08", tipi: ["organic"] },
  { data: "2026-07-11", tipi: ["organic"] },
  { data: "2026-07-15", tipi: ["organic"] },
  { data: "2026-07-16", tipi: ["paper"] },
  { data: "2026-07-17", tipi: ["plastic_metals"] },
  { data: "2026-07-18", tipi: ["organic"] },
  { data: "2026-07-20", tipi: ["residual"] },
  { data: "2026-07-21", tipi: ["glass"] },
  { data: "2026-07-22", tipi: ["organic"] },
  { data: "2026-07-25", tipi: ["organic"] },
  { data: "2026-07-29", tipi: ["organic"] },
  { data: "2026-07-30", tipi: ["paper"] },
  { data: "2026-07-31", tipi: ["plastic_metals"] },
  { data: "2026-08-01", tipi: ["organic"] },
  { data: "2026-08-03", tipi: ["residual"] },
  { data: "2026-08-04", tipi: ["glass"] },
  { data: "2026-08-05", tipi: ["organic"] },
  { data: "2026-08-08", tipi: ["organic"] },
  { data: "2026-08-12", tipi: ["organic"] },
  { data: "2026-08-13", tipi: ["paper"] },
  { data: "2026-08-14", tipi: ["plastic_metals"] },
  { data: "2026-08-17", tipi: ["residual"] },
  { data: "2026-08-18", tipi: ["glass"] },
  { data: "2026-08-19", tipi: ["organic"] },
  { data: "2026-08-22", tipi: ["organic"] },
  { data: "2026-08-26", tipi: ["organic"] },
  { data: "2026-08-27", tipi: ["paper"] },
  { data: "2026-08-28", tipi: ["plastic_metals"] },
  { data: "2026-08-29", tipi: ["organic"] },
  { data: "2026-08-31", tipi: ["residual"] },
  { data: "2026-09-01", tipi: ["glass"] },
  { data: "2026-09-02", tipi: ["organic"] },
  { data: "2026-09-05", tipi: ["organic"] },
  { data: "2026-09-09", tipi: ["organic"] },
  { data: "2026-09-10", tipi: ["paper"] },
  { data: "2026-09-11", tipi: ["plastic_metals"] },
  { data: "2026-09-12", tipi: ["organic"] },
  { data: "2026-09-14", tipi: ["residual"] },
  { data: "2026-09-15", tipi: ["glass"] },
  { data: "2026-09-16", tipi: ["organic"] },
  { data: "2026-09-19", tipi: ["organic"] },
  { data: "2026-09-23", tipi: ["organic"] },
  { data: "2026-09-24", tipi: ["paper"] },
  { data: "2026-09-25", tipi: ["plastic_metals"] },
  { data: "2026-09-26", tipi: ["organic"] },
  { data: "2026-09-28", tipi: ["residual"] },
  { data: "2026-09-29", tipi: ["glass"] },
  { data: "2026-09-30", tipi: ["organic"] },
  { data: "2026-10-07", tipi: ["organic"] },
  { data: "2026-10-08", tipi: ["paper"] },
  { data: "2026-10-09", tipi: ["plastic_metals"] },
  { data: "2026-10-12", tipi: ["residual"] },
  { data: "2026-10-13", tipi: ["glass"] },
  { data: "2026-10-14", tipi: ["organic"] },
  { data: "2026-10-21", tipi: ["organic"] },
  { data: "2026-10-22", tipi: ["paper"] },
  { data: "2026-10-23", tipi: ["plastic_metals"] },
  { data: "2026-10-26", tipi: ["residual"] },
  { data: "2026-10-27", tipi: ["glass"] },
  { data: "2026-10-28", tipi: ["organic"] },
  { data: "2026-11-04", tipi: ["organic"] },
  { data: "2026-11-05", tipi: ["paper"] },
  { data: "2026-11-06", tipi: ["plastic_metals"] },
  { data: "2026-11-09", tipi: ["residual"] },
  { data: "2026-11-10", tipi: ["glass"] },
  { data: "2026-11-11", tipi: ["organic"] },
  { data: "2026-11-18", tipi: ["organic"] },
  { data: "2026-11-19", tipi: ["paper"] },
  { data: "2026-11-20", tipi: ["plastic_metals"] },
  { data: "2026-11-23", tipi: ["residual"] },
  { data: "2026-11-24", tipi: ["glass"] },
  { data: "2026-11-25", tipi: ["organic"] },
  { data: "2026-12-02", tipi: ["organic"] },
  { data: "2026-12-03", tipi: ["paper"] },
  { data: "2026-12-04", tipi: ["plastic_metals"] },
  { data: "2026-12-07", tipi: ["residual"] },
  { data: "2026-12-08", tipi: ["glass"] },
  { data: "2026-12-09", tipi: ["organic"] },
  { data: "2026-12-16", tipi: ["organic"] },
  { data: "2026-12-17", tipi: ["paper"] },
  { data: "2026-12-18", tipi: ["plastic_metals"] },
  { data: "2026-12-21", tipi: ["residual"] },
  { data: "2026-12-22", tipi: ["glass"] },
  { data: "2026-12-23", tipi: ["organic"] },
  { data: "2026-12-30", tipi: ["organic"] },
  { data: "2026-12-31", tipi: ["paper"] },
];

const RIFIUTI_GEA_FANNA = [
  { data: "2026-01-07", tipi: ["organic", "residual", "paper"] },
  { data: "2026-01-14", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-01-21", tipi: ["organic", "residual", "paper"] },
  { data: "2026-01-28", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-02-04", tipi: ["organic", "residual", "paper"] },
  { data: "2026-02-11", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-02-18", tipi: ["organic", "residual", "paper"] },
  { data: "2026-02-25", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-03-04", tipi: ["organic", "residual", "paper"] },
  { data: "2026-03-11", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-03-18", tipi: ["organic", "residual", "paper"] },
  { data: "2026-03-25", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-04-01", tipi: ["organic", "residual", "paper"] },
  { data: "2026-04-08", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-04-15", tipi: ["organic", "residual", "paper"] },
  { data: "2026-04-22", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-04-29", tipi: ["organic", "residual", "paper"] },
  { data: "2026-05-06", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-05-13", tipi: ["organic", "residual", "paper"] },
  { data: "2026-05-20", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-05-27", tipi: ["organic", "residual", "paper"] },
  { data: "2026-06-03", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-06-06", tipi: ["organic"] },
  { data: "2026-06-10", tipi: ["organic", "residual", "paper"] },
  { data: "2026-06-13", tipi: ["organic"] },
  { data: "2026-06-17", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-06-20", tipi: ["organic"] },
  { data: "2026-06-24", tipi: ["organic", "residual", "paper"] },
  { data: "2026-06-27", tipi: ["organic"] },
  { data: "2026-07-01", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-07-04", tipi: ["organic"] },
  { data: "2026-07-08", tipi: ["organic", "residual", "paper"] },
  { data: "2026-07-11", tipi: ["organic"] },
  { data: "2026-07-15", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-07-18", tipi: ["organic"] },
  { data: "2026-07-22", tipi: ["organic", "residual", "paper"] },
  { data: "2026-07-25", tipi: ["organic"] },
  { data: "2026-07-29", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-08-01", tipi: ["organic"] },
  { data: "2026-08-05", tipi: ["organic", "residual", "paper"] },
  { data: "2026-08-08", tipi: ["organic"] },
  { data: "2026-08-12", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-08-19", tipi: ["organic", "residual", "paper"] },
  { data: "2026-08-22", tipi: ["organic"] },
  { data: "2026-08-26", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-08-29", tipi: ["organic"] },
  { data: "2026-09-02", tipi: ["organic", "residual", "paper"] },
  { data: "2026-09-05", tipi: ["organic"] },
  { data: "2026-09-09", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-09-12", tipi: ["organic"] },
  { data: "2026-09-16", tipi: ["organic", "residual", "paper"] },
  { data: "2026-09-19", tipi: ["organic"] },
  { data: "2026-09-23", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-09-26", tipi: ["organic"] },
  { data: "2026-09-30", tipi: ["organic", "residual", "paper"] },
  { data: "2026-10-07", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-10-14", tipi: ["organic", "residual", "paper"] },
  { data: "2026-10-21", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-10-28", tipi: ["organic", "residual", "paper"] },
  { data: "2026-11-04", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-11-11", tipi: ["organic", "residual", "paper"] },
  { data: "2026-11-18", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-11-25", tipi: ["organic", "residual", "paper"] },
  { data: "2026-12-02", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-12-09", tipi: ["organic", "residual", "paper"] },
  { data: "2026-12-16", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-12-23", tipi: ["organic", "residual", "paper"] },
  { data: "2026-12-30", tipi: ["organic", "plastic_metals", "glass"] },
];

const RIFIUTI_GEA_FRISANCO = [
  { data: "2026-01-03", tipi: ["organic"] },
  { data: "2026-01-08", tipi: ["organic", "residual", "paper"] },
  { data: "2026-01-12", tipi: ["plastic_metals", "glass"] },
  { data: "2026-01-15", tipi: ["organic"] },
  { data: "2026-01-22", tipi: ["organic", "residual", "paper"] },
  { data: "2026-01-26", tipi: ["plastic_metals", "glass"] },
  { data: "2026-01-29", tipi: ["organic"] },
  { data: "2026-02-05", tipi: ["organic", "residual", "paper"] },
  { data: "2026-02-09", tipi: ["plastic_metals", "glass"] },
  { data: "2026-02-12", tipi: ["organic"] },
  { data: "2026-02-19", tipi: ["organic", "residual", "paper"] },
  { data: "2026-02-23", tipi: ["plastic_metals", "glass"] },
  { data: "2026-02-26", tipi: ["organic"] },
  { data: "2026-03-05", tipi: ["organic", "residual", "paper"] },
  { data: "2026-03-09", tipi: ["plastic_metals", "glass"] },
  { data: "2026-03-12", tipi: ["organic"] },
  { data: "2026-03-19", tipi: ["organic", "residual", "paper"] },
  { data: "2026-03-23", tipi: ["plastic_metals", "glass"] },
  { data: "2026-03-26", tipi: ["organic"] },
  { data: "2026-04-02", tipi: ["organic", "residual", "paper"] },
  { data: "2026-04-04", tipi: ["plastic_metals", "glass"] },
  { data: "2026-04-09", tipi: ["organic"] },
  { data: "2026-04-16", tipi: ["organic", "residual", "paper"] },
  { data: "2026-04-20", tipi: ["plastic_metals", "glass"] },
  { data: "2026-04-23", tipi: ["organic"] },
  { data: "2026-04-30", tipi: ["organic", "residual", "paper"] },
  { data: "2026-05-04", tipi: ["plastic_metals", "glass"] },
  { data: "2026-05-07", tipi: ["organic"] },
  { data: "2026-05-14", tipi: ["organic", "residual", "paper"] },
  { data: "2026-05-18", tipi: ["plastic_metals", "glass"] },
  { data: "2026-05-21", tipi: ["organic"] },
  { data: "2026-05-28", tipi: ["organic", "residual", "paper"] },
  { data: "2026-06-01", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-06-04", tipi: ["organic"] },
  { data: "2026-06-08", tipi: ["organic"] },
  { data: "2026-06-11", tipi: ["organic", "residual", "paper"] },
  { data: "2026-06-15", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-06-18", tipi: ["organic"] },
  { data: "2026-06-22", tipi: ["organic"] },
  { data: "2026-06-25", tipi: ["organic", "residual", "paper"] },
  { data: "2026-06-29", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-07-02", tipi: ["organic"] },
  { data: "2026-07-06", tipi: ["organic"] },
  { data: "2026-07-09", tipi: ["organic", "residual", "paper"] },
  { data: "2026-07-13", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-07-16", tipi: ["organic"] },
  { data: "2026-07-20", tipi: ["organic"] },
  { data: "2026-07-23", tipi: ["organic", "residual", "paper"] },
  { data: "2026-07-27", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-07-30", tipi: ["organic"] },
  { data: "2026-08-03", tipi: ["organic"] },
  { data: "2026-08-06", tipi: ["organic", "residual", "paper"] },
  { data: "2026-08-10", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-08-13", tipi: ["organic"] },
  { data: "2026-08-17", tipi: ["organic"] },
  { data: "2026-08-20", tipi: ["organic", "residual", "paper"] },
  { data: "2026-08-24", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-08-27", tipi: ["organic"] },
  { data: "2026-08-31", tipi: ["organic"] },
  { data: "2026-09-03", tipi: ["organic", "residual", "paper"] },
  { data: "2026-09-07", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-09-10", tipi: ["organic"] },
  { data: "2026-09-14", tipi: ["organic"] },
  { data: "2026-09-17", tipi: ["organic", "residual", "paper"] },
  { data: "2026-09-21", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-09-24", tipi: ["organic"] },
  { data: "2026-09-28", tipi: ["organic"] },
  { data: "2026-10-01", tipi: ["organic", "residual", "paper"] },
  { data: "2026-10-05", tipi: ["plastic_metals", "glass"] },
  { data: "2026-10-08", tipi: ["organic"] },
  { data: "2026-10-15", tipi: ["organic", "residual", "paper"] },
  { data: "2026-10-19", tipi: ["plastic_metals", "glass"] },
  { data: "2026-10-22", tipi: ["organic"] },
  { data: "2026-10-29", tipi: ["organic", "residual", "paper"] },
  { data: "2026-11-02", tipi: ["plastic_metals", "glass"] },
  { data: "2026-11-05", tipi: ["organic"] },
  { data: "2026-11-12", tipi: ["organic", "residual", "paper"] },
  { data: "2026-11-16", tipi: ["plastic_metals", "glass"] },
  { data: "2026-11-19", tipi: ["organic"] },
  { data: "2026-11-26", tipi: ["organic", "residual", "paper"] },
  { data: "2026-11-30", tipi: ["plastic_metals", "glass"] },
  { data: "2026-12-03", tipi: ["organic"] },
  { data: "2026-12-10", tipi: ["organic", "residual", "paper"] },
  { data: "2026-12-14", tipi: ["plastic_metals", "glass"] },
  { data: "2026-12-17", tipi: ["organic"] },
  { data: "2026-12-24", tipi: ["organic", "residual", "paper"] },
  { data: "2026-12-28", tipi: ["plastic_metals", "glass"] },
  { data: "2026-12-31", tipi: ["organic"] },
];

const RIFIUTI_GEA_CANEVA_ZONA_A = [
  { data: "2026-01-03", tipi: ["organic"] },
  { data: "2026-01-05", tipi: ["paper"] },
  { data: "2026-01-08", tipi: ["organic", "glass"] },
  { data: "2026-01-12", tipi: ["plastic_metals"] },
  { data: "2026-01-13", tipi: ["residual"] },
  { data: "2026-01-15", tipi: ["organic"] },
  { data: "2026-01-19", tipi: ["paper"] },
  { data: "2026-01-22", tipi: ["organic", "glass"] },
  { data: "2026-01-26", tipi: ["plastic_metals"] },
  { data: "2026-01-27", tipi: ["residual"] },
  { data: "2026-01-29", tipi: ["organic"] },
  { data: "2026-02-02", tipi: ["paper"] },
  { data: "2026-02-05", tipi: ["organic", "glass"] },
  { data: "2026-02-09", tipi: ["plastic_metals"] },
  { data: "2026-02-10", tipi: ["residual"] },
  { data: "2026-02-12", tipi: ["organic"] },
  { data: "2026-02-16", tipi: ["paper"] },
  { data: "2026-02-19", tipi: ["organic", "glass"] },
  { data: "2026-02-23", tipi: ["plastic_metals"] },
  { data: "2026-02-24", tipi: ["residual"] },
  { data: "2026-02-26", tipi: ["organic"] },
  { data: "2026-03-02", tipi: ["paper"] },
  { data: "2026-03-05", tipi: ["organic", "glass"] },
  { data: "2026-03-09", tipi: ["plastic_metals"] },
  { data: "2026-03-10", tipi: ["residual"] },
  { data: "2026-03-12", tipi: ["organic"] },
  { data: "2026-03-16", tipi: ["paper"] },
  { data: "2026-03-19", tipi: ["organic", "glass"] },
  { data: "2026-03-23", tipi: ["plastic_metals"] },
  { data: "2026-03-24", tipi: ["residual"] },
  { data: "2026-03-26", tipi: ["organic"] },
  { data: "2026-03-30", tipi: ["paper"] },
  { data: "2026-04-02", tipi: ["organic", "glass"] },
  { data: "2026-04-04", tipi: ["plastic_metals"] },
  { data: "2026-04-07", tipi: ["residual"] },
  { data: "2026-04-09", tipi: ["organic"] },
  { data: "2026-04-13", tipi: ["paper"] },
  { data: "2026-04-16", tipi: ["organic", "glass"] },
  { data: "2026-04-20", tipi: ["plastic_metals"] },
  { data: "2026-04-21", tipi: ["residual"] },
  { data: "2026-04-23", tipi: ["organic"] },
  { data: "2026-04-27", tipi: ["paper"] },
  { data: "2026-04-30", tipi: ["organic", "glass"] },
  { data: "2026-05-04", tipi: ["plastic_metals"] },
  { data: "2026-05-05", tipi: ["residual"] },
  { data: "2026-05-07", tipi: ["organic"] },
  { data: "2026-05-11", tipi: ["paper"] },
  { data: "2026-05-14", tipi: ["organic", "glass"] },
  { data: "2026-05-18", tipi: ["plastic_metals"] },
  { data: "2026-05-19", tipi: ["residual"] },
  { data: "2026-05-21", tipi: ["organic"] },
  { data: "2026-05-25", tipi: ["paper"] },
  { data: "2026-05-28", tipi: ["organic", "glass"] },
  { data: "2026-06-01", tipi: ["organic", "plastic_metals"] },
  { data: "2026-06-02", tipi: ["residual"] },
  { data: "2026-06-04", tipi: ["organic"] },
  { data: "2026-06-08", tipi: ["organic", "paper"] },
  { data: "2026-06-11", tipi: ["organic", "glass"] },
  { data: "2026-06-15", tipi: ["organic", "plastic_metals"] },
  { data: "2026-06-16", tipi: ["residual"] },
  { data: "2026-06-18", tipi: ["organic"] },
  { data: "2026-06-22", tipi: ["organic", "paper"] },
  { data: "2026-06-25", tipi: ["organic", "glass"] },
  { data: "2026-06-29", tipi: ["organic", "plastic_metals"] },
  { data: "2026-06-30", tipi: ["residual"] },
  { data: "2026-07-02", tipi: ["organic"] },
  { data: "2026-07-06", tipi: ["organic", "paper"] },
  { data: "2026-07-09", tipi: ["organic", "glass"] },
  { data: "2026-07-13", tipi: ["organic", "plastic_metals"] },
  { data: "2026-07-14", tipi: ["residual"] },
  { data: "2026-07-16", tipi: ["organic"] },
  { data: "2026-07-20", tipi: ["organic", "paper"] },
  { data: "2026-07-23", tipi: ["organic", "glass"] },
  { data: "2026-07-27", tipi: ["organic", "plastic_metals"] },
  { data: "2026-07-28", tipi: ["residual"] },
  { data: "2026-07-30", tipi: ["organic"] },
  { data: "2026-08-03", tipi: ["organic", "paper"] },
  { data: "2026-08-06", tipi: ["organic", "glass"] },
  { data: "2026-08-10", tipi: ["organic", "plastic_metals"] },
  { data: "2026-08-11", tipi: ["residual"] },
  { data: "2026-08-13", tipi: ["organic"] },
  { data: "2026-08-17", tipi: ["organic", "paper"] },
  { data: "2026-08-20", tipi: ["organic", "glass"] },
  { data: "2026-08-24", tipi: ["organic", "plastic_metals"] },
  { data: "2026-08-25", tipi: ["residual"] },
  { data: "2026-08-27", tipi: ["organic"] },
  { data: "2026-08-31", tipi: ["organic", "paper"] },
  { data: "2026-09-03", tipi: ["organic", "glass"] },
  { data: "2026-09-07", tipi: ["organic", "plastic_metals"] },
  { data: "2026-09-08", tipi: ["residual"] },
  { data: "2026-09-10", tipi: ["organic"] },
  { data: "2026-09-14", tipi: ["organic", "paper"] },
  { data: "2026-09-17", tipi: ["organic", "glass"] },
  { data: "2026-09-21", tipi: ["organic", "plastic_metals"] },
  { data: "2026-09-22", tipi: ["residual"] },
  { data: "2026-09-24", tipi: ["organic"] },
  { data: "2026-09-28", tipi: ["organic", "paper"] },
  { data: "2026-10-01", tipi: ["organic", "glass"] },
  { data: "2026-10-05", tipi: ["plastic_metals"] },
  { data: "2026-10-06", tipi: ["residual"] },
  { data: "2026-10-08", tipi: ["organic"] },
  { data: "2026-10-12", tipi: ["paper"] },
  { data: "2026-10-15", tipi: ["organic", "glass"] },
  { data: "2026-10-19", tipi: ["plastic_metals"] },
  { data: "2026-10-20", tipi: ["residual"] },
  { data: "2026-10-22", tipi: ["organic"] },
  { data: "2026-10-26", tipi: ["paper"] },
  { data: "2026-10-29", tipi: ["organic", "glass"] },
  { data: "2026-11-02", tipi: ["plastic_metals"] },
  { data: "2026-11-03", tipi: ["residual"] },
  { data: "2026-11-05", tipi: ["organic"] },
  { data: "2026-11-09", tipi: ["paper"] },
  { data: "2026-11-12", tipi: ["organic", "glass"] },
  { data: "2026-11-16", tipi: ["plastic_metals"] },
  { data: "2026-11-17", tipi: ["residual"] },
  { data: "2026-11-19", tipi: ["organic"] },
  { data: "2026-11-23", tipi: ["paper"] },
  { data: "2026-11-26", tipi: ["organic", "glass"] },
  { data: "2026-11-30", tipi: ["plastic_metals"] },
  { data: "2026-12-01", tipi: ["residual"] },
  { data: "2026-12-03", tipi: ["organic"] },
  { data: "2026-12-07", tipi: ["paper"] },
  { data: "2026-12-10", tipi: ["organic", "glass"] },
  { data: "2026-12-14", tipi: ["plastic_metals"] },
  { data: "2026-12-15", tipi: ["residual"] },
  { data: "2026-12-17", tipi: ["organic"] },
  { data: "2026-12-21", tipi: ["paper"] },
  { data: "2026-12-24", tipi: ["organic", "glass"] },
  { data: "2026-12-28", tipi: ["plastic_metals"] },
  { data: "2026-12-29", tipi: ["residual"] },
  { data: "2026-12-31", tipi: ["organic"] },
];

const RIFIUTI_GEA_CANEVA_ZONA_B = [
  { data: "2026-01-02", tipi: ["paper"] },
  { data: "2026-01-03", tipi: ["organic", "glass"] },
  { data: "2026-01-06", tipi: ["residual"] },
  { data: "2026-01-08", tipi: ["organic"] },
  { data: "2026-01-09", tipi: ["plastic_metals"] },
  { data: "2026-01-15", tipi: ["organic", "glass"] },
  { data: "2026-01-16", tipi: ["paper"] },
  { data: "2026-01-20", tipi: ["residual"] },
  { data: "2026-01-22", tipi: ["organic"] },
  { data: "2026-01-23", tipi: ["plastic_metals"] },
  { data: "2026-01-29", tipi: ["organic", "glass"] },
  { data: "2026-01-30", tipi: ["paper"] },
  { data: "2026-02-03", tipi: ["residual"] },
  { data: "2026-02-05", tipi: ["organic"] },
  { data: "2026-02-06", tipi: ["plastic_metals"] },
  { data: "2026-02-12", tipi: ["organic", "glass"] },
  { data: "2026-02-13", tipi: ["paper"] },
  { data: "2026-02-17", tipi: ["residual"] },
  { data: "2026-02-19", tipi: ["organic"] },
  { data: "2026-02-20", tipi: ["plastic_metals"] },
  { data: "2026-02-26", tipi: ["organic", "glass"] },
  { data: "2026-02-27", tipi: ["paper"] },
  { data: "2026-03-03", tipi: ["residual"] },
  { data: "2026-03-05", tipi: ["organic"] },
  { data: "2026-03-06", tipi: ["plastic_metals"] },
  { data: "2026-03-12", tipi: ["organic", "glass"] },
  { data: "2026-03-13", tipi: ["paper"] },
  { data: "2026-03-17", tipi: ["residual"] },
  { data: "2026-03-19", tipi: ["organic"] },
  { data: "2026-03-20", tipi: ["plastic_metals"] },
  { data: "2026-03-26", tipi: ["organic", "glass"] },
  { data: "2026-03-27", tipi: ["paper"] },
  { data: "2026-03-31", tipi: ["residual"] },
  { data: "2026-04-02", tipi: ["organic"] },
  { data: "2026-04-03", tipi: ["plastic_metals"] },
  { data: "2026-04-09", tipi: ["organic", "glass"] },
  { data: "2026-04-10", tipi: ["paper"] },
  { data: "2026-04-14", tipi: ["residual"] },
  { data: "2026-04-16", tipi: ["organic"] },
  { data: "2026-04-17", tipi: ["plastic_metals"] },
  { data: "2026-04-23", tipi: ["organic", "glass"] },
  { data: "2026-04-24", tipi: ["paper"] },
  { data: "2026-04-28", tipi: ["residual"] },
  { data: "2026-04-30", tipi: ["organic"] },
  { data: "2026-05-02", tipi: ["plastic_metals"] },
  { data: "2026-05-07", tipi: ["organic", "glass"] },
  { data: "2026-05-08", tipi: ["paper"] },
  { data: "2026-05-12", tipi: ["residual"] },
  { data: "2026-05-14", tipi: ["organic"] },
  { data: "2026-05-15", tipi: ["plastic_metals"] },
  { data: "2026-05-21", tipi: ["organic", "glass"] },
  { data: "2026-05-22", tipi: ["paper"] },
  { data: "2026-05-26", tipi: ["residual"] },
  { data: "2026-05-28", tipi: ["organic"] },
  { data: "2026-05-29", tipi: ["plastic_metals"] },
  { data: "2026-06-01", tipi: ["organic"] },
  { data: "2026-06-04", tipi: ["organic", "glass"] },
  { data: "2026-06-05", tipi: ["paper"] },
  { data: "2026-06-08", tipi: ["organic"] },
  { data: "2026-06-09", tipi: ["residual"] },
  { data: "2026-06-11", tipi: ["organic"] },
  { data: "2026-06-12", tipi: ["plastic_metals"] },
  { data: "2026-06-15", tipi: ["organic"] },
  { data: "2026-06-18", tipi: ["organic", "glass"] },
  { data: "2026-06-19", tipi: ["paper"] },
  { data: "2026-06-22", tipi: ["organic"] },
  { data: "2026-06-23", tipi: ["residual"] },
  { data: "2026-06-25", tipi: ["organic"] },
  { data: "2026-06-26", tipi: ["plastic_metals"] },
  { data: "2026-06-29", tipi: ["organic"] },
  { data: "2026-07-02", tipi: ["organic", "glass"] },
  { data: "2026-07-03", tipi: ["paper"] },
  { data: "2026-07-06", tipi: ["organic"] },
  { data: "2026-07-07", tipi: ["residual"] },
  { data: "2026-07-09", tipi: ["organic"] },
  { data: "2026-07-10", tipi: ["plastic_metals"] },
  { data: "2026-07-13", tipi: ["organic"] },
  { data: "2026-07-16", tipi: ["organic", "glass"] },
  { data: "2026-07-17", tipi: ["paper"] },
  { data: "2026-07-20", tipi: ["organic"] },
  { data: "2026-07-21", tipi: ["residual"] },
  { data: "2026-07-23", tipi: ["organic"] },
  { data: "2026-07-24", tipi: ["plastic_metals"] },
  { data: "2026-07-27", tipi: ["organic"] },
  { data: "2026-07-30", tipi: ["organic", "glass"] },
  { data: "2026-07-31", tipi: ["paper"] },
  { data: "2026-08-03", tipi: ["organic"] },
  { data: "2026-08-04", tipi: ["residual"] },
  { data: "2026-08-06", tipi: ["organic"] },
  { data: "2026-08-07", tipi: ["plastic_metals"] },
  { data: "2026-08-10", tipi: ["organic"] },
  { data: "2026-08-13", tipi: ["organic", "glass"] },
  { data: "2026-08-14", tipi: ["paper"] },
  { data: "2026-08-17", tipi: ["organic"] },
  { data: "2026-08-18", tipi: ["residual"] },
  { data: "2026-08-20", tipi: ["organic"] },
  { data: "2026-08-21", tipi: ["plastic_metals"] },
  { data: "2026-08-24", tipi: ["organic"] },
  { data: "2026-08-27", tipi: ["organic", "glass"] },
  { data: "2026-08-28", tipi: ["paper"] },
  { data: "2026-08-31", tipi: ["organic"] },
  { data: "2026-09-01", tipi: ["residual"] },
  { data: "2026-09-03", tipi: ["organic"] },
  { data: "2026-09-04", tipi: ["plastic_metals"] },
  { data: "2026-09-07", tipi: ["organic"] },
  { data: "2026-09-10", tipi: ["organic", "glass"] },
  { data: "2026-09-11", tipi: ["paper"] },
  { data: "2026-09-14", tipi: ["organic"] },
  { data: "2026-09-15", tipi: ["residual"] },
  { data: "2026-09-17", tipi: ["organic"] },
  { data: "2026-09-18", tipi: ["plastic_metals"] },
  { data: "2026-09-21", tipi: ["organic"] },
  { data: "2026-09-24", tipi: ["organic", "glass"] },
  { data: "2026-09-25", tipi: ["paper"] },
  { data: "2026-09-28", tipi: ["organic"] },
  { data: "2026-09-29", tipi: ["residual"] },
  { data: "2026-10-01", tipi: ["organic"] },
  { data: "2026-10-02", tipi: ["plastic_metals"] },
  { data: "2026-10-08", tipi: ["organic", "glass"] },
  { data: "2026-10-09", tipi: ["paper"] },
  { data: "2026-10-13", tipi: ["residual"] },
  { data: "2026-10-15", tipi: ["organic"] },
  { data: "2026-10-16", tipi: ["plastic_metals"] },
  { data: "2026-10-22", tipi: ["organic", "glass"] },
  { data: "2026-10-23", tipi: ["paper"] },
  { data: "2026-10-27", tipi: ["residual"] },
  { data: "2026-10-29", tipi: ["organic"] },
  { data: "2026-10-30", tipi: ["plastic_metals"] },
  { data: "2026-11-05", tipi: ["organic", "glass"] },
  { data: "2026-11-06", tipi: ["paper"] },
  { data: "2026-11-10", tipi: ["residual"] },
  { data: "2026-11-12", tipi: ["organic"] },
  { data: "2026-11-13", tipi: ["plastic_metals"] },
  { data: "2026-11-19", tipi: ["organic", "glass"] },
  { data: "2026-11-20", tipi: ["paper"] },
  { data: "2026-11-24", tipi: ["residual"] },
  { data: "2026-11-26", tipi: ["organic"] },
  { data: "2026-11-27", tipi: ["plastic_metals"] },
  { data: "2026-12-03", tipi: ["organic", "glass"] },
  { data: "2026-12-04", tipi: ["paper"] },
  { data: "2026-12-08", tipi: ["residual"] },
  { data: "2026-12-10", tipi: ["organic"] },
  { data: "2026-12-11", tipi: ["plastic_metals"] },
  { data: "2026-12-17", tipi: ["organic", "glass"] },
  { data: "2026-12-18", tipi: ["paper"] },
  { data: "2026-12-22", tipi: ["residual"] },
  { data: "2026-12-24", tipi: ["organic"] },
  { data: "2026-12-26", tipi: ["plastic_metals"] },
  { data: "2026-12-31", tipi: ["organic", "glass"] },
];

const RIFIUTI_GEA_CIMOLAIS = [
  { data: "2026-01-02", tipi: ["plastic_metals"] },
  { data: "2026-01-03", tipi: ["paper"] },
  { data: "2026-01-05", tipi: ["residual"] },
  { data: "2026-01-06", tipi: ["glass"] },
  { data: "2026-01-07", tipi: ["organic"] },
  { data: "2026-01-14", tipi: ["organic"] },
  { data: "2026-01-15", tipi: ["paper"] },
  { data: "2026-01-16", tipi: ["plastic_metals"] },
  { data: "2026-01-19", tipi: ["residual"] },
  { data: "2026-01-20", tipi: ["glass"] },
  { data: "2026-01-21", tipi: ["organic"] },
  { data: "2026-01-28", tipi: ["organic"] },
  { data: "2026-01-29", tipi: ["paper"] },
  { data: "2026-01-30", tipi: ["plastic_metals"] },
  { data: "2026-02-02", tipi: ["residual"] },
  { data: "2026-02-03", tipi: ["glass"] },
  { data: "2026-02-04", tipi: ["organic"] },
  { data: "2026-02-11", tipi: ["organic"] },
  { data: "2026-02-12", tipi: ["paper"] },
  { data: "2026-02-13", tipi: ["plastic_metals"] },
  { data: "2026-02-16", tipi: ["residual"] },
  { data: "2026-02-17", tipi: ["glass"] },
  { data: "2026-02-18", tipi: ["organic"] },
  { data: "2026-02-25", tipi: ["organic"] },
  { data: "2026-02-26", tipi: ["paper"] },
  { data: "2026-02-27", tipi: ["plastic_metals"] },
  { data: "2026-03-02", tipi: ["residual"] },
  { data: "2026-03-03", tipi: ["glass"] },
  { data: "2026-03-04", tipi: ["organic"] },
  { data: "2026-03-11", tipi: ["organic"] },
  { data: "2026-03-12", tipi: ["paper"] },
  { data: "2026-03-13", tipi: ["plastic_metals"] },
  { data: "2026-03-16", tipi: ["residual"] },
  { data: "2026-03-17", tipi: ["glass"] },
  { data: "2026-03-18", tipi: ["organic"] },
  { data: "2026-03-25", tipi: ["organic"] },
  { data: "2026-03-26", tipi: ["paper"] },
  { data: "2026-03-27", tipi: ["plastic_metals"] },
  { data: "2026-03-30", tipi: ["residual"] },
  { data: "2026-03-31", tipi: ["glass"] },
  { data: "2026-04-01", tipi: ["organic"] },
  { data: "2026-04-08", tipi: ["organic"] },
  { data: "2026-04-09", tipi: ["paper"] },
  { data: "2026-04-10", tipi: ["plastic_metals"] },
  { data: "2026-04-13", tipi: ["residual"] },
  { data: "2026-04-14", tipi: ["glass"] },
  { data: "2026-04-15", tipi: ["organic"] },
  { data: "2026-04-22", tipi: ["organic"] },
  { data: "2026-04-23", tipi: ["paper"] },
  { data: "2026-04-24", tipi: ["plastic_metals"] },
  { data: "2026-04-27", tipi: ["residual"] },
  { data: "2026-04-28", tipi: ["glass"] },
  { data: "2026-04-29", tipi: ["organic"] },
  { data: "2026-05-06", tipi: ["organic"] },
  { data: "2026-05-07", tipi: ["paper"] },
  { data: "2026-05-08", tipi: ["plastic_metals"] },
  { data: "2026-05-11", tipi: ["residual"] },
  { data: "2026-05-12", tipi: ["glass"] },
  { data: "2026-05-13", tipi: ["organic"] },
  { data: "2026-05-20", tipi: ["organic"] },
  { data: "2026-05-21", tipi: ["paper"] },
  { data: "2026-05-22", tipi: ["plastic_metals"] },
  { data: "2026-05-25", tipi: ["residual"] },
  { data: "2026-05-26", tipi: ["glass"] },
  { data: "2026-05-27", tipi: ["organic"] },
  { data: "2026-06-03", tipi: ["organic"] },
  { data: "2026-06-04", tipi: ["paper"] },
  { data: "2026-06-05", tipi: ["plastic_metals"] },
  { data: "2026-06-06", tipi: ["organic"] },
  { data: "2026-06-08", tipi: ["residual"] },
  { data: "2026-06-09", tipi: ["glass"] },
  { data: "2026-06-10", tipi: ["organic"] },
  { data: "2026-06-13", tipi: ["organic"] },
  { data: "2026-06-17", tipi: ["organic"] },
  { data: "2026-06-18", tipi: ["paper"] },
  { data: "2026-06-19", tipi: ["plastic_metals"] },
  { data: "2026-06-20", tipi: ["organic"] },
  { data: "2026-06-22", tipi: ["residual"] },
  { data: "2026-06-23", tipi: ["glass"] },
  { data: "2026-06-24", tipi: ["organic"] },
  { data: "2026-06-27", tipi: ["organic"] },
  { data: "2026-07-01", tipi: ["organic"] },
  { data: "2026-07-02", tipi: ["paper"] },
  { data: "2026-07-03", tipi: ["plastic_metals"] },
  { data: "2026-07-04", tipi: ["organic"] },
  { data: "2026-07-06", tipi: ["residual"] },
  { data: "2026-07-07", tipi: ["glass"] },
  { data: "2026-07-08", tipi: ["organic"] },
  { data: "2026-07-11", tipi: ["organic"] },
  { data: "2026-07-15", tipi: ["organic"] },
  { data: "2026-07-16", tipi: ["paper"] },
  { data: "2026-07-17", tipi: ["plastic_metals"] },
  { data: "2026-07-18", tipi: ["organic"] },
  { data: "2026-07-20", tipi: ["residual"] },
  { data: "2026-07-21", tipi: ["glass"] },
  { data: "2026-07-22", tipi: ["organic"] },
  { data: "2026-07-25", tipi: ["organic"] },
  { data: "2026-07-29", tipi: ["organic"] },
  { data: "2026-07-30", tipi: ["paper"] },
  { data: "2026-07-31", tipi: ["plastic_metals"] },
  { data: "2026-08-01", tipi: ["organic"] },
  { data: "2026-08-03", tipi: ["residual"] },
  { data: "2026-08-04", tipi: ["glass"] },
  { data: "2026-08-05", tipi: ["organic"] },
  { data: "2026-08-08", tipi: ["organic"] },
  { data: "2026-08-12", tipi: ["organic"] },
  { data: "2026-08-13", tipi: ["paper"] },
  { data: "2026-08-14", tipi: ["plastic_metals"] },
  { data: "2026-08-17", tipi: ["residual"] },
  { data: "2026-08-18", tipi: ["glass"] },
  { data: "2026-08-19", tipi: ["organic"] },
  { data: "2026-08-22", tipi: ["organic"] },
  { data: "2026-08-26", tipi: ["organic"] },
  { data: "2026-08-27", tipi: ["paper"] },
  { data: "2026-08-28", tipi: ["plastic_metals"] },
  { data: "2026-08-29", tipi: ["organic"] },
  { data: "2026-08-31", tipi: ["residual"] },
  { data: "2026-09-01", tipi: ["glass"] },
  { data: "2026-09-02", tipi: ["organic"] },
  { data: "2026-09-05", tipi: ["organic"] },
  { data: "2026-09-09", tipi: ["organic"] },
  { data: "2026-09-10", tipi: ["paper"] },
  { data: "2026-09-11", tipi: ["plastic_metals"] },
  { data: "2026-09-12", tipi: ["organic"] },
  { data: "2026-09-14", tipi: ["residual"] },
  { data: "2026-09-15", tipi: ["glass"] },
  { data: "2026-09-16", tipi: ["organic"] },
  { data: "2026-09-19", tipi: ["organic"] },
  { data: "2026-09-23", tipi: ["organic"] },
  { data: "2026-09-24", tipi: ["paper"] },
  { data: "2026-09-25", tipi: ["plastic_metals"] },
  { data: "2026-09-26", tipi: ["organic"] },
  { data: "2026-09-28", tipi: ["residual"] },
  { data: "2026-09-29", tipi: ["glass"] },
  { data: "2026-09-30", tipi: ["organic"] },
  { data: "2026-10-07", tipi: ["organic"] },
  { data: "2026-10-08", tipi: ["paper"] },
  { data: "2026-10-09", tipi: ["plastic_metals"] },
  { data: "2026-10-12", tipi: ["residual"] },
  { data: "2026-10-13", tipi: ["glass"] },
  { data: "2026-10-14", tipi: ["organic"] },
  { data: "2026-10-21", tipi: ["organic"] },
  { data: "2026-10-22", tipi: ["paper"] },
  { data: "2026-10-23", tipi: ["plastic_metals"] },
  { data: "2026-10-26", tipi: ["residual"] },
  { data: "2026-10-27", tipi: ["glass"] },
  { data: "2026-10-28", tipi: ["organic"] },
  { data: "2026-11-04", tipi: ["organic"] },
  { data: "2026-11-05", tipi: ["paper"] },
  { data: "2026-11-06", tipi: ["plastic_metals"] },
  { data: "2026-11-09", tipi: ["residual"] },
  { data: "2026-11-10", tipi: ["glass"] },
  { data: "2026-11-11", tipi: ["organic"] },
  { data: "2026-11-18", tipi: ["organic"] },
  { data: "2026-11-19", tipi: ["paper"] },
  { data: "2026-11-20", tipi: ["plastic_metals"] },
  { data: "2026-11-23", tipi: ["residual"] },
  { data: "2026-11-24", tipi: ["glass"] },
  { data: "2026-11-25", tipi: ["organic"] },
  { data: "2026-12-02", tipi: ["organic"] },
  { data: "2026-12-03", tipi: ["paper"] },
  { data: "2026-12-04", tipi: ["plastic_metals"] },
  { data: "2026-12-07", tipi: ["residual"] },
  { data: "2026-12-08", tipi: ["glass"] },
  { data: "2026-12-09", tipi: ["organic"] },
  { data: "2026-12-16", tipi: ["organic"] },
  { data: "2026-12-17", tipi: ["paper"] },
  { data: "2026-12-18", tipi: ["plastic_metals"] },
  { data: "2026-12-21", tipi: ["residual"] },
  { data: "2026-12-22", tipi: ["glass"] },
  { data: "2026-12-23", tipi: ["organic"] },
  { data: "2026-12-30", tipi: ["organic"] },
  { data: "2026-12-31", tipi: ["paper"] },
];

// Aggiunto il 30/09/2026 — Cordenons, tredicesimo comune GEA e primo con
// un'architettura diversa da tutti gli altri (vedi il commento esteso
// sopra RIFIUTI_COMUNI_GEA più sotto per la ricognizione completa fatta
// prima di modellarlo, incluso cosa resta fuori scope). Qui di seguito
// solo la parte porta a porta quindicinale di secco/carta/plastica,
// unica parte modellata in questa v1: due zone (Zona 1/Zona 2, stesse
// mostrate nella mappa del PDF), ciascuna con calendario proprio.
// Trascritto letteralmente pagina per pagina dai 12 mesi del PDF
// ufficiale 2026 (28 pagine), con un controllo che si è rivelato
// necessario: una prima lettura a 150dpi aveva scambiato per errore
// alcuni badge tra Zona 1 e Zona 2 (i due badge sono molto vicini al
// divisore della tabella) — rifatta la trascrizione con crop mirati a
// 300dpi sul confine tra le due colonne per ogni singola data, non solo
// per le date "sospette", dato che è la prima volta che questo comune
// viene modellato e non c'è un pattern precedente con cui confrontare
// il risultato. Una volta corretto, il pattern è pulito: ogni tipo è
// quindicinale sia in Zona 1 che in Zona 2, con i due materiali
// carta/plastica che si alternano ogni settimana sullo stesso giorno
// (mercoledì in Zona 1, giovedì in Zona 2) e il secco quindicinale su
// un giorno proprio (sabato in Zona 1, martedì in Zona 2). Due eccezioni
// festive senza recupero visibile nel PDF, stesso trattamento del
// Ferragosto già visto in altri comuni GEA — omesse dai dati, non
// inventata una data sostitutiva: CARTA di Zona 2 del 1° gennaio
// (Capodanno) e SECCO di Zona 1 del 15 agosto (Ferragosto).

const RIFIUTI_GEA_CORDENONS_ZONA1 = [
  { data: "2026-01-03", tipi: ["residual"] },
  { data: "2026-01-07", tipi: ["plastic_metals"] },
  { data: "2026-01-14", tipi: ["paper"] },
  { data: "2026-01-17", tipi: ["residual"] },
  { data: "2026-01-21", tipi: ["plastic_metals"] },
  { data: "2026-01-28", tipi: ["paper"] },
  { data: "2026-01-31", tipi: ["residual"] },
  { data: "2026-02-04", tipi: ["plastic_metals"] },
  { data: "2026-02-11", tipi: ["paper"] },
  { data: "2026-02-14", tipi: ["residual"] },
  { data: "2026-02-18", tipi: ["plastic_metals"] },
  { data: "2026-02-25", tipi: ["paper"] },
  { data: "2026-02-28", tipi: ["residual"] },
  { data: "2026-03-04", tipi: ["plastic_metals"] },
  { data: "2026-03-11", tipi: ["paper"] },
  { data: "2026-03-14", tipi: ["residual"] },
  { data: "2026-03-18", tipi: ["plastic_metals"] },
  { data: "2026-03-25", tipi: ["paper"] },
  { data: "2026-03-28", tipi: ["residual"] },
  { data: "2026-04-01", tipi: ["plastic_metals"] },
  { data: "2026-04-08", tipi: ["paper"] },
  { data: "2026-04-11", tipi: ["residual"] },
  { data: "2026-04-15", tipi: ["plastic_metals"] },
  { data: "2026-04-22", tipi: ["paper"] },
  { data: "2026-04-25", tipi: ["residual"] },
  { data: "2026-04-29", tipi: ["plastic_metals"] },
  { data: "2026-05-06", tipi: ["paper"] },
  { data: "2026-05-09", tipi: ["residual"] },
  { data: "2026-05-13", tipi: ["plastic_metals"] },
  { data: "2026-05-20", tipi: ["paper"] },
  { data: "2026-05-23", tipi: ["residual"] },
  { data: "2026-05-27", tipi: ["plastic_metals"] },
  { data: "2026-06-03", tipi: ["paper"] },
  { data: "2026-06-06", tipi: ["residual"] },
  { data: "2026-06-10", tipi: ["plastic_metals"] },
  { data: "2026-06-17", tipi: ["paper"] },
  { data: "2026-06-20", tipi: ["residual"] },
  { data: "2026-06-24", tipi: ["plastic_metals"] },
  { data: "2026-07-01", tipi: ["paper"] },
  { data: "2026-07-04", tipi: ["residual"] },
  { data: "2026-07-08", tipi: ["plastic_metals"] },
  { data: "2026-07-15", tipi: ["paper"] },
  { data: "2026-07-18", tipi: ["residual"] },
  { data: "2026-07-22", tipi: ["plastic_metals"] },
  { data: "2026-07-29", tipi: ["paper"] },
  { data: "2026-08-01", tipi: ["residual"] },
  { data: "2026-08-05", tipi: ["plastic_metals"] },
  { data: "2026-08-12", tipi: ["paper"] },
  { data: "2026-08-19", tipi: ["plastic_metals"] },
  { data: "2026-08-26", tipi: ["paper"] },
  { data: "2026-08-29", tipi: ["residual"] },
  { data: "2026-09-02", tipi: ["plastic_metals"] },
  { data: "2026-09-09", tipi: ["paper"] },
  { data: "2026-09-12", tipi: ["residual"] },
  { data: "2026-09-16", tipi: ["plastic_metals"] },
  { data: "2026-09-23", tipi: ["paper"] },
  { data: "2026-09-26", tipi: ["residual"] },
  { data: "2026-09-30", tipi: ["plastic_metals"] },
  { data: "2026-10-07", tipi: ["paper"] },
  { data: "2026-10-10", tipi: ["residual"] },
  { data: "2026-10-14", tipi: ["plastic_metals"] },
  { data: "2026-10-21", tipi: ["paper"] },
  { data: "2026-10-24", tipi: ["residual"] },
  { data: "2026-10-28", tipi: ["plastic_metals"] },
  { data: "2026-11-04", tipi: ["paper"] },
  { data: "2026-11-07", tipi: ["residual"] },
  { data: "2026-11-11", tipi: ["plastic_metals"] },
  { data: "2026-11-18", tipi: ["paper"] },
  { data: "2026-11-21", tipi: ["residual"] },
  { data: "2026-11-25", tipi: ["plastic_metals"] },
  { data: "2026-12-02", tipi: ["paper"] },
  { data: "2026-12-05", tipi: ["residual"] },
  { data: "2026-12-09", tipi: ["plastic_metals"] },
  { data: "2026-12-16", tipi: ["paper"] },
  { data: "2026-12-19", tipi: ["residual"] },
  { data: "2026-12-23", tipi: ["plastic_metals"] },
  { data: "2026-12-30", tipi: ["paper"] },
];

const RIFIUTI_GEA_CORDENONS_ZONA2 = [
  { data: "2026-01-08", tipi: ["plastic_metals"] },
  { data: "2026-01-13", tipi: ["residual"] },
  { data: "2026-01-15", tipi: ["paper"] },
  { data: "2026-01-22", tipi: ["plastic_metals"] },
  { data: "2026-01-27", tipi: ["residual"] },
  { data: "2026-01-29", tipi: ["paper"] },
  { data: "2026-02-05", tipi: ["plastic_metals"] },
  { data: "2026-02-10", tipi: ["residual"] },
  { data: "2026-02-12", tipi: ["paper"] },
  { data: "2026-02-19", tipi: ["plastic_metals"] },
  { data: "2026-02-24", tipi: ["residual"] },
  { data: "2026-02-26", tipi: ["paper"] },
  { data: "2026-03-05", tipi: ["plastic_metals"] },
  { data: "2026-03-10", tipi: ["residual"] },
  { data: "2026-03-12", tipi: ["paper"] },
  { data: "2026-03-19", tipi: ["plastic_metals"] },
  { data: "2026-03-24", tipi: ["residual"] },
  { data: "2026-03-26", tipi: ["paper"] },
  { data: "2026-04-02", tipi: ["plastic_metals"] },
  { data: "2026-04-07", tipi: ["residual"] },
  { data: "2026-04-09", tipi: ["paper"] },
  { data: "2026-04-16", tipi: ["plastic_metals"] },
  { data: "2026-04-21", tipi: ["residual"] },
  { data: "2026-04-23", tipi: ["paper"] },
  { data: "2026-04-30", tipi: ["plastic_metals"] },
  { data: "2026-05-05", tipi: ["residual"] },
  { data: "2026-05-07", tipi: ["paper"] },
  { data: "2026-05-14", tipi: ["plastic_metals"] },
  { data: "2026-05-19", tipi: ["residual"] },
  { data: "2026-05-21", tipi: ["paper"] },
  { data: "2026-05-28", tipi: ["plastic_metals"] },
  { data: "2026-06-02", tipi: ["residual"] },
  { data: "2026-06-04", tipi: ["paper"] },
  { data: "2026-06-11", tipi: ["plastic_metals"] },
  { data: "2026-06-16", tipi: ["residual"] },
  { data: "2026-06-18", tipi: ["paper"] },
  { data: "2026-06-25", tipi: ["plastic_metals"] },
  { data: "2026-06-30", tipi: ["residual"] },
  { data: "2026-07-02", tipi: ["paper"] },
  { data: "2026-07-09", tipi: ["plastic_metals"] },
  { data: "2026-07-14", tipi: ["residual"] },
  { data: "2026-07-16", tipi: ["paper"] },
  { data: "2026-07-23", tipi: ["plastic_metals"] },
  { data: "2026-07-28", tipi: ["residual"] },
  { data: "2026-07-30", tipi: ["paper"] },
  { data: "2026-08-06", tipi: ["plastic_metals"] },
  { data: "2026-08-11", tipi: ["residual"] },
  { data: "2026-08-13", tipi: ["paper"] },
  { data: "2026-08-20", tipi: ["plastic_metals"] },
  { data: "2026-08-25", tipi: ["residual"] },
  { data: "2026-08-27", tipi: ["paper"] },
  { data: "2026-09-03", tipi: ["plastic_metals"] },
  { data: "2026-09-08", tipi: ["residual"] },
  { data: "2026-09-10", tipi: ["paper"] },
  { data: "2026-09-17", tipi: ["plastic_metals"] },
  { data: "2026-09-22", tipi: ["residual"] },
  { data: "2026-09-24", tipi: ["paper"] },
  { data: "2026-10-01", tipi: ["plastic_metals"] },
  { data: "2026-10-06", tipi: ["residual"] },
  { data: "2026-10-08", tipi: ["paper"] },
  { data: "2026-10-15", tipi: ["plastic_metals"] },
  { data: "2026-10-20", tipi: ["residual"] },
  { data: "2026-10-22", tipi: ["paper"] },
  { data: "2026-10-29", tipi: ["plastic_metals"] },
  { data: "2026-11-03", tipi: ["residual"] },
  { data: "2026-11-05", tipi: ["paper"] },
  { data: "2026-11-12", tipi: ["plastic_metals"] },
  { data: "2026-11-17", tipi: ["residual"] },
  { data: "2026-11-19", tipi: ["paper"] },
  { data: "2026-11-26", tipi: ["plastic_metals"] },
  { data: "2026-12-01", tipi: ["residual"] },
  { data: "2026-12-03", tipi: ["paper"] },
  { data: "2026-12-10", tipi: ["plastic_metals"] },
  { data: "2026-12-15", tipi: ["residual"] },
  { data: "2026-12-17", tipi: ["paper"] },
  { data: "2026-12-24", tipi: ["plastic_metals"] },
  { data: "2026-12-29", tipi: ["residual"] },
  { data: "2026-12-31", tipi: ["paper"] },
];

// --- Batch conclusivo comuni GEA (Tramonti di Sopra/Sotto, Vito d'Asio, Vivaro,
// Maniago, Meduno, Sequals, Montereale Valcellina, Prata di Pordenone,
// Roveredo in Piano, San Quirino) --------------------------------------
const RIFIUTI_GEA_TRAMONTI_SOPRA = [
  { data: "2026-01-05", tipi: ["organic", "residual", "paper"] },
  { data: "2026-01-12", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-01-19", tipi: ["organic", "residual", "paper"] },
  { data: "2026-01-26", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-02-02", tipi: ["organic", "residual", "paper"] },
  { data: "2026-02-09", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-02-16", tipi: ["organic", "residual", "paper"] },
  { data: "2026-02-23", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-03-02", tipi: ["organic", "residual", "paper"] },
  { data: "2026-03-09", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-03-16", tipi: ["organic", "residual", "paper"] },
  { data: "2026-03-23", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-03-30", tipi: ["organic", "residual", "paper"] },
  { data: "2026-04-04", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-04-13", tipi: ["organic", "residual", "paper"] },
  { data: "2026-04-20", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-04-27", tipi: ["organic", "residual", "paper"] },
  { data: "2026-05-04", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-05-11", tipi: ["organic", "residual", "paper"] },
  { data: "2026-05-18", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-05-25", tipi: ["organic", "residual", "paper"] },
  { data: "2026-06-01", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-06-05", tipi: ["organic"] },
  { data: "2026-06-08", tipi: ["organic", "residual", "paper"] },
  { data: "2026-06-12", tipi: ["organic"] },
  { data: "2026-06-15", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-06-19", tipi: ["organic"] },
  { data: "2026-06-22", tipi: ["organic", "residual", "paper"] },
  { data: "2026-06-26", tipi: ["organic"] },
  { data: "2026-06-29", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-07-03", tipi: ["organic"] },
  { data: "2026-07-06", tipi: ["organic", "residual", "paper"] },
  { data: "2026-07-10", tipi: ["organic"] },
  { data: "2026-07-13", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-07-17", tipi: ["organic"] },
  { data: "2026-07-20", tipi: ["organic", "residual", "paper"] },
  { data: "2026-07-24", tipi: ["organic"] },
  { data: "2026-07-27", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-07-31", tipi: ["organic"] },
  { data: "2026-08-03", tipi: ["organic", "residual", "paper"] },
  { data: "2026-08-07", tipi: ["organic"] },
  { data: "2026-08-10", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-08-14", tipi: ["organic"] },
  { data: "2026-08-17", tipi: ["organic", "residual", "paper"] },
  { data: "2026-08-21", tipi: ["organic"] },
  { data: "2026-08-24", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-08-28", tipi: ["organic"] },
  { data: "2026-08-31", tipi: ["organic", "residual", "paper"] },
  { data: "2026-09-04", tipi: ["organic"] },
  { data: "2026-09-07", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-09-11", tipi: ["organic"] },
  { data: "2026-09-14", tipi: ["organic", "residual", "paper"] },
  { data: "2026-09-18", tipi: ["organic"] },
  { data: "2026-09-21", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-09-25", tipi: ["organic"] },
  { data: "2026-09-28", tipi: ["organic", "residual", "paper"] },
  { data: "2026-10-05", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-10-12", tipi: ["organic", "residual", "paper"] },
  { data: "2026-10-19", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-10-26", tipi: ["organic", "residual", "paper"] },
  { data: "2026-11-02", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-11-09", tipi: ["organic", "residual", "paper"] },
  { data: "2026-11-16", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-11-23", tipi: ["organic", "residual", "paper"] },
  { data: "2026-11-30", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-12-07", tipi: ["organic", "residual", "paper"] },
  { data: "2026-12-14", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-12-21", tipi: ["organic", "residual", "paper"] },
  { data: "2026-12-28", tipi: ["organic", "plastic_metals", "glass"] },
];

const RIFIUTI_GEA_TRAMONTI_SOTTO = [
  { data: "2026-01-05", tipi: ["organic", "residual", "paper"] },
  { data: "2026-01-12", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-01-19", tipi: ["organic", "residual", "paper"] },
  { data: "2026-01-26", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-02-02", tipi: ["organic", "residual", "paper"] },
  { data: "2026-02-09", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-02-16", tipi: ["organic", "residual", "paper"] },
  { data: "2026-02-23", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-03-02", tipi: ["organic", "residual", "paper"] },
  { data: "2026-03-09", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-03-16", tipi: ["organic", "residual", "paper"] },
  { data: "2026-03-23", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-03-30", tipi: ["organic", "residual", "paper"] },
  { data: "2026-04-04", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-04-13", tipi: ["organic", "residual", "paper"] },
  { data: "2026-04-20", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-04-27", tipi: ["organic", "residual", "paper"] },
  { data: "2026-05-04", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-05-11", tipi: ["organic", "residual", "paper"] },
  { data: "2026-05-18", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-05-25", tipi: ["organic", "residual", "paper"] },
  { data: "2026-06-01", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-06-05", tipi: ["organic"] },
  { data: "2026-06-08", tipi: ["organic", "residual", "paper"] },
  { data: "2026-06-12", tipi: ["organic"] },
  { data: "2026-06-15", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-06-19", tipi: ["organic"] },
  { data: "2026-06-22", tipi: ["organic", "residual", "paper"] },
  { data: "2026-06-26", tipi: ["organic"] },
  { data: "2026-06-29", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-07-03", tipi: ["organic"] },
  { data: "2026-07-06", tipi: ["organic", "residual", "paper"] },
  { data: "2026-07-10", tipi: ["organic"] },
  { data: "2026-07-13", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-07-17", tipi: ["organic"] },
  { data: "2026-07-20", tipi: ["organic", "residual", "paper"] },
  { data: "2026-07-24", tipi: ["organic"] },
  { data: "2026-07-27", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-07-31", tipi: ["organic"] },
  { data: "2026-08-03", tipi: ["organic", "residual", "paper"] },
  { data: "2026-08-07", tipi: ["organic"] },
  { data: "2026-08-10", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-08-14", tipi: ["organic"] },
  { data: "2026-08-17", tipi: ["organic", "residual", "paper"] },
  { data: "2026-08-21", tipi: ["organic"] },
  { data: "2026-08-24", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-08-28", tipi: ["organic"] },
  { data: "2026-08-31", tipi: ["organic", "residual", "paper"] },
  { data: "2026-09-04", tipi: ["organic"] },
  { data: "2026-09-07", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-09-11", tipi: ["organic"] },
  { data: "2026-09-14", tipi: ["organic", "residual", "paper"] },
  { data: "2026-09-18", tipi: ["organic"] },
  { data: "2026-09-21", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-09-25", tipi: ["organic"] },
  { data: "2026-09-28", tipi: ["organic", "residual", "paper"] },
  { data: "2026-10-05", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-10-12", tipi: ["organic", "residual", "paper"] },
  { data: "2026-10-19", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-10-26", tipi: ["organic", "residual", "paper"] },
  { data: "2026-11-02", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-11-09", tipi: ["organic", "residual", "paper"] },
  { data: "2026-11-16", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-11-23", tipi: ["organic", "residual", "paper"] },
  { data: "2026-11-30", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-12-07", tipi: ["organic", "residual", "paper"] },
  { data: "2026-12-14", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-12-21", tipi: ["organic", "residual", "paper"] },
  { data: "2026-12-28", tipi: ["organic", "plastic_metals", "glass"] },
];

const RIFIUTI_GEA_VITO_DASIO = [
  { "data": "2026-01-02", "tipi": ["plastic_metals", "glass"] },
  { "data": "2026-01-06", "tipi": ["organic"] },
  { "data": "2026-01-09", "tipi": ["paper"] },
  { "data": "2026-01-13", "tipi": ["organic", "residual"] },
  { "data": "2026-01-16", "tipi": ["plastic_metals", "glass"] },
  { "data": "2026-01-20", "tipi": ["organic"] },
  { "data": "2026-01-23", "tipi": ["paper"] },
  { "data": "2026-01-27", "tipi": ["organic", "residual"] },
  { "data": "2026-01-30", "tipi": ["plastic_metals", "glass"] },

  { "data": "2026-02-03", "tipi": ["organic"] },
  { "data": "2026-02-06", "tipi": ["paper"] },
  { "data": "2026-02-10", "tipi": ["organic", "residual"] },
  { "data": "2026-02-13", "tipi": ["plastic_metals", "glass"] },
  { "data": "2026-02-17", "tipi": ["organic"] },
  { "data": "2026-02-20", "tipi": ["paper"] },
  { "data": "2026-02-24", "tipi": ["organic", "residual"] },
  { "data": "2026-02-27", "tipi": ["plastic_metals", "glass"] },

  { "data": "2026-03-03", "tipi": ["organic"] },
  { "data": "2026-03-06", "tipi": ["paper"] },
  { "data": "2026-03-10", "tipi": ["organic", "residual"] },
  { "data": "2026-03-13", "tipi": ["plastic_metals", "glass"] },
  { "data": "2026-03-17", "tipi": ["organic"] },
  { "data": "2026-03-20", "tipi": ["paper"] },
  { "data": "2026-03-24", "tipi": ["organic", "residual"] },
  { "data": "2026-03-27", "tipi": ["plastic_metals", "glass"] },
  { "data": "2026-03-31", "tipi": ["organic"] },

  { "data": "2026-04-03", "tipi": ["paper"] },
  { "data": "2026-04-07", "tipi": ["organic", "residual"] },
  { "data": "2026-04-10", "tipi": ["plastic_metals", "glass"] },
  { "data": "2026-04-14", "tipi": ["organic"] },
  { "data": "2026-04-17", "tipi": ["paper"] },
  { "data": "2026-04-21", "tipi": ["organic", "residual"] },
  { "data": "2026-04-24", "tipi": ["plastic_metals", "glass"] },
  { "data": "2026-04-28", "tipi": ["organic"] },

  { "data": "2026-05-02", "tipi": ["paper"] },
  { "data": "2026-05-05", "tipi": ["organic", "residual"] },
  { "data": "2026-05-08", "tipi": ["plastic_metals", "glass"] },
  { "data": "2026-05-12", "tipi": ["organic"] },
  { "data": "2026-05-15", "tipi": ["paper"] },
  { "data": "2026-05-19", "tipi": ["organic", "residual"] },
  { "data": "2026-05-22", "tipi": ["plastic_metals", "glass"] },
  { "data": "2026-05-26", "tipi": ["organic"] },
  { "data": "2026-05-29", "tipi": ["paper"] },

  { "data": "2026-06-02", "tipi": ["organic", "residual"] },
  { "data": "2026-06-05", "tipi": ["organic", "plastic_metals", "glass"] },
  { "data": "2026-06-09", "tipi": ["organic"] },
  { "data": "2026-06-12", "tipi": ["organic", "paper"] },
  { "data": "2026-06-16", "tipi": ["organic", "residual"] },
  { "data": "2026-06-19", "tipi": ["organic", "plastic_metals", "glass"] },
  { "data": "2026-06-23", "tipi": ["organic"] },
  { "data": "2026-06-26", "tipi": ["organic", "paper"] },
  { "data": "2026-06-30", "tipi": ["organic", "residual"] },

  { "data": "2026-07-03", "tipi": ["organic", "plastic_metals", "glass"] },
  { "data": "2026-07-07", "tipi": ["organic"] },
  { "data": "2026-07-10", "tipi": ["organic", "paper"] },
  { "data": "2026-07-14", "tipi": ["organic", "residual"] },
  { "data": "2026-07-17", "tipi": ["organic", "plastic_metals", "glass"] },
  { "data": "2026-07-21", "tipi": ["organic"] },
  { "data": "2026-07-24", "tipi": ["organic", "paper"] },
  { "data": "2026-07-28", "tipi": ["organic", "residual"] },
  { "data": "2026-07-31", "tipi": ["organic", "plastic_metals", "glass"] },

  { "data": "2026-08-04", "tipi": ["organic"] },
  { "data": "2026-08-07", "tipi": ["organic", "paper"] },
  { "data": "2026-08-11", "tipi": ["organic", "residual"] },
  { "data": "2026-08-14", "tipi": ["organic", "plastic_metals", "glass"] },
  { "data": "2026-08-18", "tipi": ["organic"] },
  { "data": "2026-08-21", "tipi": ["organic", "paper"] },
  { "data": "2026-08-25", "tipi": ["organic", "residual"] },
  { "data": "2026-08-28", "tipi": ["organic", "plastic_metals", "glass"] },

  { "data": "2026-09-01", "tipi": ["organic"] },
  { "data": "2026-09-04", "tipi": ["organic", "paper"] },
  { "data": "2026-09-08", "tipi": ["organic", "residual"] },
  { "data": "2026-09-11", "tipi": ["organic", "plastic_metals", "glass"] },
  { "data": "2026-09-15", "tipi": ["organic"] },
  { "data": "2026-09-18", "tipi": ["organic", "paper"] },
  { "data": "2026-09-22", "tipi": ["organic", "residual"] },
  { "data": "2026-09-25", "tipi": ["organic", "plastic_metals", "glass"] },
  { "data": "2026-09-29", "tipi": ["organic"] },

  { "data": "2026-10-02", "tipi": ["paper"] },
  { "data": "2026-10-06", "tipi": ["organic", "residual"] },
  { "data": "2026-10-09", "tipi": ["plastic_metals", "glass"] },
  { "data": "2026-10-13", "tipi": ["organic"] },
  { "data": "2026-10-16", "tipi": ["paper"] },
  { "data": "2026-10-20", "tipi": ["organic", "residual"] },
  { "data": "2026-10-23", "tipi": ["plastic_metals", "glass"] },
  { "data": "2026-10-27", "tipi": ["organic"] },
  { "data": "2026-10-30", "tipi": ["paper"] },

  { "data": "2026-11-03", "tipi": ["organic", "residual"] },
  { "data": "2026-11-06", "tipi": ["plastic_metals", "glass"] },
  { "data": "2026-11-10", "tipi": ["organic"] },
  { "data": "2026-11-13", "tipi": ["paper"] },
  { "data": "2026-11-17", "tipi": ["organic", "residual"] },
  { "data": "2026-11-20", "tipi": ["plastic_metals", "glass"] },
  { "data": "2026-11-24", "tipi": ["organic"] },
  { "data": "2026-11-27", "tipi": ["paper"] },

  { "data": "2026-12-01", "tipi": ["organic", "residual"] },
  { "data": "2026-12-04", "tipi": ["plastic_metals", "glass"] },
  { "data": "2026-12-08", "tipi": ["organic"] },
  { "data": "2026-12-11", "tipi": ["paper"] },
  { "data": "2026-12-15", "tipi": ["organic", "residual"] },
  { "data": "2026-12-18", "tipi": ["plastic_metals", "glass"] },
  { "data": "2026-12-22", "tipi": ["organic"] },
  { "data": "2026-12-26", "tipi": ["paper"] },
  { "data": "2026-12-29", "tipi": ["organic", "residual"] }
];

const RIFIUTI_GEA_VIVARO = [
  { data: "2026-01-07", tipi: ["organic", "glass"] },
  { data: "2026-01-09", tipi: ["plastic_metals"] },
  { data: "2026-01-12", tipi: ["residual"] },
  { data: "2026-01-13", tipi: ["paper"] },
  { data: "2026-01-14", tipi: ["organic"] },
  { data: "2026-01-21", tipi: ["organic", "glass"] },
  { data: "2026-01-23", tipi: ["plastic_metals"] },
  { data: "2026-01-26", tipi: ["residual"] },
  { data: "2026-01-27", tipi: ["paper"] },
  { data: "2026-01-28", tipi: ["organic"] },

  { data: "2026-02-04", tipi: ["organic", "glass"] },
  { data: "2026-02-06", tipi: ["plastic_metals"] },
  { data: "2026-02-09", tipi: ["residual"] },
  { data: "2026-02-10", tipi: ["paper"] },
  { data: "2026-02-11", tipi: ["organic"] },
  { data: "2026-02-18", tipi: ["organic", "glass"] },
  { data: "2026-02-20", tipi: ["plastic_metals"] },
  { data: "2026-02-23", tipi: ["residual"] },
  { data: "2026-02-24", tipi: ["paper"] },
  { data: "2026-02-25", tipi: ["organic"] },

  { data: "2026-03-04", tipi: ["organic", "glass"] },
  { data: "2026-03-06", tipi: ["plastic_metals"] },
  { data: "2026-03-09", tipi: ["residual"] },
  { data: "2026-03-10", tipi: ["paper"] },
  { data: "2026-03-11", tipi: ["organic"] },
  { data: "2026-03-18", tipi: ["organic", "glass"] },
  { data: "2026-03-20", tipi: ["plastic_metals"] },
  { data: "2026-03-23", tipi: ["residual"] },
  { data: "2026-03-24", tipi: ["paper"] },
  { data: "2026-03-25", tipi: ["organic"] },

  { data: "2026-04-01", tipi: ["organic", "glass"] },
  { data: "2026-04-03", tipi: ["plastic_metals"] },
  { data: "2026-04-04", tipi: ["residual"] },
  { data: "2026-04-07", tipi: ["paper"] },
  { data: "2026-04-08", tipi: ["organic"] },
  { data: "2026-04-15", tipi: ["organic", "glass"] },
  { data: "2026-04-17", tipi: ["plastic_metals"] },
  { data: "2026-04-20", tipi: ["residual"] },
  { data: "2026-04-21", tipi: ["paper"] },
  { data: "2026-04-22", tipi: ["organic"] },
  { data: "2026-04-29", tipi: ["organic", "glass"] },

  { data: "2026-05-02", tipi: ["plastic_metals"] },
  { data: "2026-05-04", tipi: ["residual"] },
  { data: "2026-05-05", tipi: ["paper"] },
  { data: "2026-05-06", tipi: ["organic"] },
  { data: "2026-05-13", tipi: ["organic", "glass"] },
  { data: "2026-05-15", tipi: ["plastic_metals"] },
  { data: "2026-05-18", tipi: ["residual"] },
  { data: "2026-05-19", tipi: ["paper"] },
  { data: "2026-05-20", tipi: ["organic"] },
  { data: "2026-05-27", tipi: ["organic", "glass"] },
  { data: "2026-05-29", tipi: ["plastic_metals"] },

  { data: "2026-06-01", tipi: ["residual"] },
  { data: "2026-06-02", tipi: ["paper"] },
  { data: "2026-06-03", tipi: ["organic"] },
  { data: "2026-06-06", tipi: ["organic"] },
  { data: "2026-06-10", tipi: ["organic", "glass"] },
  { data: "2026-06-12", tipi: ["plastic_metals"] },
  { data: "2026-06-13", tipi: ["organic"] },
  { data: "2026-06-15", tipi: ["residual"] },
  { data: "2026-06-16", tipi: ["paper"] },
  { data: "2026-06-17", tipi: ["organic"] },
  { data: "2026-06-20", tipi: ["organic"] },
  { data: "2026-06-24", tipi: ["organic", "glass"] },
  { data: "2026-06-26", tipi: ["plastic_metals"] },
  { data: "2026-06-27", tipi: ["organic"] },
  { data: "2026-06-29", tipi: ["residual"] },
  { data: "2026-06-30", tipi: ["paper"] },

  { data: "2026-07-01", tipi: ["organic"] },
  { data: "2026-07-04", tipi: ["organic"] },
  { data: "2026-07-08", tipi: ["organic", "glass"] },
  { data: "2026-07-10", tipi: ["plastic_metals"] },
  { data: "2026-07-11", tipi: ["organic"] },
  { data: "2026-07-13", tipi: ["residual"] },
  { data: "2026-07-14", tipi: ["paper"] },
  { data: "2026-07-15", tipi: ["organic"] },
  { data: "2026-07-18", tipi: ["organic"] },
  { data: "2026-07-22", tipi: ["organic", "glass"] },
  { data: "2026-07-24", tipi: ["plastic_metals"] },
  { data: "2026-07-25", tipi: ["organic"] },
  { data: "2026-07-27", tipi: ["residual"] },
  { data: "2026-07-28", tipi: ["paper"] },
  { data: "2026-07-29", tipi: ["organic"] },

  { data: "2026-08-01", tipi: ["organic"] },
  { data: "2026-08-05", tipi: ["organic", "glass"] },
  { data: "2026-08-07", tipi: ["plastic_metals"] },
  { data: "2026-08-08", tipi: ["organic"] },
  { data: "2026-08-10", tipi: ["residual"] },
  { data: "2026-08-11", tipi: ["paper"] },
  { data: "2026-08-12", tipi: ["organic"] },
  { data: "2026-08-19", tipi: ["organic", "glass"] },
  { data: "2026-08-21", tipi: ["plastic_metals"] },
  { data: "2026-08-22", tipi: ["organic"] },
  { data: "2026-08-24", tipi: ["residual"] },
  { data: "2026-08-25", tipi: ["paper"] },
  { data: "2026-08-26", tipi: ["organic"] },
  { data: "2026-08-29", tipi: ["organic"] },

  { data: "2026-09-02", tipi: ["organic", "glass"] },
  { data: "2026-09-04", tipi: ["plastic_metals"] },
  { data: "2026-09-05", tipi: ["organic"] },
  { data: "2026-09-07", tipi: ["residual"] },
  { data: "2026-09-08", tipi: ["paper"] },
  { data: "2026-09-09", tipi: ["organic"] },
  { data: "2026-09-12", tipi: ["organic"] },
  { data: "2026-09-16", tipi: ["organic", "glass"] },
  { data: "2026-09-18", tipi: ["plastic_metals"] },
  { data: "2026-09-19", tipi: ["organic"] },
  { data: "2026-09-21", tipi: ["residual"] },
  { data: "2026-09-22", tipi: ["paper"] },
  { data: "2026-09-23", tipi: ["organic"] },
  { data: "2026-09-26", tipi: ["organic"] },
  { data: "2026-09-30", tipi: ["organic", "glass"] },

  { data: "2026-10-02", tipi: ["plastic_metals"] },
  { data: "2026-10-05", tipi: ["residual"] },
  { data: "2026-10-06", tipi: ["paper"] },
  { data: "2026-10-07", tipi: ["organic"] },
  { data: "2026-10-14", tipi: ["organic", "glass"] },
  { data: "2026-10-16", tipi: ["plastic_metals"] },
  { data: "2026-10-19", tipi: ["residual"] },
  { data: "2026-10-20", tipi: ["paper"] },
  { data: "2026-10-21", tipi: ["organic"] },
  { data: "2026-10-28", tipi: ["organic", "glass"] },
  { data: "2026-10-30", tipi: ["plastic_metals"] },

  { data: "2026-11-02", tipi: ["residual"] },
  { data: "2026-11-03", tipi: ["paper"] },
  { data: "2026-11-04", tipi: ["organic"] },
  { data: "2026-11-11", tipi: ["organic", "glass"] },
  { data: "2026-11-13", tipi: ["plastic_metals"] },
  { data: "2026-11-16", tipi: ["residual"] },
  { data: "2026-11-17", tipi: ["paper"] },
  { data: "2026-11-18", tipi: ["organic"] },
  { data: "2026-11-25", tipi: ["organic", "glass"] },
  { data: "2026-11-27", tipi: ["plastic_metals"] },
  { data: "2026-11-30", tipi: ["residual"] },

  { data: "2026-12-01", tipi: ["paper"] },
  { data: "2026-12-02", tipi: ["organic"] },
  { data: "2026-12-09", tipi: ["organic", "glass"] },
  { data: "2026-12-11", tipi: ["plastic_metals"] },
  { data: "2026-12-14", tipi: ["residual"] },
  { data: "2026-12-15", tipi: ["paper"] },
  { data: "2026-12-16", tipi: ["organic"] },
  { data: "2026-12-23", tipi: ["organic", "glass"] },
  { data: "2026-12-26", tipi: ["plastic_metals"] },
  { data: "2026-12-28", tipi: ["residual"] },
  { data: "2026-12-29", tipi: ["paper"] },
  { data: "2026-12-30", tipi: ["organic"] },
];


const RIFIUTI_GEA_MANIAGO_ZONA_A = [
  { data: "2026-01-03", tipi: ["organic"] },
  { data: "2026-01-07", tipi: ["organic"] },
  { data: "2026-01-08", tipi: ["plastic_metals"] },
  { data: "2026-01-09", tipi: ["glass"] },
  { data: "2026-01-10", tipi: ["organic"] },
  { data: "2026-01-12", tipi: ["residual"] },
  { data: "2026-01-13", tipi: ["paper"] },
  { data: "2026-01-14", tipi: ["organic"] },
  { data: "2026-01-17", tipi: ["organic"] },
  { data: "2026-01-21", tipi: ["organic"] },
  { data: "2026-01-22", tipi: ["plastic_metals"] },
  { data: "2026-01-23", tipi: ["glass"] },
  { data: "2026-01-24", tipi: ["organic"] },
  { data: "2026-01-26", tipi: ["residual"] },
  { data: "2026-01-27", tipi: ["paper"] },
  { data: "2026-01-28", tipi: ["organic"] },
  { data: "2026-01-31", tipi: ["organic"] },
  { data: "2026-02-04", tipi: ["organic"] },
  { data: "2026-02-05", tipi: ["plastic_metals"] },
  { data: "2026-02-06", tipi: ["glass"] },
  { data: "2026-02-07", tipi: ["organic"] },
  { data: "2026-02-09", tipi: ["residual"] },
  { data: "2026-02-10", tipi: ["paper"] },
  { data: "2026-02-11", tipi: ["organic"] },
  { data: "2026-02-14", tipi: ["organic"] },
  { data: "2026-02-18", tipi: ["organic"] },
  { data: "2026-02-19", tipi: ["plastic_metals"] },
  { data: "2026-02-20", tipi: ["glass"] },
  { data: "2026-02-21", tipi: ["organic"] },
  { data: "2026-02-23", tipi: ["residual"] },
  { data: "2026-02-24", tipi: ["paper"] },
  { data: "2026-02-25", tipi: ["organic"] },
  { data: "2026-02-28", tipi: ["organic"] },
  { data: "2026-03-04", tipi: ["organic"] },
  { data: "2026-03-05", tipi: ["plastic_metals"] },
  { data: "2026-03-06", tipi: ["glass"] },
  { data: "2026-03-07", tipi: ["organic"] },
  { data: "2026-03-09", tipi: ["residual"] },
  { data: "2026-03-10", tipi: ["paper"] },
  { data: "2026-03-11", tipi: ["organic"] },
  { data: "2026-03-14", tipi: ["organic"] },
  { data: "2026-03-18", tipi: ["organic"] },
  { data: "2026-03-19", tipi: ["plastic_metals"] },
  { data: "2026-03-20", tipi: ["glass"] },
  { data: "2026-03-21", tipi: ["organic"] },
  { data: "2026-03-23", tipi: ["residual"] },
  { data: "2026-03-24", tipi: ["paper"] },
  { data: "2026-03-25", tipi: ["organic"] },
  { data: "2026-03-28", tipi: ["organic"] },
  { data: "2026-04-01", tipi: ["organic"] },
  { data: "2026-04-02", tipi: ["plastic_metals"] },
  { data: "2026-04-03", tipi: ["glass"] },
  { data: "2026-04-04", tipi: ["organic"] },
  { data: "2026-04-06", tipi: ["residual"] },
  { data: "2026-04-07", tipi: ["paper"] },
  { data: "2026-04-08", tipi: ["organic"] },
  { data: "2026-04-11", tipi: ["organic"] },
  { data: "2026-04-15", tipi: ["organic"] },
  { data: "2026-04-16", tipi: ["plastic_metals"] },
  { data: "2026-04-17", tipi: ["glass"] },
  { data: "2026-04-18", tipi: ["organic"] },
  { data: "2026-04-20", tipi: ["residual"] },
  { data: "2026-04-21", tipi: ["paper"] },
  { data: "2026-04-22", tipi: ["organic"] },
  { data: "2026-04-25", tipi: ["organic"] },
  { data: "2026-04-29", tipi: ["organic"] },
  { data: "2026-04-30", tipi: ["plastic_metals"] },
  { data: "2026-05-02", tipi: ["organic", "glass"] },
  { data: "2026-05-04", tipi: ["residual"] },
  { data: "2026-05-05", tipi: ["paper"] },
  { data: "2026-05-06", tipi: ["organic"] },
  { data: "2026-05-09", tipi: ["organic"] },
  { data: "2026-05-13", tipi: ["organic"] },
  { data: "2026-05-14", tipi: ["plastic_metals"] },
  { data: "2026-05-15", tipi: ["glass"] },
  { data: "2026-05-16", tipi: ["organic"] },
  { data: "2026-05-18", tipi: ["residual"] },
  { data: "2026-05-19", tipi: ["paper"] },
  { data: "2026-05-20", tipi: ["organic"] },
  { data: "2026-05-23", tipi: ["organic"] },
  { data: "2026-05-27", tipi: ["organic"] },
  { data: "2026-05-28", tipi: ["plastic_metals"] },
  { data: "2026-05-29", tipi: ["glass"] },
  { data: "2026-05-30", tipi: ["organic"] },
  { data: "2026-06-01", tipi: ["residual"] },
  { data: "2026-06-02", tipi: ["paper"] },
  { data: "2026-06-03", tipi: ["organic"] },
  { data: "2026-06-06", tipi: ["organic"] },
  { data: "2026-06-10", tipi: ["organic"] },
  { data: "2026-06-11", tipi: ["plastic_metals"] },
  { data: "2026-06-12", tipi: ["glass"] },
  { data: "2026-06-13", tipi: ["organic"] },
  { data: "2026-06-15", tipi: ["residual"] },
  { data: "2026-06-16", tipi: ["paper"] },
  { data: "2026-06-17", tipi: ["organic"] },
  { data: "2026-06-20", tipi: ["organic"] },
  { data: "2026-06-24", tipi: ["organic"] },
  { data: "2026-06-25", tipi: ["plastic_metals"] },
  { data: "2026-06-26", tipi: ["glass"] },
  { data: "2026-06-27", tipi: ["organic"] },
  { data: "2026-06-29", tipi: ["residual"] },
  { data: "2026-06-30", tipi: ["paper"] },
  { data: "2026-07-01", tipi: ["organic"] },
  { data: "2026-07-04", tipi: ["organic"] },
  { data: "2026-07-08", tipi: ["organic"] },
  { data: "2026-07-09", tipi: ["plastic_metals"] },
  { data: "2026-07-10", tipi: ["glass"] },
  { data: "2026-07-11", tipi: ["organic"] },
  { data: "2026-07-13", tipi: ["residual"] },
  { data: "2026-07-14", tipi: ["paper"] },
  { data: "2026-07-15", tipi: ["organic"] },
  { data: "2026-07-18", tipi: ["organic"] },
  { data: "2026-07-22", tipi: ["organic"] },
  { data: "2026-07-23", tipi: ["plastic_metals"] },
  { data: "2026-07-24", tipi: ["glass"] },
  { data: "2026-07-25", tipi: ["organic"] },
  { data: "2026-07-27", tipi: ["residual"] },
  { data: "2026-07-28", tipi: ["paper"] },
  { data: "2026-07-29", tipi: ["organic"] },
  { data: "2026-08-01", tipi: ["organic"] },
  { data: "2026-08-05", tipi: ["organic"] },
  { data: "2026-08-06", tipi: ["plastic_metals"] },
  { data: "2026-08-07", tipi: ["glass"] },
  { data: "2026-08-08", tipi: ["organic"] },
  { data: "2026-08-10", tipi: ["residual"] },
  { data: "2026-08-11", tipi: ["paper"] },
  { data: "2026-08-12", tipi: ["organic"] },
  { data: "2026-08-19", tipi: ["organic"] },
  { data: "2026-08-20", tipi: ["plastic_metals"] },
  { data: "2026-08-21", tipi: ["glass"] },
  { data: "2026-08-22", tipi: ["organic"] },
  { data: "2026-08-24", tipi: ["residual"] },
  { data: "2026-08-25", tipi: ["paper"] },
  { data: "2026-08-26", tipi: ["organic"] },
  { data: "2026-08-29", tipi: ["organic"] },
  { data: "2026-09-02", tipi: ["organic"] },
  { data: "2026-09-03", tipi: ["plastic_metals"] },
  { data: "2026-09-04", tipi: ["glass"] },
  { data: "2026-09-05", tipi: ["organic"] },
  { data: "2026-09-07", tipi: ["residual"] },
  { data: "2026-09-08", tipi: ["paper"] },
  { data: "2026-09-09", tipi: ["organic"] },
  { data: "2026-09-12", tipi: ["organic"] },
  { data: "2026-09-16", tipi: ["organic"] },
  { data: "2026-09-17", tipi: ["plastic_metals"] },
  { data: "2026-09-18", tipi: ["glass"] },
  { data: "2026-09-19", tipi: ["organic"] },
  { data: "2026-09-21", tipi: ["residual"] },
  { data: "2026-09-22", tipi: ["paper"] },
  { data: "2026-09-23", tipi: ["organic"] },
  { data: "2026-09-26", tipi: ["organic"] },
  { data: "2026-09-30", tipi: ["organic"] },
  { data: "2026-10-01", tipi: ["plastic_metals"] },
  { data: "2026-10-02", tipi: ["glass"] },
  { data: "2026-10-03", tipi: ["organic"] },
  { data: "2026-10-05", tipi: ["residual"] },
  { data: "2026-10-06", tipi: ["paper"] },
  { data: "2026-10-07", tipi: ["organic"] },
  { data: "2026-10-10", tipi: ["organic"] },
  { data: "2026-10-14", tipi: ["organic"] },
  { data: "2026-10-15", tipi: ["plastic_metals"] },
  { data: "2026-10-16", tipi: ["glass"] },
  { data: "2026-10-17", tipi: ["organic"] },
  { data: "2026-10-19", tipi: ["residual"] },
  { data: "2026-10-20", tipi: ["paper"] },
  { data: "2026-10-21", tipi: ["organic"] },
  { data: "2026-10-24", tipi: ["organic"] },
  { data: "2026-10-28", tipi: ["organic"] },
  { data: "2026-10-29", tipi: ["plastic_metals"] },
  { data: "2026-10-30", tipi: ["glass"] },
  { data: "2026-10-31", tipi: ["organic"] },
  { data: "2026-11-02", tipi: ["residual"] },
  { data: "2026-11-03", tipi: ["paper"] },
  { data: "2026-11-04", tipi: ["organic"] },
  { data: "2026-11-07", tipi: ["organic"] },
  { data: "2026-11-11", tipi: ["organic"] },
  { data: "2026-11-12", tipi: ["plastic_metals"] },
  { data: "2026-11-13", tipi: ["glass"] },
  { data: "2026-11-14", tipi: ["organic"] },
  { data: "2026-11-16", tipi: ["residual"] },
  { data: "2026-11-17", tipi: ["paper"] },
  { data: "2026-11-18", tipi: ["organic"] },
  { data: "2026-11-21", tipi: ["organic"] },
  { data: "2026-11-25", tipi: ["organic"] },
  { data: "2026-11-26", tipi: ["plastic_metals"] },
  { data: "2026-11-27", tipi: ["glass"] },
  { data: "2026-11-28", tipi: ["organic"] },
  { data: "2026-11-30", tipi: ["residual"] },
  { data: "2026-12-01", tipi: ["paper"] },
  { data: "2026-12-02", tipi: ["organic"] },
  { data: "2026-12-05", tipi: ["organic"] },
  { data: "2026-12-09", tipi: ["organic"] },
  { data: "2026-12-10", tipi: ["plastic_metals"] },
  { data: "2026-12-11", tipi: ["glass"] },
  { data: "2026-12-12", tipi: ["organic"] },
  { data: "2026-12-14", tipi: ["residual"] },
  { data: "2026-12-15", tipi: ["paper"] },
  { data: "2026-12-16", tipi: ["organic"] },
  { data: "2026-12-19", tipi: ["organic"] },
  { data: "2026-12-23", tipi: ["organic"] },
  { data: "2026-12-24", tipi: ["plastic_metals"] },
  { data: "2026-12-26", tipi: ["organic", "glass"] },
  { data: "2026-12-28", tipi: ["residual"] },
  { data: "2026-12-29", tipi: ["paper"] },
  { data: "2026-12-30", tipi: ["organic"] },
];

const RIFIUTI_GEA_MANIAGO_ZONA_B = [
  { data: "2026-01-02", tipi: ["glass", "plastic_metals"] },
  { data: "2026-01-03", tipi: ["organic"] },
  { data: "2026-01-05", tipi: ["residual"] },
  { data: "2026-01-06", tipi: ["paper"] },
  { data: "2026-01-07", tipi: ["organic"] },
  { data: "2026-01-10", tipi: ["organic"] },
  { data: "2026-01-14", tipi: ["organic"] },
  { data: "2026-01-15", tipi: ["plastic_metals"] },
  { data: "2026-01-16", tipi: ["glass"] },
  { data: "2026-01-17", tipi: ["organic"] },
  { data: "2026-01-19", tipi: ["residual"] },
  { data: "2026-01-20", tipi: ["paper"] },
  { data: "2026-01-21", tipi: ["organic"] },
  { data: "2026-01-24", tipi: ["organic"] },
  { data: "2026-01-28", tipi: ["organic"] },
  { data: "2026-01-29", tipi: ["plastic_metals"] },
  { data: "2026-01-30", tipi: ["glass"] },
  { data: "2026-01-31", tipi: ["organic"] },
  { data: "2026-02-02", tipi: ["residual"] },
  { data: "2026-02-03", tipi: ["paper"] },
  { data: "2026-02-04", tipi: ["organic"] },
  { data: "2026-02-07", tipi: ["organic"] },
  { data: "2026-02-11", tipi: ["organic"] },
  { data: "2026-02-12", tipi: ["plastic_metals"] },
  { data: "2026-02-13", tipi: ["glass"] },
  { data: "2026-02-14", tipi: ["organic"] },
  { data: "2026-02-16", tipi: ["residual"] },
  { data: "2026-02-17", tipi: ["paper"] },
  { data: "2026-02-18", tipi: ["organic"] },
  { data: "2026-02-21", tipi: ["organic"] },
  { data: "2026-02-25", tipi: ["organic"] },
  { data: "2026-02-26", tipi: ["plastic_metals"] },
  { data: "2026-02-27", tipi: ["glass"] },
  { data: "2026-02-28", tipi: ["organic"] },
  { data: "2026-03-02", tipi: ["residual"] },
  { data: "2026-03-03", tipi: ["paper"] },
  { data: "2026-03-04", tipi: ["organic"] },
  { data: "2026-03-07", tipi: ["organic"] },
  { data: "2026-03-11", tipi: ["organic"] },
  { data: "2026-03-12", tipi: ["plastic_metals"] },
  { data: "2026-03-13", tipi: ["glass"] },
  { data: "2026-03-14", tipi: ["organic"] },
  { data: "2026-03-16", tipi: ["residual"] },
  { data: "2026-03-17", tipi: ["paper"] },
  { data: "2026-03-18", tipi: ["organic"] },
  { data: "2026-03-21", tipi: ["organic"] },
  { data: "2026-03-25", tipi: ["organic"] },
  { data: "2026-03-26", tipi: ["plastic_metals"] },
  { data: "2026-03-27", tipi: ["glass"] },
  { data: "2026-03-28", tipi: ["organic"] },
  { data: "2026-03-30", tipi: ["residual"] },
  { data: "2026-03-31", tipi: ["paper"] },
  { data: "2026-04-01", tipi: ["organic"] },
  { data: "2026-04-04", tipi: ["organic"] },
  { data: "2026-04-08", tipi: ["organic"] },
  { data: "2026-04-09", tipi: ["plastic_metals"] },
  { data: "2026-04-10", tipi: ["glass"] },
  { data: "2026-04-11", tipi: ["organic"] },
  { data: "2026-04-13", tipi: ["residual"] },
  { data: "2026-04-14", tipi: ["paper"] },
  { data: "2026-04-15", tipi: ["organic"] },
  { data: "2026-04-18", tipi: ["organic"] },
  { data: "2026-04-22", tipi: ["organic"] },
  { data: "2026-04-23", tipi: ["plastic_metals"] },
  { data: "2026-04-24", tipi: ["glass"] },
  { data: "2026-04-25", tipi: ["organic"] },
  { data: "2026-04-27", tipi: ["residual"] },
  { data: "2026-04-28", tipi: ["paper"] },
  { data: "2026-04-29", tipi: ["organic"] },
  { data: "2026-05-02", tipi: ["organic"] },
  { data: "2026-05-06", tipi: ["organic"] },
  { data: "2026-05-07", tipi: ["plastic_metals"] },
  { data: "2026-05-08", tipi: ["glass"] },
  { data: "2026-05-09", tipi: ["organic"] },
  { data: "2026-05-11", tipi: ["residual"] },
  { data: "2026-05-12", tipi: ["paper"] },
  { data: "2026-05-13", tipi: ["organic"] },
  { data: "2026-05-16", tipi: ["organic"] },
  { data: "2026-05-20", tipi: ["organic"] },
  { data: "2026-05-21", tipi: ["plastic_metals"] },
  { data: "2026-05-22", tipi: ["glass"] },
  { data: "2026-05-23", tipi: ["organic"] },
  { data: "2026-05-25", tipi: ["residual"] },
  { data: "2026-05-26", tipi: ["paper"] },
  { data: "2026-05-27", tipi: ["organic"] },
  { data: "2026-05-30", tipi: ["organic"] },
  { data: "2026-06-03", tipi: ["organic"] },
  { data: "2026-06-04", tipi: ["plastic_metals"] },
  { data: "2026-06-05", tipi: ["glass"] },
  { data: "2026-06-06", tipi: ["organic"] },
  { data: "2026-06-08", tipi: ["residual"] },
  { data: "2026-06-09", tipi: ["paper"] },
  { data: "2026-06-10", tipi: ["organic"] },
  { data: "2026-06-13", tipi: ["organic"] },
  { data: "2026-06-17", tipi: ["organic"] },
  { data: "2026-06-18", tipi: ["plastic_metals"] },
  { data: "2026-06-19", tipi: ["glass"] },
  { data: "2026-06-20", tipi: ["organic"] },
  { data: "2026-06-22", tipi: ["residual"] },
  { data: "2026-06-23", tipi: ["paper"] },
  { data: "2026-06-24", tipi: ["organic"] },
  { data: "2026-06-27", tipi: ["organic"] },
  { data: "2026-07-01", tipi: ["organic"] },
  { data: "2026-07-02", tipi: ["plastic_metals"] },
  { data: "2026-07-03", tipi: ["glass"] },
  { data: "2026-07-04", tipi: ["organic"] },
  { data: "2026-07-06", tipi: ["residual"] },
  { data: "2026-07-07", tipi: ["paper"] },
  { data: "2026-07-08", tipi: ["organic"] },
  { data: "2026-07-11", tipi: ["organic"] },
  { data: "2026-07-15", tipi: ["organic"] },
  { data: "2026-07-16", tipi: ["plastic_metals"] },
  { data: "2026-07-17", tipi: ["glass"] },
  { data: "2026-07-18", tipi: ["organic"] },
  { data: "2026-07-20", tipi: ["residual"] },
  { data: "2026-07-21", tipi: ["paper"] },
  { data: "2026-07-22", tipi: ["organic"] },
  { data: "2026-07-25", tipi: ["organic"] },
  { data: "2026-07-29", tipi: ["organic"] },
  { data: "2026-07-30", tipi: ["plastic_metals"] },
  { data: "2026-07-31", tipi: ["glass"] },
  { data: "2026-08-01", tipi: ["organic"] },
  { data: "2026-08-03", tipi: ["residual"] },
  { data: "2026-08-04", tipi: ["paper"] },
  { data: "2026-08-05", tipi: ["organic"] },
  { data: "2026-08-08", tipi: ["organic"] },
  { data: "2026-08-12", tipi: ["organic"] },
  { data: "2026-08-13", tipi: ["plastic_metals"] },
  { data: "2026-08-14", tipi: ["glass"] },
  { data: "2026-08-17", tipi: ["residual"] },
  { data: "2026-08-18", tipi: ["paper"] },
  { data: "2026-08-19", tipi: ["organic"] },
  { data: "2026-08-22", tipi: ["organic"] },
  { data: "2026-08-26", tipi: ["organic"] },
  { data: "2026-08-27", tipi: ["plastic_metals"] },
  { data: "2026-08-28", tipi: ["glass"] },
  { data: "2026-08-29", tipi: ["organic"] },
  { data: "2026-08-31", tipi: ["residual"] },
  { data: "2026-09-01", tipi: ["paper"] },
  { data: "2026-09-02", tipi: ["organic"] },
  { data: "2026-09-05", tipi: ["organic"] },
  { data: "2026-09-09", tipi: ["organic"] },
  { data: "2026-09-10", tipi: ["plastic_metals"] },
  { data: "2026-09-11", tipi: ["glass"] },
  { data: "2026-09-12", tipi: ["organic"] },
  { data: "2026-09-14", tipi: ["residual"] },
  { data: "2026-09-15", tipi: ["paper"] },
  { data: "2026-09-16", tipi: ["organic"] },
  { data: "2026-09-19", tipi: ["organic"] },
  { data: "2026-09-23", tipi: ["organic"] },
  { data: "2026-09-24", tipi: ["plastic_metals"] },
  { data: "2026-09-25", tipi: ["glass"] },
  { data: "2026-09-26", tipi: ["organic"] },
  { data: "2026-09-28", tipi: ["residual"] },
  { data: "2026-09-29", tipi: ["paper"] },
  { data: "2026-09-30", tipi: ["organic"] },
  { data: "2026-10-03", tipi: ["organic"] },
  { data: "2026-10-07", tipi: ["organic"] },
  { data: "2026-10-08", tipi: ["plastic_metals"] },
  { data: "2026-10-09", tipi: ["glass"] },
  { data: "2026-10-10", tipi: ["organic"] },
  { data: "2026-10-12", tipi: ["residual"] },
  { data: "2026-10-13", tipi: ["paper"] },
  { data: "2026-10-14", tipi: ["organic"] },
  { data: "2026-10-17", tipi: ["organic"] },
  { data: "2026-10-21", tipi: ["organic"] },
  { data: "2026-10-22", tipi: ["plastic_metals"] },
  { data: "2026-10-23", tipi: ["glass"] },
  { data: "2026-10-24", tipi: ["organic"] },
  { data: "2026-10-26", tipi: ["residual"] },
  { data: "2026-10-27", tipi: ["paper"] },
  { data: "2026-10-28", tipi: ["organic"] },
  { data: "2026-10-31", tipi: ["organic"] },
  { data: "2026-11-04", tipi: ["organic"] },
  { data: "2026-11-05", tipi: ["plastic_metals"] },
  { data: "2026-11-06", tipi: ["glass"] },
  { data: "2026-11-07", tipi: ["organic"] },
  { data: "2026-11-09", tipi: ["residual"] },
  { data: "2026-11-10", tipi: ["paper"] },
  { data: "2026-11-11", tipi: ["organic"] },
  { data: "2026-11-14", tipi: ["organic"] },
  { data: "2026-11-18", tipi: ["organic"] },
  { data: "2026-11-19", tipi: ["plastic_metals"] },
  { data: "2026-11-20", tipi: ["glass"] },
  { data: "2026-11-21", tipi: ["organic"] },
  { data: "2026-11-23", tipi: ["residual"] },
  { data: "2026-11-24", tipi: ["paper"] },
  { data: "2026-11-25", tipi: ["organic"] },
  { data: "2026-11-28", tipi: ["organic"] },
  { data: "2026-12-02", tipi: ["organic"] },
  { data: "2026-12-03", tipi: ["plastic_metals"] },
  { data: "2026-12-04", tipi: ["glass"] },
  { data: "2026-12-05", tipi: ["organic"] },
  { data: "2026-12-07", tipi: ["residual"] },
  { data: "2026-12-08", tipi: ["paper"] },
  { data: "2026-12-09", tipi: ["organic"] },
  { data: "2026-12-12", tipi: ["organic"] },
  { data: "2026-12-16", tipi: ["organic"] },
  { data: "2026-12-17", tipi: ["plastic_metals"] },
  { data: "2026-12-18", tipi: ["glass"] },
  { data: "2026-12-19", tipi: ["organic"] },
  { data: "2026-12-21", tipi: ["residual"] },
  { data: "2026-12-22", tipi: ["paper"] },
  { data: "2026-12-23", tipi: ["organic"] },
  { data: "2026-12-26", tipi: ["organic"] },
  { data: "2026-12-30", tipi: ["organic"] },
  { data: "2026-12-31", tipi: ["plastic_metals"] },
];

const RIFIUTI_GEA_MEDUNO = [
  { "data": "2026-01-03", "tipi": ["plastic_metals"] },
  { "data": "2026-01-05", "tipi": ["organic"] },
  { "data": "2026-01-08", "tipi": ["residual", "paper"] },
  { "data": "2026-01-12", "tipi": ["organic"] },
  { "data": "2026-01-14", "tipi": ["glass"] },
  { "data": "2026-01-15", "tipi": ["plastic_metals"] },
  { "data": "2026-01-19", "tipi": ["organic"] },
  { "data": "2026-01-22", "tipi": ["residual", "paper"] },
  { "data": "2026-01-26", "tipi": ["organic"] },
  { "data": "2026-01-28", "tipi": ["glass"] },
  { "data": "2026-01-29", "tipi": ["plastic_metals"] },

  { "data": "2026-02-02", "tipi": ["organic"] },
  { "data": "2026-02-05", "tipi": ["residual", "paper"] },
  { "data": "2026-02-09", "tipi": ["organic"] },
  { "data": "2026-02-11", "tipi": ["glass"] },
  { "data": "2026-02-12", "tipi": ["plastic_metals"] },
  { "data": "2026-02-16", "tipi": ["organic"] },
  { "data": "2026-02-19", "tipi": ["residual", "paper"] },
  { "data": "2026-02-23", "tipi": ["organic"] },
  { "data": "2026-02-25", "tipi": ["glass"] },
  { "data": "2026-02-26", "tipi": ["plastic_metals"] },

  { "data": "2026-03-02", "tipi": ["organic"] },
  { "data": "2026-03-05", "tipi": ["residual", "paper"] },
  { "data": "2026-03-09", "tipi": ["organic"] },
  { "data": "2026-03-11", "tipi": ["glass"] },
  { "data": "2026-03-12", "tipi": ["plastic_metals"] },
  { "data": "2026-03-16", "tipi": ["organic"] },
  { "data": "2026-03-19", "tipi": ["residual", "paper"] },
  { "data": "2026-03-23", "tipi": ["organic"] },
  { "data": "2026-03-25", "tipi": ["glass"] },
  { "data": "2026-03-26", "tipi": ["plastic_metals"] },
  { "data": "2026-03-30", "tipi": ["organic"] },

  { "data": "2026-04-02", "tipi": ["residual", "paper"] },
  { "data": "2026-04-04", "tipi": ["organic"] },
  { "data": "2026-04-08", "tipi": ["glass"] },
  { "data": "2026-04-09", "tipi": ["plastic_metals"] },
  { "data": "2026-04-13", "tipi": ["organic"] },
  { "data": "2026-04-16", "tipi": ["residual", "paper"] },
  { "data": "2026-04-20", "tipi": ["organic"] },
  { "data": "2026-04-22", "tipi": ["glass"] },
  { "data": "2026-04-23", "tipi": ["plastic_metals"] },
  { "data": "2026-04-27", "tipi": ["organic"] },
  { "data": "2026-04-30", "tipi": ["residual", "paper"] },

  { "data": "2026-05-04", "tipi": ["organic"] },
  { "data": "2026-05-06", "tipi": ["glass"] },
  { "data": "2026-05-07", "tipi": ["plastic_metals"] },
  { "data": "2026-05-11", "tipi": ["organic"] },
  { "data": "2026-05-14", "tipi": ["residual", "paper"] },
  { "data": "2026-05-18", "tipi": ["organic"] },
  { "data": "2026-05-20", "tipi": ["glass"] },
  { "data": "2026-05-21", "tipi": ["plastic_metals"] },
  { "data": "2026-05-25", "tipi": ["organic"] },
  { "data": "2026-05-28", "tipi": ["residual", "paper"] },

  { "data": "2026-06-01", "tipi": ["organic"] },
  { "data": "2026-06-03", "tipi": ["glass"] },
  { "data": "2026-06-04", "tipi": ["plastic_metals", "organic"] },
  { "data": "2026-06-08", "tipi": ["organic"] },
  { "data": "2026-06-11", "tipi": ["residual", "paper", "organic"] },
  { "data": "2026-06-15", "tipi": ["organic"] },
  { "data": "2026-06-17", "tipi": ["glass"] },
  { "data": "2026-06-18", "tipi": ["plastic_metals", "organic"] },
  { "data": "2026-06-22", "tipi": ["organic"] },
  { "data": "2026-06-25", "tipi": ["residual", "paper", "organic"] },
  { "data": "2026-06-29", "tipi": ["organic"] },

  { "data": "2026-07-01", "tipi": ["glass"] },
  { "data": "2026-07-02", "tipi": ["plastic_metals", "organic"] },
  { "data": "2026-07-06", "tipi": ["organic"] },
  { "data": "2026-07-09", "tipi": ["residual", "paper", "organic"] },
  { "data": "2026-07-13", "tipi": ["organic"] },
  { "data": "2026-07-15", "tipi": ["glass"] },
  { "data": "2026-07-16", "tipi": ["plastic_metals", "organic"] },
  { "data": "2026-07-20", "tipi": ["organic"] },
  { "data": "2026-07-23", "tipi": ["residual", "paper", "organic"] },
  { "data": "2026-07-27", "tipi": ["organic"] },
  { "data": "2026-07-29", "tipi": ["glass"] },
  { "data": "2026-07-30", "tipi": ["plastic_metals", "organic"] },

  { "data": "2026-08-03", "tipi": ["organic"] },
  { "data": "2026-08-06", "tipi": ["residual", "paper", "organic"] },
  { "data": "2026-08-10", "tipi": ["organic"] },
  { "data": "2026-08-12", "tipi": ["glass"] },
  { "data": "2026-08-13", "tipi": ["plastic_metals", "organic"] },
  { "data": "2026-08-17", "tipi": ["organic"] },
  { "data": "2026-08-20", "tipi": ["residual", "paper", "organic"] },
  { "data": "2026-08-24", "tipi": ["organic"] },
  { "data": "2026-08-26", "tipi": ["glass"] },
  { "data": "2026-08-27", "tipi": ["plastic_metals", "organic"] },
  { "data": "2026-08-31", "tipi": ["organic"] },

  { "data": "2026-09-03", "tipi": ["residual", "paper", "organic"] },
  { "data": "2026-09-07", "tipi": ["organic"] },
  { "data": "2026-09-09", "tipi": ["glass"] },
  { "data": "2026-09-10", "tipi": ["plastic_metals", "organic"] },
  { "data": "2026-09-14", "tipi": ["organic"] },
  { "data": "2026-09-17", "tipi": ["residual", "paper", "organic"] },
  { "data": "2026-09-21", "tipi": ["organic"] },
  { "data": "2026-09-23", "tipi": ["glass"] },
  { "data": "2026-09-24", "tipi": ["plastic_metals", "organic"] },
  { "data": "2026-09-28", "tipi": ["organic"] },

  { "data": "2026-10-01", "tipi": ["residual", "paper"] },
  { "data": "2026-10-05", "tipi": ["organic"] },
  { "data": "2026-10-07", "tipi": ["glass"] },
  { "data": "2026-10-08", "tipi": ["plastic_metals"] },
  { "data": "2026-10-12", "tipi": ["organic"] },
  { "data": "2026-10-15", "tipi": ["residual", "paper"] },
  { "data": "2026-10-19", "tipi": ["organic"] },
  { "data": "2026-10-21", "tipi": ["glass"] },
  { "data": "2026-10-22", "tipi": ["plastic_metals"] },
  { "data": "2026-10-26", "tipi": ["organic"] },
  { "data": "2026-10-29", "tipi": ["residual", "paper"] },

  { "data": "2026-11-02", "tipi": ["organic"] },
  { "data": "2026-11-04", "tipi": ["glass"] },
  { "data": "2026-11-05", "tipi": ["plastic_metals"] },
  { "data": "2026-11-09", "tipi": ["organic"] },
  { "data": "2026-11-12", "tipi": ["residual", "paper"] },
  { "data": "2026-11-16", "tipi": ["organic"] },
  { "data": "2026-11-18", "tipi": ["glass"] },
  { "data": "2026-11-19", "tipi": ["plastic_metals"] },
  { "data": "2026-11-23", "tipi": ["organic"] },
  { "data": "2026-11-26", "tipi": ["residual", "paper"] },
  { "data": "2026-11-30", "tipi": ["organic"] },

  { "data": "2026-12-02", "tipi": ["glass"] },
  { "data": "2026-12-03", "tipi": ["plastic_metals"] },
  { "data": "2026-12-07", "tipi": ["organic"] },
  { "data": "2026-12-10", "tipi": ["residual", "paper"] },
  { "data": "2026-12-14", "tipi": ["organic"] },
  { "data": "2026-12-16", "tipi": ["glass"] },
  { "data": "2026-12-17", "tipi": ["plastic_metals"] },
  { "data": "2026-12-21", "tipi": ["organic"] },
  { "data": "2026-12-24", "tipi": ["residual", "paper"] },
  { "data": "2026-12-28", "tipi": ["organic"] },
  { "data": "2026-12-30", "tipi": ["glass"] },
  { "data": "2026-12-31", "tipi": ["plastic_metals"] }
];

const RIFIUTI_GEA_SEQUALS = [
  { data: "2026-01-06", tipi: ["organic", "residual", "paper"] },
  { data: "2026-01-13", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-01-20", tipi: ["organic", "residual", "paper"] },
  { data: "2026-01-27", tipi: ["organic", "plastic_metals", "glass"] },

  { data: "2026-02-03", tipi: ["organic", "residual", "paper"] },
  { data: "2026-02-10", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-02-17", tipi: ["organic", "residual", "paper"] },
  { data: "2026-02-24", tipi: ["organic", "plastic_metals", "glass"] },

  { data: "2026-03-03", tipi: ["organic", "residual", "paper"] },
  { data: "2026-03-10", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-03-17", tipi: ["organic", "residual", "paper"] },
  { data: "2026-03-24", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-03-31", tipi: ["organic", "residual", "paper"] },

  { data: "2026-04-07", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-04-14", tipi: ["organic", "residual", "paper"] },
  { data: "2026-04-21", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-04-28", tipi: ["organic", "residual", "paper"] },

  { data: "2026-05-05", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-05-12", tipi: ["organic", "residual", "paper"] },
  { data: "2026-05-19", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-05-26", tipi: ["organic", "residual", "paper"] },

  { data: "2026-06-02", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-06-06", tipi: ["organic"] },
  { data: "2026-06-09", tipi: ["organic", "residual", "paper"] },
  { data: "2026-06-13", tipi: ["organic"] },
  { data: "2026-06-16", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-06-20", tipi: ["organic"] },
  { data: "2026-06-23", tipi: ["organic", "residual", "paper"] },
  { data: "2026-06-27", tipi: ["organic"] },
  { data: "2026-06-30", tipi: ["organic", "plastic_metals", "glass"] },

  { data: "2026-07-04", tipi: ["organic"] },
  { data: "2026-07-07", tipi: ["organic", "residual", "paper"] },
  { data: "2026-07-11", tipi: ["organic"] },
  { data: "2026-07-14", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-07-18", tipi: ["organic"] },
  { data: "2026-07-21", tipi: ["organic", "residual", "paper"] },
  { data: "2026-07-25", tipi: ["organic"] },
  { data: "2026-07-28", tipi: ["organic", "plastic_metals", "glass"] },

  { data: "2026-08-01", tipi: ["organic"] },
  { data: "2026-08-04", tipi: ["organic", "residual", "paper"] },
  { data: "2026-08-08", tipi: ["organic"] },
  { data: "2026-08-11", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-08-18", tipi: ["organic", "residual", "paper"] },
  { data: "2026-08-22", tipi: ["organic"] },
  { data: "2026-08-25", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-08-29", tipi: ["organic"] },

  { data: "2026-09-01", tipi: ["organic", "residual", "paper"] },
  { data: "2026-09-05", tipi: ["organic"] },
  { data: "2026-09-08", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-09-12", tipi: ["organic"] },
  { data: "2026-09-15", tipi: ["organic", "residual", "paper"] },
  { data: "2026-09-19", tipi: ["organic"] },
  { data: "2026-09-22", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-09-26", tipi: ["organic"] },
  { data: "2026-09-29", tipi: ["organic", "residual", "paper"] },

  { data: "2026-10-06", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-10-13", tipi: ["organic", "residual", "paper"] },
  { data: "2026-10-20", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-10-27", tipi: ["organic", "residual", "paper"] },

  { data: "2026-11-03", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-11-10", tipi: ["organic", "residual", "paper"] },
  { data: "2026-11-17", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-11-24", tipi: ["organic", "residual", "paper"] },

  { data: "2026-12-01", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-12-08", tipi: ["organic", "residual", "paper"] },
  { data: "2026-12-15", tipi: ["organic", "plastic_metals", "glass"] },
  { data: "2026-12-22", tipi: ["organic", "residual", "paper"] },
  { data: "2026-12-29", tipi: ["organic", "plastic_metals", "glass"] },
];

const RIFIUTI_GEA_MONTEREALE_SLEONARDO = [
  { data: "2026-01-07", tipi: ["residual"] },
  { data: "2026-01-21", tipi: ["residual"] },
  { data: "2026-02-04", tipi: ["residual"] },
  { data: "2026-02-18", tipi: ["residual"] },
  { data: "2026-03-04", tipi: ["residual"] },
  { data: "2026-03-18", tipi: ["residual"] },
  { data: "2026-04-01", tipi: ["residual"] },
  { data: "2026-04-15", tipi: ["residual"] },
  { data: "2026-04-29", tipi: ["residual"] },
  { data: "2026-05-13", tipi: ["residual"] },
  { data: "2026-05-27", tipi: ["residual"] },
  { data: "2026-06-10", tipi: ["residual"] },
  { data: "2026-06-24", tipi: ["residual"] },
  { data: "2026-07-08", tipi: ["residual"] },
  { data: "2026-07-22", tipi: ["residual"] },
  { data: "2026-08-05", tipi: ["residual"] },
  { data: "2026-08-19", tipi: ["residual"] },
  { data: "2026-09-02", tipi: ["residual"] },
  { data: "2026-09-16", tipi: ["residual"] },
  { data: "2026-09-30", tipi: ["residual"] },
  { data: "2026-10-14", tipi: ["residual"] },
  { data: "2026-10-28", tipi: ["residual"] },
  { data: "2026-11-11", tipi: ["residual"] },
  { data: "2026-11-25", tipi: ["residual"] },
  { data: "2026-12-09", tipi: ["residual"] },
  { data: "2026-12-23", tipi: ["residual"] },
];
const RIFIUTI_GEA_MONTEREALE_GRIZZOMALNISIO = [
  { data: "2026-01-09", tipi: ["residual"] },
  { data: "2026-01-23", tipi: ["residual"] },
  { data: "2026-02-06", tipi: ["residual"] },
  { data: "2026-02-20", tipi: ["residual"] },
  { data: "2026-03-06", tipi: ["residual"] },
  { data: "2026-03-20", tipi: ["residual"] },
  { data: "2026-04-03", tipi: ["residual"] },
  { data: "2026-04-17", tipi: ["residual"] },
  { data: "2026-05-01", tipi: ["residual"] },
  { data: "2026-05-15", tipi: ["residual"] },
  { data: "2026-05-29", tipi: ["residual"] },
  { data: "2026-06-12", tipi: ["residual"] },
  { data: "2026-06-26", tipi: ["residual"] },
  { data: "2026-07-10", tipi: ["residual"] },
  { data: "2026-07-24", tipi: ["residual"] },
  { data: "2026-08-07", tipi: ["residual"] },
  { data: "2026-08-21", tipi: ["residual"] },
  { data: "2026-09-04", tipi: ["residual"] },
  { data: "2026-09-18", tipi: ["residual"] },
  { data: "2026-10-02", tipi: ["residual"] },
  { data: "2026-10-16", tipi: ["residual"] },
  { data: "2026-10-30", tipi: ["residual"] },
  { data: "2026-11-13", tipi: ["residual"] },
  { data: "2026-11-27", tipi: ["residual"] },
  { data: "2026-12-11", tipi: ["residual"] },
  { data: "2026-12-28", tipi: ["residual"] }, // Natale: raccolta del 25/12 POSTICIPATA al 28/12 (da calendario)
];


const RIFIUTI_GEA_PRATA_DI_PORDENONE = [
  { data: "2026-01-02", tipi: ["plastic_metals"] },
  { data: "2026-01-06", tipi: ["paper"] },
  { data: "2026-01-10", tipi: ["residual"] },
  { data: "2026-01-16", tipi: ["plastic_metals"] },
  { data: "2026-01-20", tipi: ["paper"] },
  { data: "2026-01-24", tipi: ["residual"] },
  { data: "2026-01-30", tipi: ["plastic_metals"] },
  { data: "2026-02-03", tipi: ["paper"] },
  { data: "2026-02-07", tipi: ["residual"] },
  { data: "2026-02-13", tipi: ["plastic_metals"] },
  { data: "2026-02-17", tipi: ["paper"] },
  { data: "2026-02-21", tipi: ["residual"] },
  { data: "2026-02-27", tipi: ["plastic_metals"] },
  { data: "2026-03-03", tipi: ["paper"] },
  { data: "2026-03-07", tipi: ["residual"] },
  { data: "2026-03-13", tipi: ["plastic_metals"] },
  { data: "2026-03-17", tipi: ["paper"] },
  { data: "2026-03-21", tipi: ["residual"] },
  { data: "2026-03-27", tipi: ["plastic_metals"] },
  { data: "2026-03-31", tipi: ["paper"] },
  { data: "2026-04-04", tipi: ["residual"] },
  { data: "2026-04-10", tipi: ["plastic_metals"] },
  { data: "2026-04-14", tipi: ["paper"] },
  { data: "2026-04-18", tipi: ["residual"] },
  { data: "2026-04-24", tipi: ["plastic_metals"] },
  { data: "2026-04-28", tipi: ["paper"] },
  { data: "2026-05-02", tipi: ["residual"] },
  { data: "2026-05-08", tipi: ["plastic_metals"] },
  { data: "2026-05-12", tipi: ["paper"] },
  { data: "2026-05-16", tipi: ["residual"] },
  { data: "2026-05-22", tipi: ["plastic_metals"] },
  { data: "2026-05-26", tipi: ["paper"] },
  { data: "2026-05-30", tipi: ["residual"] },
  { data: "2026-06-05", tipi: ["plastic_metals"] },
  { data: "2026-06-09", tipi: ["paper"] },
  { data: "2026-06-13", tipi: ["residual"] },
  { data: "2026-06-19", tipi: ["plastic_metals"] },
  { data: "2026-06-23", tipi: ["paper"] },
  { data: "2026-06-27", tipi: ["residual"] },
  { data: "2026-07-03", tipi: ["plastic_metals"] },
  { data: "2026-07-07", tipi: ["paper"] },
  { data: "2026-07-11", tipi: ["residual"] },
  { data: "2026-07-17", tipi: ["plastic_metals"] },
  { data: "2026-07-21", tipi: ["paper"] },
  { data: "2026-07-25", tipi: ["residual"] },
  { data: "2026-07-31", tipi: ["plastic_metals"] },
  { data: "2026-08-04", tipi: ["paper"] },
  { data: "2026-08-08", tipi: ["residual"] },
  { data: "2026-08-14", tipi: ["plastic_metals"] },
  { data: "2026-08-18", tipi: ["paper"] },
  { data: "2026-08-22", tipi: ["residual"] },
  { data: "2026-08-28", tipi: ["plastic_metals"] },
  { data: "2026-09-01", tipi: ["paper"] },
  { data: "2026-09-05", tipi: ["residual"] },
  { data: "2026-09-11", tipi: ["plastic_metals"] },
  { data: "2026-09-15", tipi: ["paper"] },
  { data: "2026-09-19", tipi: ["residual"] },
  { data: "2026-09-25", tipi: ["plastic_metals"] },
  { data: "2026-09-29", tipi: ["paper"] },
  { data: "2026-10-03", tipi: ["residual"] },
  { data: "2026-10-09", tipi: ["plastic_metals"] },
  { data: "2026-10-13", tipi: ["paper"] },
  { data: "2026-10-17", tipi: ["residual"] },
  { data: "2026-10-23", tipi: ["plastic_metals"] },
  { data: "2026-10-27", tipi: ["paper"] },
  { data: "2026-10-31", tipi: ["residual"] },
  { data: "2026-11-06", tipi: ["plastic_metals"] },
  { data: "2026-11-10", tipi: ["paper"] },
  { data: "2026-11-14", tipi: ["residual"] },
  { data: "2026-11-20", tipi: ["plastic_metals"] },
  { data: "2026-11-24", tipi: ["paper"] },
  { data: "2026-11-28", tipi: ["residual"] },
  { data: "2026-12-04", tipi: ["plastic_metals"] },
  { data: "2026-12-08", tipi: ["paper"] },
  { data: "2026-12-12", tipi: ["residual"] },
  { data: "2026-12-18", tipi: ["plastic_metals"] },
  { data: "2026-12-22", tipi: ["paper"] },
  { data: "2026-12-26", tipi: ["residual"] },
];

const RIFIUTI_GEA_ROVEREDO_IN_PIANO = [
  { data: "2026-01-07", tipi: ["plastic_metals"] },
  { data: "2026-01-09", tipi: ["residual"] },
  { data: "2026-01-14", tipi: ["paper"] },
  { data: "2026-01-21", tipi: ["plastic_metals"] },
  { data: "2026-01-23", tipi: ["residual"] },
  { data: "2026-01-28", tipi: ["paper"] },
  { data: "2026-02-04", tipi: ["plastic_metals"] },
  { data: "2026-02-06", tipi: ["residual"] },
  { data: "2026-02-11", tipi: ["paper"] },
  { data: "2026-02-18", tipi: ["plastic_metals"] },
  { data: "2026-02-20", tipi: ["residual"] },
  { data: "2026-02-25", tipi: ["paper"] },
  { data: "2026-03-04", tipi: ["plastic_metals"] },
  { data: "2026-03-06", tipi: ["residual"] },
  { data: "2026-03-11", tipi: ["paper"] },
  { data: "2026-03-18", tipi: ["plastic_metals"] },
  { data: "2026-03-20", tipi: ["residual"] },
  { data: "2026-03-25", tipi: ["paper"] },
  { data: "2026-04-01", tipi: ["plastic_metals"] },
  { data: "2026-04-03", tipi: ["residual"] },
  { data: "2026-04-08", tipi: ["paper"] },
  { data: "2026-04-15", tipi: ["plastic_metals"] },
  { data: "2026-04-17", tipi: ["residual"] },
  { data: "2026-04-22", tipi: ["paper"] },
  { data: "2026-04-29", tipi: ["plastic_metals"] },
  { data: "2026-05-01", tipi: ["residual"] },
  { data: "2026-05-06", tipi: ["paper"] },
  { data: "2026-05-13", tipi: ["plastic_metals"] },
  { data: "2026-05-15", tipi: ["residual"] },
  { data: "2026-05-20", tipi: ["paper"] },
  { data: "2026-05-27", tipi: ["plastic_metals"] },
  { data: "2026-05-29", tipi: ["residual"] },
  { data: "2026-06-03", tipi: ["paper"] },
  { data: "2026-06-10", tipi: ["plastic_metals"] },
  { data: "2026-06-12", tipi: ["residual"] },
  { data: "2026-06-17", tipi: ["paper"] },
  { data: "2026-06-24", tipi: ["plastic_metals"] },
  { data: "2026-06-26", tipi: ["residual"] },
  { data: "2026-07-01", tipi: ["paper"] },
  { data: "2026-07-08", tipi: ["plastic_metals"] },
  { data: "2026-07-10", tipi: ["residual"] },
  { data: "2026-07-15", tipi: ["paper"] },
  { data: "2026-07-22", tipi: ["plastic_metals"] },
  { data: "2026-07-24", tipi: ["residual"] },
  { data: "2026-07-29", tipi: ["paper"] },
  { data: "2026-08-05", tipi: ["plastic_metals"] },
  { data: "2026-08-07", tipi: ["residual"] },
  { data: "2026-08-12", tipi: ["paper"] },
  { data: "2026-08-19", tipi: ["plastic_metals"] },
  { data: "2026-08-21", tipi: ["residual"] },
  { data: "2026-08-26", tipi: ["paper"] },
  { data: "2026-09-02", tipi: ["plastic_metals"] },
  { data: "2026-09-04", tipi: ["residual"] },
  { data: "2026-09-09", tipi: ["paper"] },
  { data: "2026-09-16", tipi: ["plastic_metals"] },
  { data: "2026-09-18", tipi: ["residual"] },
  { data: "2026-09-23", tipi: ["paper"] },
  { data: "2026-09-30", tipi: ["plastic_metals"] },
  { data: "2026-10-02", tipi: ["residual"] },
  { data: "2026-10-07", tipi: ["paper"] },
  { data: "2026-10-14", tipi: ["plastic_metals"] },
  { data: "2026-10-16", tipi: ["residual"] },
  { data: "2026-10-21", tipi: ["paper"] },
  { data: "2026-10-28", tipi: ["plastic_metals"] },
  { data: "2026-10-30", tipi: ["residual"] },
  { data: "2026-11-04", tipi: ["paper"] },
  { data: "2026-11-11", tipi: ["plastic_metals"] },
  { data: "2026-11-13", tipi: ["residual"] },
  { data: "2026-11-18", tipi: ["paper"] },
  { data: "2026-11-25", tipi: ["plastic_metals"] },
  { data: "2026-11-27", tipi: ["residual"] },
  { data: "2026-12-02", tipi: ["paper"] },
  { data: "2026-12-09", tipi: ["plastic_metals"] },
  { data: "2026-12-11", tipi: ["residual"] },
  { data: "2026-12-16", tipi: ["paper"] },
  { data: "2026-12-21", tipi: ["residual"] },
  { data: "2026-12-23", tipi: ["plastic_metals"] },
  { data: "2026-12-30", tipi: ["paper"] },
];

const RIFIUTI_GEA_SAN_QUIRINO = [
  { data: "2026-01-03", tipi: ["residual", "plastic_metals"] },
  { data: "2026-01-10", tipi: ["paper"] },
  { data: "2026-01-17", tipi: ["residual", "plastic_metals"] },
  { data: "2026-01-24", tipi: ["paper"] },
  { data: "2026-01-31", tipi: ["residual", "plastic_metals"] },
  { data: "2026-02-07", tipi: ["paper"] },
  { data: "2026-02-14", tipi: ["residual", "plastic_metals"] },
  { data: "2026-02-21", tipi: ["paper"] },
  { data: "2026-02-28", tipi: ["residual", "plastic_metals"] },
  { data: "2026-03-07", tipi: ["paper"] },
  { data: "2026-03-14", tipi: ["residual", "plastic_metals"] },
  { data: "2026-03-21", tipi: ["paper"] },
  { data: "2026-03-28", tipi: ["residual", "plastic_metals"] },
  { data: "2026-04-04", tipi: ["paper"] },
  { data: "2026-04-11", tipi: ["residual", "plastic_metals"] },
  { data: "2026-04-18", tipi: ["paper"] },
  { data: "2026-04-25", tipi: ["residual", "plastic_metals"] },
  { data: "2026-05-02", tipi: ["paper"] },
  { data: "2026-05-09", tipi: ["residual", "plastic_metals"] },
  { data: "2026-05-16", tipi: ["paper"] },
  { data: "2026-05-23", tipi: ["residual", "plastic_metals"] },
  { data: "2026-05-30", tipi: ["paper"] },
  { data: "2026-06-06", tipi: ["residual", "plastic_metals"] },
  { data: "2026-06-13", tipi: ["paper"] },
  { data: "2026-06-20", tipi: ["residual", "plastic_metals"] },
  { data: "2026-06-27", tipi: ["paper"] },
  { data: "2026-07-04", tipi: ["residual", "plastic_metals"] },
  { data: "2026-07-11", tipi: ["paper"] },
  { data: "2026-07-18", tipi: ["residual", "plastic_metals"] },
  { data: "2026-07-25", tipi: ["paper"] },
  { data: "2026-08-01", tipi: ["residual", "plastic_metals"] },
  { data: "2026-08-08", tipi: ["paper"] },
  { data: "2026-08-15", tipi: ["residual", "plastic_metals"] },
  { data: "2026-08-22", tipi: ["paper"] },
  { data: "2026-08-29", tipi: ["residual", "plastic_metals"] },
  { data: "2026-09-05", tipi: ["paper"] },
  { data: "2026-09-12", tipi: ["residual", "plastic_metals"] },
  { data: "2026-09-19", tipi: ["paper"] },
  { data: "2026-09-26", tipi: ["residual", "plastic_metals"] },
  { data: "2026-10-03", tipi: ["paper"] },
  { data: "2026-10-10", tipi: ["residual", "plastic_metals"] },
  { data: "2026-10-17", tipi: ["paper"] },
  { data: "2026-10-24", tipi: ["residual", "plastic_metals"] },
  { data: "2026-10-31", tipi: ["paper"] },
  { data: "2026-11-07", tipi: ["residual", "plastic_metals"] },
  { data: "2026-11-14", tipi: ["paper"] },
  { data: "2026-11-21", tipi: ["residual", "plastic_metals"] },
  { data: "2026-11-28", tipi: ["paper"] },
  { data: "2026-12-05", tipi: ["residual", "plastic_metals"] },
  { data: "2026-12-12", tipi: ["paper"] },
  { data: "2026-12-19", tipi: ["residual", "plastic_metals"] },
  { data: "2026-12-26", tipi: ["paper"] },
];

const RIFIUTI_COMUNI_GEA = [
  {
    slug: "aviano",
    nome: "Aviano",
    provincia: "pordenone",
    gestore: "GEA",
    aree: [
      { area: "Blu", giorni: RIFIUTI_GEA_AVIANO_BLU },
      { area: "Gialla", giorni: RIFIUTI_GEA_AVIANO_GIALLA },
    ],
    centro_raccolta: {
      indirizzo: "Zona Industriale, via Ellero",
      apertura:
        "Lun, Mer, Ven 14:15-17:00 (15:15-18:00 in orario legale); Mar, Sab 8:30-12:00",
      materiali: [
        "Ingombranti",
        "Carta e cartone",
        "Imballaggi in plastica",
        "Tessili",
        "Vetro",
        "Ferro e metalli",
        "Materiale inerte (max 30 kg)",
        "Verde",
        "Legno",
        "Olio minerale e vegetale",
        "Batterie, pile e medicinali",
        "Pneumatici",
        "RAEE",
      ],
    },
    campane_vetro: [],
    stale: false,
  },
  {
    slug: "pordenone",
    nome: "Pordenone",
    provincia: "pordenone",
    gestore: "GEA",
    aree: [
      { area: "Blu", giorni: RIFIUTI_GEA_PORDENONE_BLU },
      { area: "Gialla", giorni: RIFIUTI_GEA_PORDENONE_GIALLA },
      { area: "Rossa", giorni: RIFIUTI_GEA_PORDENONE_ROSSA },
      { area: "Marrone", giorni: RIFIUTI_GEA_PORDENONE_MARRONE },
      { area: "Verde Nord", giorni: RIFIUTI_GEA_PORDENONE_VERDE_NORD },
      { area: "Verde Sud", giorni: RIFIUTI_GEA_PORDENONE_VERDE_SUD },
    ],
    centro_raccolta: {
      indirizzo: "Via Nuova di Corva (angolo tra via Santorini e via Segaluzza), Pordenone",
      apertura:
        "Lun-Ven 8:00-12:00 e 14:00-17:00, Sab 8:00-12:00 e 13:00-18:00 (ultimo accesso mattutino entro le 11:50)",
      materiali: [
        "Tessili",
        "Ingombranti",
        "RAEE",
        "Vetro (lastre)",
        "Rifiuti inerti",
        "Rifiuti pericolosi (vernici, solventi)",
        "Oli minerali",
        "Pile e accumulatori",
        "Prodotti chimici pericolosi",
        "Sfalci e ramaglie, cassette in legno",
      ],
    },
    campane_vetro: [],
    nota: "A Pordenone l'umido e il vetro non sono a calendario porta a porta: si conferiscono nei cassonetti stradali (marrone per l'umido, aperto con chiave personale richiedibile a GEA; verde/campana per il vetro). Gli sfalci e le ramaglie e i pannolini/pannoloni hanno servizi dedicati non coperti da questa pagina. Esiste inoltre un servizio cartone riservato alle attività commerciali iscritte. Nessuno di questi servizi è ancora coperto da questa pagina.",
    stale: false,
  },
  {
    slug: "budoia",
    nome: "Budoia",
    provincia: "pordenone",
    gestore: "GEA",
    aree: [
      { area: "Budoia centro e Zona Ind.", giorni: RIFIUTI_GEA_BUDOIA_CENTRO },
      { area: "Dardago e S.Lucia", giorni: RIFIUTI_GEA_BUDOIA_DARDAGO },
    ],
    centro_raccolta: {
      indirizzo: "Via della Braida, 13",
      apertura:
        "Invernale: lun 8:00-12:00, sab 9:30-12:30 e 14:00-16:00. Estivo: lun 8:00-12:00, mer 16:00-19:00, sab 9:30-12:30 e 16:00-19:00.",
      materiali: [
        "Ingombranti",
        "RAEE",
        "Carta e cartone",
        "Vetro di grandi dimensioni",
        "Contenitori in plastica di grandi dimensioni",
        "Metallo ferroso e non ferroso",
        "Verde (sfalci e ramaglie)",
        "Legno",
        "Oli minerali e vegetali",
        "Pile e accumulatori",
        "Prodotti chimici pericolosi",
        "Materiale inerte in piccole quantità (mattonelle, ceramiche)",
      ],
    },
    campane_vetro: [],
    stale: false,
  },
  {
    slug: "andreis",
    nome: "Andreis",
    provincia: "pordenone",
    gestore: "GEA",
    aree: [{ area: null, giorni: RIFIUTI_GEA_ANDREIS }],
    centro_raccolta: {
      indirizzo: "Zona Industriale, Montereale Valcellina (centro di raccolta di Montereale Valcellina, utilizzabile anche dai residenti di Andreis)",
      apertura: "Lunedì e mercoledì 13:30-16:00, sabato 13:00-17:00. Chiuso nei giorni festivi.",
      materiali: [
        "Ingombranti",
        "RAEE",
        "Carta e cartone di grandi dimensioni",
        "Vetro di grandi dimensioni",
        "Contenitori in plastica di grandi dimensioni",
        "Metallo ferroso e non ferroso",
        "Legno",
        "Materiale inerte in piccole quantità (mattonelle, ceramiche)",
      ],
    },
    campane_vetro: [],
    stale: false,
  },
  {
    slug: "barcis",
    nome: "Barcis",
    provincia: "pordenone",
    gestore: "GEA",
    aree: [{ area: null, giorni: RIFIUTI_GEA_BARCIS }],
    centro_raccolta: null,
    campane_vetro: [],
    stale: false,
  },

  {
    slug: "claut",
    nome: "Claut",
    provincia: "pordenone",
    gestore: "GEA",
    aree: [{ area: null, giorni: RIFIUTI_GEA_CLAUT }],
    centro_raccolta: {
      indirizzo: "Ingresso della Val Settimana, presso il depuratore, Claut (PN)",
      apertura: "1° e 3° sabato del mese, ore 8:30-12:00",
      materiali: [
        "Rifiuti ingombranti e RAEE (mobili, divani, frigoriferi, congelatori, condizionatori, televisori, computer, stampanti)",
        "Cartoni di grandi dimensioni",
        "Vetro di grandi dimensioni",
        "Contenitori in plastica di grandi dimensioni (taniche, secchi, ecc.)",
        "Manufatti in metallo, ferroso e non ferroso, legno",
        "Piccole quantità di rifiuto misto ingombrante (mattonelle, ceramiche)",
      ],
    },
    campane_vetro: [],
    stale: false,
  },
  {
    slug: "clauzetto",
    nome: "Clauzetto",
    provincia: "pordenone",
    gestore: "GEA",
    aree: [{ area: null, giorni: RIFIUTI_GEA_CLAUZETTO }],
    centro_raccolta: null,
    campane_vetro: [],
    stale: false,
  },
  {
    slug: "erto-e-casso",
    nome: "Erto e Casso",
    provincia: "pordenone",
    gestore: "GEA",
    aree: [{ area: null, giorni: RIFIUTI_GEA_ERTO_E_CASSO }],
    centro_raccolta: {
      indirizzo: "Il centro di raccolta comunale non è ancora attivo (in attesa di realizzazione). In alternativa sono disponibili due punti fissi a Erto: il Centro di raccolta in Via Stortan a Erto (solo RAEE - rifiuti di apparecchiature elettriche ed elettroniche) e la Piazzola interrata in Via IX Ottobre a Erto (carta, plastica e lattine, vetro, secco eccedenti i limiti dei bidoncini domiciliari). E' inoltre attivo un servizio di Ecocentro mobile per i rifiuti non gestibili col porta a porta.",
      apertura: "Orari non specificati nel PDF per i punti fissi di Via Stortan e Via IX Ottobre. Per l'Ecocentro mobile e per i rifiuti ingombranti (servizio porta a porta su prenotazione) contattare il numero verde 800.501.077 (dal lunedì al giovedì 09.00-13.00/14.00-17.00, venerdì 09.00-13.00).",
      materiali: [
        "RAEE (piccoli elettrodomestici, apparecchiature elettriche/elettroniche) - Centro di raccolta Via Stortan",
        "Carta e cartone, plastica e lattine, vetro, secco non riciclabile eccedenti le quantità conferibili nei bidoncini domiciliari - Piazzola interrata Via IX Ottobre",
        "Ecocentro mobile: piccoli elettrodomestici, pentolame e casalinghi in metallo, casalinghi in ceramica, rifiuti di stampa, neon e lampade a basso consumo, tessili, olio vegetale, vernici/solventi/inchiostri, batterie e accumulatori, pile esaurite, olio minerale, filtri olio",
        "Rifiuti ingombranti: servizio porta a porta su prenotazione (numero verde 800.501.077)",
      ],
    },
    campane_vetro: [],
    stale: false,
  },
  {
    slug: "fanna",
    nome: "Fanna",
    provincia: "pordenone",
    gestore: "GEA",
    aree: [{ area: null, giorni: RIFIUTI_GEA_FANNA }],
    centro_raccolta: {
      indirizzo: "Via Circonvallazione Nuova, Fanna (PN)",
      apertura: "Lunedi 15:30-16:30, Giovedi 8:30-9:30, Sabato 10:00-12:00 (stesso orario tutto l'anno, nessun orario estivo differenziato indicato nel PDF)",
      materiali: [
        "rifiuti differenziati conferibili elencati nell'art. 6 del Regolamento comunale per la gestione del centro di raccolta (eco piazzola) - il PDF non ne riporta l'elenco dettagliato",
        "NON accettati: eternit e altri materiali contenenti amianto (per modiche quantita' di lastre in eternit, GEA offre un servizio di ritiro a pagamento su chiamata al numero verde 800.501.077)",
      ],
    },
    campane_vetro: [],
    stale: false,
  },
  {
    slug: "frisanco",
    nome: "Frisanco",
    provincia: "pordenone",
    gestore: "GEA",
    aree: [{ area: null, giorni: RIFIUTI_GEA_FRISANCO }],
    centro_raccolta: {
      indirizzo: "Via Valdestali, dietro le ex Scuole Elementari - Frisanco",
      apertura: "Sabato dalle ore 10.00 alle 12.00",
      materiali: [
        "Rifiuti ingombranti (materassi, divani, ecc.)",
        "RAEE (frigoriferi, congelatori, condizionatori, televisori, computer, stampanti, circuiti elettrici)",
        "Carta e cartone di grandi dimensioni",
        "Vetro, lastre di vetro, specchi",
        "Contenitori in plastica di grandi dimensioni (taniche, secchi)",
        "Verde (erba, sfalci e ramaglie)",
        "Legno (cassette di legno)",
        "Ferro, rottami metallici e manufatti in metallo (ferroso e non ferroso)",
        "Tessili puliti e in buono stato (abiti, cuoio, pellame, stracci, scarpe)",
        "Barattoli di vernice, contenitori etichettati T e/o F",
        "Lampade al neon",
        "Oli vegetali ad uso alimentare e oli minerali esausti",
        "Accumulatori e batterie, pile esauste",
        "Farmaci scaduti",
        "Cartucce e toner esausti per stampanti",
        "Piccole quantità domestiche di rifiuto inerte (mattonelle, ceramiche)",
      ],
    },
    campane_vetro: [],
    stale: false,
  },
  {
    slug: "caneva",
    nome: "Caneva",
    provincia: "pordenone",
    gestore: "GEA",
    aree: [
      { area: "Zona A", giorni: RIFIUTI_GEA_CANEVA_ZONA_A },
      { area: "Zona B", giorni: RIFIUTI_GEA_CANEVA_ZONA_B },
    ],
    centro_raccolta: {
      indirizzo: "Lungo la bretella autostradale, in località Fratta, Comune di Caneva (PN)",
      apertura: "Lunedì 15:00-18:00; Mercoledì 10:00-13:00; Sabato 9:00-13:00 (esclusi i festivi)",
      materiali: [
        "Oli minerali e vegetali esausti",
        "Ingombranti di natura domestica",
        "RAEE (rifiuti da apparecchiature elettriche ed elettroniche)",
        "Piccole quantità di inerti da lavori domestici di modesta entità (escluso cartongesso)",
        "Rifiuti differenziati di grandi dimensioni (vetro, plastica, ferro, legno)",
        "Toner esausti da uso domestico",
        "Tessili (abiti usati, tessuti, scarpe e cinture puliti e in buono stato)",
      ],
    },
    campane_vetro: [],
    stale: false,
  },
  {
    slug: "cimolais",
    nome: "Cimolais",
    provincia: "pordenone",
    gestore: "GEA",
    aree: [{ area: null, giorni: RIFIUTI_GEA_CIMOLAIS }],
    centro_raccolta: {
      indirizzo: "Strada Cimiteriale, Cimolais",
      apertura: "Orario invernale (ora solare): sabato dalle 14:00 alle 17:00, ogni 15 giorni. Orario estivo (ora legale): sabato dalle 14:00 alle 17:00, tutti i sabati.",
      materiali: [
        "piccoli elettrodomestici (RAEE)",
        "pentolame e casalinghi in metallo",
        "casalinghi in ceramica",
        "neon e lampade a basso consumo",
        "olio vegetale (di frittura, da alimentari)",
        "vernici, solventi, inchiostri, T/F, insetticidi, bombolette spray",
        "batterie e accumulatori (auto, moto ecc.)",
        "pile esaurite",
        "filtri olio minerale e olio vegetale",
        "materiale ferroso",
        "ingombranti",
        "lavatrici",
        "legno",
        "imballaggi in plastica e lattine, plastica dura",
        "carta e cartone",
      ],
    },
    campane_vetro: [],
    stale: false,
  },
  {
    slug: "cordenons",
    nome: "Cordenons",
    provincia: "pordenone",
    gestore: "GEA",
    aree: [
      { area: "Zona 1", giorni: RIFIUTI_GEA_CORDENONS_ZONA1 },
      { area: "Zona 2", giorni: RIFIUTI_GEA_CORDENONS_ZONA2 },
    ],
    centro_raccolta: {
      indirizzo: "Via Chiavornicco, 49, 33084 Cordenons (PN)",
      apertura: "Lunedì, giovedì e sabato: 9:00-12:00 e 15:00-18:00. Chiuso durante le festività.",
      materiali: [
        "tessili (abiti, tessuti, scarpe e cinture puliti e in buono stato)",
        "rifiuti ingombranti (tappeti, moquette, bauli, poltrone, divani ecc.)",
        "metalli (biciclette, reti, attrezzi, latte e fusti)",
        "scarti verdi (da utenze private)",
        "R.A.E.E. (rifiuti da apparecchiature elettriche ed elettroniche)",
        "legno (cassette, bancali e mobili ridotti di volume)",
        "imballaggi in carta e cartone",
        "imballaggi in plastica",
        "imballaggi in vetro",
        "abiti usati",
        "accumulatori al piombo esausti (da utenze private)",
        "pile esauste",
        "contenitori etichettati \"T\" e/o \"F\" e rifiuti del fai da te pericolosi (da utenze private)",
        "materiale inerte (piccole quantità da attività domestiche)",
        "oli di origine animale e vegetale, oli minerali, oli sintetici",
        "medicinali",
      ],
    },
    campane_vetro: [],
    nota: "A Cordenons l'umido e il vetro non sono a calendario: si conferiscono in qualsiasi momento nei cassonetti stradali (marrone per l'umido, verde per il vetro) aperti con una chiave personale, richiedibile all'ecosportello GEA. Gli sfalci e le ramaglie hanno una raccolta porta a porta propria (settimanale da marzo a novembre, quindicinale su prenotazione nei restanti mesi) con zone diverse da Zona 1/Zona 2 (Zona A/B/C). Esiste anche un servizio cartone riservato alle attività commerciali iscritte. Nessuno di questi tre servizi è ancora coperto da questa pagina.",
    stale: false,
  },
  {
    slug: "tramonti-di-sopra",
    nome: "Tramonti di Sopra",
    provincia: "pordenone",
    gestore: "GEA",
    aree: [{ area: null, giorni: RIFIUTI_GEA_TRAMONTI_SOPRA }],
    centro_raccolta: {
      indirizzo:
        "Località Chiarchia, Comune di Tramonti di Sotto (centro di raccolta rifiuti intercomunale Tramonti di Sopra / Tramonti di Sotto)",
      apertura:
        "Per orari di apertura e informazioni: numero verde GEA 800.501.077 (lun-gio 9:00-13:00 e 14:00-17:00, ven 9:00-13:00). È inoltre annunciato ma non ancora attivo un Ecocentro Mobile (orario previsto: sabato 13:30-15:30).",
      materiali: [
        "Piccoli elettrodomestici elettrici ed elettronici",
        "Pentolame e casalinghi in metallo",
        "Casalinghi in ceramica",
        "Rifiuti di stampa (cartucce e nastri per stampanti)",
        "Neon e lampade a basso consumo",
        "Tessili",
        "Olio vegetale",
        "Vernici, solventi, inchiostri, T/F",
        "Batterie e accumulatori",
        "Pile esauste",
        "Olio minerale",
        "Filtri olio minerale e olio vegetale",
        "Ingombranti e RAEE",
        "Materiale inerte in piccole quantità (mattonelle, ceramiche)",
      ],
    },
    campane_vetro: [],
    stale: false,
  },
  {
    slug: "tramonti-di-sotto",
    nome: "Tramonti di Sotto",
    provincia: "pordenone",
    gestore: "GEA",
    aree: [{ area: null, giorni: RIFIUTI_GEA_TRAMONTI_SOTTO }],
    centro_raccolta: {
      indirizzo:
        "Località Chiarchia, Comune di Tramonti di Sotto (centro di raccolta rifiuti intercomunale Tramonti di Sopra / Tramonti di Sotto)",
      apertura:
        "Per orari di apertura e informazioni: numero verde GEA 800.501.077 (lun-gio 9:00-13:00 e 14:00-17:00, ven 9:00-13:00). È inoltre annunciato ma non ancora attivo un Ecocentro Mobile (orario previsto: sabato 13:30-15:30).",
      materiali: [
        "Piccoli elettrodomestici elettrici ed elettronici",
        "Pentolame e casalinghi in metallo",
        "Casalinghi in ceramica",
        "Rifiuti di stampa (cartucce e nastri per stampanti)",
        "Neon e lampade a basso consumo",
        "Tessili",
        "Olio vegetale",
        "Vernici, solventi, inchiostri, T/F",
        "Batterie e accumulatori",
        "Pile esauste",
        "Olio minerale",
        "Filtri olio minerale e olio vegetale",
        "Ingombranti e RAEE",
        "Materiale inerte in piccole quantità (mattonelle, ceramiche)",
      ],
    },
    campane_vetro: [],
    stale: false,
  },
  {
    slug: "vito-d-asio",
    nome: "Vito d'Asio",
    provincia: "pordenone",
    gestore: "GEA",
    aree: [{ area: null, giorni: RIFIUTI_GEA_VITO_DASIO }],
    centro_raccolta: null,
    campane_vetro: [],
    nota: "A Vito d'Asio non è attivo un centro di raccolta fisso. È annunciato ma non ancora attivo un Ecocentro Mobile per i rifiuti non intercettabili dalla raccolta porta a porta; per informazioni e aggiornamenti: numero verde GEA 800.501.077.",
    stale: false,
  },
  {
    slug: "vivaro",
    nome: "Vivaro",
    provincia: "pordenone",
    gestore: "GEA",
    aree: [{ area: null, giorni: RIFIUTI_GEA_VIVARO }],
    centro_raccolta: {
      indirizzo: "Via San Marco 15/A, Zona Artigianale di Vivaro (PN)",
      apertura:
        "Orari stagionali (invernale/estivo); per il dettaglio degli orari e altre informazioni contattare il numero verde GEA 800.501.077.",
      materiali: [
        "Ingombranti",
        "RAEE",
        "Carta e cartone di grandi dimensioni",
        "Vetro di grandi dimensioni",
        "Imballaggi in plastica di grandi dimensioni",
        "Metallo ferroso e non ferroso",
        "Verde (sfalci e ramaglie)",
        "Legno",
        "Oli minerali e vegetali",
        "Pile e accumulatori",
        "Materiale inerte in piccole quantità (mattonelle, ceramiche)",
      ],
    },
    campane_vetro: [],
    stale: false,
  },
  {
    slug: "maniago",
    nome: "Maniago",
    provincia: "pordenone",
    gestore: "GEA",
    aree: [
      { area: "Zona A", giorni: RIFIUTI_GEA_MANIAGO_ZONA_A },
      { area: "Zona B", giorni: RIFIUTI_GEA_MANIAGO_ZONA_B },
    ],
    centro_raccolta: {
      indirizzo: "Via Violis, 13, Maniago (PN)",
      apertura:
        "Per orari di apertura e informazioni contattare il numero verde GEA 800.501.077.",
      materiali: [
        "Ingombranti",
        "RAEE",
        "Carta e cartone di grandi dimensioni",
        "Vetro di grandi dimensioni",
        "Imballaggi in plastica di grandi dimensioni",
        "Metallo ferroso e non ferroso",
        "Verde (sfalci e ramaglie)",
        "Legno",
        "Oli minerali e vegetali",
        "Pile e accumulatori",
        "Materiale inerte in piccole quantità (mattonelle, ceramiche)",
      ],
    },
    campane_vetro: [],
    stale: false,
  },
  {
    slug: "meduno",
    nome: "Meduno",
    provincia: "pordenone",
    gestore: "GEA",
    aree: [{ area: null, giorni: RIFIUTI_GEA_MEDUNO }],
    centro_raccolta: {
      indirizzo:
        "Località Solimbergo, Comune di Sequals (centro di raccolta rifiuti intercomunale Meduno / Sequals)",
      apertura:
        "Orari stagionali (mercoledì e sabato); per il dettaglio degli orari e altre informazioni contattare il numero verde GEA 800.501.077.",
      materiali: [
        "Ingombranti",
        "RAEE",
        "Carta e cartone di grandi dimensioni",
        "Vetro di grandi dimensioni",
        "Imballaggi in plastica di grandi dimensioni",
        "Metallo ferroso e non ferroso",
        "Verde (sfalci e ramaglie)",
        "Legno",
        "Oli minerali e vegetali",
        "Pile e accumulatori",
        "Materiale inerte in piccole quantità (mattonelle, ceramiche)",
      ],
    },
    campane_vetro: [],
    stale: false,
  },
  {
    slug: "sequals",
    nome: "Sequals",
    provincia: "pordenone",
    gestore: "GEA",
    aree: [{ area: null, giorni: RIFIUTI_GEA_SEQUALS }],
    centro_raccolta: {
      indirizzo:
        "Località Solimbergo, Comune di Sequals (centro di raccolta rifiuti intercomunale Meduno / Sequals)",
      apertura:
        "Orari stagionali (mercoledì e sabato); per il dettaglio degli orari e altre informazioni contattare il numero verde GEA 800.501.077.",
      materiali: [
        "Ingombranti",
        "RAEE",
        "Carta e cartone di grandi dimensioni",
        "Vetro di grandi dimensioni",
        "Imballaggi in plastica di grandi dimensioni",
        "Metallo ferroso e non ferroso",
        "Verde (sfalci e ramaglie)",
        "Legno",
        "Oli minerali e vegetali",
        "Pile e accumulatori",
        "Materiale inerte in piccole quantità (mattonelle, ceramiche)",
      ],
    },
    campane_vetro: [],
    stale: false,
  },
  {
    slug: "montereale-valcellina",
    nome: "Montereale Valcellina",
    provincia: "pordenone",
    gestore: "GEA",
    aree: [
      { area: "San Leonardo", giorni: RIFIUTI_GEA_MONTEREALE_SLEONARDO },
      { area: "Capoluogo, Grizzo e Malnisio", giorni: RIFIUTI_GEA_MONTEREALE_GRIZZOMALNISIO },
    ],
    centro_raccolta: {
      indirizzo: "Zona Industriale 8, fraz. Grizzo, Montereale Valcellina (PN)",
      apertura:
        "Lunedì e mercoledì 13:30-16:00, sabato 13:00-17:00. Chiuso nei giorni festivi.",
      materiali: [
        "Ingombranti",
        "RAEE",
        "Carta e cartone di grandi dimensioni",
        "Vetro di grandi dimensioni",
        "Imballaggi in plastica di grandi dimensioni",
        "Metallo ferroso e non ferroso",
        "Legno",
        "Materiale inerte in piccole quantità (mattonelle, ceramiche)",
      ],
    },
    campane_vetro: [],
    nota: "È attivo anche un secondo centro di raccolta, per la frazione di San Leonardo, in Zona Artigianale, via Montereale 23, con proprio orario di apertura (per dettagli: numero verde GEA 800.501.077). A calendario è presente solo il secco residuo (raccolta quindicinale): il vetro si conferisce liberamente nei cassonetti stradali (campana, senza chiave), mentre l'umido richiede una chiave personale richiedibile al Comune; carta e plastica non sono a calendario porta a porta. Sono inoltre presenti servizi dedicati per sfalci, pannolini/pannoloni e un servizio cartone riservato alle attività commerciali, nessuno dei quali è coperto da questa pagina.",
    stale: false,
  },
  {
    slug: "prata-di-pordenone",
    nome: "Prata di Pordenone",
    provincia: "pordenone",
    gestore: "GEA",
    aree: [{ area: null, giorni: RIFIUTI_GEA_PRATA_DI_PORDENONE }],
    centro_raccolta: {
      indirizzo: "Via Antonio Durante, Prata di Pordenone (PN)",
      apertura:
        "Orario invernale: mercoledì 14:30-17:30, sabato 9:00-12:00 e 14:00-17:00. Orario estivo: mercoledì 16:00-19:00, sabato 9:00-12:00 e 15:00-18:00.",
      materiali: [
        "Ingombranti",
        "RAEE",
        "Carta e cartone di grandi dimensioni",
        "Vetro di grandi dimensioni",
        "Imballaggi in plastica di grandi dimensioni",
        "Metallo ferroso e non ferroso",
        "Verde (sfalci e ramaglie)",
        "Legno",
        "Oli minerali e vegetali",
        "Pile e accumulatori",
        "Materiale inerte in piccole quantità (mattonelle, ceramiche)",
      ],
    },
    campane_vetro: [],
    nota: "A Prata di Pordenone sfalci, umido, vetro, pannolini/pannoloni e il servizio cartone riservato alle attività commerciali non sono a calendario porta a porta: hanno servizi dedicati non coperti da questa pagina. A calendario sono presenti solo secco, plastica e carta.",
    stale: false,
  },
  {
    slug: "roveredo-in-piano",
    nome: "Roveredo in Piano",
    provincia: "pordenone",
    gestore: "GEA",
    aree: [{ area: null, giorni: RIFIUTI_GEA_ROVEREDO_IN_PIANO }],
    centro_raccolta: {
      indirizzo: "Via Del Mas, 24 (nei pressi del Magazzino Comunale), Roveredo in Piano (PN)",
      apertura: "Martedì 9:00-12:00, giovedì 13:30-16:30, sabato 9:00-16:30.",
      materiali: [
        "Ingombranti",
        "RAEE",
        "Carta e cartone di grandi dimensioni",
        "Vetro di grandi dimensioni",
        "Imballaggi in plastica di grandi dimensioni",
        "Metallo ferroso e non ferroso",
        "Verde (sfalci e ramaglie)",
        "Legno",
        "Oli minerali e vegetali",
        "Pile e accumulatori",
        "Materiale inerte in piccole quantità (mattonelle, ceramiche)",
      ],
    },
    campane_vetro: [],
    nota: "A Roveredo in Piano sfalci, umido, vetro, pannolini/pannoloni e il servizio cartone riservato alle attività commerciali non sono a calendario porta a porta: hanno servizi dedicati non coperti da questa pagina. A calendario sono presenti solo secco, plastica e carta.",
    stale: false,
  },
  {
    slug: "san-quirino",
    nome: "San Quirino",
    provincia: "pordenone",
    gestore: "GEA",
    aree: [{ area: null, giorni: RIFIUTI_GEA_SAN_QUIRINO }],
    centro_raccolta: {
      indirizzo: "Via San Rocco, San Quirino (PN)",
      apertura:
        "Lunedì 14:30-16:30, mercoledì 14:30-16:30, sabato 8:30-12:00. Accesso riservato alle utenze iscritte a TARI nel Comune di San Quirino.",
      materiali: [
        "Ingombranti",
        "RAEE",
        "Carta e cartone di grandi dimensioni",
        "Vetro di grandi dimensioni",
        "Imballaggi in plastica di grandi dimensioni",
        "Metallo ferroso e non ferroso",
        "Verde (sfalci e ramaglie)",
        "Legno",
        "Oli minerali e vegetali",
        "Pile e accumulatori",
        "Materiale inerte in piccole quantità (mattonelle, ceramiche)",
      ],
    },
    campane_vetro: [],
    nota: "A San Quirino sfalci, umido, vetro, pannolini/pannoloni e il servizio cartone riservato alle attività commerciali non sono a calendario porta a porta: hanno servizi dedicati non coperti da questa pagina. A calendario sono presenti solo secco, plastica e carta.",
    stale: false,
  },
];

// GEA è dato statico (vedi commento sopra): nessun fetch di rete, nessun
// fallback stale/cache — restituisce sempre lo stesso array. I parametri
// sono tenuti per uniformità di firma con rifiutiIngestIsontina()/
// rifiutiIngestAet2000(), anche se non usati.
async function rifiutiIngestGea(_annoCorrente, _meseCorrente, _precedentePerSlug) {
  console.log(`Rifiuti (GEA) dati statici: ${RIFIUTI_COMUNI_GEA.length} comuni (Aviano, Pordenone, Budoia, Andreis, Barcis, Claut, Clauzetto, Erto e Casso, Fanna, Frisanco, Caneva, Cimolais, Cordenons, Tramonti di Sopra, Tramonti di Sotto, Vito d'Asio, Vivaro, Maniago, Meduno, Sequals, Montereale Valcellina, Prata di Pordenone, Roveredo in Piano, San Quirino)`);
  return RIFIUTI_COMUNI_GEA;
}

// ---------------------------------------------------------------------
// Rifiuti, quarto gestore: AcegasApsAmga (Trieste città), via Il
// Rifiutologo — piattaforma "Officine Digitali"/Gruppo Hera, usata sia
// per i comuni Hera sia per Acegas (parametro isAcegas=1). Aggiunto il
// 18/09/2026.
//
// **CORREZIONE (stesso giorno, dopo l'HTML/JS reale della pagina
// principale "il Rifiutologo" /casa/rifiutologo/Trieste)**: la
// conclusione originale qui sotto — "Trieste non ha un calendario porta
// a porta per indirizzo" — **era sbagliata**, dedotta da una sola
// chiamata (getDataRifiutologoWeb.php) e da una cattura di rete
// incompleta (la tab Network catturata dall'utente in quel momento era
// a metà del flusso di ricerca indirizzo, PRIMA che scattasse la
// chiamata del calendario). L'HTML/JS della pagina principale mostra
// `urlWs.GetCalendarioPap: .../getCalendarioPap.php`, chiamata con
// `idComune/idIndirizzo/idCivico/isBusiness/idCategoriaAzienda/date/
// giorniDaMostrare=31` non appena l'utente arriva sulla pagina
// "SceltaProdotto" (subito dopo aver scelto comune+indirizzo+civico,
// PRIMA di cercare un oggetto specifico) — risposta
// `{ notaPap, calendario: [{ data, conferimenti: [{ macroprodotto:
// {descrizione, pittogramma}, orario, note }] }] }`, un vero calendario
// giorno-per-giorno con "orario di esposizione" per categoria di
// rifiuto. **Trieste ha quindi un calendario reale, ma è per
// indirizzo/civico (via+numero civico), non selezionabile per sola area
// come i comuni minori di Isontina** — richiede lo stesso flusso di
// ricerca indirizzo del sito vero (`getIndirizzi.php`/
// `getNumeriCivici.php`) prima di poter interrogare il calendario,
// diversamente dal semplice "primo indirizzo per area" bastato per
// Gorizia/Monfalcone/Grado (comuni molto più piccoli). Non ancora
// implementato in questa sessione — v. la richiesta di indicazioni
// all'utente subito dopo questo modulo, prima di scriverlo, viste le
// dimensioni di Trieste rispetto ai comuni già coperti.
//
// **Ancora valido**, invece, quanto segue sui punti fissi: Il
// Rifiutologo distingue chiaramente conferimenti "a calendario"
// (ingombranti/cartone/altre categorie con esposizione programmata,
// gestiti da getCalendarioPap.php) da conferimenti a punto fisso
// (stazioni ecologiche/isole interrate/campane, gestiti dagli endpoint
// sotto) — le due cose coesistono, non si escludono a vicenda.
//
// Per questo motivo rifiutiIngestAcegas() non riempie mai `aree` (resta
// [] per Trieste, il frontend mostra "nessun dato di calendario" com'è
// già il comportamento esistente per un comune senza raccolte) né
// `centro_raccolta` (resta null) — riempie invece il nuovo campo
// `stazioni_ecologiche` (v. lib/rifiuti.ts), un elenco anziché un
// singolo oggetto perché Trieste ne ha più d'uno in contemporanea.
//
// **Fonte verificata da sorgente reale**, non da un solo esempio di
// risposta: l'utente ha incollato l'HTML/JS completo della pagina
// "Stazioni ecologiche" di Trieste (https://www.ilrifiutologo.it/casa/
// stazioni-ecologiche/Trieste), che dichiara esplicitamente
//   newIdComune = 424 (fisso per Trieste), isAcegas = 1
//   urlWsBase = "https://webapp-ambiente.gruppohera.it"
//   path_ws_rifiutologo = "rifiutologo/rifiutologoweb"
//   GetListaStazioniEcologiche: .../getListaStazioniEcologiche.php
//   GetDettaglioStazione: .../getDettaglioStazione.php
// e i campi letti dal JS (setMarkers/addContentMappa/
// initDettaglioStazioneEcologica): id, nome, indirizzo, comune,
// latitudine, longitudine per l'elenco; aperture[] (dataInizio,
// dataFine, giorno 1-7, orarioInizio, orarioFine, note), chiusure[],
// comuni[] (sovracomunalità), macroprodotti[].descrizione per il
// dettaglio.
//
// **Non verificato da questa sandbox**: se questi due endpoint sono
// raggiungibili da una richiesta reale senza sessione browser — sia il
// proxy di rete del sandbox sia, separatamente, il sito stesso hanno
// rifiutato ogni tentativo di chiamata diretta da qui durante lo
// sviluppo. Confermato solo da un'esecuzione reale su GitHub Actions,
// come per isontinambiente.it.
//
// **Orari**: la pagina reale mostra intervalli di validità (dataInizio/
// dataFine) con possibili sovrapposizioni per giorno (vedi la dedup lato
// client in JS, arrayAperturaInizioFine). Qui si tiene solo l'intervallo
// attualmente valido per ciascuna stazione (senza dataFine, o con
// dataFine non ancora passata) invece di portarsi dietro l'intera
// storia — coerente con quanto mostra di default la pagina stessa.
//
// **"Dove lo butto?" (catalogo macroprodotti, ricerca oggetto→
// destinazione) NON incluso in questa prima versione**: l'endpoint che
// alimenta la casella di ricerca sulla pagina principale (/casa/
// rifiutologo/Trieste, diversa da questa) non è ancora stato confermato
// da sorgente reale — in attesa dell'HTML/JS di quella pagina prima di
// scriverne il parser, stesso principio (mai inventare un endpoint) già
// seguito per il resto di questo modulo.
// ---------------------------------------------------------------------

// SPOSTATO su Vercel il 19/09/2026 — questa sezione non fa più fetch
// da qui. Test reale dell'utente il 19/09/2026: la stessa identica
// richiesta a getListaStazioniEcologiche.php restituisce 200 con dati
// veri da una rete normale ma 403 da GitHub Actions — blocco per IP
// datacenter/cloud (stesso pattern già noto per TPL FVG/autobus), non
// risolvibile restando su questa infrastruttura. Il fetch (lista +
// dettaglio per stazione, stessi endpoint/campi documentati sopra) vive
// ora in app/api/cron/rifiuti-acegas/route.ts, richiamato una volta al
// giorno da un Vercel Cron Job (vedi vercel.json, orario fissato dopo
// la finestra di sync di questo script per evitare che una scrittura
// sovrascriva l'altra — v. commento lì per l'analisi dell'ordinamento).
// Dettagli/opzioni valutate: claude/fvgmonitor-stato.md, sezione
// "Rifiutologo/AcegasApsAmga — 403 solo da GitHub Actions..."
// (19/09/2026).
//
// Qui ci limitiamo a riproporre invariata l'ultima riga "trieste" già
// presente nello snapshot (scritta dalla route Vercel) — nessun nuovo
// tentativo di rete, nessuna modifica al campo `stale`: la freschezza
// di questo comune è decisa solo dalla route Vercel, non da questo
// script. Se la route Vercel non ha ancora mai girato (bootstrap),
// `vecchioTrieste` è `undefined` e Trieste resta assente da questo
// gestore per questo run, esattamente come per un gestore che non ha
// ancora prodotto nulla.
async function rifiutiIngestAcegas(precedentePerSlug) {
  const vecchioTrieste = precedentePerSlug.get("trieste");
  return vecchioTrieste ? [vecchioTrieste] : [];
}
// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// Rifiuti, quinto gestore: NET S.p.A. (provincia di Udine + Muggia, TS),
// via netaziendapulita.it. Aggiunto il 19/09/2026, a partire da un audit
// (pacchetto ChatGPT, `FVG_Monitor_NET_Multizone_Audit_v1.zip`) su quali
// comuni NET fossero multi-zona — architettura SQL proposta (tabelle
// `waste_collection_zones`/`waste_calendar_profiles`) NON adottata, come
// sempre in questo modulo: si resta su ingest-light.mjs + snapshot
// condiviso "rifiuti".
//
// **Verificato da questa sessione, non preso per buono dall'audit**: un
// WebFetch su netaziendapulita.it (raggiungibile, a differenza di
// gruppohera.it/aet2000.it) e soprattutto HTML reale incollato
// dall'utente (pagina indice comuni + Cervignano del Friuli) prima di
// scrivere qualunque selettore — stesso principio di sempre. Struttura
// reale: un `<select id="id-comune">`/elenco `<ul class="info-comune">`
// con 57 comuni e i loro slug reali (alcuni non deducibili per
// kebab-case ovvio, es. "Terzo di Aquileia" → `terzo-daquileia`, non
// `terzo-di-aquileia` — da qui l'insistenza su HTML reale invece di
// derivare gli slug dal nome). **Muggia è incluso nell'elenco NET** pur
// essendo provincia di Trieste, non Udine — stesso pattern già esistente
// per Isontina Ambiente (duino-aurisina/monrupino/sgonico-zgonik, sopra),
// un gestore può coprire comuni di più province.
//
// **Scope di questa v1, deciso esplicitamente con l'utente**: SOLO i
// comuni a calendario unico (nessuna suddivisione geografica in zone).
// Restano fuori Udine (multi-zona reale: 7 zone geografiche raggruppate
// in 3 calendari "Zona 1"/"Zone 2-4-5-6"/"Zone 3-7" — e, scoperta da
// questa sessione e non presente nell'audit, **il sito NON offre alcuna
// ricerca indirizzo→zona**: l'utente reale deve consultare un PDF
// "Elenco vie" o una mappa, esattamente come dovrebbe fare un ipotetico
// utente di questo sito) e Tarcento/Tavagnacco (regole "esclusive" non
// meglio specificate dall'audit, mai viste su HTML reale). Tutti e tre
// da valutare in una sessione futura.
//
// **Struttura di una pagina comune** (verificata su Cervignano del
// Friuli, HTML reale): calendario diviso in due blocchi, `#calendario-1`
// "Domestico" e `#calendario-2` "Non domestico", ciascuno con un proprio
// id numerico `cal=<id>` (diverso per ogni comune E per ogni blocco —
// mai fisso, va letto dal link "mese successivo" di ciascun blocco) e
// tabella `table.calendar` con celle `<td>` contenenti il numero del
// giorno seguito da zero o più `<div class="raccolta COLORE"
// title="Tipo">` (il `title` basta da solo per il tipo, come già per
// Acegas — non serve la `<dl class="legenda">`). Giorni del mese
// adiacente marcati `<span class="out">N</span>` dentro la cella, invece
// di una classe sulla cella stessa come AET2000 (`.not_current_month`)
// — stesso principio di scarto per non costruire date inesistenti.
//
// **Solo il calendario "Domestico" viene ingerito in questa v1**: è
// quello rilevante per l'utenza residenziale a cui si rivolge il resto
// del sito (nessun altro gestore già integrato distingue
// domestico/non-domestico) — dimezza anche le richieste di rete per
// comune. Non essendoci una suddivisione geografica per i comuni in
// questa v1, l'unica voce di `aree` ha sempre `area: null`.
//
// **Centro di raccolta**: sezione `#centri-raccolta`, indirizzo nell'
// `<h3>Centro di raccolta VIA</h3>` dentro `.info-centro`, orario nel
// testo libero che segue (separato da `<br>`, stesso trattamento già
// usato per Isontina/AET2000). Il paragrafo introduttivo con l'elenco
// materiali accettati è un testo boilerplate quasi identico su ogni
// comune (mai un elenco strutturato) — non affidabile da estrarre con un
// selettore robusto, quindi `materiali` resta sempre `[]` per questo
// gestore, deliberatamente (meglio vuoto che un'estrazione fragile).
//
// **Verifica**: fixture HTML reali (indice comuni + Cervignano) salvate
// su disco e parser testati offline con cheerio prima di scrivere questo
// codice — 57 comuni estratti correttamente inclusi gli slug non ovvi,
// 13 giorni corretti per settembre 2026 su Cervignano (carta/secco/
// plastica, pannolini scartato perché non è uno dei 5 TipoRifiuto
// standard — corretto, è un servizio opzionale non paragonabile agli
// altri), centro di raccolta estratto correttamente. **Non verificato**:
// il comportamento reale della navigazione mese-successivo con `cal=`
// sui 54 comuni in produzione (questa sandbox non raggiunge il sito per
// un test dal vivo, stesso limite di sempre) — la richiesta per il mese
// successivo passa sempre il `cal` del blocco #calendario-1 letto dalla
// pagina base, per restare corretti anche se la navigazione dell'altro
// blocco (#calendario-2, non ingerito) si comportasse diversamente.
const RIFIUTI_COMUNI_NET = [
  { slug: "aiello-del-friuli", nome: "Aiello del Friuli" },
  { slug: "aquileia", nome: "Aquileia" },
  { slug: "attimis", nome: "Attimis" },
  { slug: "bagnaria-arsa", nome: "Bagnaria Arsa" },
  { slug: "bicinicco", nome: "Bicinicco" },
  { slug: "buja", nome: "Buja" },
  { slug: "campolongo-tapogliano", nome: "Campolongo Tapogliano" },
  { slug: "carlino", nome: "Carlino" },
  { slug: "cassacco", nome: "Cassacco" },
  { slug: "castions-di-strada", nome: "Castions di Strada" },
  { slug: "cervignano-del-friuli", nome: "Cervignano del Friuli" },
  { slug: "chiopris-viscone", nome: "Chiopris Viscone" },
  { slug: "chiusaforte", nome: "Chiusaforte" },
  { slug: "cividale-del-friuli", nome: "Cividale del Friuli" },
  { slug: "drenchia", nome: "Drenchia" },
  { slug: "faedis", nome: "Faedis" },
  { slug: "fiumicello-villa-vicentina", nome: "Fiumicello Villa Vicentina" },
  { slug: "gonars", nome: "Gonars" },
  { slug: "grimacco", nome: "Grimacco" },
  { slug: "latisana", nome: "Latisana" },
  { slug: "malborghetto-valbruna", nome: "Malborghetto - Valbruna" },
  { slug: "manzano", nome: "Manzano" },
  { slug: "marano-lagunare", nome: "Marano Lagunare" },
  { slug: "mereto-di-tomba", nome: "Mereto di Tomba" },
  // Provincia di Trieste, non Udine — v. commento sopra.
  { slug: "muggia", nome: "Muggia", provincia: "trieste" },
  { slug: "muzzana-del-turgnano", nome: "Muzzana del Turgnano" },
  { slug: "palazzolo-dello-stella", nome: "Palazzolo dello Stella" },
  { slug: "palmanova", nome: "Palmanova" },
  { slug: "pocenia", nome: "Pocenia" },
  { slug: "pontebba", nome: "Pontebba" },
  { slug: "porpetto", nome: "Porpetto" },
  { slug: "povoletto", nome: "Povoletto" },
  { slug: "precenicco", nome: "Precenicco" },
  { slug: "prepotto", nome: "Prepotto" },
  { slug: "pulfero", nome: "Pulfero" },
  { slug: "resia", nome: "Resia" },
  { slug: "rivignano-teor", nome: "Rivignano Teor" },
  { slug: "ronchis", nome: "Ronchis" },
  { slug: "ruda", nome: "Ruda" },
  { slug: "san-giorgio-di-nogaro", nome: "San Giorgio di Nogaro" },
  { slug: "san-leonardo", nome: "San Leonardo" },
  { slug: "san-pietro-al-natisone", nome: "San Pietro al Natisone" },
  { slug: "san-vito-al-torre", nome: "San Vito al Torre" },
  { slug: "santa-maria-la-longa", nome: "Santa Maria La Longa" },
  { slug: "savogna", nome: "Savogna" },
  { slug: "stregna", nome: "Stregna" },
  { slug: "talmassons", nome: "Talmassons" },
  // Tarcento, Tavagnacco e Udine restano fuori da questa v1 — v. commento sopra.
  { slug: "tarvisio", nome: "Tarvisio" },
  { slug: "terzo-daquileia", nome: "Terzo di Aquileia" },
  { slug: "torreano", nome: "Torreano" },
  { slug: "torviscosa", nome: "Torviscosa" },
  { slug: "tricesimo", nome: "Tricesimo" },
  { slug: "trivignano-udinese", nome: "Trivignano Udinese" },
  { slug: "visco", nome: "Visco" },
].map((c) => ({
  ...c,
  url: `https://netaziendapulita.it/comuni/${c.slug}/`,
  provincia: c.provincia ?? "udine",
  gestore: "NET S.p.A.",
}));

// Legge il `cal=` del blocco #calendario-1 (Domestico) dal link "mese
// successivo" — diverso per ogni comune, non va mai fissato a mano.
function rifiutiNetParseCalId($scope) {
  const href = $scope.find('a[href*="cal="]').first().attr("href") || "";
  const m = href.match(/[?&]cal=(\d+)/);
  return m ? m[1] : null;
}

// Classificazione dedicata a NET, DIVERSA da `rifiutiTipoDaEtichetta()`
// usata da Isontina: per NET plastica e lattine NON sono lo stesso
// giro di raccolta — le lattine (e il "barattolame", stesso termine
// usato nell'elenco tipologie NET per "Imballaggi vetro e barattolame")
// vanno con il vetro, non con la plastica. Controllare vetro/lattine
// PRIMA di plastica è quindi essenziale: una cella con titolo tipo
// "Vetro e lattine" non deve mai finire in plastic_metals.
function rifiutiNetTipoDaEtichetta(s = "") {
  const n = s.normalize("NFKD").replace(/[̀-ͯ]/g, "").toLowerCase();
  if (n.includes("carta") || n.includes("cartone")) return "paper";
  if (n.includes("organico") || n.includes("umido")) return "organic";
  if (n.includes("vetro") || n.includes("lattine") || n.includes("barattolame")) return "glass";
  if (n.includes("plastica")) return "plastic_metals";
  if (n.includes("secco") || n.includes("residuo") || n.includes("indifferenzi")) return "residual";
  return null;
}

function rifiutiNetParseGiorni($, $scope, anno, mese) {
  const giorni = [];
  $scope.find("table.calendar td").each((_, td) => {
    const $td = $(td);
    // Giorno del mese adiacente: marcato con uno span, non una classe
    // sulla cella (a differenza di AET2000) — v. commento in testa alla
    // sezione.
    if ($td.find("span.out").length) return;
    const $clone = $td.clone();
    $clone.find("div.raccolta").remove();
    const giornoNum = parseInt(clean($clone.text()), 10);
    if (!giornoNum || giornoNum < 1 || giornoNum > 31) return;
    const tipi = new Set();
    $td.find("div.raccolta[title]").each((_, div) => {
      const tipo = rifiutiNetTipoDaEtichetta(clean($(div).attr("title") || ""));
      if (tipo) tipi.add(tipo);
    });
    if (tipi.size === 0) return;
    giorni.push({ data: `${anno}-${pad2(mese)}-${pad2(giornoNum)}`, tipi: [...tipi] });
  });
  return giorni;
}

// Indirizzo/orario del centro di raccolta. `materiali` resta sempre []
// — v. commento in testa alla sezione sul perché.
function rifiutiNetParseCentro($) {
  const $h3 = $("#centri-raccolta h3")
    .filter((_, el) => /centro di raccolta/i.test(clean($(el).text())))
    .first();
  if (!$h3.length) return null;
  const indirizzo = clean($h3.text()).replace(/^centro di raccolta\s*/i, "") || null;

  const $infoCentro = $h3.closest(".info-centro");
  let apertura = null;
  if ($infoCentro.length) {
    // cheerio .text() non inserisce uno spazio ai <br> — stesso problema
    // già risolto per i centri di raccolta di Isontina/AET2000.
    const $clone = $infoCentro.clone();
    $clone.find("h3, h4").remove();
    $clone.find("br").replaceWith(" | ");
    apertura = clean($clone.text()).replace(/^\|\s*/, "") || null;
  }

  if (!indirizzo && !apertura) return null;
  return { indirizzo, apertura, materiali: [] };
}

async function rifiutiNetFetchComune(comune, anno, mese) {
  const prossimo = rifiutiMeseSuccessivo(anno, mese);

  const $base = await rifiutiGetHtml(comune.url);
  const $domestico = $base("#calendario-1");
  if (!$domestico.length) throw new Error("blocco calendario domestico (#calendario-1) non trovato");
  const calId = rifiutiNetParseCalId($domestico);
  if (!calId) throw new Error("cal id del blocco domestico non trovato");

  const giorniMese1 = rifiutiNetParseGiorni($base, $domestico, anno, mese);

  const urlMese2 = new URL(comune.url);
  urlMese2.searchParams.set("month", String(prossimo.mese));
  urlMese2.searchParams.set("year", String(prossimo.anno));
  urlMese2.searchParams.set("cal", calId);
  const $mese2 = await rifiutiGetHtml(urlMese2.toString());
  const giorniMese2 = rifiutiNetParseGiorni($mese2, $mese2("#calendario-1"), prossimo.anno, prossimo.mese);

  const centro = rifiutiNetParseCentro($base);

  return {
    slug: comune.slug,
    nome: comune.nome,
    provincia: comune.provincia,
    gestore: comune.gestore,
    aree: [{ area: null, giorni: [...giorniMese1, ...giorniMese2] }],
    centro_raccolta: centro,
    campane_vetro: [],
    stale: false,
  };
}

// Recupera i comuni gestiti da NET. Come gli altri gestori, non scrive
// lo snapshot — vedi il commento sopra rifiutiIngestIsontina().
async function rifiutiIngestNet(annoCorrente, meseCorrente, precedentePerSlug) {
  const risultati = await rifiutiConLimiteConcorrenza(RIFIUTI_COMUNI_NET, RIFIUTI_CONCORRENZA, async (comune) => {
    try {
      return await rifiutiNetFetchComune(comune, annoCorrente, meseCorrente);
    } catch (err) {
      console.warn(`Rifiuti (NET): errore comune ${comune.nome}: ${err.message}`);
      const vecchio = precedentePerSlug.get(comune.slug);
      return vecchio ? { ...vecchio, stale: true } : null;
    }
  });
  const comuni = risultati.filter(Boolean);
  const falliti = RIFIUTI_COMUNI_NET.length - comuni.filter((c) => !c.stale).length;
  console.log(
    `Rifiuti (NET) aggiornati: ${comuni.length}/${RIFIUTI_COMUNI_NET.length} comuni` +
      (falliti > 0 ? ` (${falliti} da cache/stale per errori di rete)` : "")
  );
  return comuni;
}
// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// Rifiuti — MTF S.r.l. (sesto gestore, Lignano Sabbiadoro, provincia di
// Udine)
// ---------------------------------------------------------------------
//
// Segnalato dall'utente il 19/09/2026 con un pacchetto ChatGPT
// (FVG_Monitor_MTF_Maps_v1.zip: script Python `extract_mtf_mymaps.py`
// per scaricare l'export KML pubblico di due mappe Google My Maps —
// zone operative e cassonetti/cestini — più tabelle Supabase dedicate
// con geometrie jsonb/PostGIS). Stessa architettura NON adottata,
// stesso motivo di sempre in questo progetto: un solo ingest-light.mjs
// + snapshot condiviso "rifiuti", non tabelle a parte.
//
// **WebFetch da solo non è servito per verificare**: restituisce un
// riassunto testuale del contenuto, non l'XML grezzo — utile per farsi
// un'idea (ha confermato che gli URL KML sono reali e cosa contengono)
// ma inutilizzabile per estrarre coordinate esatte. **curl diretto da
// questa sandbox verso google.com è bloccato dal proxy di rete
// (organization policy)** — stesso limite già noto per altri domini in
// questo progetto, stavolta anche per Google Maps. Risolto con un
// browser reale (stessa via già usata per V.A.SCO. sopra): la
// *navigazione* diretta a google.com è bloccata anche lì, ma un
// `fetch()` eseguito nel contesto JS di una pagina già aperta su
// mtfsrl.it (quindi cross-origin verso google.com dal punto di vista
// del browser, non di questa sandbox) è passato senza problemi —
// recuperato così l'intero KML reale delle zone (29.221 caratteri, 17
// Placemark: Zona A×2, B×4, C×9, Pedonale×2 — salvato in
// .scratch/mtf-audit/mtf_zones_raw.kml per riferimento).
//
// **Scoperta chiave, che ha cambiato l'ambito di questa integrazione**:
// verificando con attenzione la Carta della Qualità reale (PDF
// ALLEGATO-B-MTF-8.4.25.pdf, non solo il primo riassunto — la prima
// lettura sommaria aveva erroneamente lasciato intendere che le zone
// determinassero anche la frequenza di raccolta rifiuti), le zone
// Pedonale/A/B/C determinano SOLO la frequenza di SPAZZAMENTO STRADE
// (pulizia urbana): Pedonale 5x/7gg → 2x/7gg (estate→inverno), Zona A
// 2x/7gg → 1x/7gg, Zona B 1x/7gg → 1x/15gg, Zona C 1x/15gg → 1x/30gg.
// La frequenza di SVUOTAMENTO DEI CASSONETTI (quella che riguarda
// davvero la sezione Rifiuti) è invece IDENTICA in tutto il comune,
// variabile solo per stagione — "5 volte ogni 7 giorni" (aprile-
// settembre), "2 volte ogni 7 giorni" (ottobre-marzo) — citato
// testualmente dal PDF per tutte e 4 le zone. Per questo, sentito
// l'utente, qui NON viene mostrata alcuna mappa delle zone (sarebbe
// stata fuorviante in una pagina di raccolta differenziata) né la
// mappa dei cassonetti/cestini della seconda My Maps (centinaia di
// punti, fuori ambito per questa integrazione) — solo l'informazione
// pertinente: raccolta stradale, materiali/colori, frequenza
// stagionale uguale per tutta la città. V. `RaccoltaStradale` in
// lib/rifiuti.ts.
//
// **Non un fetch ad ogni esecuzione**: come VASCO_MONFALCONE e i dati
// GEA, è contenuto statico da un documento pubblicato (Carta della
// Qualità datata 8/4/2025) — un fetch live per una tabella che cambia
// una volta l'anno non è giustificato.
const RACCOLTA_STRADALE_LIGNANO = {
  descrizione:
    "Raccolta rifiuti interamente stradale, a cassonetti colorati sempre disponibili — nessun porta a porta.",
  materiali: [
    { tipo: "paper", colore: "Giallo" },
    { tipo: "plastic_metals", colore: "Blu" },
    { tipo: "glass", colore: "Verde" },
    { tipo: "organic", colore: "Marrone" },
    { tipo: "residual", colore: "Blu con coperchio giallo" },
  ],
  frequenza_estate: "5 volte a settimana (aprile–settembre), uguale in tutta la città",
  frequenza_inverno: "2 volte a settimana (ottobre–marzo), uguale in tutta la città",
};

// Recupera il comune gestito da MTF S.r.l. Come gli altri gestori, non
// scrive lo snapshot — vedi il commento sopra rifiutiIngestIsontina().
// Nessun fetch di rete: v. commento esteso sopra RACCOLTA_STRADALE_LIGNANO.
async function rifiutiIngestMtf() {
  return [
    {
      slug: "lignano-sabbiadoro",
      nome: "Lignano Sabbiadoro",
      provincia: "udine",
      gestore: "MTF S.r.l.",
      aree: [],
      centro_raccolta: null,
      campane_vetro: [],
      raccolta_stradale: RACCOLTA_STRADALE_LIGNANO,
      stale: false,
    },
  ];
}
// ---------------------------------------------------------------------

async function ingestRifiuti() {
  const forzato = process.env.GITHUB_EVENT_NAME === "workflow_dispatch";
  if (!forzato) {
    const { ora, minuti } = oraEuropeRome();
    if (ora !== RIFIUTI_ORA_SYNC || minuti >= 15) {
      console.log("Rifiuti: fuori dalla finestra di sync giornaliera (03:00 Europe/Rome), salto.");
      return;
    }
  }

  const oggiIso = oggiEuropeRome();
  const [annoCorrente, meseCorrente] = oggiIso.split("-").map(Number);

  const precedente = (await leggiSnapshotEsistente("rifiuti"))?.comuni ?? [];
  const precedentePerSlug = new Map(precedente.map((c) => [c.slug, c]));

  // Ogni gestore viene recuperato separatamente e unito qui in un unico
  // array prima dell'unica scrittura sullo snapshot condiviso "rifiuti".
  const comuniIsontina = await rifiutiIngestIsontina(annoCorrente, meseCorrente, precedentePerSlug);
  const comuniAet2000 = await rifiutiIngestAet2000(annoCorrente, meseCorrente, precedentePerSlug);
  const comuniGea = await rifiutiIngestGea(annoCorrente, meseCorrente, precedentePerSlug);
  const comuniAcegas = await rifiutiIngestAcegas(precedentePerSlug);
  const comuniNet = await rifiutiIngestNet(annoCorrente, meseCorrente, precedentePerSlug);
  const comuniMtf = await rifiutiIngestMtf();
  const comuni = [...comuniIsontina, ...comuniAet2000, ...comuniGea, ...comuniAcegas, ...comuniNet, ...comuniMtf];

  if (comuni.length === 0) {
    console.warn("Rifiuti: nessun comune recuperato, snapshot non aggiornato.");
    return;
  }

  await upsertSnapshot("rifiuti", "ambiente", null, {
    comuni,
    aggiornato_al: new Date().toISOString(),
  });
  console.log(`Rifiuti: snapshot aggiornato con ${comuni.length} comuni totali.`);
}
// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// CALCIO — campionati dilettantistici FVG (gare.lnd.it). La pagina è
// un'app Inertia.js: al primo caricamento normale (nessun header
// speciale necessario) incorpora l'intero stato in un tag
// <script data-page="app" type="application/json"> — lo estraiamo
// con cheerio invece di scrapare l'HTML visibile, stesso principio
// degli altri moduli ma sorgente diversa (JSON incorporato). Questa
// struttura è comune a tutto il dominio gare.lnd.it — verificata più
// volte su più campionati diversi (Eccellenza, Promozione, Prima/
// Seconda/Terza Categoria) — estendibile aggiungendo voci a
// COMPETIZIONI_CALCIO.
//
// Stagioni: si tengono SEMPRE due stagioni per competizione — quella
// corrente (default in UI) e quella immediatamente precedente
// (archivio, selezionabile da un toggle a fondo pagina su /calcio).
// Verificato il 31/08/2026 via screenshot fornito dall'utente: la
// stagione 2026/27 è già pubblicata su gare.lnd.it (calendario dal
// 5 settembre 2026, classifica con tutte le squadre a 0 partite
// giocate) con lo stesso URL, solo `stagione=2026` invece di 2025.
// Promemoria annuale: a inizio nuova stagione, il primo valore di
// CALCIO_STAGIONI diventa il secondo (archivio) e si aggiunge il
// nuovo anno come primo (default) — invariato invece il resto
// (COMPETIZIONI_CALCIO, che non contiene più la stagione nell'URL).
// ---------------------------------------------------------------------

const CALCIO_STAGIONI = ["2026", "2025"]; // [0] = corrente/default, [1] = archivio

const COMPETIZIONI_CALCIO = [
  { slug: "eccellenza-a", nome: "Eccellenza", girone: "Girone A", campionato: "EC", gironeParam: "A" },
  { slug: "promozione-a", nome: "Promozione", girone: "Girone A", campionato: "PR", gironeParam: "A" },
  { slug: "prima-categoria-a", nome: "Prima Categoria", girone: "Girone A", campionato: "1C", gironeParam: "A" },
  { slug: "prima-categoria-b", nome: "Prima Categoria", girone: "Girone B", campionato: "1C", gironeParam: "B" },
  { slug: "prima-categoria-c", nome: "Prima Categoria", girone: "Girone C", campionato: "1C", gironeParam: "C" },
  { slug: "seconda-categoria-gorizia", nome: "Seconda Categoria Gorizia", girone: "Girone D", campionato: "22", gironeParam: "D" },
  { slug: "seconda-categoria-pordenone", nome: "Seconda Categoria Pordenone", girone: "Girone A", campionato: "23", gironeParam: "A" },
  { slug: "seconda-categoria-udine-b", nome: "Seconda Categoria Udine", girone: "Girone B", campionato: "26", gironeParam: "B" },
  { slug: "seconda-categoria-udine-c", nome: "Seconda Categoria Udine", girone: "Girone C", campionato: "26", gironeParam: "C" },
  // Terza Categoria (17/09/2026, richiesta esplicita dell'utente con 4
  // link diretti già navigati/copiati da lui su gare.lnd.it). I primi 2
  // (girone D, girone A) usano l'URL "classico" già in uso per tutte le
  // altre competizioni sopra. Gli ultimi 2 (girone B, girone C, stesso
  // campionato "36") sono stati incollati dall'utente con un percorso
  // diverso, `/competizione/friuli-venezia-giulia` invece di `/` con
  // `cr=07` esplicito — non verificabile da questa sessione se le due
  // forme siano intercambiabili (gare.lnd.it non è raggiungibile
  // direttamente da questa sandbox, e WebFetch non vede i dati perché
  // sono incorporati in un tag <script> JSON, tagliato via dalla
  // conversione HTML→markdown — stesso limite già noto per questo
  // sito). Per questo qui si replica ESATTAMENTE il link fornito
  // dall'utente (vedi `urlBase` sotto e `urlCalcio()`), invece di
  // riscriverlo nella forma "classica" e rischiare di rompere qualcosa
  // che l'utente aveva già verificato funzionare nel proprio browser.
  { slug: "terza-categoria-d", nome: "Terza Categoria", girone: "Girone D", campionato: "32", gironeParam: "D" },
  { slug: "terza-categoria-a", nome: "Terza Categoria", girone: "Girone A", campionato: "33", gironeParam: "A" },
  {
    slug: "terza-categoria-b",
    nome: "Terza Categoria",
    girone: "Girone B",
    campionato: "36",
    gironeParam: "B",
    urlBase: "https://gare.lnd.it/competizione/friuli-venezia-giulia",
  },
  {
    slug: "terza-categoria-c",
    nome: "Terza Categoria",
    girone: "Girone C",
    campionato: "36",
    gironeParam: "C",
    urlBase: "https://gare.lnd.it/competizione/friuli-venezia-giulia",
  },
];

// Costruisce l'URL gare.lnd.it per una competizione/stagione. Forma
// "classica" (`https://gare.lnd.it/?campionato=...&cr=07`) per default;
// se la competizione specifica `urlBase`, usa quella base invece (senza
// `cr=07` esplicito — vedi commento sopra su Terza Categoria B/C).
function urlCalcio(comp, stagione) {
  if (comp.urlBase) {
    return `${comp.urlBase}?campionato=${comp.campionato}&girone=${comp.gironeParam}&stagione=${stagione}`;
  }
  return `https://gare.lnd.it/?campionato=${comp.campionato}&girone=${comp.gironeParam}&stagione=${stagione}&cr=07`;
}

async function ingestCalcioCompetizione(comp, stagione) {
  const url = urlCalcio(comp, stagione);
  const res = await fetchConRetry(url, {
    headers: { "User-Agent": "Mozilla/5.0 (compatible; FVGMonitorBot/1.0)" },
  });
  if (!res.ok) {
    console.warn(`Pagina calcio "${comp.nome}" stagione ${stagione} non disponibile (HTTP ${res.status})`);
    return;
  }

  const html = await res.text();
  const $ = cheerio.load(html);
  const scriptTag = $('script[data-page="app"]').first().html();
  if (!scriptTag) {
    console.warn(`Tag dati non trovato per "${comp.nome}" — la struttura della pagina potrebbe essere cambiata`);
    return;
  }

  let dati;
  try {
    dati = JSON.parse(scriptTag);
  } catch {
    console.warn(`JSON non valido per "${comp.nome}"`);
    return;
  }

  const props = dati.props;
  const partite = (props.matches || []).map((m) => ({
    casa: m.home,
    ospite: m.away,
    golCasa: m.homeGoals,
    golOspite: m.awayGoals,
    data: m.date,
    ora: m.time,
    campo: m.field,
    logoCasa: m.homeLogo,
    logoOspite: m.awayLogo,
    inCorso: m.isLive,
  }));

  const classifica = (props.standings || []).map((s) => ({
    posizione: s.position,
    squadra: s.team,
    logo: s.logo,
    punti: s.points,
    giocate: s.played,
    vittorie: s.wins,
    pareggi: s.draws,
    sconfitte: s.losses,
    golFatti: s.goalsFor,
    golSubiti: s.goalsAgainst,
  }));

  await upsertSnapshot(`calcio:${comp.slug}:${stagione}`, "calcio", null, {
    campionato: comp.nome,
    girone: comp.girone,
    stagione,
    giornata_corrente: props.currentMatchday || null,
    partite,
    classifica,
    aggiornato_al: new Date().toISOString(),
  });
  console.log(`Calcio aggiornato (${comp.nome} ${comp.girone}, stagione ${stagione}): ${partite.length} partite, ${classifica.length} squadre`);
}

async function ingestCalcio() {
  await Promise.all(
    COMPETIZIONI_CALCIO.flatMap((c) => CALCIO_STAGIONI.map((stagione) => ingestCalcioCompetizione(c, stagione)))
  );
}

// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// BASKET — fip.it/risultati (Federazione Italiana Pallacanestro).
// A differenza di gare.lnd.it, qui i dati sono già presenti nell'HTML
// servito dal server (nessun tag JSON incorporato) — scraping diretto
// con cheerio, struttura verificata manualmente via devtools.
//
// Nota: l'URL usato non specifica un girone/comitato esplicito come
// per il calcio — la pagina mostra un default (al momento: Trieste,
// Serie C/Divisione Regionale 1, Girone D) che potrebbe cambiare nel
// tempo lato FIP. Se in futuro i dati non tornano coerenti, va
// verificato se l'URL richiede parametri più specifici.
// ---------------------------------------------------------------------

const COMPETIZIONI_BASKET = [
  {
    slug: "trieste-serie-c",
    nome: "Serie C — Divisione Regionale 1",
    girone: "Girone D",
    url: "https://fip.it/risultati/?group=campionati-regionali&regione_codice=FR&comitato_codice=RFR",
  },
];

async function ingestBasketCompetizione(comp) {
  const res = await fetchConRetry(comp.url, {
    headers: { "User-Agent": "Mozilla/5.0 (compatible; FVGMonitorBot/1.0)" },
  });
  if (!res.ok) {
    console.warn(`Pagina basket "${comp.nome}" non disponibile (HTTP ${res.status})`);
    return;
  }

  const html = await res.text();
  const $ = cheerio.load(html);

  const partite = [];
  $(".results-matches__match").each((_, el) => {
    const squadre = $(el).find(".teams .team");
    if (squadre.length < 2) return;
    const casa = $(squadre[0]).find(".team__name").text().trim();
    const ospite = $(squadre[1]).find(".team__name").text().trim();
    const puntiCasa = $(squadre[0]).find(".team__points").text().trim();
    const puntiOspite = $(squadre[1]).find(".team__points").text().trim();
    const data = $(el).find(".date").first().text().trim();
    const ora = $(el).find(".time").first().text().trim();
    if (casa && ospite) {
      partite.push({
        casa,
        ospite,
        puntiCasa: puntiCasa || null,
        puntiOspite: puntiOspite || null,
        data,
        ora,
      });
    }
  });

  const classifica = [];
  $(".results-tab.results-ranking-full table tbody tr").each((_, tr) => {
    const celle = $(tr).find("td");
    if (celle.length < 8) return;
    classifica.push({
      posizione: $(celle[0]).text().trim(),
      squadra: $(celle[1]).find(".team__name").text().trim(),
      punti: $(celle[2]).text().trim(),
      giocate: $(celle[3]).text().trim(),
      vittorie: $(celle[4]).text().trim(),
      sconfitte: $(celle[5]).text().trim(),
      puntiFatti: $(celle[6]).text().trim(),
      puntiSubiti: $(celle[7]).text().trim(),
    });
  });

  if (partite.length === 0 && classifica.length === 0) {
    console.warn(`Nessun dato basket estratto per "${comp.nome}" — la struttura HTML potrebbe essere cambiata`);
    return;
  }

  await upsertSnapshot(`basket:${comp.slug}`, "basket", null, {
    campionato: comp.nome,
    girone: comp.girone,
    partite,
    classifica,
    aggiornato_al: new Date().toISOString(),
  });
  console.log(`Basket aggiornato (${comp.nome} ${comp.girone}): ${partite.length} partite, ${classifica.length} squadre`);
}

async function ingestBasket() {
  await Promise.all(COMPETIZIONI_BASKET.map((c) => ingestBasketCompetizione(c)));
}

// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// BASEBALL — live.baseballfvg.it (sito dell'utente stesso, con due
// route API dedicate create apposta per FVG Monitor). Nessuna
// protezione anti-bot, fetch semplice — a differenza del tentativo
// iniziale con fibs.it direttamente (bloccato con HTTP 403).
//
// Le competizioni vengono scoperte dinamicamente dalla risposta del
// calendario (filtrata fvg=true) invece di essere elencate a mano,
// dato che coprono sia baseball che softball con squadre FVG diverse.
// ---------------------------------------------------------------------

const BASEBALLFVG_BASE = "https://live.baseballfvg.it/api";

async function ingestBaseballFvg() {
  const res = await fetchConRetry(`${BASEBALLFVG_BASE}/calendario?sport=all&fvg=true`);
  if (!res.ok) {
    console.warn(`Calendario baseball FVG non disponibile (HTTP ${res.status})`);
    return;
  }

  const { games } = await res.json();
  if (!Array.isArray(games) || games.length === 0) {
    console.warn("Nessuna partita trovata sul calendario baseball FVG");
    return;
  }

  // Raggruppa le partite per competizione (id univoco lato sorgente)
  const competizioni = new Map();
  for (const g of games) {
    const id = g.competition?.id;
    if (!id) continue;
    if (!competizioni.has(id)) {
      competizioni.set(id, { id, nome: g.competition.name, sport: g.competition.sport, partite: [] });
    }
    competizioni.get(id).partite.push(g);
  }

  for (const comp of competizioni.values()) {
    // Selezioniamo le 10 partite più vicine ad "adesso" (sia risultati
    // recenti nel passato che prossimi incontri nel futuro), poi le
    // riordiniamo in ordine cronologico crescente per la visualizzazione:
    // prima le partite più vicine a oggi, poi quelle più lontane (es.
    // prima il 12 settembre, poi il 19). In precedenza si ordinava per
    // data decrescente e si prendevano le prime 10, il che mostrava le
    // partite più lontane nel futuro per prime — ordine invertito rispetto
    // a quanto atteso, ed era anche facile scambiarlo per un disallineamento
    // rispetto al calendario ufficiale, dato che le partite più vicine a
    // oggi (facilmente confrontabili con il calendario) finivano in fondo
    // alla lista invece che in cima.
    const ora = Date.now();
    const partiteRecenti = comp.partite
      .slice()
      .sort(
        (a, b) =>
          Math.abs(new Date(a.startsAt) - ora) - Math.abs(new Date(b.startsAt) - ora)
      )
      .slice(0, 10)
      .sort((a, b) => new Date(a.startsAt) - new Date(b.startsAt))
      .map((g) => ({
        casa: g.homeTeam?.name ?? "?",
        casaFvg: !!g.homeTeam?.isFvg,
        ospite: g.awayTeam?.name ?? "?",
        ospiteFvg: !!g.awayTeam?.isFvg,
        punteggioCasa: g.homeScore,
        punteggioOspite: g.awayScore,
        data: g.startsAt,
        stato: g.status,
        luogo: g.venue,
      }));

    let classifica = [];
    try {
      const resClass = await fetchConRetry(`${BASEBALLFVG_BASE}/classifiche?competition=${comp.id}`);
      if (resClass.ok) {
        const { rows } = await resClass.json();
        classifica = (rows || []).map((r) => ({
          girone: r.groupName,
          posizione: r.position,
          squadra: r.team?.name ?? "?",
          squadraFvg: !!r.team?.isFvg,
          vittorie: r.wins,
          sconfitte: r.losses,
          percentuale: r.percentage,
          partiteDietro: r.gamesBehind,
        }));
      } else {
        console.warn(`Classifica baseball "${comp.nome}" non disponibile (HTTP ${resClass.status})`);
      }
    } catch (err) {
      console.warn(`Errore classifica baseball "${comp.nome}": ${err.message}`);
    }

    await upsertSnapshot(`baseball:${comp.id}`, "baseball", null, {
      campionato: comp.nome,
      sport: comp.sport,
      partite: partiteRecenti,
      classifica,
      aggiornato_al: new Date().toISOString(),
    });
    console.log(`Baseball aggiornato (${comp.nome}): ${partiteRecenti.length} partite, ${classifica.length} squadre in classifica`);
  }
}

// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// TENNIS — ranking FITP (Federazione Italiana Tennis e Padel), categoria
// "Assoluti" (open, senza limiti di età), maschile e femminile, FVG.
//
// API scoperta dall'utente via DevTools (la pagina ufficiale fitp.it è
// una SPA Angular che non espone dati nell'HTML statico — stesso
// ostacolo incontrato con il nuoto, ma qui risolto grazie a un
// endpoint JSON diretto).
//
//   POST https://dp-myfit-test-function-v2.azurewebsites.net/api/v1/tesserati/list
//   Content-Type: application/json
//   body: { id_disciplina, id_provincia, id_regione, id_gruppo_rank,
//           id_categoria_rank, id_categoria_eta, sesso, freetext,
//           rowstoskip, fetchrows, sortcolumn, sortorder }
//
// id_regione=6 → Friuli-Venezia Giulia, id_disciplina=4332 → Tennis
// (entrambi confermati sperimentalmente confrontando i conteggi).
//
// NOTE IMPORTANTI (verificate con richieste reali, non assunte):
//
// 1) sortcolumn NON è affidabile per ordinare per classifica. Testati
//    "gr", "grado", "classifica_ranking": nessuno produce un ordine
//    corretto (es. con "grado"/"classifica_ranking" il primo risultato
//    aveva gr="4.NC", una delle classifiche peggiori possibili — e i
//    due nomi colonna restituivano risultati IDENTICI, segno che
//    entrambi vengono ignorati lato server e si ricade su un ordine
//    di default arbitrario). Risolto ordinando lato client (nota 4).
//
// 2) sesso ("M"/"F") è invece un filtro affidabile e verificato:
//    M=2691 + F=757 = 3448, combacia col totale non filtrato.
//
// 3) Il parametro id_categoria_eta (presumibilmente il filtro
//    server-side per "categoria età", es. Assoluti/Over 40/Under 16)
//    non è stato scoperto — nessun valore noto per "Assoluti". Aggirato
//    filtrando lato client sul campo restituito "ce": si ipotizza (in
//    base a tutti gli esempi osservati, mai smentita) che
//    ce === "NOR" = Assoluti maschile, ce === "NOF" = Assoluti
//    femminile — non confermato da un'etichetta esplicita dell'API,
//    solo dedotto dai nomi e dal genere dei nominativi corrispondenti.
//    Se in futuro risultasse sbagliato, va rivisto qui.
//
// 4) Ordinamento classifica: il campo "gr" (grado/classifica) segue
//    sempre il formato "<cifra>.<cifra o NC>" (es. "2.4", "4.NC" — 1 è
//    la categoria migliore, 4 la più debole; NC = non classificato,
//    peggio di qualsiasi cifra). Un confronto alfabetico ascendente
//    sulla stringa "gr" produce da solo l'ordine corretto dal migliore
//    al peggiore, perché il carattere "N" ha valore ASCII maggiore di
//    qualsiasi cifra — nessun bisogno di interpretare la gerarchia
//    delle classifiche italiane. Verificato su tutti i valori "gr"
//    osservati nei campioni (tutti nel formato atteso). La cifra prima
//    del punto è anche la "categoria" (2ª/3ª/4ª) richiesta dall'utente
//    per suddividere le classifiche (vedi ingestGenereTennis sotto).
//
// 5) La prima versione di questo modulo (senza deduplicazione)
//    produceva classifiche con lo stesso giocatore ripetuto più volte
//    (stessi nome/cognome/comune/grado/V-P) — segnalato dall'utente con
//    uno screenshot in produzione. Il sandbox di questa sessione non
//    riesce a chiamare l'API per verificare direttamente la causa
//    esatta (l'host `dp-myfit-test-function-v2.azurewebsites.net` non è
//    nella allowlist di rete di questo ambiente — errore distinto da un
//    blocco lato FITP, non testabile da qui nemmeno con un fetch
//    diretto in Node). Cause plausibili non escluse a vicenda: (a)
//    l'API non rispetta `rowstoskip` in modo affidabile e restituisce
//    pagine sovrapposte; (b) con `id_gruppo_rank`/`id_categoria_rank`
//    lasciati a null l'API restituisce più righe per la stessa persona
//    (es. una per gruppo di ranking). **Soluzione adottata, robusta
//    indipendentemente dalla causa esatta**: deduplicare per
//    nome+cognome+comune dopo il filtro `ce`, PRIMA di ordinare — vedi
//    `dedupeGiocatoriTennis`. Rimossa anche la condizione di stop
//    `giocatori.length < fetchrows` nella paginazione (poteva fermarsi
//    troppo presto se l'API limita silenziosamente la dimensione di
//    pagina sotto quella richiesta), sostituita da un contatore di
//    sicurezza anti-loop-infinito.
//
// Per poter ordinare noi stessi serve l'elenco completo per categoria:
// si pagina l'intero elenco per sesso (filtro server affidabile) e si
// filtra per "ce" lato client, senza altri filtri server-side.
// ---------------------------------------------------------------------

const TENNIS_API_URL = "https://dp-myfit-test-function-v2.azurewebsites.net/api/v1/tesserati/list";
const TENNIS_ID_REGIONE_FVG = 6;
const TENNIS_ID_DISCIPLINA = 4332;
const TENNIS_PAGE_SIZE = 500;
const TENNIS_TOP_N = 10;
const TENNIS_MAX_PAGINE = 30; // sicurezza anti-loop-infinito, non un limite atteso in pratica

async function fetchPaginaTennis(sesso, rowstoskip) {
  const res = await fetchConRetry(TENNIS_API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "User-Agent": "Mozilla/5.0 (compatible; FVGMonitorBot/1.0)",
    },
    body: JSON.stringify({
      id_disciplina: TENNIS_ID_DISCIPLINA,
      id_provincia: 0,
      id_regione: TENNIS_ID_REGIONE_FVG,
      id_gruppo_rank: null,
      id_categoria_rank: null,
      id_categoria_eta: null,
      sesso,
      freetext: null,
      rowstoskip,
      fetchrows: TENNIS_PAGE_SIZE,
      sortcolumn: "cognome",
      sortorder: "asc",
    }),
  });
  if (!res.ok) throw new Error(`Tennis API HTTP ${res.status} (sesso=${sesso}, skip=${rowstoskip})`);
  return res.json();
}

// Pagina l'intero elenco per genere. Si ferma solo quando rowstoskip
// raggiunge il totale dichiarato dall'API (`record`) o quando una
// pagina torna vuota — MAI in base alla lunghezza della pagina rispetto
// a fetchrows (vedi nota 5 sopra: l'API potrebbe limitare la pagina
// sotto il valore richiesto senza avvisare).
async function fetchTuttiGiocatoriTennis(sesso) {
  const tutti = [];
  let rowstoskip = 0;
  let pagina = 0;
  for (;;) {
    pagina++;
    if (pagina > TENNIS_MAX_PAGINE) {
      console.warn(`Tennis (${sesso}): fermato dopo ${TENNIS_MAX_PAGINE} pagine — controllare se l'API rispetta rowstoskip`);
      break;
    }
    const { giocatori, record } = await fetchPaginaTennis(sesso, rowstoskip);
    if (!Array.isArray(giocatori) || giocatori.length === 0) break;
    tutti.push(...giocatori);
    rowstoskip += giocatori.length;
    if (rowstoskip >= record) break;
  }
  return tutti;
}

function mappaGiocatoreTennis(g) {
  return {
    nome: g.n,
    cognome: g.c,
    comune: g.cit,
    grado: g.gr,
    categoriaRanking: g.cr,
    partiteVinte: g.pv,
    partitePerse: g.pp,
  };
}

// Chiave usata per riconoscere lo stesso giocatore su più righe
// restituite dall'API (vedi nota 5 sopra) — non abbiamo un ID persona
// di cui fidarci ciecamente, nome+cognome+comune è il miglior
// compromesso disponibile con i campi che l'API espone.
function chiaveGiocatoreTennis(g) {
  return `${(g.c || "").trim().toLowerCase()}|${(g.n || "").trim().toLowerCase()}|${(g.cit || "").trim().toLowerCase()}`;
}

function dedupeGiocatoriTennis(lista) {
  const mappa = new Map();
  for (const g of lista) {
    const chiave = chiaveGiocatoreTennis(g);
    const esistente = mappa.get(chiave);
    // A parità di persona, se per assurdo i duplicati avessero un grado
    // diverso, teniamo quello migliore (stringa più bassa — vedi nota 4).
    if (!esistente || (g.gr && esistente.gr && g.gr < esistente.gr)) {
      mappa.set(chiave, g);
    }
  }
  return [...mappa.values()];
}

// Cifra prima del punto in "gr" = categoria (1 migliore .. 4 più debole,
// vedi nota 4 sopra) — sempre presente nel formato osservato.
function categoriaDiGrado(gr) {
  return gr ? gr.charAt(0) : null;
}

// Costruisce le classifiche 2ª/3ª/4ª categoria (richieste esplicitamente
// dall'utente, invece di un'unica lista "assoluta" dominata dai pochi
// giocatori di 1ª/2ª categoria) per un genere.
async function ingestGenereTennis(sesso, ceAtteso, prefissoSlug, prefissoNome) {
  const tutti = await fetchTuttiGiocatoriTennis(sesso);
  const filtrati = tutti.filter((g) => g.ce === ceAtteso && g.gr);
  const senzaDuplicati = dedupeGiocatoriTennis(filtrati);

  return ["2", "3", "4"].map((cifra) => {
    const delGruppo = senzaDuplicati
      .filter((g) => categoriaDiGrado(g.gr) === cifra)
      // Ordinamento lato client — vedi nota 4 sopra: confronto stringa
      // ascendente sul campo "gr" produce l'ordine dal migliore al peggiore.
      .sort((a, b) => (a.gr < b.gr ? -1 : a.gr > b.gr ? 1 : 0));
    return {
      slug: `${prefissoSlug}-${cifra}a-categoria`,
      nome: `${prefissoNome} — ${cifra}ª categoria`,
      giocatori: delGruppo.slice(0, TENNIS_TOP_N).map(mappaGiocatoreTennis),
      totale_categoria: delGruppo.length,
    };
  });
}

async function ingestTennis() {
  const [categorieM, categorieF] = await Promise.all([
    ingestGenereTennis("M", "NOR", "maschile", "Maschile"),
    ingestGenereTennis("F", "NOF", "femminile", "Femminile"),
  ]);

  const categorie = [...categorieM, ...categorieF];
  const totaleGiocatori = categorie.reduce((somma, c) => somma + c.giocatori.length, 0);
  if (totaleGiocatori === 0) {
    console.warn("Nessun giocatore tennis trovato nelle categorie 2ª/3ª/4ª — controllare l'ipotesi ce/NOR/NOF o il formato di gr");
    return;
  }

  await upsertSnapshot("tennis:classifica", "tennis", null, {
    categorie,
    aggiornato_al: new Date().toISOString(),
  });
  console.log(
    `Tennis aggiornato: ${categorie.map((c) => `${c.nome} ${c.giocatori.length}/${c.totale_categoria}`).join(", ")}`
  );
}

// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// SCI — calendario gare FISI (Federazione Italiana Sport Invernali),
// Comitato Friuli-Venezia Giulia. A differenza di Calcio/Basket/
// Baseball/Tennis, qui NON esiste una classifica di campionato: sono
// gare singole (fondo, salto, combinata nordica, biathlon, alpino,
// ecc.) — stesso tipo di modello dati discusso e mai implementato per
// il Nuoto (vedi "Idee future" nel doc di progetto), ma qui la fonte
// è stata effettivamente sbloccata.
//
// Endpoint scoperto dall'utente via DevTools → Network → "Copia come
// cURL" (stesso metodo del Tennis):
//
//   GET https://comitati.fisi.org/wp-admin/admin-ajax.php
//       ?action=competizioni_get_all
//       &offset=0&limit=10
//       &url=https://comitati.fisi.org/friuli-venezia-giulia/calendario/?d=
//       &idStagione=2026&dataInizio=01/06/2026&dataFine=30/05/2027
//
// Azione AJAX di WordPress (comitati.fisi.org gira su WordPress — solo
// le route REST standard sono documentate su /wp-json/, questa azione
// custom non compare lì). Risposta: array di gare, es.
//   { disciplina, dataInizio, comune, provincia, nazione, nome,
//     formato, livello, status, idCompetizione, logo_url }
//
// NOTE (dedotte da UNA sola risposta reale catturata il 25/08/2026,
// non da uno script di test sistematico come per calcio/tennis — vedi
// limiti sotto):
//
// 1) Il filtro geografico (FVG) non passa per un id numerico come nel
//    Tennis (`id_regione`) — passa per il parametro `url`, che deve
//    corrispondere alla pagina calendario del comitato regionale
//    (`FISI_CALENDARIO_URL` sotto). Non verificato cosa succeda con un
//    valore diverso — non necessario dato che l'unico valore che ci
//    serve è noto e funzionante.
//
// 2) `idStagione`/`dataInizio`/`dataFine`: la richiesta reale catturata
//    aveva idStagione=2026 abbinato a dataInizio=01/06/2026 e
//    dataFine=30/05/2027 — dedotto che la "stagione sciistica" è
//    etichettata con l'anno di inizio e va da giugno a maggio
//    dell'anno successivo (convenzione tipica dello sport invernale,
//    non documentata esplicitamente da FISI). Calcolata **dinamicamente**
//    a ogni esecuzione (`stagioneScisticaCorrente()`) invece di essere
//    scritta a mano come `COMPETIZIONI_CALCIO` (che richiede un
//    promemoria annuale manuale, vedi nota su calcio in README) — qui
//    non serve nessun intervento a ogni cambio stagione.
//
// 3) Solo 4 gare estive/autunnali trovate nel primo test (Sci di fondo,
//    Combinata Nordica, Salto con gli sci, Biathlon — a fine agosto la
//    stagione invernale vera e propria, dicembre-marzo, non è ancora
//    popolata nel calendario). Non un bug: il calendario gare si
//    riempie progressivamente nel corso della stagione man mano che le
//    società organizzatrici iscrivono le gare — atteso che la lista
//    cresca da qui a dicembre.
//
// 4) Solo lo status "In Calendario" è stato osservato nella risposta
//    dell'API — e (osservazione utente in produzione, 25/08/2026)
//    resta "In Calendario" ANCHE per gare con data ormai passata: il
//    campo non è affidabile per sapere se una gara si è svolta. Non
//    più usato per questo — vedi `svolta`/`stato` calcolati dalla
//    data in `mappaGaraSci` più sotto; il valore grezzo dell'API resta
//    solo in `statoApi`, come riferimento/debug.
//
// 5) Paginazione (`offset`/`limit`) non stata testata con più di una
//    pagina reale (il campione aveva solo 4 gare, meno del limit=10
//    richiesto). Per lo stesso motivo del bug duplicati sul Tennis
//    (vedi sopra), la paginazione qui NON si ferma in base alla
//    lunghezza della pagina rispetto a `limit` — si ferma solo su
//    pagina vuota, con deduplica per `idCompetizione` applicata in via
//    preventiva (lezione appresa dal Tennis, non aspettata un bug
//    analogo per confermarla).
//
// 6) Questa azione AJAX restituisce solo il calendario (data, luogo,
//    nome, livello) — non le classifiche di gara. I risultati delle
//    gare passate NON passano da questa API: sono pagine HTML statiche
//    separate, scaricate con cheerio — vedi la sezione più sotto
//    ("SCI — risultati delle gare passate").
// ---------------------------------------------------------------------

const FISI_AJAX_URL = "https://comitati.fisi.org/wp-admin/admin-ajax.php";
const FISI_CALENDARIO_URL = "https://comitati.fisi.org/friuli-venezia-giulia/calendario/?d=";
const FISI_PAGE_SIZE = 100;
const FISI_MAX_PAGINE = 30; // sicurezza anti-loop-infinito, non un limite atteso in pratica

// Stagione sciistica: giugno anno N → maggio anno N+1, etichettata come
// "anno N" — dedotto dalla richiesta reale (nota 2 sopra), non
// documentato esplicitamente da FISI. Calcolo dinamico per evitare la
// manutenzione manuale annuale che invece serve per COMPETIZIONI_CALCIO.
function stagioneScisticaCorrente(adesso = new Date()) {
  const anno = adesso.getFullYear();
  const mese = adesso.getMonth(); // 0 = gennaio … 5 = giugno
  return mese >= 5 ? anno : anno - 1;
}

function isoDaDataItaliana(str) {
  const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(str || "");
  if (!m) return null;
  const [, giorno, mese, anno] = m;
  return `${anno}-${mese}-${giorno}`;
}

async function fetchPaginaSci(offset, dataInizio, dataFine, idStagione) {
  const params = new URLSearchParams({
    action: "competizioni_get_all",
    offset: String(offset),
    limit: String(FISI_PAGE_SIZE),
    url: FISI_CALENDARIO_URL,
    idStagione: String(idStagione),
    dataInizio,
    dataFine,
  });
  const res = await fetchConRetry(`${FISI_AJAX_URL}?${params.toString()}`, {
    headers: {
      Accept: "*/*",
      "X-Requested-With": "XMLHttpRequest",
      "User-Agent": "Mozilla/5.0 (compatible; FVGMonitorBot/1.0)",
    },
  });
  if (!res.ok) throw new Error(`FISI API HTTP ${res.status} (offset=${offset})`);
  return res.json();
}

// Pagina l'intero calendario stagionale. Si ferma solo su pagina vuota
// (mai in base a `gare.length < FISI_PAGE_SIZE`) — vedi nota 5 sopra.
async function fetchTutteGareSci(dataInizio, dataFine, idStagione) {
  const tutte = [];
  let offset = 0;
  let pagina = 0;
  for (;;) {
    pagina++;
    if (pagina > FISI_MAX_PAGINE) {
      console.warn(`Sci: fermato dopo ${FISI_MAX_PAGINE} pagine — controllare la paginazione`);
      break;
    }
    const gare = await fetchPaginaSci(offset, dataInizio, dataFine, idStagione);
    if (!Array.isArray(gare) || gare.length === 0) break;
    tutte.push(...gare);
    offset += gare.length;
  }
  return tutte;
}

function dedupeGareSci(lista) {
  const mappa = new Map();
  for (const g of lista) {
    const chiave = g.idCompetizione ?? `${g.nome}|${g.dataInizio}|${g.comune}`;
    if (!mappa.has(chiave)) mappa.set(chiave, g);
  }
  return [...mappa.values()];
}

// NOTA (25/08/2026, osservazione utente in produzione): il campo
// `status` dell'API resta "In Calendario" ANCHE per competizioni con
// data ormai passata — non aggiornato lato FISI, non affidabile per
// sapere se una gara si è svolta. "svolta" viene quindi calcolato qui
// confrontando la data della gara con oggi, MAI leggendo `g.status`.
// Il valore grezzo dell'API è comunque tenuto in `statoApi` solo come
// riferimento/debug (non usato per alcuna logica, non mostrato di
// default nel frontend).
function mappaGaraSci(g, oggiIso) {
  const data = isoDaDataItaliana(g.dataInizio);
  const svolta = data ? data < oggiIso : false;
  return {
    id: g.idCompetizione ?? null,
    nome: g.nome ?? null,
    disciplina: g.disciplina ?? null,
    data,
    comune: g.comune ?? null,
    provincia: g.provincia ?? null,
    livello: g.livello ?? null,
    svolta,
    stato: svolta ? "Svolta" : "In programma",
    statoApi: g.status ?? null,
    formato: g.formato ?? null,
  };
}

async function ingestSci() {
  const stagione = stagioneScisticaCorrente();
  const dataInizio = `01/06/${stagione}`;
  const dataFine = `30/05/${stagione + 1}`;
  const oggiIso = new Date().toISOString().slice(0, 10);

  const grezze = await fetchTutteGareSci(dataInizio, dataFine, stagione);
  const senzaDuplicati = dedupeGareSci(grezze);
  const gare = senzaDuplicati
    .map((g) => mappaGaraSci(g, oggiIso))
    .filter((g) => g.data) // scarta eventuali gare con data in formato inatteso
    .sort((a, b) => (a.data < b.data ? -1 : a.data > b.data ? 1 : 0));

  if (gare.length === 0) {
    console.warn("Nessuna gara di sci trovata per la stagione corrente — controllare endpoint/parametri");
    return;
  }

  const discipline = [...new Set(gare.map((g) => g.disciplina).filter(Boolean))].sort();

  await upsertSnapshot("sci:calendario", "sci", null, {
    stagione: `${stagione}/${stagione + 1}`,
    discipline,
    gare,
    aggiornato_al: new Date().toISOString(),
  });
  console.log(`Sci aggiornato: ${gare.length} gare, stagione ${stagione}/${stagione + 1}, discipline: ${discipline.join(", ")}`);

  // I risultati di gara sono un job "annesso" ma indipendente: se
  // fallisce (es. host bloccato, struttura pagina cambiata) il
  // calendario è già stato salvato correttamente sopra — non deve far
  // fallire l'intero job "sci" agli occhi di main().
  try {
    await ingestRisultatiSci(gare);
  } catch (err) {
    console.warn("Sci: risultati gare non aggiornati —", err.message);
  }
}

// ---------------------------------------------------------------------
// SCI — risultati delle gare passate (drill-down calendario →
// competizione → gara). Richiesto esplicitamente dall'utente il
// 25/08/2026, dopo aver verificato in produzione che il calendario
// funziona. Struttura HTML verificata manualmente su DUE pagine reali
// (outerHTML incollato dall'utente via DevTools, lo stesso host è
// bloccato dalla allowlist di rete di questo sandbox — vedi nota
// generale sopra sul Tennis/Sci):
//
//   - pagina "competizione" (?idComp=57797): elenco delle singole gare
//     che compongono l'evento (una per disciplina/specialità/
//     categoria/genere — 23 osservate per l'evento campione).
//   - pagina "gara" (?idGara=...&idComp=...): tabella risultati di UNA
//     gara (posizione, cod.fisi, atleta, anno, società, tempo gara,
//     punti gara, punti graduatoria).
//
// Entrambe le pagine riusano le STESSE classi CSS (`.disciplina`,
// `.luogo`, `.nome`, `.specialità`, `.status`) con significati
// completamente diversi tra una pagina e l'altra, e in più il nome
// classe `specialità` contiene un accento (rischioso come selettore
// letterale). Per questo l'estrazione qui sotto è SEMPRE posizionale
// (`.x-col` con indice fisso dentro `.x-row-inner`), mai per nome di
// classe — verificato con un mini script cheerio contro l'HTML reale
// prima di scrivere questo codice, non solo per ispezione visiva.
//
// NOTA sul volume di richieste: nessun endpoint "bulk" noto — una
// competizione con 20+ gare richiede 1 richiesta per l'elenco gare +
// 1 richiesta per gara per i risultati. In piena stagione invernale
// (dicembre-marzo) possono esserci decine di competizioni passate
// contemporaneamente nel calendario. Per non generare centinaia di
// richieste HTTP ad ogni esecuzione (ogni 15 minuti):
//   1) i risultati vengono messi in cache nello snapshot
//      `sci:risultati` — una competizione già scaricata per intero
//      (`completo: true`) non viene MAI ripetuta (i risultati di una
//      gara passata non cambiano più una volta pubblicati, per quanto
//      osservato finora — se in futuro risultasse falso, va rivista);
//   2) al massimo `FISI_MAX_COMPETIZIONI_NUOVE_PER_ESECUZIONE`
//      competizioni NUOVE vengono scaricate per esecuzione — le altre
//      restano in coda e vengono recuperate nelle esecuzioni
//      successive (arretrato smaltito in poche ore, accettabile per
//      dati storici non urgenti).
// ---------------------------------------------------------------------

const FISI_COMPETIZIONE_URL_BASE = "https://comitati.fisi.org/friuli-venezia-giulia/competizione/";
const FISI_GARA_URL_BASE = "https://comitati.fisi.org/friuli-venezia-giulia/gara/";
const FISI_MAX_GARE_PER_COMPETIZIONE = 60; // sicurezza anti-loop — ~20-25 osservate in pratica
const FISI_MAX_COMPETIZIONI_NUOVE_PER_ESECUZIONE = 5; // vedi nota sul volume di richieste sopra

// Pagina "competizione": elenco delle gare che compongono l'evento.
// Colonne osservate (indice `.x-col`, non nome classe — vedi nota
// generale sopra): 0 = disciplina (testo primario) + data/ora (sub),
// 1 = provincia (primario) + comune (sub), 2 = nome competizione
// (primario) + codice (sub), 3 = tipo gara (primario) + categoria/
// genere testuale (sub), 4 = stato (has-graphic, NON usato — vedi
// nota su `statoApi`), 5 = genere (lettera singola).
async function fetchGareCompetizioneSci(idComp) {
  const res = await fetchConRetry(`${FISI_COMPETIZIONE_URL_BASE}?idComp=${idComp}`, {
    headers: { "User-Agent": "Mozilla/5.0 (compatible; FVGMonitorBot/1.0)" },
  });
  if (!res.ok) throw new Error(`Pagina competizione ${idComp} HTTP ${res.status}`);

  const $ = cheerio.load(await res.text());
  const righe = $("#competizioni-container").first().children("a");

  const gare = [];
  righe.each((i, el) => {
    if (i >= FISI_MAX_GARE_PER_COMPETIZIONE) return;
    const $el = $(el);
    const href = $el.attr("href") || "";
    const m = /idGara=(\d+)/.exec(href);
    if (!m) return; // riga senza idGara valido, struttura inattesa
    const idGara = m[1];

    const cols = $el.find(".x-row-inner").first().children(".x-col");
    if (cols.length < 6) return; // struttura inattesa, riga scartata

    const testoCol = (indice, selettore) => {
      const t = $(cols[indice]).find(selettore).first().text().trim();
      return t || null;
    };
    const primario = (indice) => testoCol(indice, ".x-text-content-text-primary");
    const secondario = (indice) => testoCol(indice, ".x-text-content-text-subheadline");

    gare.push({
      idGara,
      idCompetizione: String(idComp),
      disciplina: primario(0),
      dataOra: secondario(0),
      provincia: primario(1),
      comune: secondario(1),
      nomeCompetizione: primario(2),
      codice: secondario(2),
      tipoGara: primario(3),
      categoria: secondario(3),
      genere: primario(5),
    });
  });

  if (righe.length >= FISI_MAX_GARE_PER_COMPETIZIONE) {
    console.warn(`Competizione ${idComp}: raggiunto il limite di sicurezza di ${FISI_MAX_GARE_PER_COMPETIZIONE} gare — potrebbero mancarne alcune`);
  }

  return gare;
}

// Pagina "gara": tabella risultati di UNA gara. Colonne osservate
// (indice `.x-col`, stesse classi della pagina competizione ma con
// significato diverso — vedi nota generale sopra): 0 = posizione,
// 1 = cod.fisi, 2 = atleta, 3 = anno, 4 = società, 5 = tempo gara,
// 6 = punti gara (spesso il segnaposto letterale "-", trattato come
// nessun dato), 7 = punti graduatoria. Righe con cod.fisi/atleta/anno/
// società vuoti ma tempo/punti valorizzati sono normali (osservate
// nella pagina reale), non un errore di parsing.
async function fetchRisultatiGaraSci(idGara, idComp) {
  const res = await fetchConRetry(`${FISI_GARA_URL_BASE}?idGara=${idGara}&idComp=${idComp}&d=`, {
    headers: { "User-Agent": "Mozilla/5.0 (compatible; FVGMonitorBot/1.0)" },
  });
  if (!res.ok) throw new Error(`Pagina gara ${idGara} HTTP ${res.status}`);

  const $ = cheerio.load(await res.text());
  const righe = $("#competizioni-container").first().children("div");

  const risultati = [];
  righe.each((_, el) => {
    const $el = $(el);
    const cols = $el.find(".x-row-inner").first().children(".x-col");
    if (cols.length < 8) return; // struttura inattesa, riga scartata

    const primario = (indice) => {
      const t = $(cols[indice]).find(".x-text-content-text-primary").first().text().trim();
      return t || null;
    };

    const puntiGara = primario(6);
    risultati.push({
      posizione: primario(0),
      codFisi: primario(1),
      atleta: primario(2),
      anno: primario(3),
      societa: primario(4),
      tempoGara: primario(5),
      puntiGara: puntiGara === "-" ? null : puntiGara,
      puntiGraduatoria: primario(7),
    });
  });

  return risultati;
}

// Orchestrazione: per ogni competizione passata nel calendario non
// ancora in cache (fino al limite per esecuzione), scarica l'elenco
// gare e i risultati di ciascuna, poi salva tutto in `sci:risultati`.
async function ingestRisultatiSci(gareCalendario) {
  const competizioniPassate = gareCalendario.filter((g) => g.svolta && g.id);
  if (competizioniPassate.length === 0) {
    console.log("Sci risultati: nessuna competizione passata nel calendario, niente da scaricare");
    return;
  }

  const cacheEsistente = await leggiSnapshotEsistente("sci:risultati");
  const competizioniCache = { ...(cacheEsistente?.competizioni || {}) };

  let nuoveScaricate = 0;
  let rimandate = 0;

  for (const comp of competizioniPassate) {
    const esistente = competizioniCache[comp.id];
    if (esistente && esistente.completo) continue; // già in cache, zero richieste

    if (nuoveScaricate >= FISI_MAX_COMPETIZIONI_NUOVE_PER_ESECUZIONE) {
      rimandate++;
      continue; // ripresa alla prossima esecuzione
    }

    try {
      const gareConDettaglio = await fetchGareCompetizioneSci(comp.id);
      const gareConRisultati = [];
      for (const g of gareConDettaglio) {
        const risultati = await fetchRisultatiGaraSci(g.idGara, comp.id);
        gareConRisultati.push({ ...g, risultati });
      }
      competizioniCache[comp.id] = {
        completo: true,
        nomeCompetizione: comp.nome,
        data: comp.data,
        gare: gareConRisultati,
      };
      nuoveScaricate++;
    } catch (err) {
      console.warn(`Sci: risultati competizione ${comp.id} (${comp.nome}) non scaricati — ${err.message}`);
      // non salvato in cache: ritentato automaticamente alla prossima esecuzione
    }
  }

  if (rimandate > 0) {
    console.log(`Sci risultati: ${rimandate} competizioni rimandate alla prossima esecuzione (limite ${FISI_MAX_COMPETIZIONI_NUOVE_PER_ESECUZIONE}/esecuzione)`);
  }

  // Scrive solo se è cambiato qualcosa — altrimenti (cache già
  // completa, nessuna competizione nuova) ogni esecuzione da 15 minuti
  // aggiungerebbe una riga identica in `history` per mesi, inutilmente.
  if (nuoveScaricate === 0 && cacheEsistente) {
    console.log("Sci risultati: nessuna novità, snapshot non riscritto");
    return;
  }

  await upsertSnapshot("sci:risultati", "sci", null, {
    competizioni: competizioniCache,
    aggiornato_al: new Date().toISOString(),
  });
  console.log(`Sci risultati aggiornato: ${Object.keys(competizioniCache).length} competizioni in cache (${nuoveScaricate} nuove questa esecuzione)`);
}

// ---------------------------------------------------------------------

// Nota: le allerte Protezione Civile NON vengono più ingerite qui.
// L'endpoint (pianiemergenza.protezionecivile.fvg.it) risulta bloccato
// in modo persistente per le richieste da GitHub Actions (timeout di
// connessione TCP puro, confermato su più tentativi anche a sito
// raggiungibile normalmente da browser) — probabile blocco specifico
// verso indirizzi IP cloud/datacenter. Spostato interamente lato
// client (vedi lib/allerte.ts + lib/jsonp.ts): i componenti React
// interrogano l'endpoint JSONP direttamente dal browser di chi visita
// il sito, esattamente come fa già il widget ufficiale — bypassa il
// blocco perché usa l'indirizzo IP del visitatore, non quello di
// GitHub Actions.

// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// WEBCAM OSMER — osmer.fvg.it/webcam_img.php. Licenza CC BY-SA 3.0
// esplicita. OSMER fa da specchio/proxy delle immagini di terze parti
// sul proprio dominio (data-src relativo) — mostriamo quelle, comode
// perché su un unico dominio invece di tante fonti diverse.
//
// Le "zone geografiche" di OSMER non coincidono sempre con i confini
// provinciali (es. "Costa ovest e Laguna" include sia Grado, provincia
// di Gorizia, sia Lignano, provincia di Udine) — usiamo una mappa
// comune→provincia il più precisa possibile, con fallback sulla zona
// quando il nome non è riconosciuto. Approssimazione nota e accettata.
//
// Escluse le zone fuori regione (Veneto, Austria, Slovenia, Croazia) —
// non pertinenti per un sito di webcam "regionali" FVG.
// ---------------------------------------------------------------------

const OSMER_ZONE_FVG = new Set([
  "Alpi_Carniche",
  "Alpi_Giulie",
  "Prealpi_Carniche",
  "Prealpi_Giulie",
  "Pianura_Pordenonese",
  "Pianura_Udinese",
  "Pianura_Goriziana",
  "Costa_ovest_e_Laguna",
  "Carso_e_Trieste",
  "A4",
  "A23",
  "A28",
  "SR354",
]);

// Fallback quando il nome della webcam non contiene un comune riconosciuto
const OSMER_ZONA_PROVINCIA_FALLBACK = {
  Alpi_Carniche: "udine",
  Alpi_Giulie: "udine",
  Prealpi_Carniche: "pordenone",
  Prealpi_Giulie: "udine",
  Pianura_Pordenonese: "pordenone",
  Pianura_Udinese: "udine",
  Pianura_Goriziana: "gorizia",
  Costa_ovest_e_Laguna: "udine",
  Carso_e_Trieste: "trieste",
  A4: "udine",
  A23: "udine",
  A28: "pordenone",
  SR354: "udine",
};

// Comuni riconosciuti nel nome della webcam → provincia (più precisa
// del fallback per zona, dove disponibile)
const OSMER_COMUNE_PROVINCIA = {
  sappada: "udine", "arta terme": "udine", ampezzo: "udine", enemonzo: "udine",
  "forni avoltri": "udine", "forni di sopra": "udine", liariis: "udine",
  "monte tenchia": "udine", zoncolan: "udine", zoufplan: "udine",
  "passo monte croce carnico": "udine", paularo: "udine", ravascletto: "udine",
  "val pesarina": "udine", montasio: "udine", "monte acomizza": "udine",
  "monte canin": "udine", lussari: "udine", pramollo: "udine", planica: "udine",
  "sella nevea": "udine", tarvisio: "udine", matajur: "udine", resia: "udine",
  tarcento: "udine", bordano: "udine", "lago di cavazzo": "udine", verzegnis: "udine",
  barcis: "pordenone", budoia: "pordenone", cansiglio: "pordenone",
  cimolais: "pordenone", claut: "pordenone", piancavallo: "pordenone",
  polcenigo: "pordenone", fontanafredda: "pordenone", maniago: "pordenone",
  sacile: "pordenone", "san vito al tagliamento": "pordenone", spilimbergo: "pordenone",
  zoppola: "pordenone", "sesto al reghena": "pordenone", "azzano": "pordenone",
  brugnera: "pordenone", pordenone: "pordenone",
  aquileia: "udine", basiliano: "udine", bertiolo: "udine", carlino: "udine",
  cervignano: "udine", cividale: "udine", gemona: "udine", martignacco: "udine",
  moruzzo: "udine", ragogna: "udine", osoppo: "udine", "san daniele": "udine",
  udine: "udine", gonars: "udine", latisana: "udine", palmanova: "udine",
  cormons: "gorizia", gorizia: "gorizia", "ronchi dei legionari": "gorizia",
  grado: "gorizia", monfalcone: "gorizia", lisert: "gorizia",
  lignano: "udine",
  "duino aurisina": "trieste", trieste: "trieste", sistiana: "trieste",
};

function provinciaWebcam(nome, zonaId) {
  const nomeLower = nome.toLowerCase();
  for (const [comune, provincia] of Object.entries(OSMER_COMUNE_PROVINCIA)) {
    if (nomeLower.includes(comune)) return provincia;
  }
  return OSMER_ZONA_PROVINCIA_FALLBACK[zonaId] ?? null;
}

async function ingestWebcamOsmer() {
  const res = await fetchConRetry("https://www.osmer.fvg.it/webcam_img.php?ln=", {
    headers: { "User-Agent": "Mozilla/5.0 (compatible; FVGMonitorBot/1.0)" },
  });
  if (!res.ok) {
    console.warn(`Pagina webcam OSMER non disponibile (HTTP ${res.status})`);
    return;
  }

  const $ = cheerio.load(await res.text());
  const webcam = [];

  $("div[id]").each((_, headerEl) => {
    const zonaId = $(headerEl).attr("id");
    if (!OSMER_ZONE_FVG.has(zonaId)) return; // salta le zone fuori regione

    const zonaNome = zonaId.replace(/_/g, " ");
    const siblings = $(headerEl).nextUntil("div[id]");

    siblings.find(".lazy-container").each((_, camEl) => {
      const nome = $(camEl).find(".panel-heading").first().text().trim();
      const img = $(camEl).find("img").first();
      const dataSrc = img.attr("data-src");
      if (!nome || !dataSrc) return;

      webcam.push({
        link: img.attr("data-url") || null,
        nome,
        zona: zonaNome,
        provincia: provinciaWebcam(nome, zonaId),
        immagine: `https://www.osmer.fvg.it/${dataSrc}`,
        descrizione: img.attr("data-desc") || null,
      });
    });
  });

  if (webcam.length === 0) {
    console.warn("Nessuna webcam OSMER estratta — la struttura HTML potrebbe essere cambiata");
    return;
  }

  await upsertSnapshot("webcam:osmer", "webcam", null, {
    webcam,
    aggiornato_al: new Date().toISOString(),
  });
  console.log(`Webcam OSMER aggiornate: ${webcam.length} trovate`);
}

// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// RADAR METEO — stessa API PC FVG (monitor.protezionecivile.fvg.it),
// gruppo "radar" mai usato prima. Solo il radar di Fossalon (id 1) è
// attivo al momento (Lussari e Mosaico risultano spenti, status "X").
//
// Prodotto scelto: "SRTLBM_1" formato PNG — mappa colorata
// dell'intensità di pioggia (mm), quella che corrisponde all'idea
// comune di "radar meteo". Altri prodotti disponibili sullo stesso
// radar (velocità Doppler, classificazione idrometeore, ecc.) restano
// per ora non utilizzati.
//
// Salviamo solo l'URL dell'immagine (l'API la serve direttamente come
// PNG binario) — nessun bisogno di scaricare/ricodificare i byte,
// il tag <img> del browser la richiede direttamente dall'API PC FVG.
// ---------------------------------------------------------------------

async function ingestRadarMeteo() {
  const ora = new Date();
  const daOra = new Date(ora.getTime() - 30 * 60 * 1000); // ultimi 30 minuti
  const fmt = (d) => d.toISOString().slice(0, 19).replace("T", " ");

  const url = `${PC_API_BASE}/radars/1/products?from=${encodeURIComponent(fmt(daOra))}&to=${encodeURIComponent(fmt(ora))}`;
  const res = await fetchConRetry(url);
  if (!res.ok) {
    console.warn(`Radar meteo non disponibile (HTTP ${res.status})`);
    return;
  }

  const json = await res.json();
  const prodotti = json.products || [];

  // Tutti e 4 i prodotti sono nella stessa risposta — non serve una
  // chiamata separata per ciascuno
  const PRODOTTI_RADAR = {
    srtlbm_1: "SRTLBM_1", // intensità pioggia (mm)
    ssi: "SSI", // storm severity index
    hmc: "HMC", // classificazione idrometeore (pioggia/neve/grandine)
    lbm_v: "LBM_V", // velocità Doppler (m/s)
  };

  const risultato = {};
  for (const [chiave, nomeProdotto] of Object.entries(PRODOTTI_RADAR)) {
    const candidati = prodotti.filter((p) => p.name === nomeProdotto && p.format === "image/png");
    if (candidati.length === 0) continue;
    const piuRecente = candidati.sort((a, b) => new Date(b.dt) - new Date(a.dt))[0];

    // details.extent è [minLon, maxLat, maxLon, minLat] — i confini
    // geografici esatti dell'immagine, necessari per sovrapporla a una
    // vera mappa (l'immagine stessa è trasparente fuori dalle zone
    // colorate, senza base geografica non si capisce cosa si sta vedendo)
    risultato[chiave] = {
      immagine: `${PC_API_BASE}/products/${piuRecente.id}`,
      extent: piuRecente.details?.extent ?? null,
      aggiornato_al: piuRecente.dt,
    };
  }

  if (Object.keys(risultato).length === 0) {
    console.warn("Nessun prodotto radar trovato negli ultimi 30 minuti");
    return;
  }

  await upsertSnapshot("radar:fossalon", "radar", null, risultato);
  console.log(`Radar meteo aggiornato: ${Object.keys(risultato).join(", ")}`);
}

// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// TERREMOTI — INGV (Istituto Nazionale di Geofisica e Vulcanologia),
// servizio standard internazionale FDSN Event Web Service. L'API PC
// FVG ha uno schema dati "Earthquake" predisposto ma nessun endpoint
// GET pubblicato per interrogarlo — usiamo quindi la fonte ufficiale
// italiana per la sismologia, gratuita e senza chiave.
//
// Filtrato per area geografica FVG (bounding box), ultimi 30 giorni.
// ---------------------------------------------------------------------

const INGV_BBOX = { minLat: 45.3, maxLat: 46.9, minLon: 12.2, maxLon: 14.0 };

async function ingestTerremoti() {
  const ora = new Date();
  const trentaGiorniFa = new Date(ora.getTime() - 30 * 24 * 60 * 60 * 1000);
  const fmt = (d) => d.toISOString().slice(0, 10);

  const url =
    `https://webservices.ingv.it/fdsnws/event/1/query?format=geojson` +
    `&starttime=${fmt(trentaGiorniFa)}&endtime=${fmt(ora)}` +
    `&minlatitude=${INGV_BBOX.minLat}&maxlatitude=${INGV_BBOX.maxLat}` +
    `&minlongitude=${INGV_BBOX.minLon}&maxlongitude=${INGV_BBOX.maxLon}&orderby=time`;

  const res = await fetchConRetry(url);
  if (!res.ok) {
    console.warn(`Terremoti INGV non disponibili (HTTP ${res.status})`);
    return;
  }

  const geojson = await res.json();
  const eventi = (geojson.features || []).map((f) => ({
    id: f.properties.eventId,
    data: f.properties.time,
    magnitudo: f.properties.mag,
    tipoMagnitudo: f.properties.magType,
    luogo: f.properties.place,
    lat: f.geometry.coordinates[1],
    lon: f.geometry.coordinates[0],
    profonditaKm: f.geometry.coordinates[2],
  }));

  await upsertSnapshot("terremoti:fvg", "terremoti", null, {
    eventi,
    aggiornato_al: new Date().toISOString(),
  });
  console.log(`Terremoti aggiornati: ${eventi.length} eventi negli ultimi 30 giorni`);
}

// ---------------------------------------------------------------------
// ECONOMIA — tasso di disoccupazione trimestrale FVG, API SDMX ufficiale
// di ISTAT (esploradati.istat.it). Prima sezione "Economia" del sito,
// nata da una ricognizione richiesta dall'utente il 10/09/2026 sulla
// categoria "Economia e Finanze" del portale open data regionale
// (risultata poco utile: quasi solo bilanci comunali) e un successivo
// approfondimento su ISTAT/Unioncamere/Camere di Commercio — solo ISTAT
// ha prodotto un'API strutturata utilizzabile.
//
// Dataflow IT1:151_914 "Tasso di disoccupazione" (DSD DCCV_TAXDISOCCU1),
// dimensioni verificate via /datastructure e query reali contro l'API
// (non da un riassunto WebFetch — l'XML SDMX-ML "GenericData" restituito
// è stato fatto riprodurre verbatim e salvato, poi il parsing testato
// contro quel campione reale prima di scrivere questa funzione):
//   FREQ.REF_AREA.DATA_TYPE.SEX.AGE.EDU_LEV_HIGHEST.CITIZENSHIP.DURATION_UNEMPLOYMENT
// Query mirata alla serie "headline": Q (trimestrale) . ITD4 (area FVG —
// attenzione: nel codelist territoriale usato da questo dataflow il FVG
// è "ITD4", non il codice NUTS2 "ITH4" più comune altrove) . UNEM_R
// (tasso di disoccupazione) . 9 (sesso: totale) . Y15-74 (età 15-74,
// definizione standard) . 99 (livello istruzione: totale) . TOTAL
// (cittadinanza: totale) . TOTAL (durata disoccupazione: totale).
//
// Cadenza reale: trimestrale, con circa un trimestre di ritardo rispetto
// a oggi (dato più recente verificato il 10/09/2026: 2026-Q1) — molto
// più lenta degli altri moduli di questo sito, per questo qui salviamo
// l'intero storico disponibile (ultimi ~3 anni) invece di un solo valore:
// un numero isolato senza contesto sarebbe poco leggibile per un dato
// che cambia così di rado.
// ---------------------------------------------------------------------

async function ingestEconomiaDisoccupazione() {
  const annoInizio = new Date().getFullYear() - 3;
  const url =
    `https://esploradati.istat.it/SDMXWS/rest/data/IT1,151_914/` +
    `Q.ITD4.UNEM_R.9.Y15-74.99.TOTAL.TOTAL?startPeriod=${annoInizio}`;

  const res = await fetchConRetry(url);
  if (!res.ok) {
    console.warn(`ISTAT disoccupazione FVG non disponibile (HTTP ${res.status})`);
    return;
  }

  const parsed = xml.parse(await res.text());
  const dataset = parsed?.["message:GenericData"]?.["message:DataSet"];
  let serie = dataset?.["generic:Series"];
  if (!serie) {
    console.warn("ISTAT disoccupazione FVG: nessuna serie nella risposta (formato cambiato?)");
    return;
  }
  if (Array.isArray(serie)) serie = serie[0]; // query mirata a una sola serie: se ce ne fosse più di una, qualcosa nella key è cambiato

  let obsList = serie["generic:Obs"];
  if (!obsList) obsList = [];
  if (!Array.isArray(obsList)) obsList = [obsList];

  const trimestri = obsList
    .map((o) => ({
      periodo: o["generic:ObsDimension"]["@_value"],
      valore: parseFloat(o["generic:ObsValue"]["@_value"]),
    }))
    .filter((t) => t.periodo && Number.isFinite(t.valore))
    .sort((a, b) => a.periodo.localeCompare(b.periodo));

  if (trimestri.length === 0) {
    console.warn("ISTAT disoccupazione FVG: nessun trimestre valido estratto");
    return;
  }

  await upsertSnapshot("economia:disoccupazione-fvg", "economia", null, {
    trimestri,
    fonte: "ISTAT — Tasso di disoccupazione, dataflow 151_914",
    aggiornato_al: new Date().toISOString(),
  });
  console.log(`Disoccupazione FVG aggiornata: ${trimestri.length} trimestri, ultimo ${trimestri[trimestri.length - 1].periodo}`);
}

// ---------------------------------------------------------------------
// PISTE CICLABILI — dataset Socrata "Piste Ciclabili" (7eat-pecq) su
// dati.friuliveneziagiulia.it. Ricognizione fatta il 27/08/2026 su dati
// reali (WebFetch su righe/metadata/query di raggruppamento) prima di
// scrivere questo modulo — punti importanti emersi, da tenere a mente:
//
// - **Copertura PARZIALE, non l'intera rete regionale**: la fonte è
//   descritta come "Ciclovie di interesse locale fornite in fase di
//   conformazione" — solo i tracciati che i singoli Comuni hanno
//   trasmesso alla Regione durante una specifica procedura urbanistica
//   (conformazione al PRGC), non un censimento completo. Bounding box
//   reale verificato (`$select=extent(the_geom)`): lon 12.42–13.49, lat
//   45.72–46.12 — copre una fascia centrale (aree di Udine/Gorizia, es.
//   Manzano/Buttrio/Cormons/Gradisca), ma NON Trieste né l'estremo
//   ovest di Pordenone né la fascia alpina a nord. Questo va dichiarato
//   esplicitamente in UI (stesso principio già seguito per Balneazione/
//   Farmacie: mai far credere a una copertura più ampia di quella reale).
// - **Ogni tracciato con nome è diviso in più segmenti**: 486 righe ma
//   solo 36 valori distinti di `nome` (verificato con
//   `$select=count(distinct nome)` e `$group=nome`) — una riga non è un
//   intero percorso, ma un pezzo di esso. Per l'elenco ha senso
//   raggruppare per nome (fatto lato client, stesso principio del
//   raggruppamento per comune già usato in Farmacie), non elencare 486
//   righe quasi ripetute.
// - **`livello` non è utile per filtrare**: 485/486 righe hanno
//   `livello: "locale"` (verificato con `$group=livello`) — quasi nessuna
//   varietà, a differenza di provincia/comune negli altri moduli. Nessun
//   campo comune/provincia in questo dataset (diversamente da Farmacie/
//   Strutture ricettive): niente tab per provincia qui, solo mappa +
//   elenco con ricerca per nome.
// - **`lunghezza` (metri) manca per molte righe** (solo 403/486 secondo
//   la metadata) — sommata per nome quando presente, il totale di un
//   tracciato può quindi essere sottostimato se alcuni suoi segmenti non
//   hanno lunghezza: dichiarato in UI, non un dato inventato.
// - **Geometria**: campo `the_geom`, GeoJSON `MultiLineString` — array di
//   linee, ciascuna un array di coppie **[lon, lat]** (ordine GeoJSON
//   standard, verificato su righe reali, WGS84). Leaflet vuole invece
//   **[lat, lon]** per ogni punto di una `Polyline` — invertito qui in
//   ingestione una volta sola, non ad ogni render lato client.
// - **Prima mappa del sito con tracciati/polilinee** invece di semplici
//   marker puntuali (Farmacie/Aviazione/Terremoti) — nessun'altra
//   insidia nota oltre l'inversione lon/lat sopra, react-leaflet 4.2.1
//   (già in uso) supporta `Polyline` nativamente.
// ---------------------------------------------------------------------

const PISTE_CICLABILI_DATASET_URL = "https://www.dati.friuliveneziagiulia.it/resource/7eat-pecq.json";

// Arricchimento (27/08/2026, richiesto dall'utente): comune di
// partenza/arrivo e provincia per ciascun PERCORSO (non per singolo
// segmento — vedi sopra, un percorso può avere più segmenti), via
// reverse geocoding Nominatim (OpenStreetMap) sui due punti estremi
// (primo punto del primo segmento, ultimo punto dell'ultimo segmento,
// nell'ordine in cui compaiono nella fonte).
//
// **Approssimazione dichiarata**: il dataset non garantisce che i
// segmenti di uno stesso nome siano ordinati spazialmente in modo
// continuo (visto già in fase di ricognizione: es.
// "Buttrio_GiroMontecristo" spezzato in 6 righe) — "partenza"/"arrivo"
// sono quindi il primo/ultimo punto nell'ordine della fonte, non un
// punto di inizio/fine verificato di un itinerario continuo. Il
// frontend (`raggruppaPerNome()` in `lib/pisteCiclabili.ts`) segnala
// "(indicativo)" quando un percorso ha più di un segmento.
//
// **NON VERIFICATO da questa sessione**: Nominatim è bloccato dalla
// rete di questo sandbox per fetch/curl diretto (stesso limite già noto
// per Overpass, vedi nota Strutture ricettive in README.md) — e qui
// nemmeno WebFetch funziona (robots.txt di nominatim.org lo vieta
// esplicitamente per l'endpoint /reverse). Il formato letto qui sotto
// (address.city/town/village/hamlet, address["ISO3166-2-lvl6"],
// address.county) è quello documentato e stabile dell'API Nominatim,
// ma va confermato al primo run reale da GitHub Actions (rete diversa,
// non bloccata) — il codice è scritto per degradare senza rompersi
// (comune/provincia restano `null`, mai un dato inventato) se il
// formato osservato in produzione risultasse diverso, e per non far
// fallire l'intera ingestione se il geocoding fallisce del tutto (es.
// se Nominatim blocca le richieste dagli IP dei runner GitHub Actions —
// già capitato con TPL FVG/autobus per un motivo simile, vedi README).
//
// **Politeness policy di Nominatim** (max ~1 richiesta/secondo, User-
// Agent identificativo obbligatorio — https://operations.osmfoundation.org/policies/nominatim/):
// geocodifica solo i percorsi non ancora in cache, al massimo
// NOMINATIM_MAX_NUOVI_PERCORSI_PER_ESECUZIONE per esecuzione, con una
// pausa tra una richiesta e l'altra (mai in parallelo). Cache
// PERMANENTE per nome in una snapshot dedicata (`piste-ciclabili-
// geocoding`) — un percorso già geocodificato non viene mai richiesto
// di nuovo. Stesso pattern di cache incrementale già usato per
// turismofvg.it/risultati gara Sci — con soli 36 percorsi (72 richieste
// in tutto) il backfill completo richiede poche esecuzioni, molto più
// rapido dei casi precedenti.
const NOMINATIM_MAX_NUOVI_PERCORSI_PER_ESECUZIONE = 15;
const NOMINATIM_PAUSA_MS = 1100; // > 1 richiesta/secondo

// Codice ISO 3166-2 (es. "IT-UD") -> slug provincia già usato altrove
// nel progetto (lib/province.ts) — se Nominatim lo restituisce è la
// fonte più affidabile (codice, non nome libero soggetto a variazioni).
const PROVINCIA_DA_ISO3166_2 = { "IT-UD": "udine", "IT-GO": "gorizia", "IT-TS": "trieste", "IT-PN": "pordenone" };
// Fallback per nome libero (campo "county", quando presente): Nominatim
// per l'Italia mappa tipicamente la provincia (admin_level 6) su questo
// campo, ma non è garantito — usato solo se manca il codice ISO sopra.
const PROVINCIA_DA_NOME_COUNTY = { udine: "udine", gorizia: "gorizia", trieste: "trieste", pordenone: "pordenone" };

async function reverseGeocodeNominatim(lat, lon) {
  const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lon}&zoom=14&accept-language=it`;
  // Solo 2 tentativi (non i 3 di default) e nessun retry aggressivo: un
  // servizio pubblico gratuito con politica d'uso esplicita non va
  // martellato in caso di errore transitorio.
  const res = await fetchConRetry(
    url,
    { headers: { "User-Agent": "fvgmonitor/1.0 (sito indipendente di dati aperti regionali FVG)" } },
    2
  );
  if (!res.ok) return null;
  const j = await res.json();
  const a = j.address ?? {};
  const comune = a.city ?? a.town ?? a.village ?? a.hamlet ?? a.municipality ?? null;
  const isoLvl6 = a["ISO3166-2-lvl6"];
  const provincia =
    (isoLvl6 && PROVINCIA_DA_ISO3166_2[isoLvl6]) ||
    (a.county && PROVINCIA_DA_NOME_COUNTY[String(a.county).toLowerCase()]) ||
    null;
  return { comune, provincia };
}

async function arricchisciPisteCiclabiliConGeocoding(segmenti) {
  // Raggruppa per nome — stesso criterio di raggruppaPerNome() in
  // lib/pisteCiclabili.ts, duplicato qui perché questo script .mjs non
  // importa il codice TS del frontend.
  const perNome = new Map();
  for (const s of segmenti) {
    const lista = perNome.get(s.nome) ?? [];
    lista.push(s);
    perNome.set(s.nome, lista);
  }

  const cache = (await leggiSnapshotEsistente("piste-ciclabili-geocoding")) ?? {};
  let nuovi = 0;

  for (const [nome, segs] of perNome.entries()) {
    if (cache[nome]) continue; // già geocodificato in un'esecuzione precedente
    if (nuovi >= NOMINATIM_MAX_NUOVI_PERCORSI_PER_ESECUZIONE) continue; // rimandato alla prossima esecuzione

    const primaLinea = segs[0]?.linee?.[0];
    const ultimaLinea = segs[segs.length - 1]?.linee?.at(-1);
    const puntoPartenza = primaLinea?.[0];
    const puntoArrivo = ultimaLinea?.at(-1);
    if (!puntoPartenza || !puntoArrivo) continue;

    try {
      const partenza = await reverseGeocodeNominatim(puntoPartenza[0], puntoPartenza[1]);
      await new Promise((r) => setTimeout(r, NOMINATIM_PAUSA_MS));
      const arrivo = await reverseGeocodeNominatim(puntoArrivo[0], puntoArrivo[1]);
      await new Promise((r) => setTimeout(r, NOMINATIM_PAUSA_MS));

      cache[nome] = {
        comunePartenza: partenza?.comune ?? null,
        comuneArrivo: arrivo?.comune ?? null,
        provincia: partenza?.provincia ?? arrivo?.provincia ?? null,
      };
      nuovi++;
    } catch (err) {
      console.warn(`Geocoding fallito per percorso "${nome}":`, err.message);
    }
  }

  if (nuovi > 0) {
    await upsertSnapshot("piste-ciclabili-geocoding", "piste-ciclabili-geocoding", null, cache);
  }
  console.log(
    `Piste ciclabili: geocoding ${nuovi} nuovi percorsi in questa esecuzione (totale in cache: ${
      Object.keys(cache).length
    }/${perNome.size})`
  );

  return cache;
}

async function ingestPisteCiclabili() {
  const url = `${PISTE_CICLABILI_DATASET_URL}?$limit=1000`;
  const res = await fetchConRetry(url);
  if (!res.ok) {
    console.warn(`Dataset piste ciclabili non disponibile (HTTP ${res.status})`);
    return;
  }

  const rows = await res.json();
  if (!Array.isArray(rows) || rows.length === 0) {
    console.warn("Dataset piste ciclabili vuoto");
    return;
  }

  const segmenti = [];
  for (const r of rows) {
    const geom = r.the_geom;
    if (!geom || geom.type !== "MultiLineString" || !Array.isArray(geom.coordinates)) continue;
    // [lon, lat] (GeoJSON) -> [lat, lon] (Leaflet), una volta sola qui.
    const linee = geom.coordinates
      .filter((linea) => Array.isArray(linea) && linea.length >= 2)
      .map((linea) => linea.map(([lon, lat]) => [lat, lon]));
    if (linee.length === 0) continue;

    segmenti.push({
      id: r.id ?? null,
      nome: testo(r.nome) ?? "Senza nome",
      lunghezzaM: r.lunghezza ? Number(r.lunghezza) : null,
      livello: testo(r.livello),
      origineDa: testo(r.origine_da),
      sigla: testo(r.sigla),
      linee,
    });
  }

  // L'arricchimento non deve mai far fallire l'intera ingestione (es. se
  // Nominatim blocca le richieste dagli IP dei runner GitHub Actions) —
  // in quel caso `arricchimento` resta vuoto/parziale, i segmenti (e la
  // mappa) restano comunque disponibili, solo senza comune/provincia.
  let arricchimento = {};
  try {
    arricchimento = await arricchisciPisteCiclabiliConGeocoding(segmenti);
  } catch (err) {
    console.warn("Arricchimento geocoding piste ciclabili fallito interamente:", err.message);
  }

  await upsertSnapshot("piste-ciclabili", "piste-ciclabili", null, {
    segmenti,
    arricchimento,
    aggiornato_al: new Date().toISOString(),
  });
  console.log(`Piste ciclabili aggiornate: ${segmenti.length} segmenti`);
}

// -----------------------------------------------------------------------
// CICLOVIE 2020 — terza fonte per /piste-ciclabili, dataset Socrata
// "Ciclovie 2020" (38yx-qk7a) su dati.friuliveneziagiulia.it. Scelto il
// 28/08/2026 dall'utente come prossimo modulo da implementare tra i due
// dataset Mobilità rimasti dalla ricognizione del 27/08/2026 (l'altro,
// Rete viaria, resta scartato per pesantezza/complessità — vedi
// claude/fvgmonitor-stato.md). Verificato su dati reali (WebFetch,
// stesso metodo già usato per Piste Ciclabili 7eat-pecq) prima di
// scrivere questo modulo:
//
// - **Dato STORICO, esplicitamente dichiarato fermo**: metadata del
//   dataset (`rowsUpdatedAt`) risulta al 23/01/2020, oltre 6 anni prima
//   di questa sessione — a differenza di "Piste Ciclabili" (7eat-pecq,
//   aggiornato 2 giorni prima della sua stessa ricognizione), qui NON
//   c'è alcuna aspettativa che il dato cambi da un'esecuzione all'altra.
//   Ingerito comunque con lo stesso pattern standard ogni 15 minuti
//   (nessuna ragione per trattarlo diversamente lato codice — un fetch
//   in più costa pochissimo), ma presentato in UI esplicitamente come
//   layer storico/di contesto, non "live" — stessa cautela già applicata
//   alle Ciclovie 2020 nella ricognizione (mai fatta passare per un dato
//   aggiornato).
// - **Copertura REGIONALE vera**, a differenza di "Piste Ciclabili"
//   (che copre solo un'area centrale Udine/Gorizia): bounding box reale
//   verificato (`$select=extent(the_geom)`) lon 12.33–13.90/lat
//   45.58–46.62, l'intero territorio del FVG compreso Trieste — coerente
//   con la descrizione della fonte ("compila e rende omogenei più
//   livelli eterogenei regionali/provinciali/altro, con eliminazione
//   duplicati e correzione traiettorie").
// - **1174 righe, solo 113 nomi distinti** (`$select=count(distinct
//   nome)`) — stesso pattern già visto in Piste Ciclabili: un percorso
//   nominato è diviso in più segmenti (qui ancora più frammentato, ~10
//   segmenti/nome in media). Raggruppato per nome lato UI
//   (`raggruppaCiclovie2020()` in lib/pisteCiclabili.ts).
// - **`stato` è il campo più utile e nuovo di questa fonte** (assente in
//   7eat-pecq, dove l'unico campo simile — `livello` — non aveva
//   varietà): 10 valori osservati (`$group=stato`), dal più frequente
//   "realizzato" (641/1174) a "in progetto"/"pianificato"/"in
//   costruzione" ecc. — **osservato che uno stesso percorso nominato può
//   avere segmenti con stato diverso** (es. "FVG 6": alcuni segmenti
//   "realizzato", altri "percorribile su viabilita esistente da
//   migliorare") — quindi niente "stato del percorso" unico e
//   semplificato: la UI mostra la lunghezza aggregata per stato
//   (`lunghezzaPerStato` in `PercorsoCiclovia2020`), mai un singolo stato
//   scelto arbitrariamente che nasconderebbe l'eterogeneità reale.
// - **`livello`**: ambito/regionale/regionale_variante (diverso
//   dall'omonimo campo, quasi-costante, di 7eat-pecq) — mostrato come
//   insieme di valori distinti presenti nel percorso, mai un singolo
//   valore scelto a caso se il percorso ne ha più di uno.
// - **`lunghezza` presente per quasi tutte le righe** (1173/1174,
//   `$select=count(lunghezza)`) — a differenza di 7eat-pecq (403/486),
//   quindi la sottostima per lunghezza mancante sarà rara qui.
// - **Campo `progetto` ("si"/"no") escluso dalla UI**: significato non
//   chiaro dalla sola metadata/righe campione (non un vero booleano
//   ovvio come "è un progetto approvato?" o "fa parte del progetto
//   ciclovie regionali?") — stessa cautela già seguita altrove nel
//   progetto per campi di un'API/dataset non documentata: mai
//   un'etichetta inventata per un campo ambiguo.
// - **Nessun comune/provincia** (come 7eat-pecq) — niente geocoding
//   aggiunto per questa fonte (scelta esplicita per contenere lo sforzo,
//   trattandosi di un layer storico/di contesto secondario, non la fonte
//   principale della pagina): solo mappa + elenco per nome, senza tab
//   provincia.
// - **Nessun bisogno di cache/backfill incrementale**: dataset piccolo
//   (1174 righe) e mai in crescita (fermo dal 2020) — riscaricato per
//   intero ad ogni esecuzione, stesso approccio di "Piste Ciclabili"
//   7eat-pecq (486 righe), non il pattern a cursore/cache usato per
//   fonti molto più grandi o davvero vive (turismofvg.it/TFVGB).
// ---------------------------------------------------------------------

const CICLOVIE_2020_DATASET_URL = "https://www.dati.friuliveneziagiulia.it/resource/38yx-qk7a.json";

async function ingestCiclovie2020() {
  const url = `${CICLOVIE_2020_DATASET_URL}?$limit=2000`;
  const res = await fetchConRetry(url);
  if (!res.ok) {
    console.warn(`Dataset Ciclovie 2020 non disponibile (HTTP ${res.status})`);
    return;
  }

  const rows = await res.json();
  if (!Array.isArray(rows) || rows.length === 0) {
    console.warn("Dataset Ciclovie 2020 vuoto");
    return;
  }

  const segmenti = [];
  for (const r of rows) {
    const geom = r.the_geom;
    if (!geom || geom.type !== "MultiLineString" || !Array.isArray(geom.coordinates)) continue;
    // [lon, lat] (GeoJSON) -> [lat, lon] (Leaflet), stessa conversione di
    // ingestPisteCiclabili() sopra.
    const linee = geom.coordinates
      .filter((linea) => Array.isArray(linea) && linea.length >= 2)
      .map((linea) => linea.map(([lon, lat]) => [lat, lon]));
    if (linee.length === 0) continue;

    segmenti.push({
      id: r.id ? Number(r.id) : null,
      nome: testo(r.nome) ?? "Senza nome",
      lunghezzaM: r.lunghezza ? Number(r.lunghezza) : null,
      stato: testo(r.stato),
      livello: testo(r.livello),
      sede: testo(r.sede),
      linee,
    });
  }

  await upsertSnapshot("piste-ciclabili-2020", "piste-ciclabili-2020", null, {
    segmenti,
    aggiornato_al: new Date().toISOString(),
  });
  console.log(`Ciclovie 2020 aggiornate: ${segmenti.length} segmenti`);
}

// -----------------------------------------------------------------------
// Piste ciclabili — fonti turismofvg.it/it/bike, 4 serie con codice (R
// anelli, P percorsi lineari, C ciclovie a tappe, M mountain bike) —
// serie R aggiunta il 28/08/2026 su richiesta dell'utente, le altre 3
// aggiunte la stessa giornata dopo l'ok esplicito dell'utente a procedere.
// Ognuna è una fonte INDIPENDENTE mostrata nella stessa pagina accanto ai
// dati Regione (mai unite fra loro: cataloghi diversi, senza
// corrispondenza 1:1 fra le voci — vedi ricognizione in
// claude/fvgmonitor-stato.md), ciascuna nel proprio box in UI. Vedi
// lib/pisteCiclabili.ts per i tipi e il contesto lato UI.
//
// Solo la serie R è stata verificata con HTML reale (pagina elenco +
// scheda R001) incollato dall'utente, come da prassi del progetto. Le
// altre 3 sono state verificate solo con WebFetch (conteggio percorsi,
// codici, presenza di un link di dettaglio) — sufficiente per confermare
// che usano la stessa sezione "bike"/stesso sito, ma NON l'HTML grezzo
// necessario per una verifica selettore-per-selettore: rischio accettato
// esplicitamente dall'utente, il parsing degrada senza rompersi (indice
// vuoto, snapshot non scritto, warning in log) se una pagina risultasse
// strutturata diversamente da R. Scoperta utile dalla verifica P/C/M: i
// codici non sono tutti "lettera+3 cifre" come per R — la serie C ha
// anche forme come "C100"/"CX05"/"C2V1" — e alcune pagine elenco (es.
// "mountain-bike") sono categorie TEMATICHE che mostrano anche percorsi
// di altre serie insieme a quelli della serie nominale — entrambe le
// cose gestite filtrando per lettera iniziale del codice, vedi
// estraiCodiceRouteTurismoFvgBike()/fetchIndiceTurismoFvgBikeSerie() sotto.
//
// La pagina elenco espone un indice completo in un campo nascosto
// <input class="js-ulmap__mapdata"> (stesso pattern del #mapdata usato
// per Agriturismi, ma selettore diverso e campi diversi: qui niente
// "City", il nome è "Title" col codice incluso, es. "Nome (R001)") più,
// per ogni percorso, i comuni attraversati in <div class="o-card__locality">
// dentro la card <a class="o-card">, associata all'indice tramite il
// codice (es. "R001") estratto dal titolo — non tramite Url, per
// tolleranza a differenze di slug fra le due strutture.
//
// La scheda di dettaglio espone i dati tecnici in un blocco
// <script type="application/ld+json"> (schema.org SportsActivityLocation)
// molto più affidabile della struttura HTML circostante (fatta apposta
// per essere letta da macchine) — usata anche per il tracciato completo
// (geo.line) e per i link GPX/KML/FIT (dedotti dall'id Outdooractive in
// "@id"). L'unico dato letto dall'HTML è l'etichetta italiana di
// difficoltà, con ripiego sulla traduzione del valore JSON-LD se il
// selettore non trova nulla. Stesso pattern di backfill incrementale con
// cache permanente già usato per Agriturismi (una scheda già scaricata
// non cambia spesso, non viene mai ripetuta) — applicato separatamente
// per ciascuna delle 4 serie, ognuna con la propria snapshot Supabase
// (`piste-ciclabili-turismofvg-r/p/c/m`).

// Le 4 serie con codice del sito (28/08/2026, ricognizione precedente —
// vedi claude/fvgmonitor-stato.md): oltre alla serie R (anelli, già
// verificata su HTML reale), le altre 3 sono state aggiunte lo stesso
// giorno su richiesta esplicita dell'utente di procedere, SENZA un nuovo
// campione HTML incollato dall'utente per verificarle (a differenza della
// prassi seguita finora per ogni nuova fonte) — accettato come rischio
// contenuto perché è la stessa sezione "bike" dello stesso sito, con lo
// stesso pattern di indice/dettaglio già confermato per R via WebFetch
// (elenco, conteggio, codici, link di dettaglio). Ogni pagina elenco
// mostra anche codici di ALTRE serie (es. la pagina "mountain-bike"
// mostra pure percorsi R048/P016/P001 insieme a M001/M003 — categoria
// "tematica", non un catalogo puro) — filtrate via `lettera` qui sotto,
// stesso meccanismo già in uso per la serie R.
const TURISMOFVG_BIKE_SERIE = [
  {
    chiave: "r",
    lettera: "R",
    etichetta: "Anelli",
    url: "https://www.turismofvg.it/it/bike/percorsi-giornalieri-ad-anello",
    idSnapshot: "piste-ciclabili-turismofvg-r",
  },
  {
    chiave: "p",
    lettera: "P",
    etichetta: "Percorsi lineari",
    url: "https://www.turismofvg.it/it/bike/percorsi-giornalieri-lineari",
    idSnapshot: "piste-ciclabili-turismofvg-p",
  },
  {
    chiave: "c",
    lettera: "C",
    etichetta: "Ciclovie a tappe",
    url: "https://www.turismofvg.it/it/bike/ciclovie-e-altri-itinerari-a-tappe",
    idSnapshot: "piste-ciclabili-turismofvg-c",
  },
  {
    chiave: "m",
    lettera: "M",
    etichetta: "Mountain bike",
    url: "https://www.turismofvg.it/it/bike/mountain-bike",
    idSnapshot: "piste-ciclabili-turismofvg-m",
  },
];
const TURISMOFVG_BIKE_MAX_NUOVE_SCHEDE_PER_ESECUZIONE = 8;

const TURISMOFVG_BIKE_DIFFICOLTA_IT = {
  easy: "facile",
  moderate: "media",
  difficult: "difficile",
  hard: "difficile",
  expert: "molto difficile",
};

// Comune -> provincia, duplicata qui in JS da lib/comuniFvg.ts perché
// questo script non può importare moduli TypeScript (stesso vincolo già
// documentato per la logica di raggruppamento delle piste Regione più
// sopra in questo file). Elenco completo dei 215 comuni FVG — vedi
// lib/comuniFvg.ts per le fonti verificate e le note sulle grafie
// alternative.
const TURISMOFVG_BIKE_COMUNE_PROVINCIA = {};
for (const nome of [
  "duino aurisina", "monrupino", "muggia", "san dorligo della valle", "sgonico", "trieste",
]) TURISMOFVG_BIKE_COMUNE_PROVINCIA[nome] = "trieste";
for (const nome of [
  "capriva del friuli", "cormons", "doberdo del lago", "dolegna del collio", "farra d isonzo",
  "fogliano redipuglia", "gorizia", "gradisca d isonzo", "grado", "mariano del friuli", "medea",
  "monfalcone", "moraro", "mossa", "romans d isonzo", "ronchi dei legionari", "sagrado",
  "san canzian d isonzo", "san floriano del collio", "san lorenzo isontino", "san pier d isonzo",
  "savogna d isonzo", "staranzano", "turriaco", "villesse",
]) TURISMOFVG_BIKE_COMUNE_PROVINCIA[nome] = "gorizia";
for (const nome of [
  "andreis", "arba", "aviano", "azzano decimo", "barcis", "brugnera", "budoia", "caneva",
  "casarsa della delizia", "castelnovo del friuli", "cavasso nuovo", "chions", "cimolais", "claut",
  "clauzetto", "cordenons", "cordovado", "erto e casso", "fanna", "fiume veneto", "fontanafredda",
  "frisanco", "maniago", "meduno", "montereale valcellina", "morsano al tagliamento",
  "pasiano di pordenone", "pinzano al tagliamento", "polcenigo", "porcia", "pordenone",
  "prata di pordenone", "pravisdomini", "roveredo in piano", "sacile", "san giorgio della richinvelda",
  "san martino al tagliamento", "san quirino", "san vito al tagliamento", "sequals",
  "sesto al reghena", "spilimbergo", "tramonti di sopra", "tramonti di sotto", "travesio", "vajont",
  "valvasone arzene", "vito d asio", "vivaro", "zoppola",
]) TURISMOFVG_BIKE_COMUNE_PROVINCIA[nome] = "pordenone";
for (const nome of [
  "aiello del friuli", "amaro", "ampezzo", "aquileia", "arta terme", "artegna", "attimis",
  "bagnaria arsa", "basiliano", "bertiolo", "bicinicco", "bordano", "buja", "buttrio",
  "camino al tagliamento", "campoformido", "campolongo tapogliano", "carlino", "cassacco",
  "castions di strada", "cavazzo carnico", "cercivento", "cervignano del friuli", "chiopris viscone",
  "chiusaforte", "cividale del friuli", "codroipo", "colloredo di monte albano", "comeglians",
  "corno di rosazzo", "coseano", "dignano", "dogna", "drenchia", "enemonzo", "faedis", "fagagna",
  "fiumicello villa vicentina", "flaibano", "forgaria nel friuli", "forni avoltri", "forni di sopra",
  "forni di sotto", "gemona del friuli", "gonars", "grimacco", "latisana", "lauco", "lestizza",
  "lignano sabbiadoro", "lusevera", "magnano in riviera", "majano", "malborghetto valbruna",
  "manzano", "marano lagunare", "martignacco", "mereto di tomba", "moggio udinese", "moimacco",
  "montenars", "mortegliano", "moruzzo", "muzzana del turgnano", "nimis", "osoppo", "ovaro",
  "pagnacco", "palazzolo dello stella", "palmanova", "paluzza", "pasian di prato", "paularo",
  "pavia di udine", "pocenia", "pontebba", "porpetto", "povoletto", "pozzuolo del friuli",
  "pradamano", "prato carnico", "precenicco", "premariacco", "preone", "prepotto", "pulfero",
  "ragogna", "ravascletto", "raveo", "reana del rojale", "remanzacco", "resia", "resiutta",
  "rigolato", "rive d arcano", "rivignano teor", "ronchis", "ruda", "san daniele del friuli",
  "san giorgio di nogaro", "san giovanni al natisone", "san leonardo", "san pietro al natisone",
  "san vito al torre", "san vito di fagagna", "santa maria la longa", "sappada", "sauris",
  "savogna", "sedegliano", "socchieve", "stregna", "sutrio", "taipana", "talmassons", "tarcento",
  "tarvisio", "tavagnacco", "terzo di aquileia", "terzo d aquileia", "tolmezzo", "torreano", "torviscosa", "trasaghis",
  "treppo grande", "treppo ligosullo", "tricesimo", "trivignano udinese", "udine", "varmo",
  "venzone", "verzegnis", "villa santina", "visco", "zuglio",
]) TURISMOFVG_BIKE_COMUNE_PROVINCIA[nome] = "udine";

function normalizzaComuneJs(nome) {
  return (nome || "")
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/['’`\-\/]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function provinciaPrevalenteTurismoFvgBike(comuni) {
  const conteggio = {};
  for (const nome of comuni) {
    const p = TURISMOFVG_BIKE_COMUNE_PROVINCIA[normalizzaComuneJs(nome)];
    if (!p) continue;
    conteggio[p] = (conteggio[p] ?? 0) + 1;
  }
  let migliore = null;
  let max = 0;
  for (const [p, n] of Object.entries(conteggio)) {
    if (n > max) {
      max = n;
      migliore = p;
    }
  }
  return migliore;
}

// Codice route tra parentesi nel titolo — es. "R048", "P023", ma anche
// forme non puramente numeriche osservate nella serie C ("C100", "CX05",
// "C2V1", "C2V2"): lettera singola + 2 o più caratteri alfanumerici,
// invece del pattern più stretto "lettera+3 cifre" che bastava per la
// sola serie R (28/08/2026, scoperto verificando le pagine elenco di
// P/C/M via WebFetch prima di scrivere il codice).
function estraiCodiceRouteTurismoFvgBike(titoloConCodice) {
  const m = /\(([A-Z][A-Z0-9]{2,})\)/.exec(titoloConCodice || "");
  return m ? m[1] : null;
}

async function fetchIndiceTurismoFvgBikeSerie(serie) {
  const res = await fetchConRetry(serie.url, {
    headers: { "User-Agent": "Mozilla/5.0 (compatible; FVGMonitorBot/1.0)" },
  });
  if (!res.ok) throw new Error(`Elenco turismofvg.it/it/bike (serie ${serie.lettera}) HTTP ${res.status}`);

  const $ = cheerio.load(await res.text());
  const raw = $("input.js-ulmap__mapdata").attr("value");
  if (!raw) {
    throw new Error(
      `turismofvg.it/it/bike (serie ${serie.lettera}): campo .js-ulmap__mapdata non trovato — struttura pagina cambiata o diversa da quella verificata per la serie R?`
    );
  }

  let voci;
  try {
    voci = JSON.parse(raw);
  } catch {
    throw new Error(`turismofvg.it/it/bike (serie ${serie.lettera}): JSON in .js-ulmap__mapdata non valido`);
  }
  if (!Array.isArray(voci))
    throw new Error(`turismofvg.it/it/bike (serie ${serie.lettera}): formato .js-ulmap__mapdata inatteso`);

  // Comuni attraversati per codice, dalle card della stessa pagina —
  // associati per codice (non per posizione/Url: più tollerante a
  // differenze fra le due strutture della pagina).
  const comuniPerCodice = new Map();
  $("a.o-card").each((_, el) => {
    const $el = $(el);
    const titolo = $el.find(".o-card__title").first().text().trim();
    const codice = estraiCodiceRouteTurismoFvgBike(titolo);
    if (!codice) return;
    const localita = $el.find(".o-card__locality").first().text().trim();
    if (!localita) return;
    const comuni = localita
      .split(",")
      .map((c) => c.trim())
      .filter(Boolean);
    if (comuni.length > 0) comuniPerCodice.set(codice, comuni);
  });

  // Alcune pagine elenco (es. "mountain-bike") sono categorie tematiche
  // che mostrano anche percorsi di ALTRE serie (es. R048/P016 insieme a
  // M001/M003) — filtrati qui per lettera iniziale del codice, non per
  // provenienza dalla pagina.
  const indice = [];
  for (const v of voci) {
    const id = typeof v.Id === "number" ? v.Id : Number(v.Id);
    const titolo = testo(v.Title);
    const url = typeof v.Url === "string" ? v.Url : null;
    if (!id || !titolo || !url) continue;
    const codice = estraiCodiceRouteTurismoFvgBike(titolo);
    if (!codice || codice.charAt(0) !== serie.lettera) continue;
    const nome = titolo.replace(/\s*\([A-Z][A-Z0-9]{2,}\)\s*$/, "").trim();
    indice.push({
      id,
      codice,
      nome,
      url: url.startsWith("http") ? url : `https://www.turismofvg.it${url.startsWith("/") ? "" : "/"}${url}`,
      comuni: comuniPerCodice.get(codice) ?? [],
    });
  }
  return indice;
}

async function fetchDettaglioTurismoFvgBike(voce) {
  const res = await fetchConRetry(voce.url, {
    headers: { "User-Agent": "Mozilla/5.0 (compatible; FVGMonitorBot/1.0)" },
  });
  if (!res.ok) throw new Error(`Scheda ${voce.url} HTTP ${res.status}`);

  const $ = cheerio.load(await res.text());

  let datiTour = null;
  $('script[type="application/ld+json"]').each((_, el) => {
    if (datiTour) return;
    let parsed;
    try {
      parsed = JSON.parse($(el).contents().text());
    } catch {
      return;
    }
    const tipo = parsed && parsed["@type"];
    if (Array.isArray(tipo) && tipo.includes("SportsActivityLocation")) datiTour = parsed;
  });
  if (!datiTour) throw new Error(`Scheda ${voce.url}: blocco JSON-LD del percorso non trovato`);

  const idOa = (() => {
    const m = /\/r\/(\d+)/.exec(datiTour["@id"] || "");
    return m ? Number(m[1]) : null;
  })();
  if (!idOa) throw new Error(`Scheda ${voce.url}: id Outdooractive non trovato in @id`);

  const amenity = {};
  const caratteristiche = [];
  for (const feat of Array.isArray(datiTour.amenityFeature) ? datiTour.amenityFeature : []) {
    if (!feat || typeof feat.name !== "string") continue;
    if (feat.value === true) caratteristiche.push(feat.name);
    else if (typeof feat.value === "number" || typeof feat.value === "string") amenity[feat.name] = feat.value;
  }

  const puntoNominato = (loc) => {
    if (!loc || !loc.geo) return null;
    const lat = Number(loc.geo.latitude);
    const lon = Number(loc.geo.longitude);
    if (!Number.isFinite(lat) || !Number.isFinite(lon)) return null;
    return { nome: testo(loc.name) ?? "", lat, lon };
  };
  const partenza = puntoNominato(datiTour.potentialAction?.fromLocation);
  const arrivo = puntoNominato(datiTour.potentialAction?.toLocation);
  const anello = Boolean(
    amenity["Percorso ad anello"] === true ||
      caratteristiche.includes("Percorso ad anello") ||
      (partenza && arrivo && partenza.nome === arrivo.nome)
  );

  // geo.line: stringa "lat lon lat lon ..." (spazi, non virgole) — una
  // sola linea continua per questa fonte (a differenza della fonte
  // Regione, qui non è frammentata), quindi `linee` ha sempre al più un
  // elemento.
  const linee = [];
  const lineaRaw = typeof datiTour.geo?.line === "string" ? datiTour.geo.line.trim() : "";
  if (lineaRaw) {
    const numeri = lineaRaw.split(/\s+/).map(Number);
    const punti = [];
    for (let i = 0; i + 1 < numeri.length; i += 2) {
      if (Number.isFinite(numeri[i]) && Number.isFinite(numeri[i + 1])) punti.push([numeri[i], numeri[i + 1]]);
    }
    if (punti.length >= 2) linee.push(punti);
  }

  // Etichetta italiana di difficoltà così come mostrata sul sito —
  // ripiego sulla traduzione del valore JSON-LD (inglese) se il
  // selettore non trova nulla (pagina cambiata, o valore non mappato).
  const difficoltaHtml = $(".oax_abstractDifficulty").first().text().trim();
  const difficoltaJsonLd = typeof amenity["difficulty"] === "string" ? amenity["difficulty"] : null;
  const difficolta =
    difficoltaHtml || (difficoltaJsonLd && TURISMOFVG_BIKE_DIFFICOLTA_IT[difficoltaJsonLd]) || difficoltaJsonLd || null;

  const lunghezzaM =
    typeof datiTour.potentialAction?.distance?.value === "number" ? datiTour.potentialAction.distance.value : null;

  return {
    id: idOa,
    codice: voce.codice,
    nome: voce.nome,
    url: voce.url,
    comuni: voce.comuni,
    provincia: provinciaPrevalenteTurismoFvgBike(voce.comuni),
    lunghezzaM,
    dislivelloSalitaM: typeof amenity["elevation_ascent"] === "number" ? amenity["elevation_ascent"] : null,
    dislivelloDiscesaM: typeof amenity["elevation_descent"] === "number" ? amenity["elevation_descent"] : null,
    quotaMinM: typeof amenity["altitude_from"] === "number" ? amenity["altitude_from"] : null,
    quotaMaxM: typeof amenity["altitude_to"] === "number" ? amenity["altitude_to"] : null,
    durataMin: typeof amenity["duration"] === "number" ? amenity["duration"] : null,
    difficolta,
    anello,
    partenza,
    arrivo,
    linee,
    caratteristiche,
    gpxUrl: `https://www.outdooractive.com/it/download.tour.gpx?i=${idOa}&project=api-friuli-venezia-giulia`,
    kmlUrl: `https://www.outdooractive.com/it/kml_generate?i=${idOa}&playlist=1&project=api-friuli-venezia-giulia`,
    fitUrl: `https://www.outdooractive.com/it/download.tour.fit?i=${idOa}&playlist=1&project=api-friuli-venezia-giulia`,
    aggiornatoAl: new Date().toISOString(),
  };
}

async function ingestTurismoFvgBikeSerie(serie) {
  const idSnapshot = serie.idSnapshot;
  const etichetta = `TurismoFVG bike (serie ${serie.lettera} — ${serie.etichetta})`;

  let indice;
  try {
    indice = await fetchIndiceTurismoFvgBikeSerie(serie);
  } catch (err) {
    console.warn(`${etichetta}: indice non scaricato, riuso la cache se presente — ${err.message}`);
    return await leggiSnapshotEsistente(idSnapshot);
  }

  const cacheEsistente = await leggiSnapshotEsistente(idSnapshot);
  const dettagliCache = { ...(cacheEsistente?.dettagli || {}) };

  let nuoveScaricate = 0;
  let rimandate = 0;
  for (const voce of indice) {
    if (dettagliCache[voce.id]) continue; // già in cache, mai ri-scaricata

    if (nuoveScaricate >= TURISMOFVG_BIKE_MAX_NUOVE_SCHEDE_PER_ESECUZIONE) {
      rimandate++;
      continue; // ripresa alla prossima esecuzione
    }

    try {
      dettagliCache[voce.id] = await fetchDettaglioTurismoFvgBike(voce);
      nuoveScaricate++;
    } catch (err) {
      console.warn(`${etichetta}: scheda ${voce.codice} (${voce.nome}) non scaricata — ${err.message}`);
      // non salvata in cache: ritentata automaticamente alla prossima esecuzione
    }
  }

  if (rimandate > 0) {
    console.log(
      `${etichetta}: ${rimandate} schede rimandate alla prossima esecuzione (limite ${TURISMOFVG_BIKE_MAX_NUOVE_SCHEDE_PER_ESECUZIONE}/esecuzione)`
    );
  }

  const risultato = { indice, dettagli: dettagliCache, aggiornato_al: new Date().toISOString() };

  if (nuoveScaricate === 0 && cacheEsistente && cacheEsistente.indice?.length === indice.length) {
    console.log(`${etichetta}: nessuna novità, snapshot non riscritto`);
    return cacheEsistente;
  }

  await upsertSnapshot(idSnapshot, "turismofvg", null, risultato);
  console.log(
    `${etichetta} aggiornato: ${indice.length} in indice, ${Object.keys(dettagliCache).length} schede con dettaglio (${nuoveScaricate} nuove questa esecuzione)`
  );
  return risultato;
}

// ---------------------------------------------------------------------
// COLONNINE ELETTRICHE — mappa di tutte le colonnine di ricarica per
// veicoli elettrici in FVG, richiesta dall'utente il 02/10/2026 ("è
// possibile inserire una mappa... con un selettore della propria
// posizione, per vedere le colonnine in un raggio di 30 km?").
//
// Fonti valutate prima di scrivere questo codice (sessione del
// 02-03/10/2026):
// - PUN (piattaformaunicanazionale.it), il registro ufficiale del
//   MASE: nessuna API pubblica, sito SPA solo-JavaScript — scartato,
//   non ispezionabile dalla sessione di sviluppo (nessun browser reale
//   disponibile per guardare le sue chiamate di rete).
// - Estrazione di onData su GitHub (reverse-engineering dell'API
//   interna di PUN, github.com/ondata/rete_ricarica_veicoli_elettrici):
//   il README del repository stesso avverte che PUN ha cambiato il
//   metodo di pubblicazione e i dati "NON SONO AGGIORNATI" — scartata
//   come fonte congelata.
// - OpenChargeMap (openchargemap.org): registro globale comunitario +
//   import di fonti aperte dove disponibili, API REST gratuita (serve
//   una chiave personale gratuita, registrata dall'utente) con query
//   nativa per raggio di distanza. Scelta come fonte, con un limite
//   dichiarato onestamente in UI: un campione reale testato il
//   02/10/2026 (10 colonnine entro ~12 km da Trieste/Grado, incollato
//   dall'utente da un browser vero — questo sandbox non riesce a
//   raggiungere l'API) mostra `DateLastVerified` fra il 2015 e il
//   2023, nessuna nel 2024-2026 — il dato è probabilmente incompleto
//   per le installazioni più recenti. Per questo ogni colonnina
//   mostra la propria data di verifica (vedi "verificatoIl" sotto),
//   invece di dare un'impressione di completezza non verificata.
//
// Formato di /v3/poi (compact=true) verificato sul campione reale
// incollato dall'utente — i nomi di campo usati sotto (AddressInfo,
// Connections, NumberOfPoints, UsageCost, DateLastVerified, ecc.)
// vengono da lì, non da documentazione generica.
//
// Formato di /v3/referencedata (usato solo per risolvere OperatorID/
// ConnectionTypeID/UsageTypeID/StatusTypeID in etichette leggibili)
// NON verificato con una richiesta reale in questa sessione — quel
// solo endpoint non era raggiungibile né da questo sandbox né,
// evidentemente in tempo utile, incollandolo manualmente. Il codice
// sotto degrada senza errori se la forma non corrisponde a quella
// documentata da OpenChargeMap: mostra l'ID numerico al posto
// dell'etichetta. Da confermare dopo il primo run reale — vedi
// "Prossimi passi".
//
// Area coperta: lo stesso bounding box "FVG + margine" già usato per
// i terremoti (INGV_BBOX, vedi sopra) — il margine serve perché il
// selettore "colonnine entro 30 km dalla mia posizione" deve
// funzionare anche vicino al confine regionale. L'API OpenChargeMap
// non ha una ricerca per rettangolo verificata in questa sessione:
// interrogata con un cerchio (lat/lon/raggio) abbastanza grande da
// contenere per intero il bounding box, poi filtrata di nuovo lato
// nostro sul rettangolo esatto.
// ---------------------------------------------------------------------

const OPENCHARGEMAP_API_KEY = process.env.OPENCHARGEMAP_API_KEY;

function mappaOcmPerId(elenco) {
  const m = new Map();
  if (!Array.isArray(elenco)) return m;
  for (const el of elenco) {
    if (el && typeof el.ID === "number") m.set(el.ID, el);
  }
  return m;
}

async function ingestColonnineElettriche() {
  if (!OPENCHARGEMAP_API_KEY) {
    console.warn("Colonnine elettriche: manca OPENCHARGEMAP_API_KEY nell'ambiente, salto questo modulo.");
    return;
  }

  // Tabelle di lookup risolte dal vivo invece di hard-codate — vedi
  // commento sopra sul perché non sono verificate in questa sessione.
  // Mai fatale: se manca o ha una forma diversa, i punti restano con
  // l'ID numerico al posto del nome.
  let operatori = new Map();
  let tipiPresa = new Map();
  let statiPunto = new Map();
  let tipiUso = new Map();
  try {
    const resRef = await fetchConRetry(
      `https://api.openchargemap.io/v3/referencedata/?key=${OPENCHARGEMAP_API_KEY}&output=json`
    );
    if (resRef.ok) {
      const ref = await resRef.json();
      operatori = mappaOcmPerId(ref?.Operators);
      tipiPresa = mappaOcmPerId(ref?.ConnectionTypes);
      statiPunto = mappaOcmPerId(ref?.StatusTypes);
      tipiUso = mappaOcmPerId(ref?.UsageTypes);
    } else {
      console.warn(`Colonnine elettriche: referencedata non disponibile (HTTP ${resRef.status}), uso solo gli ID.`);
    }
  } catch (err) {
    console.warn(`Colonnine elettriche: referencedata non raggiungibile, uso solo gli ID — ${err.message}`);
  }

  // Centro e raggio del cerchio che contiene per intero INGV_BBOX
  // (diagonale ≈115 km, raggio 120 km per un margine di sicurezza).
  const centroLat = (INGV_BBOX.minLat + INGV_BBOX.maxLat) / 2;
  const centroLon = (INGV_BBOX.minLon + INGV_BBOX.maxLon) / 2;
  const raggioKm = 120;

  const url =
    `https://api.openchargemap.io/v3/poi/?key=${OPENCHARGEMAP_API_KEY}` +
    `&output=json&countrycode=IT&latitude=${centroLat}&longitude=${centroLon}` +
    `&distance=${raggioKm}&distanceunit=KM&maxresults=2000&compact=true`;

  const res = await fetchConRetry(url);
  if (!res.ok) {
    console.warn(`Colonnine elettriche: OpenChargeMap non disponibile (HTTP ${res.status})`);
    return;
  }

  const poiGrezzi = await res.json();
  if (!Array.isArray(poiGrezzi)) {
    console.warn("Colonnine elettriche: risposta OpenChargeMap non è un array (formato cambiato?), salto.");
    return;
  }

  // maxresults=2000 non verificato contro la reale dimensione del
  // dataset FVG in questa sessione (l'endpoint non era raggiungibile
  // da qui) — se questo avviso compare sistematicamente, l'API sta
  // probabilmente troncando: aumentare il valore o aggiungere
  // paginazione (parametro "offset", documentato da OpenChargeMap ma
  // non verificato qui).
  if (poiGrezzi.length >= 2000) {
    console.warn(`Colonnine elettriche: ricevuti ${poiGrezzi.length} risultati — possibile troncamento, verificare.`);
  }

  const punti = poiGrezzi
    .map((p) => {
      const ai = p.AddressInfo;
      if (!ai || typeof ai.Latitude !== "number" || typeof ai.Longitude !== "number") return null;
      const stato = statiPunto.get(p.StatusTypeID);
      return {
        id: p.ID,
        uuid: p.UUID,
        nome: ai.Title ?? null,
        indirizzo: [ai.AddressLine1, ai.AddressLine2].filter(Boolean).join(", ") || null,
        comune: ai.Town?.trim() || null, // il dato OpenChargeMap ha a volte spazi iniziali (visto nel campione reale)
        provincia: ai.StateOrProvince ?? null,
        lat: ai.Latitude,
        lon: ai.Longitude,
        telefono: ai.ContactTelephone1 ?? null,
        sito: ai.RelatedURL ?? null,
        operatore: operatori.get(p.OperatorID)?.Title ?? null,
        tipoUso: tipiUso.get(p.UsageTypeID)?.Title ?? null,
        costo: p.UsageCost ?? null,
        note: p.GeneralComments ?? null,
        numeroPostazioni: p.NumberOfPoints ?? null,
        stato: stato?.Title ?? null,
        operativo: typeof stato?.IsOperational === "boolean" ? stato.IsOperational : null,
        verificatoIl: p.DateLastVerified ?? p.DateLastStatusUpdate ?? null,
        prese: Array.isArray(p.Connections)
          ? p.Connections.map((c) => ({
              tipo: tipiPresa.get(c.ConnectionTypeID)?.Title ?? (c.ConnectionTypeID ? `Tipo #${c.ConnectionTypeID}` : null),
              potenzaKw: c.PowerKW ?? null,
              quantita: c.Quantity ?? 1,
            }))
          : [],
      };
    })
    .filter((p) => p !== null)
    .filter(
      (p) =>
        p.lat >= INGV_BBOX.minLat &&
        p.lat <= INGV_BBOX.maxLat &&
        p.lon >= INGV_BBOX.minLon &&
        p.lon <= INGV_BBOX.maxLon
    );

  await upsertSnapshot("colonnine-elettriche:fvg", "trasporti", null, {
    punti,
    totale: punti.length,
    aggiornato_al: new Date().toISOString(),
    fonte: "OpenChargeMap (dato comunitario — vedi la data di verifica di ciascuna colonnina)",
  });
  console.log(`Colonnine elettriche aggiornate: ${punti.length} punti in FVG (OpenChargeMap)`);
}

// ---------------------------------------------------------------------

async function main() {
  const jobs = [
    ["meteo", ingestMeteo()],
    ["meteo-pazzi-telegram", ingestPazziTelegram()],
    ["meteo-pazzi-previsioni", ingestPazziPrevisioni()],
    ["notizie", ingestNotizie()],
    ["vento", ingestVento()],
    ["viabilita", ingestViabilita()],
    ["confini-prometsi", ingestConfiniPrometsi()],
    ["carburanti", ingestCarburanti()],
    ["eventi", ingestEventi()],
    ["rifiuti", ingestRifiuti()],
    ["qualita-aria", ingestQualitaAria()],
    ["voli", ingestVoli()],
    ["pioggia", ingestPioggia()],
    ["temperatura", ingestTemperatura()],
    ["fiumi", ingestFiumi()],
    ["mare", ingestMare()],
    ["maree-osservate", ingestMareeOsservate()],
    ["maree-previste", ingestMareePreviste()],
    ["balneazione", ingestBalneazione()],
    ["farmacie", ingestFarmacie()],
    ["pronto-soccorso", ingestProntoSoccorso()],
    ["neve-impianti", ingestNeveImpianti()],
    ["strutture-ricettive", ingestStruttureRicettive()],
    ["ozono", ingestOzono()],
    ["no2", ingestNo2()],
    ["pm25", ingestPm25()],
    ["pollini", ingestPollini()],
    ["calcio", ingestCalcio()],
    ["basket", ingestBasket()],
    ["baseball", ingestBaseballFvg()],
    ["tennis", ingestTennis()],
    ["sci", ingestSci()],
    ["webcam-osmer", ingestWebcamOsmer()],
    ["radar-meteo", ingestRadarMeteo()],
    ["terremoti", ingestTerremoti()],
    ["colonnine-elettriche", ingestColonnineElettriche()],
    ["economia-disoccupazione", ingestEconomiaDisoccupazione()],
    ["piste-ciclabili", ingestPisteCiclabili()],
    ["piste-ciclabili-2020", ingestCiclovie2020()],
    ...TURISMOFVG_BIKE_SERIE.map((serie) => [
      `piste-ciclabili-turismofvg-${serie.chiave}`,
      ingestTurismoFvgBikeSerie(serie),
    ]),
    ...PROVINCE_NOTIZIE.map((p) => [`notizie-provincia-${p.slug}`, ingestNotizieProvincia(p.slug, p.fonti)]),
  ];

  const risultati = await Promise.allSettled(jobs.map(([, p]) => p));

  let falliti = 0;
  risultati.forEach((r, i) => {
    if (r.status === "rejected") {
      falliti++;
      console.error(`Job "${jobs[i][0]}" fallito:`, r.reason);
    }
  });

  const totale = risultati.length;
  if (falliti > 0) {
    console.warn(`${falliti}/${totale} moduli falliti — vedi sopra per i dettagli.`);
  }

  // L'esecuzione fallisce (rosso su GitHub Actions) solo se TUTTI i
  // moduli sono falliti — quasi certamente un problema serio e comune
  // a tutti (es. credenziali Supabase rotte), non il blocco di rete
  // su una singola fonte. Se anche solo un modulo va a buon fine, i
  // dati continuano ad aggiornarsi correttamente per tutto il resto.
  if (falliti === totale) {
    console.error("Tutti i moduli sono falliti — interrompo con errore.");
    process.exit(1);
  }
}

main();
