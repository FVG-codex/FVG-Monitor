import { StrutturaTipoPage } from "@/components/StrutturaTipoPage";

export default function Page() {
  return <StrutturaTipoPage tipo="rifugi" />;
}
