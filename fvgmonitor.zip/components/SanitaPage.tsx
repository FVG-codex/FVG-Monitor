import Link from "next/link";
import { getTranslations } from "next-intl/server";
import { TopHeader } from "@/components/TopHeader";
import { Footer } from "@/components/Footer";

// Hub "Sanità" (11/09/2026) — stesso pattern di app/sport/page.tsx e
// components/CommercioPage.tsx: una card per sezione. Farmacie esisteva
// già come voce di menù a sé (dal 26/08/2026); da questa sessione è
// raggiungibile da qui invece che direttamente dal menù ad amburger
// (vedi MenuHamburger.tsx, voce "Farmacie" sostituita da "Sanità").
// Cliniche & centri medici e Dentisti & Odontoiatri sono nuove voci
// strutturali senza dati ancora (componenti/route placeholder, vedi
// components/InArrivoPage.tsx). Veterinari & Emergenze ha dati reali
// per tutte e 4 le province (vedi lib/veterinari.ts). Pronto Soccorso
// (16/09/2026) è la voce con dati in tempo reale più richiesta
// dall'utente ("probabilmente una delle pagine con maggiore utilità
// reale del portale") — messa per prima nell'elenco per questo motivo,
// vedi lib/prontosoccorso.ts.
const SEZIONI = [
  {
    key: "prontoSoccorso",
    href: "/pronto-soccorso",
    icona: (
      <svg viewBox="0 0 48 48" className="w-10 h-10" fill="none" stroke="currentColor" strokeWidth="1.5">
        <path d="M24 8l14 6v10c0 10-6 17-14 16-8-1-14-8-14-16V14z" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M24 18v12M18 24h12" strokeLinecap="round" />
      </svg>
    ),
  },
  {
    key: "farmacie",
    href: "/farmacie",
    icona: (
      <svg viewBox="0 0 48 48" className="w-10 h-10" fill="none" stroke="currentColor" strokeWidth="1.5">
        <rect x="8" y="8" width="32" height="32" rx="3" />
        <path d="M24 16v16M16 24h16" strokeLinecap="round" />
      </svg>
    ),
  },
  {
    key: "cliniche",
    href: "/cliniche",
    icona: (
      <svg viewBox="0 0 48 48" className="w-10 h-10" fill="none" stroke="currentColor" strokeWidth="1.5">
        <path d="M24 8v14M17 15h14" strokeLinecap="round" />
        <rect x="8" y="22" width="32" height="18" rx="3" />
      </svg>
    ),
  },
  {
    key: "veterinari",
    href: "/veterinari",
    icona: (
      <svg viewBox="0 0 48 48" className="w-10 h-10" fill="none" stroke="currentColor" strokeWidth="1.5">
        <path
          d="M24 40c-9-6-16-12-16-20a8 8 0 0 1 16-3 8 8 0 0 1 16 3c0 8-7 14-16 20z"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path d="M24 17v10M19 22h10" strokeLinecap="round" />
      </svg>
    ),
  },
  {
    key: "dentisti",
    href: "/dentisti",
    icona: (
      <svg viewBox="0 0 48 48" className="w-10 h-10" fill="none" stroke="currentColor" strokeWidth="1.5">
        <path
          d="M24 10c-5 0-9 3-9 9 0 6 2 8 2 13 0 4 2 6 4 6s3-3 3-8 0-6 0-6 0 1 0 6 1 8 3 8 4-2 4-6c0-5 2-7 2-13 0-6-4-9-9-9z"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    ),
  },
];

export async function SanitaPage() {
  const t = await getTranslations("sanita");
  const tNav = await getTranslations("nav");
  const tChrome = await getTranslations("chrome");
  return (
    <>
      <TopHeader />
      <div className="isobar" />

      <main id="contenuto-principale" className="max-w-[1180px] mx-auto px-5 py-6">
        <h1 className="font-cond font-bold text-2xl uppercase tracking-wide mb-1">{tNav("sanita")}</h1>
        <p className="text-ink-faint text-xs font-mono mb-6">{t("descrizione")}</p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {SEZIONI.map((s) => (
            <Link
              key={s.href}
              href={s.href}
              className="border border-line rounded p-5 bg-panel hover:border-cool transition-colors flex flex-col gap-3"
            >
              <span className="text-cool-ink">{s.icona}</span>
              <div>
                <div className="font-cond font-bold text-lg uppercase tracking-wide">
                  {t(`sezioni.${s.key}.nome`)}
                </div>
                <div className="text-ink-faint text-xs mt-1">
                  {s.key === "cliniche" || s.key === "dentisti" ? tChrome("inArrivo") : t(`sezioni.${s.key}.descrizione`)}
                </div>
              </div>
            </Link>
          ))}
        </div>
      </main>

      <Footer />
    </>
  );
}
