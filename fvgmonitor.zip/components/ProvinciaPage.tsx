"use client";

import { useTranslations } from "next-intl";
import { AllertaWidgetSlot } from "@/components/AllertaWidgetSlot";
import { FiumePanel } from "@/components/FiumePanel";
import { MeteoDettaglio } from "@/components/MeteoPanel";
import { MeteoWidgetSlot } from "@/components/MeteoWidgetSlot";
import { Panel } from "@/components/Panel";
import { PioggiaPanel } from "@/components/PioggiaPanel";
import { TemperaturaBadge } from "@/components/TemperaturaBadge";
import { TopHeader } from "@/components/TopHeader";
import { Footer } from "@/components/Footer";
import { VentoPanel } from "@/components/VentoPanel";
import { ZonaAllertamentoLive } from "@/components/ZonaAllertamentoLive";
import { PROVINCE, type ProvinciaSlug } from "@/lib/province";

export function ProvinciaPage({ slug }: { slug: ProvinciaSlug }) {
  const provincia = PROVINCE[slug];
  const t = useTranslations("provincia");
  const tNav = useTranslations("nav");

  return (
    <>
      <TopHeader paginaAttiva={slug} />
      <div className="isobar" />

      <main id="contenuto-principale" className="max-w-[1180px] mx-auto px-5 py-6">
        {/* h1 invisibile (Fase 4 — Accessibilità, 24/08/2026): la pagina
            non aveva nessun heading — chi naviga con uno screen reader per
            intestazioni si trovava senza alcun punto di riferimento. Resta
            solo per schermo/lettori, il design visivo non cambia (il nome
            provincia è già leggibile nei tab dell'header e nel titolo del
            pannello "Condizioni live"). */}
        <h1 className="sr-only">{provincia.nome} — FVG Monitor</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-line border border-line">
          <Panel title={tNav("meteo")} linkLabel="OSMER ARPA FVG →" linkHref="https://www.meteo.fvg.it">
            <MeteoDettaglio provincia={slug} />
          </Panel>

          <Panel title={t("condizioniLive", { provincia: provincia.nome })}>
            <TemperaturaBadge provincia={slug} size="lg" />
            <div className="mt-3">
              <MeteoWidgetSlot slug={slug} cittaNome={provincia.nome} />
            </div>
          </Panel>

          <Panel
            title={t("vento")}
            linkLabel="Protezione Civile FVG →"
            linkHref="https://monitor.protezionecivile.fvg.it"
          >
            <VentoPanel provincia={slug} />
          </Panel>

          <Panel
            title={t("pioggia")}
            linkLabel="Protezione Civile FVG →"
            linkHref="https://monitor.protezionecivile.fvg.it"
          >
            <PioggiaPanel provincia={slug} />
          </Panel>

          <Panel
            title={t("livelloFiume")}
            linkLabel="Protezione Civile FVG →"
            linkHref="https://monitor.protezionecivile.fvg.it"
          >
            <FiumePanel provincia={slug} />
          </Panel>

          <Panel
            title={t("allertaProtezioneCivile")}
            linkLabel={t("storicoLink")}
            linkHref="https://www.protezionecivile.fvg.it/it/allerte-tutte"
          >
            <div className="flex items-center gap-2 mb-3">
              <span className="text-sm text-ink-dim">{t("zonaAllertamento")}</span>
              <ZonaAllertamentoLive provincia={slug} />
            </div>
            <AllertaWidgetSlot slug={slug} cittaNome={provincia.nome} />
          </Panel>
        </div>

        <p className="text-ink-faint text-xs font-mono mt-6">
          {t("altriModuli", { provincia: provincia.nome })}
        </p>
      </main>

      <Footer />
    </>
  );
}
