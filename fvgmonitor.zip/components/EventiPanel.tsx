"use client";

import { useEffect, useState } from "react";
import { useTranslations } from "next-intl";
import { supabase } from "@/lib/supabase";
import type { Evento, EventiSnapshot } from "@/lib/eventi";

export function EventiPanel() {
  const [dati, setDati] = useState<EventiSnapshot | null>(null);
  const [stato, setStato] = useState<"loading" | "ready" | "error">("loading");
  const t = useTranslations("eventi");
  const tChrome = useTranslations("chrome");

  useEffect(() => {
    let attivo = true;
    async function carica() {
      const { data, error } = await supabase
        .from("snapshots")
        .select("data")
        .eq("id", "eventi:turismofvg")
        .single();
      if (!attivo) return;
      if (error || !data) {
        setStato("error");
        return;
      }
      setDati(data.data as EventiSnapshot);
      setStato("ready");
    }
    carica();
    const id = setInterval(carica, 15 * 60 * 1000);
    return () => {
      attivo = false;
      clearInterval(id);
    };
  }, []);

  if (stato === "loading") {
    return <p className="text-ink-faint text-sm font-mono">{t("caricamento")}</p>;
  }

  const prossimi: Evento[] = dati?.prossimi ?? [];

  if (stato === "error" || !dati || prossimi.length === 0) {
    return <p className="text-ink-faint text-sm font-mono">{t("nonDisponibili")}</p>;
  }

  return (
    <div>
      {prossimi.slice(0, 5).map((e, i) => (
        <a
          key={`${e.link}|${e.dataIso}`}
          href={e.link}
          target="_blank"
          rel="noopener noreferrer"
          className={`flex gap-3 py-2.5 items-baseline ${i > 0 ? "border-t border-line" : ""} hover:bg-panel-alt transition-colors -mx-1 px-1`}
        >
          <div className="font-mono text-cool-ink text-xs flex-shrink-0 w-9 text-center">
            <div className="text-base leading-none">{e.giorno}</div>
            <div>{e.mese}</div>
          </div>
          <div className="min-w-0">
            <div className="text-ink text-sm leading-snug">
              {e.titolo}
              <span className="sr-only"> {tChrome("apreNuovaScheda")}</span>
            </div>
            {e.luogo && <div className="text-ink-faint text-xs font-mono mt-0.5">{e.luogo}</div>}
          </div>
        </a>
      ))}
      <a href="/eventi" className="block text-cool-ink text-[10px] font-mono mt-3 border-t border-line pt-2 hover:underline">
        {t("tuttiGliEventi")}
      </a>
    </div>
  );
}
