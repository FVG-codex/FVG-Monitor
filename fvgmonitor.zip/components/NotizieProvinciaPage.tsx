"use client";

import { useEffect, useState } from "react";
import { useTranslations } from "next-intl";
import { supabase } from "@/lib/supabase";
import { Panel } from "@/components/Panel";
import { TopHeader } from "@/components/TopHeader";
import { Footer } from "@/components/Footer";
import { PROVINCE, PROVINCE_LIST, type ProvinciaSlug } from "@/lib/province";
import { PROVINCE_NOTIZIE_ATTIVE, type SnapshotNotizieProvincia } from "@/lib/notizieProvincia";

// Una quinta scheda oltre alle 4 province (11/09/2026, richiesto
// dall'utente): "Sport" — notizie sportive regionali, non ancora
// implementate (nessuna fonte ancora scelta/verificata), solo un
// segnaposto "in arrivo" accanto ai tab provincia. Non una provincia,
// quindi un tipo a sé (non aggiunta a ProvinciaSlug/PROVINCE_LIST) —
// stesso principio di "Cliniche"/"Dentisti" in Sanità o "Galleria
// fotografica" in FVG in immagini: la struttura di navigazione è pronta
// prima del dato reale.
type SchedaNotizie = ProvinciaSlug | "sport";

function tempoRelativo(dataStr: string, t: ReturnType<typeof useTranslations>): string {
  const diffMs = Date.now() - new Date(dataStr).getTime();
  const minuti = Math.floor(diffMs / 60000);
  if (minuti < 60) return t("minFa", { n: minuti });
  const ore = Math.floor(minuti / 60);
  if (ore < 24) return t("oreFa", { n: ore });
  return t("giorniFa", { n: Math.floor(ore / 24) });
}

/**
 * Notizie locali per provincia (05/09/2026) — distinta dal pannello ANSA
 * regionale di homepage (NotiziePanel.tsx, invariato): qui si aggregano
 * fonti iper-locali, una provincia alla volta. Tutte e 4 le province sono
 * ora attive (PROVINCE_NOTIZIE_ATTIVE: Trieste 05/09, Udine e Gorizia
 * 06/09, Pordenone 08/09/2026) — rollout completato. Il messaggio "in
 * arrivo" sotto resta nel codice come fallback (mai un tab disabilitato)
 * per una futura provincia aggiunta dopo un cambio dei confini
 * amministrativi o simili, ma con l'elenco attuale non compare più.
 */
export function NotizieProvinciaPage() {
  const [scheda, setScheda] = useState<SchedaNotizie>("trieste");
  const [dati, setDati] = useState<SnapshotNotizieProvincia | null>(null);
  const [stato, setStato] = useState<"loading" | "ready" | "error">("loading");
  const t = useTranslations("notizieProvincia");
  const tNav = useTranslations("nav");
  const tChrome = useTranslations("chrome");

  const provincia = scheda === "sport" ? null : scheda;
  const attiva = provincia !== null && PROVINCE_NOTIZIE_ATTIVE.includes(provincia);

  useEffect(() => {
    if (!attiva || !provincia) return;
    let attivoEffect = true;
    setStato("loading");
    async function carica() {
      const { data, error } = await supabase
        .from("snapshots")
        .select("data")
        .eq("id", `notizie-provincia:${provincia}`)
        .single();
      if (!attivoEffect) return;
      if (error || !data) {
        setStato("error");
        return;
      }
      setDati(data.data as SnapshotNotizieProvincia);
      setStato("ready");
    }
    carica();
    const id = setInterval(carica, 5 * 60 * 1000);
    return () => {
      attivoEffect = false;
      clearInterval(id);
    };
  }, [provincia, attiva]);

  const titoloScheda = scheda === "sport" ? "Sport" : PROVINCE[scheda].nome;

  return (
    <>
      <TopHeader />
      <div className="isobar" />

      <main id="contenuto-principale" className="max-w-[1180px] mx-auto px-5 py-6">
        <h1 className="font-cond font-bold text-2xl uppercase tracking-wide mb-1">{tNav("notizie")}</h1>
        <p className="text-ink-faint text-xs font-mono mb-4">{t("descrizione")}</p>

        <div className="flex gap-1.5 flex-wrap mb-6">
          {PROVINCE_LIST.map((p) => (
            <button
              key={p.slug}
              onClick={() => setScheda(p.slug)}
              aria-pressed={scheda === p.slug}
              className={`px-3 py-1.5 rounded text-xs font-cond font-semibold uppercase tracking-wide transition-colors ${
                scheda === p.slug
                  ? "bg-cool text-on-accent"
                  : "border border-line text-ink-dim hover:text-ink"
              }`}
            >
              {p.nome}
            </button>
          ))}
          <button
            onClick={() => setScheda("sport")}
            aria-pressed={scheda === "sport"}
            className={`px-3 py-1.5 rounded text-xs font-cond font-semibold uppercase tracking-wide transition-colors ${
              scheda === "sport"
                ? "bg-cool text-on-accent"
                : "border border-line text-ink-dim hover:text-ink"
            }`}
          >
            {tNav("sport")}
          </button>
        </div>

        <div className="grid grid-cols-1 gap-px bg-line border border-line">
          <Panel title={t("panelTitle", { scheda: titoloScheda })}>
            {scheda === "sport" ? (
              <p className="text-ink-faint text-sm font-mono">{t("sportInArrivo")}</p>
            ) : !attiva ? (
              <p className="text-ink-faint text-sm font-mono">
                {t("provinciaInArrivo", { scheda: titoloScheda })}
              </p>
            ) : stato === "loading" ? (
              <p className="text-ink-faint text-sm font-mono">{t("caricamentoNotizie")}</p>
            ) : stato === "error" || !dati || dati.items.length === 0 ? (
              <p className="text-ink-faint text-sm font-mono">{t("notizieNonDisponibili")}</p>
            ) : (
              <div>
                {dati.items.map((n, i) => (
                  <div key={n.link} className={`py-3 ${i > 0 ? "border-t border-line" : ""}`}>
                    <a href={n.link} target="_blank" rel="noopener noreferrer" className="block">
                      <div className="text-ink text-[15px] leading-snug mb-1.5 hover:text-cool-ink transition-colors">
                        {n.titolo}
                        <span className="sr-only"> {tChrome("apreNuovaScheda")}</span>
                      </div>
                    </a>
                    <div className="flex gap-2 items-center font-mono text-[10px] text-ink-faint uppercase tracking-wide">
                      <span className="text-warm">{n.fonte}</span>
                      <span>· {tempoRelativo(n.data, t)}</span>
                    </div>
                  </div>
                ))}
                {dati.fonti.length > 0 && (
                  <p className="text-ink-faint text-[10px] font-mono mt-3 pt-3 border-t border-line">
                    {t("fonti")}{" "}
                    {dati.fonti.map((f, i) => (
                      <span key={f.fonte_url}>
                        {i > 0 && " · "}
                        <a
                          href={f.fonte_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-cool-ink"
                        >
                          {f.fonte}
                          <span className="sr-only"> {tChrome("apreNuovaScheda")}</span>
                        </a>
                      </span>
                    ))}
                  </p>
                )}
              </div>
            )}
          </Panel>
        </div>
      </main>

      <Footer />
    </>
  );
}
