"use client";

import { useEffect, useState } from "react";
import { useLocale, useTranslations } from "next-intl";
import { supabase } from "@/lib/supabase";
import { PROVINCE_LIST, type ProvinciaSlug } from "@/lib/province";
import { intlLocale } from "@/lib/intlLocale";

type PuntoSfavorevole = { nome: string; enterococchi: number | null; ecoli: number | null; data: string };

type BalneazioneProvincia = {
  totale: number;
  favorevoli: number;
  sfavorevoli: number;
  nd: number;
  punti_sfavorevoli: PuntoSfavorevole[];
  aggiornato_al: string;
};

type SnapshotBalneazione = {
  per_provincia: Partial<Record<ProvinciaSlug, BalneazioneProvincia>>;
};

function formattaData(iso: string, locale: string): string {
  const d = new Date(iso);
  return d.toLocaleDateString(intlLocale(locale), { day: "numeric", month: "short" });
}

// provincia opzionale (11/09/2026, per la nuova pagina "Dati ambientali"
// sotto Ambiente): stessa logica di PolliniPanel.tsx — tab interno
// quando assente (comportamento di sempre, usato in homepage), tab
// interni nascosti e provincia imposta dall'esterno quando presente.
export function BalneazionePanel({ provincia: provinciaProp }: { provincia?: ProvinciaSlug } = {}) {
  const [dati, setDati] = useState<SnapshotBalneazione | null>(null);
  const [stato, setStato] = useState<"loading" | "ready" | "error">("loading");
  const [tabInterno, setTabInterno] = useState<ProvinciaSlug>("trieste");
  const tab = provinciaProp ?? tabInterno;
  const t = useTranslations("balneazione");
  const locale = useLocale();

  useEffect(() => {
    let attivo = true;
    async function carica() {
      const { data, error } = await supabase.from("snapshots").select("data").eq("id", "balneazione").single();
      if (!attivo) return;
      if (error || !data) {
        setStato("error");
        return;
      }
      setDati(data.data as SnapshotBalneazione);
      setStato("ready");
    }
    carica();
    const id = setInterval(carica, 15 * 60 * 1000);
    return () => {
      attivo = false;
      clearInterval(id);
    };
  }, []);

  if (stato === "loading") {
    return <p className="text-ink-faint text-sm font-mono">{t("caricamento")}</p>;
  }
  if (stato === "error" || !dati) {
    return <p className="text-ink-faint text-sm font-mono">{t("nonDisponibili")}</p>;
  }

  const provincia = dati.per_provincia[tab];
  const nomeProvincia = PROVINCE_LIST.find((p) => p.slug === tab)?.nome ?? tab;

  return (
    <div>
      {!provinciaProp && (
        <div className="flex gap-1 mb-3 flex-wrap">
          {PROVINCE_LIST.map((p) => (
            <button
              key={p.slug}
              onClick={() => setTabInterno(p.slug)}
              aria-pressed={tab === p.slug}
              className={`px-2.5 py-1 rounded text-xs font-cond font-semibold uppercase tracking-wide transition-colors ${
                tab === p.slug ? "bg-cool text-on-accent" : "border border-line text-ink-dim hover:text-ink"
              }`}
            >
              {p.nome}
            </button>
          ))}
        </div>
      )}

      {!provincia ? (
        <p className="text-ink-faint text-sm font-mono">
          {t("nessunPunto", { provincia: nomeProvincia })}
        </p>
      ) : (
        <>
          <div className="flex gap-6 mb-3">
            <div>
              <div className="font-cond font-bold text-[36px] leading-[0.9] text-allerta-verde-ink">
                {provincia.favorevoli}
              </div>
              <div className="font-mono text-[10px] text-ink-faint uppercase mt-1">{t("favorevoli")}</div>
            </div>
            <div>
              <div
                className={`font-cond font-bold text-[36px] leading-[0.9] ${
                  provincia.sfavorevoli > 0 ? "text-allerta-rossa-ink" : "text-ink-dim"
                }`}
              >
                {provincia.sfavorevoli}
              </div>
              <div className="font-mono text-[10px] text-ink-faint uppercase mt-1">{t("sfavorevoli")}</div>
            </div>
            <div>
              <div className="font-cond font-bold text-[36px] leading-[0.9] text-ink-dim">{provincia.totale}</div>
              <div className="font-mono text-[10px] text-ink-faint uppercase mt-1">{t("puntiMonitorati")}</div>
            </div>
          </div>

          {provincia.punti_sfavorevoli.length > 0 && (
            <div className="mb-3">
              {provincia.punti_sfavorevoli.map((pt) => (
                <div key={pt.nome} className="flex items-center gap-2 py-1.5 text-sm border-t border-line first:border-t-0">
                  {/* aria-hidden: puntino puramente decorativo — questo
                      elenco contiene solo punti "sfavorevoli" (vedi il
                      controllo punti_sfavorevoli.length sopra), non
                      distingue stati diversi tramite colore. */}
                  <span aria-hidden="true" className="w-2 h-2 rounded-full bg-allerta-rossa flex-shrink-0" />
                  <span className="text-ink-dim flex-1 min-w-0 truncate">{pt.nome}</span>
                  <span className="font-mono text-[10px] text-ink-faint">{formattaData(pt.data, locale)}</span>
                </div>
              ))}
            </div>
          )}

          <div className="flex justify-between font-mono text-[11px] text-ink-faint border-t border-line pt-3">
            <span>{t("ultimoPrelievo")}</span>
            <span>{formattaData(provincia.aggiornato_al, locale)}</span>
          </div>
          <p className="text-ink-faint text-[10px] font-mono mt-2">
            {t("fonte")}
          </p>
        </>
      )}
    </div>
  );
}
