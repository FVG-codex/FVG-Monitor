"use client";

import { useEffect, useRef } from "react";
import { MapContainer, TileLayer, Polyline, Popup } from "react-leaflet";
import { useTranslations } from "next-intl";
import type { Map as LeafletMap } from "leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

// Colori riusati dalla palette esistente (tailwind.config.ts, già
// verificato per contrasto) — un colore per fonte/serie, così le 6 fonti
// (Regione + le 4 serie turismofvg.it + Ciclovie 2020) si distinguono a
// colpo d'occhio sulla mappa (28/08/2026: da 2 a 5, poi a 6 fonti,
// ognuna col proprio box in UI — vedi PisteCiclabiliPage.tsx). Nessun
// colore nuovo inventato per la 6ª fonte: `ink-faint` (già verificato
// per contrasto, usato altrove nel sito per indicare dati "di sfondo" —
// coerente con Ciclovie 2020 come layer storico/di contesto, non "live"
// come le altre 5) — evitati i toni rosso/arancio-rosso (zone.d,
// allerta.rossa) per non confondersi con COLORE_EVIDENZIATO sotto.
const COLORE_REGIONE = "#5FB3A3"; // cool
const COLORE_SERIE: Record<"r" | "p" | "c" | "m", string> = {
  r: "#CD7554", // warm — anelli (prima fonte turismofvg.it aggiunta, 28/08/2026)
  p: "#6FA9E0", // zone.a — percorsi lineari
  c: "#E8B93E", // zone.c / allerta.gialla — ciclovie a tappe
  m: "#4C9A5B", // allerta.verde — mountain bike
};
const COLORE_CICLOVIE_2020 = "#92AAA8"; // ink-faint — layer storico/di contesto, 28/08/2026
// Evidenziazione al click sul nome nell'elenco (27/08/2026, richiesto
// dall'utente: "cliccando sopra il nome, che appaia sulla mappa") —
// colore ben distinto (allerta.rossa) più tratto più spesso, uguale per
// tutte le fonti così il percorso selezionato risalta comunque.
const COLORE_EVIDENZIATO = "#C1382E"; // allerta.rossa

// Un "tracciato" sulla mappa, indipendente dalla fonte — vedi
// PisteCiclabiliPage.tsx per come viene costruito a partire dai
// segmenti Regione e dai percorsi delle 4 serie turismofvg.it. `chiave`
// è univoca fra tutte le fonti (prefissata con la fonte) ed è quella
// usata per l'evidenziazione al click nell'elenco.
export type TracciatoMappa = {
  chiave: string;
  fonte: "regione" | "r" | "p" | "c" | "m" | "ciclovie2020";
  nome: string;
  linee: [number, number][][];
  // Riga aggiuntiva nel popup (es. "R001 · media · 2:15 h" per
  // turismofvg) — null quando non c'è nulla di utile da aggiungere.
  extra?: string | null;
};

export function PisteCiclabiliMap({
  tracciati,
  centro,
  evidenziato,
}: {
  tracciati: TracciatoMappa[];
  centro: [number, number];
  evidenziato: string | null;
}) {
  const mapRef = useRef<LeafletMap | null>(null);
  const t = useTranslations("pisteCiclabili");

  // Multilingua (06/10/2026): l'etichetta fonte per il popup non è più
  // un dizionario italiano fisso (ex ETICHETTA_FONTE sopra) ma composta
  // da chiavi di traduzione — "regione"/"ciclovie2020" riusano
  // t("fonteMappa.<chiave>"), le 4 serie turismofvg.it riusano il
  // template t("fonteTurismoFvg") combinato con le etichette t("serie.<f>")
  // già esistenti (stesso identico testo italiano di PisteCiclabiliPage.tsx).
  function etichettaFonte(fonte: TracciatoMappa["fonte"]): string {
    if (fonte === "regione") return t("fonteMappa.regione");
    if (fonte === "ciclovie2020") return t("fonteMappa.ciclovie2020");
    return t("fonteTurismoFvg", { serie: t(`serie.${fonte}`) });
  }

  // Zoom automatico sul percorso selezionato: calcola i punti estremi di
  // tutte le sue linee e adatta la vista con fitBounds — coerente con
  // "che appaia sulla mappa" della richiesta originale, non solo un
  // cambio di colore facilmente perso di vista se il percorso è piccolo
  // o fuori dalla vista corrente.
  useEffect(() => {
    if (!mapRef.current) return;
    if (!evidenziato) {
      // Nessuna selezione (stato iniziale, o dopo "Mostra tutta la
      // mappa" nel pannello Elenco) — vista di default sull'intero
      // dataset, non un semplice "non fare nulla" che lascerebbe la
      // mappa ferma sull'ultimo percorso zoomato.
      mapRef.current.setView(centro, 9);
      return;
    }
    const punti = tracciati
      .filter((t) => t.chiave === evidenziato)
      .flatMap((t) => t.linee)
      .flat();
    if (punti.length === 0) return;
    mapRef.current.fitBounds(L.latLngBounds(punti), { padding: [24, 24], maxZoom: 15 });
  }, [evidenziato, tracciati, centro]);

  return (
    <MapContainer ref={mapRef} center={centro} zoom={9} style={{ height: "100%", width: "100%" }} scrollWheelZoom={false}>
      <TileLayer
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
      />
      {tracciati.map((tracciato, ti) => {
        const isEvidenziato = tracciato.chiave === evidenziato;
        const colore =
          tracciato.fonte === "regione"
            ? COLORE_REGIONE
            : tracciato.fonte === "ciclovie2020"
              ? COLORE_CICLOVIE_2020
              : COLORE_SERIE[tracciato.fonte];
        return tracciato.linee.map((linea, li) => (
          <Polyline
            key={`${tracciato.chiave}-${ti}-${li}`}
            positions={linea}
            pathOptions={{
              color: isEvidenziato ? COLORE_EVIDENZIATO : colore,
              weight: isEvidenziato ? 6 : 4,
              opacity: !evidenziato || isEvidenziato ? 0.85 : 0.35,
            }}
          >
            <Popup>
              <strong>{tracciato.nome}</strong>
              <br />
              {t("fontePopup", { fonte: etichettaFonte(tracciato.fonte) })}
              {tracciato.extra && (
                <>
                  <br />
                  {tracciato.extra}
                </>
              )}
            </Popup>
          </Polyline>
        ));
      })}
    </MapContainer>
  );
}
