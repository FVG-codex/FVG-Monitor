"use client";

import { useEffect, useState } from "react";
import { useTranslations } from "next-intl";
import { fetchPassaggiBlocco, urlRealtimeFermata, BLOCCHI_AUTOBUS, type PassaggioAutobus } from "@/lib/autobus";

const FILTRI = ["tutti", "partenze", "arrivi"] as const;
type Filtro = (typeof FILTRI)[number];

export function AutobusPanel() {
  const [bloccoSlug, setBloccoSlug] = useState<string>(BLOCCHI_AUTOBUS[0].slug);
  const [filtro, setFiltro] = useState<Filtro>("tutti");
  const [passaggi, setPassaggi] = useState<PassaggioAutobus[] | null>(null);
  const [stato, setStato] = useState<"loading" | "ready" | "error">("loading");
  const t = useTranslations("autobus");
  const tVoli = useTranslations("voli");
  const tChrome = useTranslations("chrome");

  useEffect(() => {
    let attivo = true;
    const blocco = BLOCCHI_AUTOBUS.find((b) => b.slug === bloccoSlug) ?? BLOCCHI_AUTOBUS[0];

    async function carica() {
      setStato((s) => (s === "ready" ? s : "loading")); // niente flash "loading" sui refresh automatici
      try {
        const dati = await fetchPassaggiBlocco(blocco);
        if (!attivo) return;
        setPassaggi(dati);
        setStato("ready");
      } catch {
        if (!attivo) return;
        setStato("error");
      }
    }

    carica();
    // Aggiornamento frequente: dato lato client pensato per essere quasi
    // in tempo reale, stesso intervallo usato dal modulo Ferrovie
    const id = setInterval(carica, 60 * 1000);
    return () => {
      attivo = false;
      clearInterval(id);
    };
  }, [bloccoSlug]);

  const blocco = BLOCCHI_AUTOBUS.find((b) => b.slug === bloccoSlug) ?? BLOCCHI_AUTOBUS[0];
  const passaggiFiltrati = passaggi?.filter((p) => {
    if (filtro === "partenze") return p.tipo === "partenza";
    if (filtro === "arrivi") return p.tipo === "arrivo";
    return true;
  });

  return (
    <div>
      <div className="flex gap-1 mb-2 flex-wrap">
        {BLOCCHI_AUTOBUS.map((b) => (
          <button
            key={b.slug}
            onClick={() => setBloccoSlug(b.slug)}
            aria-pressed={bloccoSlug === b.slug}
            className={`px-2.5 py-1 rounded text-xs font-cond font-semibold uppercase tracking-wide transition-colors ${
              bloccoSlug === b.slug ? "bg-cool text-on-accent" : "border border-line text-ink-dim hover:text-ink"
            }`}
          >
            {b.nome}
          </button>
        ))}
      </div>

      <div className="flex gap-1 mb-3">
        {FILTRI.map((chiave) => (
          <button
            key={chiave}
            onClick={() => setFiltro(chiave)}
            aria-pressed={filtro === chiave}
            className={`px-2.5 py-1 rounded text-xs font-cond font-semibold uppercase tracking-wide transition-colors ${
              filtro === chiave ? "bg-cool text-on-accent" : "border border-line text-ink-dim hover:text-ink"
            }`}
          >
            {chiave === "tutti" ? t("filtroTutti") : chiave === "partenze" ? tVoli("partenze") : tVoli("arrivi")}
          </button>
        ))}
      </div>

      {stato === "loading" && <p className="text-ink-faint text-sm font-mono">{t("caricamento")}</p>}
      {stato === "error" && (
        <p className="text-ink-faint text-sm font-mono">{t("nonDisponibili")}</p>
      )}
      {stato === "ready" && passaggiFiltrati && passaggiFiltrati.length === 0 && (
        <p className="text-ink-dim text-sm">{t("nessunPassaggio")}</p>
      )}

      {stato === "ready" && passaggiFiltrati && passaggiFiltrati.length > 0 && (
        <div>
          {passaggiFiltrati.slice(0, 12).map((p, i) => (
            <div key={`${p.linea}-${p.corsa}-${p.fermataCodice}-${i}`} className={`py-2 text-sm ${i > 0 ? "border-t border-line" : ""}`}>
              <div className="flex items-center gap-3">
                <span className="font-mono text-xs text-ink-faint w-14 flex-shrink-0">{p.linea}</span>
                {/* min-w-0 è necessario perché "truncate" funzioni
                    davvero dentro un flex item — vedi stessa nota in
                    TreniPanel.tsx */}
                <span className="text-ink flex-1 min-w-0 truncate">
                  {p.tipo === "partenza" ? t("versoLuogo", { luogo: p.luogo ?? "—" }) : t("daLuogo", { luogo: p.luogo ?? "—" })}
                </span>
                <span className="font-mono text-xs text-ink-dim flex-shrink-0">{p.orario ?? "—"}</span>
                {p.binario && (
                  <span className="font-mono text-[10px] text-ink-faint flex-shrink-0 hidden sm:inline">
                    {tChrome("binario", { binario: p.binario })}
                  </span>
                )}
                <span
                  className={`font-mono text-[10px] flex-shrink-0 w-28 text-right ${
                    p.inTempoReale ? "text-allerta-verde-ink" : "text-ink-faint"
                  }`}
                >
                  {p.inTempoReale ? t("tempoReale") : t("programmato")}
                </span>
              </div>
              {/* Fermata fisica di origine: più fermate del blocco possono
                  condividere lo stesso indirizzo (es. pensiline diverse
                  della Stazione Ferroviaria), quindi mostriamo anche il
                  codice per distinguerle davvero. Link alla pagina in
                  tempo reale della fermata sul sito TPL FVG (09/09/2026,
                  richiesta esplicita dell'utente) — stesso URL che genera
                  l'elenco fermate del blocco nel footer sotto. */}
              <a
                href={urlRealtimeFermata(p.fermataCodice)}
                target="_blank"
                rel="noopener noreferrer"
                className="font-mono text-[10px] text-ink-faint hover:text-cool-ink mt-0.5 pl-[68px] truncate block"
              >
                {p.fermataNome || t("fermataFallback")} · {p.fermataCodice}
                <span className="sr-only"> {tChrome("apreNuovaScheda")}</span>
              </a>
            </div>
          ))}
        </div>
      )}

      <p className="text-ink-faint text-[10px] font-mono mt-3 border-t border-line pt-2">
        {t("footerBlocco", { nome: blocco.nome, n: blocco.fermate.length })}
      </p>

      {/* Elenco di TUTTE le fermate del blocco con link alla pagina in
          tempo reale ufficiale — non solo quelle con un passaggio
          visibile sopra (09/09/2026, richiesta esplicita dell'utente:
          "per ogni nome e sigla si generasse un link"). */}
      <p className="text-ink-faint text-[10px] font-mono mt-1.5 flex flex-wrap gap-x-1.5 gap-y-1">
        <span>{t("fermateLabel")}</span>
        {blocco.fermate.map((f, i) => (
          <span key={f.stopCode}>
            <a
              href={urlRealtimeFermata(f.stopCode)}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-cool-ink hover:underline"
            >
              {f.nome || f.stopCode}
              <span className="sr-only"> {tChrome("apreNuovaScheda")}</span>
            </a>
            {i < blocco.fermate.length - 1 && " ·"}
          </span>
        ))}
      </p>
    </div>
  );
}
