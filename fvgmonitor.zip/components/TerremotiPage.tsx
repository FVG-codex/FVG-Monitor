"use client";

import { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import { useLocale, useTranslations } from "next-intl";
import { supabase } from "@/lib/supabase";
import { TopHeader } from "@/components/TopHeader";
import { Footer } from "@/components/Footer";
import { Panel } from "@/components/Panel";
import { intlLocale } from "@/lib/intlLocale";

const TerremotiMap = dynamic(() => import("@/components/TerremotiMap").then((m) => m.TerremotiMap), {
  ssr: false,
  loading: () => <p className="text-ink-faint text-sm font-mono">Caricamento mappa…</p>,
});

type Evento = {
  id: number;
  data: string;
  magnitudo: number;
  tipoMagnitudo: string;
  luogo: string;
  lat: number;
  lon: number;
  profonditaKm: number;
};

type TerremotiData = { eventi: Evento[]; aggiornato_al: string };

function formattaData(iso: string, locale: string): string {
  return new Date(iso).toLocaleString(intlLocale(locale), {
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function TerremotiPage() {
  const [dati, setDati] = useState<TerremotiData | null>(null);
  const [stato, setStato] = useState<"loading" | "ready" | "error">("loading");
  const t = useTranslations("terremoti");
  const tNav = useTranslations("nav");
  const tAmbiente = useTranslations("ambiente");
  const tChrome = useTranslations("chrome");
  const locale = useLocale();

  useEffect(() => {
    let attivo = true;
    async function carica() {
      const { data, error } = await supabase
        .from("snapshots")
        .select("data")
        .eq("id", "terremoti:fvg")
        .single();
      if (!attivo) return;
      if (error || !data) {
        setStato("error");
        return;
      }
      setDati(data.data as TerremotiData);
      setStato("ready");
    }
    carica();
    const id = setInterval(carica, 15 * 60 * 1000);
    return () => {
      attivo = false;
      clearInterval(id);
    };
  }, []);

  const eventiOrdinati = dati
    ? dati.eventi.slice().sort((a, b) => new Date(b.data).getTime() - new Date(a.data).getTime())
    : [];

  return (
    <>
      <TopHeader />
      <div className="isobar" />

      <main id="contenuto-principale" className="max-w-[1180px] mx-auto px-5 py-6">
        <a href="/ambiente" className="text-cool-ink text-xs font-mono hover:underline">
          ← {tNav("ambiente")}
        </a>
        <h1 className="font-cond font-bold text-2xl uppercase tracking-wide mb-1 mt-1">
          {tAmbiente("sezioni.terremoti.nome")}
        </h1>
        <p className="text-ink-faint text-xs font-mono mb-6">{t("descrizione")}</p>

        {stato === "loading" && <p className="text-ink-faint text-sm font-mono">{tChrome("caricamento")}</p>}
        {stato === "error" && <p className="text-ink-faint text-sm font-mono">{tChrome("datiNonDisponibili")}</p>}

        {stato === "ready" && dati && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-px bg-line border border-line">
            <Panel title={tChrome("mappa")}>
              {/* role="region" + aria-label (Fase 4 — Accessibilità,
                  24/08/2026): la mappa Leaflet dietro questo div non è
                  navigabile in modo significativo con uno screen reader —
                  gli stessi dati sono comunque disponibili per intero,
                  in forma testuale, nel pannello "Elenco eventi" qui
                  accanto. L'etichetta evita solo che la regione risulti
                  anonima. */}
              <div
                role="region"
                aria-label={t("mappaAriaLabel")}
                style={{ height: 420 }}
                className="rounded overflow-hidden"
              >
                <TerremotiMap eventi={eventiOrdinati} centro={[46.1, 13.1]} />
              </div>
            </Panel>

            <Panel title={t("elencoEventi", { count: eventiOrdinati.length })}>
              {eventiOrdinati.length === 0 ? (
                <p className="text-ink-faint text-sm font-mono">{t("nessunEvento")}</p>
              ) : (
                <div className="max-h-[420px] overflow-y-auto">
                  {eventiOrdinati.map((e, i) => (
                    <div key={e.id} className={`py-2.5 ${i > 0 ? "border-t border-line" : ""}`}>
                      <div className="flex items-baseline justify-between text-sm">
                        <span className="font-cond font-bold text-lg">M{e.magnitudo.toFixed(1)}</span>
                        <span className="font-mono text-[10px] text-ink-faint">{formattaData(e.data, locale)}</span>
                      </div>
                      <div className="text-ink-dim text-sm">{e.luogo}</div>
                      <div className="font-mono text-[10px] text-ink-faint">
                        {t("profondita", { km: e.profonditaKm.toFixed(1) })}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Panel>
          </div>
        )}
      </main>

      <Footer />
    </>
  );
}
