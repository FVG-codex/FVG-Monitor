"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useLocale, useTranslations } from "next-intl";
import { TopHeader } from "@/components/TopHeader";
import { Footer } from "@/components/Footer";
import { Panel } from "@/components/Panel";
import { RifiutiTriesteCalendario } from "@/components/RifiutiTriesteCalendario";
import { supabase } from "@/lib/supabase";
import { PROVINCE, PROVINCE_LIST, type ProvinciaSlug } from "@/lib/province";
import { intlLocale } from "@/lib/intlLocale";
import {
  type SnapshotRifiuti,
  type ComuneRifiuti,
  type TipoRifiuto,
  type SostaVeicoloMobile,
  COLORE_TIPO,
  GIORNI_SETTIMANA_BREVE,
  PROVINCE_RIFIUTI_ATTIVE,
  prossimeRaccolte,
  comuniPerProvincia,
  provinceConDati,
} from "@/lib/rifiuti";

// Ambiente → Servizi → Rifiuti (17/09/2026, richiesto dall'utente).
// Riorganizzata per provincia il 18/09/2026, stesso giorno in cui sono
// arrivati un secondo gestore (A&T 2000, provincia di Udine) e un terzo
// (GEA, provincia di Pordenone). Vedi il commento esteso sopra
// ingestRifiuti()/rifiutiIngestAet2000()/RIFIUTI_COMUNI_GEA in
// scripts/ingest-light.mjs per fonti, metodo di verifica/trascrizione e
// i limiti noti: Gorizia e i comuni minori di Trieste sono coperti per
// intero (28 comuni, Isontina Ambiente), Udine solo parzialmente (2
// comuni su ~80, A&T 2000 — San Daniele del Friuli e Tolmezzo, gli
// unici di cui si è vista HTML reale finora), Pordenone anch'essa
// parzialmente (2 comuni su una ventina serviti da GEA — Aviano e
// Pordenone, gli unici di cui si sono visti i PDF reali; a differenza
// degli altri due gestori il dato GEA è statico, trascritto a mano dai
// calendari PDF annuali). Calendario "solo comune" — quando un comune
// ha più aree al suo interno (es. Gorizia, 6 aree; Tolmezzo, 2 zone
// Nord/Sud; Pordenone stesso, 6 zone Blu/Gialla/Rossa/Marrone/Verde
// Nord/Verde Sud) qui sotto compare un piccolo selettore di area, non
// una ricerca per via/indirizzo. Le tab provincia seguono lo stesso
// pattern già usato in NotizieProvinciaPage.tsx: tutte e 4 visibili,
// quelle non ancora coperte mostrano un messaggio "in arrivo" invece di
// restare disabilitate.
//
// Quarto gestore aggiunto lo stesso giorno: AcegasApsAmga (Trieste
// città, via Il Rifiutologo/webapp-ambiente.gruppohera.it — v. commento
// esteso sopra rifiutiIngestAcegas() in scripts/ingest-light.mjs).
// Copre per ora solo i punti di raccolta fissi: `aree` resta sempre []
// e `centro_raccolta` null per questo comune — il pannello destro
// mostra invece l'elenco `stazioni_ecologiche` quando presente. Trieste
// ha in realtà anche un calendario porta a porta per indirizzo/civico
// (scoperta corretta lo stesso giorno, v. commento sopra
// rifiutiIngestAcegas() in scripts/ingest-light.mjs), non ancora
// implementato perché richiede un vero flusso di ricerca indirizzo
// (v. sotto), non il blocco singolo centro/campane usato dagli altri
// gestori.

function oggiIsoLocale(): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Rome" }).format(new Date());
}

function formattaDataLocale(dataIso: string, locale: string): string {
  const d = new Date(`${dataIso}T12:00:00Z`);
  return d.toLocaleDateString(intlLocale(locale), {
    weekday: "short",
    day: "numeric",
    month: "short",
  });
}

// Raggruppa le soste di un veicolo mobile (es. VASCO) per il testo
// libero `giorni` — la fonte (v. VASCO_MONFALCONE in
// scripts/ingest-light.mjs) le elenca già una dopo l'altra per turno
// settimanale, quindi qui basta preservare l'ordine di prima comparsa
// invece di ordinare alfabeticamente.
function raggruppaSostePerGiorni(soste: SostaVeicoloMobile[]): [string, SostaVeicoloMobile[]][] {
  const mappa = new Map<string, SostaVeicoloMobile[]>();
  for (const s of soste) {
    if (!mappa.has(s.giorni)) mappa.set(s.giorni, []);
    mappa.get(s.giorni)!.push(s);
  }
  return [...mappa.entries()];
}

export function RifiutiPage() {
  const [dati, setDati] = useState<SnapshotRifiuti | null>(null);
  const [stato, setStato] = useState<"loading" | "ready" | "error">("loading");
  const [provincia, setProvincia] = useState<ProvinciaSlug>("gorizia");
  const [comuneSlug, setComuneSlug] = useState<string>("");
  const [areaIndice, setAreaIndice] = useState(0);
  const t = useTranslations("rifiuti");
  const tServizi = useTranslations("servizi");
  const tChrome = useTranslations("chrome");
  const locale = useLocale();

  function tipoLabel(tipo: TipoRifiuto, gestore?: string): string {
    const chiave = tipo === "plastic_metals" && gestore === "NET S.p.A." ? "plastic_metals_net" : tipo;
    return t(`tipi.${chiave}`);
  }

  useEffect(() => {
    let attivo = true;
    async function carica() {
      const { data, error } = await supabase
        .from("snapshots")
        .select("data")
        .eq("id", "rifiuti")
        .single();
      if (!attivo) return;
      if (error || !data) {
        setStato("error");
        return;
      }
      const snapshot = data.data as SnapshotRifiuti;
      setDati(snapshot);
      setStato("ready");
    }
    carica();
    const id = setInterval(carica, 15 * 60 * 1000);
    return () => {
      attivo = false;
      clearInterval(id);
    };
  }, []);

  const gruppi = useMemo(() => comuniPerProvincia(dati?.comuni ?? []), [dati]);
  const provinceAttive = useMemo(
    () => (dati ? provinceConDati(dati.comuni) : PROVINCE_RIFIUTI_ATTIVE),
    [dati]
  );
  const comuniProvincia = gruppi.get(provincia) ?? [];

  // Se la provincia selezionata non ha (ancora) comuni nello snapshot,
  // o il comune scelto non appartiene più a quella provincia (es. dopo
  // un cambio di tab), si riallinea sul primo comune disponibile.
  useEffect(() => {
    if (comuniProvincia.length === 0) return;
    if (!comuniProvincia.some((c) => c.slug === comuneSlug)) {
      setComuneSlug(comuniProvincia[0].slug);
      setAreaIndice(0);
    }
  }, [provincia, comuniProvincia, comuneSlug]);

  const comune: ComuneRifiuti | undefined = useMemo(
    () => comuniProvincia.find((c) => c.slug === comuneSlug),
    [comuniProvincia, comuneSlug]
  );

  const areaCorrente = comune?.aree[areaIndice] ?? comune?.aree[0];
  const oggiIso = oggiIsoLocale();
  const prossime = prossimeRaccolte(areaCorrente, oggiIso, 8);

  return (
    <>
      <TopHeader />
      <div className="isobar" />

      <main id="contenuto-principale" className="max-w-[1180px] mx-auto px-5 py-6">
        <Link href="/servizi" className="text-cool-ink text-xs font-mono hover:underline">
          ← {tServizi("titolo")}
        </Link>
        <h1 className="font-cond font-bold text-2xl uppercase tracking-wide mb-1 mt-1">
          {tServizi("sezioni.rifiuti.nome")}
        </h1>
        <p className="text-ink-faint text-xs font-mono mb-4">{t("descrizione")}</p>

        <div className="flex gap-1.5 flex-wrap mb-4">
          {PROVINCE_LIST.map((p) => (
            <button
              key={p.slug}
              onClick={() => setProvincia(p.slug)}
              aria-pressed={provincia === p.slug}
              className={`px-3 py-1.5 rounded text-xs font-cond font-semibold uppercase tracking-wide transition-colors ${
                provincia === p.slug ? "bg-cool text-on-accent" : "border border-line text-ink-dim hover:text-ink"
              }`}
            >
              {p.nome}
            </button>
          ))}
        </div>

        {stato === "loading" && <p className="text-ink-faint text-sm font-mono">{tChrome("caricamento")}</p>}
        {stato === "error" && (
          <p className="text-ink-faint text-sm font-mono">{t("nonDisponibili")}</p>
        )}

        {stato === "ready" && dati && !provinceAttive.includes(provincia) && (
          <p className="text-ink-faint text-sm font-mono">
            {t("inArrivoProvincia", { provincia: PROVINCE[provincia].nome })}
          </p>
        )}

        {stato === "ready" && dati && provinceAttive.includes(provincia) && (
          <>
            <div className="flex items-center gap-2 flex-wrap mb-3">
              <label htmlFor="rifiuti-comune" className="text-ink-faint text-xs font-mono uppercase tracking-wide">
                {t("comuneLabel")}
              </label>
              <select
                id="rifiuti-comune"
                value={comuneSlug}
                onChange={(e) => {
                  setComuneSlug(e.target.value);
                  setAreaIndice(0);
                }}
                className="border border-line rounded px-2 py-1.5 text-sm font-mono bg-panel text-ink"
              >
                {comuniProvincia.map((c) => (
                  <option key={c.slug} value={c.slug}>
                    {c.nome}
                  </option>
                ))}
              </select>
              {comune && (
                <span className="text-ink-faint text-[10px] font-mono">
                  {t("gestoreEtichetta", { gestore: comune.gestore })}
                </span>
              )}
            </div>

            {comune && comune.stale && (
              <p className="text-allerta-arancione-ink text-[10px] font-mono uppercase mb-3">
                {t("datoNonAggiornato")}
              </p>
            )}

            {comune && comune.aree.length > 1 && (
              <div className="flex items-center gap-1.5 flex-wrap mb-4">
                <span className="text-ink-faint text-xs font-mono uppercase tracking-wide mr-1">
                  {t("areaLabel")}
                </span>
                {comune.aree.map((a, i) => (
                  <button
                    key={`${a.area ?? "?"}-${i}`}
                    onClick={() => setAreaIndice(i)}
                    aria-pressed={areaIndice === i}
                    className={`px-3 py-1.5 rounded text-xs font-cond font-semibold uppercase tracking-wide transition-colors ${
                      areaIndice === i ? "bg-cool text-on-accent" : "border border-line text-ink-dim hover:text-ink"
                    }`}
                  >
                    {a.area ? t("areaNumero", { numero: a.area }) : t("nd")}
                  </button>
                ))}
              </div>
            )}

            {comune && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-px bg-line border border-line">
                <Panel
                  title={
                    comune.gestore === "AcegasApsAmga"
                      ? t("calendarioPortaPorta")
                      : comune.raccolta_stradale
                        ? t("raccoltaStradale")
                        : t("prossimeRaccolte")
                  }
                >
                  {comune.gestore === "AcegasApsAmga" ? (
                    <RifiutiTriesteCalendario />
                  ) : comune.raccolta_stradale ? (
                    <div>
                      <p className="text-ink-dim text-xs mb-3">{comune.raccolta_stradale.descrizione}</p>
                      <div className="flex flex-wrap gap-3 mb-4">
                        {comune.raccolta_stradale.materiali.map((m) => (
                          <span key={m.tipo} className="flex items-center gap-1.5 text-sm">
                            <span
                              className="inline-block w-2.5 h-2.5 rounded-full flex-shrink-0"
                              style={{ backgroundColor: COLORE_TIPO[m.tipo] }}
                            />
                            {tipoLabel(m.tipo, comune.gestore)}
                            <span className="text-ink-faint text-xs">({m.colore})</span>
                          </span>
                        ))}
                      </div>
                      <div className="text-xs space-y-1">
                        <div>
                          <span className="text-ink-faint uppercase tracking-wide mr-1.5">{t("estate")}</span>
                          {comune.raccolta_stradale.frequenza_estate}
                        </div>
                        <div>
                          <span className="text-ink-faint uppercase tracking-wide mr-1.5">{t("inverno")}</span>
                          {comune.raccolta_stradale.frequenza_inverno}
                        </div>
                      </div>
                    </div>
                  ) : prossime.length === 0 ? (
                    <p className="text-ink-faint text-sm font-mono">{t("nessunDatoCalendario")}</p>
                  ) : (
                    prossime.map((g, i) => (
                      <div
                        key={g.data}
                        className={`flex items-center gap-3 py-2.5 ${i > 0 ? "border-t border-line" : ""}`}
                      >
                        <div className="font-mono text-ink-dim text-xs w-24 flex-shrink-0 uppercase">
                          {g.data === oggiIso ? t("oggi") : formattaDataLocale(g.data, locale)}
                        </div>
                        <div className="flex items-center gap-3 flex-wrap">
                          {g.tipi.map((tipo) => (
                            <span key={tipo} className="flex items-center gap-1.5 text-sm">
                              <span
                                className="inline-block w-2.5 h-2.5 rounded-full flex-shrink-0"
                                style={{ backgroundColor: COLORE_TIPO[tipo] }}
                              />
                              {tipoLabel(tipo, comune.gestore)}
                            </span>
                          ))}
                        </div>
                      </div>
                    ))
                  )}
                </Panel>

                <Panel
                  title={
                    comune.stazioni_ecologiche && comune.stazioni_ecologiche.length > 0
                      ? t("stazioniEcologiche")
                      : t("centroRaccoltaEVetro")
                  }
                >
                  {comune.stazioni_ecologiche && comune.stazioni_ecologiche.length > 0 ? (
                    <div className="space-y-4">
                      {comune.stazioni_ecologiche.map((s, i) => (
                        <div key={s.id} className={i > 0 ? "border-t border-line pt-3" : ""}>
                          <div className="font-cond font-semibold text-sm uppercase tracking-wide mb-1">
                            {s.nome}
                          </div>
                          {s.indirizzo && (
                            <div className="text-ink text-sm mb-1">
                              {s.indirizzo}
                              {s.comune ? ` — ${s.comune}` : ""}
                            </div>
                          )}
                          {s.orari.length > 0 && (
                            <div className="text-ink-dim text-xs mb-2">
                              {s.orari.map((o, oi) => {
                                const giornoBreve = GIORNI_SETTIMANA_BREVE[o.giorno];
                                return (
                                  <span key={oi} className="mr-2 whitespace-nowrap">
                                    {giornoBreve ? t(`giorniBrevi.${giornoBreve}`) : o.giorno} {o.orarioInizio}–
                                    {o.orarioFine}
                                  </span>
                                );
                              })}
                            </div>
                          )}
                          {s.materiali.length > 0 && (
                            <div className="flex flex-wrap gap-1.5">
                              {s.materiali.map((m) => (
                                <span
                                  key={m}
                                  className="px-2 py-0.5 rounded text-[10px] font-mono bg-panel-alt text-ink-dim"
                                >
                                  {m}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <>
                      {comune.centro_raccolta ? (
                        <div className="mb-4">
                          <div className="font-cond font-semibold text-sm uppercase tracking-wide mb-1">
                            {t("conferimentiIngombranti")}
                          </div>
                          {comune.centro_raccolta.indirizzo && (
                            <div className="text-ink text-sm mb-1">{comune.centro_raccolta.indirizzo}</div>
                          )}
                          {comune.centro_raccolta.apertura && (
                            <div className="text-ink-dim text-xs mb-2">{comune.centro_raccolta.apertura}</div>
                          )}
                          {comune.centro_raccolta.materiali.length > 0 && (
                            <div className="flex flex-wrap gap-1.5">
                              {comune.centro_raccolta.materiali.map((m) => (
                                <span
                                  key={m}
                                  className="px-2 py-0.5 rounded text-[10px] font-mono bg-panel-alt text-ink-dim"
                                >
                                  {m}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                      ) : (
                        <p className="text-ink-faint text-sm font-mono mb-4">{t("infoCentroNonDisponibili")}</p>
                      )}

                      {comune.campane_vetro.length > 0 && (
                        <div>
                          <div className="font-cond font-semibold text-sm uppercase tracking-wide mb-1">
                            {t("campaneDelVetro")}
                          </div>
                          <ul className="text-ink-dim text-xs space-y-1 list-disc list-inside">
                            {comune.campane_vetro.map((c) => (
                              <li key={c}>{c}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </>
                  )}
                </Panel>

                {comune.nota && (
                  <Panel title={t("daSapere")} span={2}>
                    <p className="text-ink-dim text-xs whitespace-pre-line">{comune.nota}</p>
                  </Panel>
                )}

                {comune.veicolo_mobile && (
                  <Panel title={comune.veicolo_mobile.nome} span={2}>
                    <p className="text-ink-dim text-xs mb-3">{comune.veicolo_mobile.descrizione}</p>
                    {comune.veicolo_mobile.materiali.length > 0 && (
                      <div className="flex flex-wrap gap-3 mb-4">
                        {comune.veicolo_mobile.materiali.map((m) => (
                          <span key={m} className="flex items-center gap-1.5 text-sm">
                            <span
                              className="inline-block w-2.5 h-2.5 rounded-full flex-shrink-0"
                              style={{ backgroundColor: COLORE_TIPO[m] }}
                            />
                            {tipoLabel(m, comune.gestore)}
                          </span>
                        ))}
                      </div>
                    )}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {raggruppaSostePerGiorni(comune.veicolo_mobile.soste).map(([giorni, soste]) => (
                        <div key={giorni}>
                          <div className="font-cond font-semibold text-xs uppercase tracking-wide mb-1.5">
                            {giorni}
                          </div>
                          <ul className="text-ink-dim text-xs space-y-1">
                            {soste.map((s, i) => (
                              <li key={i}>
                                {s.luogo} — {s.orario}
                              </li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </Panel>
                )}
              </div>
            )}

            <p className="text-ink-faint text-[10px] font-mono mt-6 border-t border-line pt-3">
              {t("aggiornatoAl", {
                data: new Date(dati.aggiornato_al).toLocaleString(intlLocale(locale)),
              })}
            </p>
          </>
        )}
      </main>

      <Footer />
    </>
  );
}
