"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useLocale, useTranslations } from "next-intl";
import { supabase } from "@/lib/supabase";
import { Panel } from "@/components/Panel";
import { TopHeader } from "@/components/TopHeader";
import { Footer } from "@/components/Footer";
import { intlLocale } from "@/lib/intlLocale";

type Partita = {
  casa: string;
  ospite: string;
  golCasa: number | null;
  golOspite: number | null;
  data: string;
  ora: string;
  campo: string;
  logoCasa: string;
  logoOspite: string;
  inCorso: boolean;
};

type RigaClassifica = {
  posizione: number;
  squadra: string;
  logo: string;
  punti: number;
  giocate: number;
  vittorie: number;
  pareggi: number;
  sconfitte: number;
  golFatti: number;
  golSubiti: number;
};

type CalcioData = {
  campionato: string;
  girone: string;
  stagione?: string;
  giornata_corrente: { number: number; leg: string; startDate: string; endDate: string } | null;
  partite: Partita[];
  classifica: RigaClassifica[];
  aggiornato_al: string;
};

// Deve corrispondere a CALCIO_STAGIONI in scripts/ingest-light.mjs — [0] = corrente/default, [1] = archivio
const STAGIONI = [
  { valore: "2026", anno: "2026/27" },
  { valore: "2025", anno: "2025/26" },
] as const;

function formattaData(iso: string, locale: string): string {
  const d = new Date(iso);
  return d.toLocaleDateString(intlLocale(locale), {
    weekday: "short",
    day: "numeric",
    month: "short",
  });
}

function nomeSquadra(s: string): string {
  return s
    .toLowerCase()
    .split(" ")
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(" ");
}

// Deve corrispondere a COMPETIZIONI_CALCIO in scripts/ingest-light.mjs
const COMPETIZIONI = [
  { slug: "eccellenza-a", label: "Eccellenza" },
  { slug: "promozione-a", label: "Promozione" },
  { slug: "prima-categoria-a", label: "1ª Cat. — Girone A" },
  { slug: "prima-categoria-b", label: "1ª Cat. — Girone B" },
  { slug: "prima-categoria-c", label: "1ª Cat. — Girone C" },
  { slug: "seconda-categoria-gorizia", label: "2ª Cat. Gorizia" },
  { slug: "seconda-categoria-pordenone", label: "2ª Cat. Pordenone" },
  { slug: "seconda-categoria-udine-b", label: "2ª Cat. Udine — B" },
  { slug: "seconda-categoria-udine-c", label: "2ª Cat. Udine — C" },
  { slug: "terza-categoria-d", label: "3ª Cat. — Girone D" },
  { slug: "terza-categoria-a", label: "3ª Cat. — Girone A" },
  { slug: "terza-categoria-b", label: "3ª Cat. — Girone B" },
  { slug: "terza-categoria-c", label: "3ª Cat. — Girone C" },
];

export function CalcioPage() {
  const [dati, setDati] = useState<CalcioData | null>(null);
  const [stato, setStato] = useState<"loading" | "ready" | "error">("loading");
  const [competizione, setCompetizione] = useState(COMPETIZIONI[0].slug);
  const [stagione, setStagione] = useState<(typeof STAGIONI)[number]["valore"]>(STAGIONI[0].valore);
  const t = useTranslations("calcio");
  const tSport = useTranslations("sport");
  const tNav = useTranslations("nav");
  const tChrome = useTranslations("chrome");
  const locale = useLocale();

  useEffect(() => {
    let attivo = true;
    setStato("loading");
    async function carica() {
      const { data, error } = await supabase
        .from("snapshots")
        .select("data")
        .eq("id", `calcio:${competizione}:${stagione}`)
        .single();
      if (!attivo) return;
      if (error || !data) {
        setStato("error");
        return;
      }
      setDati(data.data as CalcioData);
      setStato("ready");
    }
    carica();
    const id = setInterval(carica, 15 * 60 * 1000);
    return () => {
      attivo = false;
      clearInterval(id);
    };
  }, [competizione, stagione]);

  return (
    <>
      <TopHeader />
      <div className="isobar" />

      <main id="contenuto-principale" className="max-w-[1180px] mx-auto px-5 py-6">
        <Link href="/sport" className="text-cool-ink text-xs font-mono hover:underline">
          ← {tNav("sport")}
        </Link>
        <h1 className="font-cond font-bold text-2xl uppercase tracking-wide mb-1 mt-1">
          {stato === "ready" && dati ? `${dati.campionato} — ${dati.girone}` : t("titoloFallback")}
        </h1>
        <p className="text-ink-faint text-xs font-mono mb-4">
          {t("descrizione")}
          {stagione !== STAGIONI[0].valore &&
            t("vistaArchivio", { stagione: STAGIONI.find((s) => s.valore === stagione)?.anno ?? "" })}
        </p>

        <div className="flex gap-1.5 flex-wrap mb-6">
          {COMPETIZIONI.map((c) => (
            <button
              key={c.slug}
              onClick={() => setCompetizione(c.slug)}
              aria-pressed={competizione === c.slug}
              className={`px-3 py-1.5 rounded text-xs font-cond font-semibold uppercase tracking-wide transition-colors ${
                competizione === c.slug ? "bg-cool text-on-accent" : "border border-line text-ink-dim hover:text-ink"
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>

        {stato === "loading" && <p className="text-ink-faint text-sm font-mono">{tChrome("caricamento")}</p>}
        {stato === "error" && (
          <p className="text-ink-faint text-sm font-mono">{tChrome("datiNonDisponibili")}</p>
        )}

        {stato === "ready" && dati && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-px bg-line border border-line">
            <Panel title={`${dati.campionato} — ${tSport("calendario")}`}>
              {dati.giornata_corrente && (
                <div className="font-cond font-semibold text-xs uppercase tracking-wide text-ink-faint mb-3">
                  {t("giornata", { numero: dati.giornata_corrente.number })} ·{" "}
                  {dati.giornata_corrente.leg === "first" ? t("andata") : t("ritorno")}
                </div>
              )}
              {dati.partite.length === 0 ? (
                <p className="text-ink-faint text-sm font-mono">{tSport("nessunaPartita")}</p>
              ) : (
                dati.partite.map((p, i) => (
                  <div key={i} className={`py-3 ${i > 0 ? "border-t border-line" : ""}`}>
                    <div className="font-mono text-[10px] text-ink-faint mb-1.5 uppercase">
                      {formattaData(p.data, locale)} · {p.ora.slice(0, 5)} · {p.campo}
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="flex-1">{nomeSquadra(p.casa)}</span>
                      <span className="font-cond font-bold text-lg px-3">
                        {p.golCasa ?? "–"} : {p.golOspite ?? "–"}
                      </span>
                      <span className="flex-1 text-right">{nomeSquadra(p.ospite)}</span>
                    </div>
                  </div>
                ))
              )}
            </Panel>

            <Panel title={`${dati.campionato} — ${tSport("classifica")}`}>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-line font-mono text-[10px] text-ink-faint uppercase">
                      <th className="text-left py-2 pr-2">#</th>
                      <th className="text-left py-2">{tSport("colSquadra")}</th>
                      <th className="text-right py-2 px-2">{tSport("colPt")}</th>
                      <th className="text-right py-2 px-2">{tSport("colG")}</th>
                      <th className="text-right py-2 px-2">{tSport("colV")}</th>
                      <th className="text-right py-2 px-2">{tSport("colN")}</th>
                      <th className="text-right py-2 px-2">{tSport("colP")}</th>
                      <th className="text-right py-2 pl-2">{tSport("colDR")}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {dati.classifica.map((r) => (
                      <tr key={r.posizione} className="border-b border-line">
                        <td className="py-2 pr-2 font-mono text-ink-faint">{r.posizione}</td>
                        <td className="py-2">{nomeSquadra(r.squadra)}</td>
                        <td className="py-2 px-2 text-right font-mono font-bold">{r.punti}</td>
                        <td className="py-2 px-2 text-right font-mono text-ink-dim">{r.giocate}</td>
                        <td className="py-2 px-2 text-right font-mono text-ink-dim">{r.vittorie}</td>
                        <td className="py-2 px-2 text-right font-mono text-ink-dim">{r.pareggi}</td>
                        <td className="py-2 px-2 text-right font-mono text-ink-dim">{r.sconfitte}</td>
                        <td className="py-2 pl-2 text-right font-mono text-ink-dim">
                          {r.golFatti - r.golSubiti > 0 ? "+" : ""}
                          {r.golFatti - r.golSubiti}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Panel>
          </div>
        )}

        <div className="mt-8 pt-4 border-t border-line flex items-center gap-1.5 flex-wrap">
          <span className="text-ink-faint text-xs font-mono uppercase tracking-wide mr-1">{t("stagioneLabel")}</span>
          {STAGIONI.map((s) => (
            <button
              key={s.valore}
              onClick={() => setStagione(s.valore)}
              aria-pressed={stagione === s.valore}
              className={`px-3 py-1.5 rounded text-xs font-cond font-semibold uppercase tracking-wide transition-colors ${
                stagione === s.valore ? "bg-cool text-on-accent" : "border border-line text-ink-dim hover:text-ink"
              }`}
            >
              {s.anno}
              {s.valore !== STAGIONI[0].valore ? ` (${t("archivio")})` : ""}
            </button>
          ))}
        </div>
      </main>

      <Footer />
    </>
  );
}
